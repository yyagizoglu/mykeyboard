package com.example.mykeyboard

import android.Manifest
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.Typeface
import android.graphics.drawable.Drawable
import android.util.TypedValue
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.ContextThemeWrapper
import androidx.core.view.WindowCompat
import android.inputmethodservice.InputMethodService
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.text.InputType
import android.util.Size
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors
import org.json.JSONObject

/** Drawable'ı XML'den her seferinde şişirmek yerine ConstantState'ten kopyalar (tuş yaratma ve shift ikonu hızlanır). */
private object DrawCache {
    private val m = HashMap<Int, Drawable.ConstantState>()
    fun get(ctx: Context, res: Int): Drawable? {
        val cs = m[res]
        if (cs != null) return cs.newDrawable(ctx.resources, ctx.theme)
        val d = ctx.getDrawable(res) ?: return null
        d.constantState?.let { m[res] = it }
        return d
    }
    fun clear() = m.clear()
}

private class KeyView(ctx: Context) : TextView(ctx) {
    var icon: Drawable? = null
    var hf = 1f
    var tf = 1f
    var tag2 = -1f
    fun setIcon(res: Int, color: Int) {
        icon = DrawCache.get(context, res)?.mutate()?.also { it.setTint(color) }
        invalidate()
    }
    private val sz = (24 * resources.displayMetrics.density).toInt()
    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        icon?.let { d ->
            val l = (width - sz) / 2; val t = (height - sz) / 2
            d.setBounds(l, t, l + sz, t + sz); d.draw(c)
        }
    }
}

/** Menü düğmesi: 2x2 kare, içlerinde tek tek m e n ü harfleri. */
private class MenuGridDrawable(private val px: Int, private val fg: Int) : Drawable() {
    private val letters = arrayOf("m", "e", "n", "ü")
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fg; alpha = 45 }
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fg; style = Paint.Style.STROKE; strokeWidth = px / 20f }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = fg; typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER }
    private val r = RectF()
    private val tb = Rect()
    override fun getIntrinsicWidth() = px
    override fun getIntrinsicHeight() = px
    override fun draw(c: Canvas) {
        val b = bounds
        val gap = b.width() * 0.09f
        val cell = (b.width() - gap) / 2f
        txt.textSize = cell * 0.78f
        txt.getTextBounds("n", 0, 1, tb)
        val rad = cell * 0.22f
        for (i in 0..3) {
            val l = b.left + (i % 2) * (cell + gap)
            val t = b.top + (i / 2) * (cell + gap)
            r.set(l, t, l + cell, t + cell)
            c.drawRoundRect(r, rad, rad, fill)
            c.drawRoundRect(r, rad, rad, stroke)
            c.drawText(letters[i], r.centerX(), r.centerY() + tb.height() / 2f, txt)
        }
    }
    override fun setAlpha(a: Int) {}
    override fun setColorFilter(f: ColorFilter?) {}
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}

class ImeService : InputMethodService() {

    companion object {
        // Ataç ile seçilen dosya: seçici ekranı kapanıp klavye tekrar bağlanınca gönderilir
        @Volatile var pending: Pair<Uri, String>? = null
        // Sesle yazma sonucu (VoiceActivity) – aynı şekilde klavye bağlanınca yazılır
        @Volatile var pendingText: String? = null
        @Volatile var pendingAt = 0L
        private const val PENDING_TTL_MS = 120_000L   // eski/bayat sonuç yanlış alana gitmesin
    }

    private enum class Mode { LETTERS, SYM1, SYM2, NUM, EMOJI }
    private class K(
        val label: String, val w: Float = 1f, val repeat: Boolean = false,
        val letter: Boolean = false, val isShift: Boolean = false, val isEnter: Boolean = false,
        val kind: Int = 0,          // 0 harf, 1 işlev (dikdörtgen), 2 işlev (hap), 3 enter
        val icon: Int = 0, val small: Boolean = false, val hf: Float = 1f, val spacer: Boolean = false,
        val act: () -> Unit
    )
    private class Shot(val uri: Uri, val mime: String, val bmp: Bitmap?)

    private val tr = Locale("tr", "TR")
    private val handler = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()
    private val net = Executors.newSingleThreadExecutor()
    private lateinit var store: ClipStore
    private lateinit var cm: ClipboardManager
    private lateinit var keys: LinearLayout
    private lateinit var thumbs: LinearLayout
    private lateinit var thumbsWrap: View
    private lateinit var attachCats: View
    private var deliverTries = 0
    private var thumbGen = 0
    private lateinit var kbRoot: View
    private lateinit var toolbar: View
    private lateinit var btnTr: ImageButton
    private lateinit var btnCl: ImageButton
    private lateinit var wrapper: FrameLayout
    private lateinit var tctx: Context
    private lateinit var btnTheme: ImageButton
    private var dark = true
    private lateinit var widthLabel: TextView
    private lateinit var hapticBtn: TextView
    private lateinit var alignBtns: List<TextView>
    private lateinit var touchHelper: ItemTouchHelper
    private lateinit var clipPanel: View
    private lateinit var sizePanel: View
    private lateinit var translatePanel: View
    private lateinit var editPanel: View
    private lateinit var tEdit: TextView
    private lateinit var btnUndo: TextView
    private lateinit var clipHint: TextView
    private val undoStack = ArrayDeque<Pair<String, Int>>()   // silinen sabitler (metin, sıra)
    private var editing = false
    private var editCur = 0
    private var editStart = 0
    private var editPre = 0
    private var editItem: ClipItem? = null
    private var enterChk = false
    private var appliedSig = ""
    private lateinit var sizeLabel: TextView
    private lateinit var tInput: TextView
    private lateinit var tOutput: TextView
    private lateinit var chipFrom: TextView
    private lateinit var chipTo: TextView
    private lateinit var adapter: ClipAdapter

    private var mode = Mode.LETTERS
    private var shift = false
    private var keyH = 38
    private var kbPct = 100
    private var kbAlign = 1
    private var haptic = false
    private var repSpeed = 5      // 1..10 silme/tekrar hızı
    private val altDelayMs = 500   // ş ı ğ ö vb. menüsü sadece 0,5 sn basılı tutunca açılır (Tepkime süresi ayarından bağımsız)
    private var holdMs = 300      // basılı tutunca tekrar/alternatif başlama süresi (ms)
    private var caps = false
    private var lastShiftTap = 0L
    private val modeViews = HashMap<Mode, LinearLayout>()
    private val keyViews = ArrayList<KeyView>()
    private val letterViews = ArrayList<TextView>()
    private val enterViews = ArrayList<KeyView>()
    private var shiftView: KeyView? = null

    // çeviri
    private var translating = false
    private var fromTr = true
    private val tbuf = StringBuilder()
    private var tOut = ""
    private var reqId = 0
    private val trRunnable: Runnable = Runnable { doTranslate() }

    private val thumbCache = HashMap<String, Bitmap>()
    @Volatile private var lastThumbKey = ""

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener { onClipChanged() }

    private fun onClipChanged() {
        try {
            val clip = cm.primaryClip ?: return
            val desc = clip.description
            if (!(desc.hasMimeType("text/plain") || desc.hasMimeType("text/html"))) return
            // Şifre yöneticisi gibi "hassas" işaretli kopyaları geçmişe kaydetme
            if (desc.extras?.getBoolean("android.content.extra.IS_SENSITIVE", false) == true) return
            if (clip.itemCount == 0) return
            val t = clip.getItemAt(0).coerceToText(this)?.toString()
            // Çok büyük metinler her kopyada diske yazılırken klavyeyi yavaşlatır
            if (t.isNullOrBlank() || t.length > 20000) return
            store.addHistory(t)
            if (::clipPanel.isInitialized && clipPanel.visibility == View.VISIBLE) reloadClips()
        } catch (_: Exception) {}   // SecurityException vb. klavyeyi düşürmesin
    }

    override fun onCreate() {
        super.onCreate()
        store = ClipStore(this)
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(clipListener)
        val sp = getSharedPreferences("ui", Context.MODE_PRIVATE)
        keyH = sp.getInt("keyH2", 38)
        dark = sp.getBoolean("dark", true)
        kbPct = sp.getInt("kbPct", 100)
        kbAlign = sp.getInt("kbAlign", 1)
        haptic = sp.getBoolean("haptic2", false)
    }

    override fun onDestroy() {
        cm.removePrimaryClipChangedListener(clipListener)
        dismissAlts(); stopRepeat()
        handler.removeCallbacksAndMessages(null)
        bg.shutdownNow(); net.shutdownNow()
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode() = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun dpf(v: Float) = (v * resources.displayMetrics.density + 0.5f).toInt()
    private fun attrColor(a: Int): Int {
        val tv = TypedValue(); tctx.theme.resolveAttribute(a, tv, true); return tv.data
    }

    private var navSig = ""
    // Alt şerit (aşağı ok + dünya simgesi) klavye rengiyle aynı olsun
    private fun applyNavBar() {
        if (!::tctx.isInitialized) return
        val w = window?.window ?: return
        val c = attrColor(R.attr.kbBg)
        val sig = "$c/$dark"
        if (sig == navSig) return   // aynı değeri tekrar tekrar pencereye yazıp yeniden düzen tetikleme
        navSig = sig
        w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS)
        w.navigationBarColor = c
        if (Build.VERSION.SDK_INT >= 28) w.navigationBarDividerColor = c
        WindowCompat.getInsetsController(w, w.decorView).isAppearanceLightNavigationBars = !dark
    }

    override fun onWindowShown() { super.onWindowShown(); applyNavBar() }
    private fun prefs() = getSharedPreferences("ui", Context.MODE_PRIVATE)

    override fun onCreateInputView(): View {
        // Görünüm yeniden kuruluyorsa (tema değişimi) eski menü/tekrar/zamanlayıcılar kalmasın
        dismissAlts(); stopRepeat(); handler.removeCallbacks(holdRunnable)
        modeViews.clear(); keyViews.clear(); letterViews.clear(); enterViews.clear(); shiftView = null
        DrawCache.clear(); hlState.clear(); shownUpper = false; shownIcon = -1; navSig = ""
        handler.removeCallbacks(prebuildRunnable)
        translating = false; editing = false; enterChk = false; appliedSig = ""
        tctx = ContextThemeWrapper(this, if (dark) R.style.KbDark else R.style.KbLight)
        lastThumbKey = ""
        val root = LayoutInflater.from(tctx).inflate(R.layout.keyboard, null)
        kbRoot = root
        wrapper = object : FrameLayout(tctx) {
            override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
                watchHold(ev)
                return super.dispatchTouchEvent(ev)
            }
        }.apply { setBackgroundColor(attrColor(R.attr.kbBg)) }
        wrapper.addView(root, FrameLayout.LayoutParams(-1, -2))
        keys = root.findViewById(R.id.keys)
        thumbs = root.findViewById(R.id.thumbs)
        thumbsWrap = root.findViewById(R.id.thumbsWrap)
        attachCats = root.findViewById(R.id.attachCats)
        root.findViewById<View>(R.id.btnAttach).setOnClickListener { showCats(attachCats.visibility != View.VISIBLE) }
        root.findViewById<View>(R.id.btnMic).setOnClickListener { showCats(false); openVoice() }
        root.findViewById<View>(R.id.catPhoto).setOnClickListener { openPicker(0) }
        root.findViewById<View>(R.id.catVideo).setOnClickListener { openPicker(1) }
        root.findViewById<View>(R.id.catDoc).setOnClickListener { openPicker(2) }
        root.findViewById<ImageButton>(R.id.btnMenu).setImageDrawable(MenuGridDrawable(dp(30), attrColor(R.attr.kbText)))
        toolbar = root.findViewById(R.id.toolbar)
        btnTr = root.findViewById(R.id.btnTranslate)
        btnCl = root.findViewById(R.id.btnClip)
        clipPanel = root.findViewById(R.id.clipPanel)
        sizePanel = root.findViewById(R.id.sizePanel)
        translatePanel = root.findViewById(R.id.translatePanel)
        editPanel = root.findViewById(R.id.editPanel)
        tEdit = root.findViewById(R.id.tEdit)
        tEdit.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_UP) editTap(e.x, e.y)
            true
        }
        btnUndo = root.findViewById(R.id.btnUndo)
        clipHint = root.findViewById(R.id.clipHint)
        btnUndo.setOnClickListener {
            val u = undoStack.removeLastOrNull()
            if (u != null) { store.restorePinned(u.first, u.second); reloadClips() }
        }
        root.findViewById<View>(R.id.btnEBack).setOnClickListener { editItem = null; showPanel(1) }
        root.findViewById<View>(R.id.btnESave).setOnClickListener { saveEdit() }
        sizeLabel = root.findViewById(R.id.sizeLabel)
        widthLabel = root.findViewById(R.id.widthLabel)
        hapticBtn = root.findViewById(R.id.btnHaptic)
        tInput = root.findViewById(R.id.tInput)
        tOutput = root.findViewById(R.id.tOutput)
        chipFrom = root.findViewById(R.id.chipFrom)
        chipTo = root.findViewById(R.id.chipTo)

        btnTheme = root.findViewById(R.id.btnTheme)
        btnTheme.setImageResource(if (dark) R.drawable.ic_sun else R.drawable.ic_moon)
        btnTheme.setOnClickListener {
            dark = !dark
            prefs().edit().putBoolean("dark", dark).apply()
            handler.post { setInputView(onCreateInputView()); loadThumbs() }
        }
        root.findViewById<View>(R.id.btnMenu).setOnClickListener { setTools(toolbar.visibility != View.VISIBLE) }
        btnTr.setOnClickListener { showPanel(if (translating) 0 else 3) }
        btnCl.setOnClickListener { showPanel(if (clipPanel.visibility == View.VISIBLE) 0 else 1) }
        setTools(prefs().getBoolean("tools", false), false)
        root.findViewById<View>(R.id.btnSize).setOnClickListener { showPanel(if (sizePanel.visibility == View.VISIBLE) 0 else 2) }
        root.findViewById<View>(R.id.btnBack).setOnClickListener { showPanel(0) }
        root.findViewById<View>(R.id.btnSizeOk).setOnClickListener { showPanel(0) }
        root.findViewById<View>(R.id.btnTBack).setOnClickListener { showPanel(0) }
        root.findViewById<View>(R.id.btnSwap).setOnClickListener { swapLang() }
        tOutput.setOnClickListener {
            if (tOut.isNotBlank()) { currentInputConnection?.commitText(tOut, 1); showPanel(0) }
        }

        // Yükseklik (canlı önizleme)
        val bar = root.findViewById<SeekBar>(R.id.sizeBar)
        bar.progress = (keyH - 30).coerceIn(0, 44)
        sizeLabel.text = "Yükseklik: $keyH"
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                keyH = 30 + p
                sizeLabel.text = "Yükseklik: $keyH"
                appliedSig = ""
                applyKeySize()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { prefs().edit().putInt("keyH2", keyH).apply() }
        })

        // Genişlik (bırakınca uygulanır; çubuk kendi içinde olduğu için canlı değişmez)
        val wbar = root.findViewById<SeekBar>(R.id.widthBar)
        wbar.progress = (kbPct - 60).coerceIn(0, 40)
        widthLabel.text = "Genişlik: %$kbPct"
        wbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                widthLabel.text = "Genişlik: %" + (60 + p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                kbPct = 60 + (s?.progress ?: 40)
                prefs().edit().putInt("kbPct", kbPct).apply()
                appliedSig = ""
                applyWidth()
            }
        })

        // Hız (tekrar hızı) ve Tepkime süresi (basılı tutma gecikmesi)
        repSpeed = prefs().getInt("repSpeed2", 5).coerceIn(1, 10)
        holdMs = prefs().getInt("holdMs2", 300).coerceIn(150, 600)
        val speedBar = root.findViewById<SeekBar>(R.id.speedBar)
        val speedLabel = root.findViewById<TextView>(R.id.speedLabel)
        speedBar.progress = repSpeed - 1
        speedLabel.text = "Hız: $repSpeed"
        speedBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                repSpeed = p + 1
                speedLabel.text = "Hız: $repSpeed"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { prefs().edit().putInt("repSpeed2", repSpeed).apply() }
        })
        val holdBar = root.findViewById<SeekBar>(R.id.holdBar)
        val holdLabel = root.findViewById<TextView>(R.id.holdLabel)
        holdBar.progress = ((holdMs - 150) / 10).coerceIn(0, 45)
        holdLabel.text = "Tepkime süresi: $holdMs ms"
        holdBar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                holdMs = 150 + p * 10
                holdLabel.text = "Tepkime süresi: $holdMs ms"
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { prefs().edit().putInt("holdMs2", holdMs).apply() }
        })

        alignBtns = listOf(
            root.findViewById<TextView>(R.id.btnAlignL),
            root.findViewById<TextView>(R.id.btnAlignC),
            root.findViewById<TextView>(R.id.btnAlignR)
        )
        alignBtns.forEachIndexed { i, b ->
            b.setOnClickListener {
                kbAlign = i
                prefs().edit().putInt("kbAlign", i).apply()
                updateAlignChips(); appliedSig = ""; applyWidth()
            }
        }
        updateAlignChips()
        updateHapticBtn()
        hapticBtn.setOnClickListener {
            haptic = !haptic
            prefs().edit().putBoolean("haptic2", haptic).apply()
            updateHapticBtn()
        }

        adapter = ClipAdapter(
            onInsert = { currentInputConnection?.commitText(it.text, 1) },
            onPin = { if (it.pinned) store.unpin(it.text) else store.pin(it.text); reloadClips() },
            onDelete = {
                if (it.pinned) {
                    undoStack.addLast(Pair(it.text, store.pinned().indexOf(it.text).coerceAtLeast(0)))
                    while (undoStack.size > 10) undoStack.removeFirst()
                }
                store.delete(it.text, it.pinned); reloadClips()
            },
            onEdit = { startEdit(it) },
            onDrag = { touchHelper.startDrag(it) }
        )
        val rv = root.findViewById<RecyclerView>(R.id.clipList)
        rv.layoutManager = GridLayoutManager(tctx, 2).apply {
            spanSizeLookup = object : GridLayoutManager.SpanSizeLookup() {
                override fun getSpanSize(position: Int): Int {
                    val ci = adapter.items.getOrNull(position)
                    return if (ci != null && ci.pinned && !ci.header) 1 else 2
                }
            }
        }
        rv.adapter = adapter
        // Sol baştaki ≡ tutamacından sürükle: sabitler kendi aralarında, diğerleri kendi aralarında sıralanır
        touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN or ItemTouchHelper.START or ItemTouchHelper.END, 0) {
            override fun isLongPressDragEnabled() = false
            override fun onMove(r: RecyclerView, v: RecyclerView.ViewHolder, t: RecyclerView.ViewHolder): Boolean {
                val a = v.bindingAdapterPosition; val b = t.bindingAdapterPosition
                val ia = adapter.items.getOrNull(a); val ib = adapter.items.getOrNull(b)
                if (ia == null || ib == null || ia.header || ib.header || ia.pinned != ib.pinned) return false
                adapter.move(a, b); return true
            }
            override fun onSwiped(v: RecyclerView.ViewHolder, d: Int) {}
            override fun clearView(r: RecyclerView, v: RecyclerView.ViewHolder) {
                super.clearView(r, v)
                store.savePinned(adapter.items.filter { it.pinned && !it.header }.map { it.text })
                store.saveHistory(adapter.items.filter { !it.pinned && !it.header }.map { it.text })
            }
        })
        touchHelper.attachToRecyclerView(rv)

        go(Mode.LETTERS)
        applyWidth()
        updateShift()
        // Diğer tuş sayfaları: yazarken değil, parmak 1,5 sn boşta kalınca birer birer hazırlanır (takılma olmasın)
        schedulePrebuild(1500)
        handler.post { applyNavBar() }
        return wrapper
    }

    private val prebuildRunnable: Runnable = Runnable {
        if (!::keys.isInitialized) return@Runnable
        val next = Mode.values().firstOrNull { !modeViews.containsKey(it) } ?: return@Runnable
        ensureMode(next)
        schedulePrebuild(500)
    }
    private fun schedulePrebuild(ms: Long) {
        handler.removeCallbacks(prebuildRunnable)
        if (::keys.isInitialized && modeViews.size < Mode.values().size) handler.postDelayed(prebuildRunnable, ms)
    }

    // ---------- Klavyede herhangi bir yerde 2.5 sn basılı tut -> boyutlandırma ----------
    private var typedFlag = false
    private var holdX = 0f
    private var holdY = 0f
    private val holdRunnable: Runnable = Runnable {
        if (!::sizePanel.isInitialized || sizePanel.visibility == View.VISIBLE) return@Runnable
        if (repeater.action != null) return@Runnable // silme tuşu basılı tutuluyorsa karışma
        if (typedFlag) { back(); typedFlag = false } // basılı tutarken yazılan harfi geri al
        stopRepeat()
        if (haptic) wrapper.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
        showPanel(2)
    }

    // Seçiciden dönünce: sola kaydır -> Fotoğraf/Video/Belge ekranına geri dön
    private var returnToCatsAt = 0L
    private fun watchHold(ev: MotionEvent) {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                typedFlag = false
                schedulePrebuild(1500)   // yazarken ağır iş yapma; boşta kalınca devam
                holdX = ev.rawX; holdY = ev.rawY
                handler.removeCallbacks(holdRunnable)
                handler.postDelayed(holdRunnable, 2500)
            }
            MotionEvent.ACTION_MOVE -> {
                val dx = ev.rawX - holdX; val dy = ev.rawY - holdY
                if (dx * dx + dy * dy > dp(30) * dp(30)) handler.removeCallbacks(holdRunnable)
            }
            MotionEvent.ACTION_UP -> {
                handler.removeCallbacks(holdRunnable)
                val dx = ev.rawX - holdX; val dy = ev.rawY - holdY
                if (returnToCatsAt != 0L && ev.eventTime - ev.downTime < 500 &&
                    dx < -dp(70) && Math.abs(dy) < dp(50) &&
                    SystemClock.elapsedRealtime() - returnToCatsAt < 180_000L) {
                    returnToCatsAt = 0L
                    showCats(true)
                }
            }
            MotionEvent.ACTION_POINTER_DOWN, MotionEvent.ACTION_CANCEL ->
                handler.removeCallbacks(holdRunnable)
        }
    }

    // ---------- Harfe basılı tut: ç ğ ı ö ş ü vb. seç (kaydırarak) ----------
    private val altMap = mapOf(
        'a' to listOf("à", "á", "â", "ä", "ã", "å", "ā"),
        'c' to listOf("ç", "ć", "č"),
        'e' to listOf("é", "è", "ê", "ë", "ē"),
        'g' to listOf("ğ"),
        'i' to listOf("ı", "İ", "í", "ì", "î", "ï"),
        'n' to listOf("ñ"),
        'o' to listOf("ö", "ó", "ò", "ô", "õ", "ø", "œ"),
        's' to listOf("ş", "ß", "ś", "š"),
        'u' to listOf("ü", "ú", "ù", "û", "ū"),
        'y' to listOf("ý", "ÿ"),
        'z' to listOf("ž", "ź", "ż")
    )
    private var lastTypedUpper = false
    private var typedSeq = 0
    private var altSeq = 0
    private var altPopup: PopupWindow? = null
    private var altKeyView: View? = null
    private var altKeyAlts: List<String> = emptyList()
    private var altKeyUp = false
    private val altRunnable: Runnable = Runnable {
        val v = altKeyView
        if (typedSeq == altSeq && v != null && v.isPressed) showAlts(v, altKeyAlts, altKeyUp)
    }
    private var altCells: List<TextView> = emptyList()
    private var altVals: List<String> = emptyList()
    private var altSel = -1
    private var altX = 0
    private var altPad = 0
    private var altCellW = 0
    private var altKeyTop = 0
    private var altKeyCx = 0
    private var altKeyW = 0
    private var altDownX = 0f
    private var altDownY = 0f
    private var cText = 0
    private var cAccent = 0
    private var cAccentIcon = 0
    private var selBg: android.graphics.drawable.GradientDrawable? = null

    private fun upperAlt(a: String) = when (a) { "ß" -> "ẞ"; else -> a.uppercase(tr) }

    private fun commitRaw(t: String) {
        if (editing) editInsert(t)
        else if (translating) { tbuf.append(t); refreshTranslate() } else currentInputConnection?.commitText(t, 1)
    }

    private fun showAlts(v: View, alts: List<String>, up: Boolean) {
        dismissAlts()
        if (!v.isAttachedToWindow || !::wrapper.isInitialized || !wrapper.isAttachedToWindow) return
        handler.removeCallbacks(holdRunnable) // menü açıldıysa 2.5 sn boyutlandırma devreye girmesin
        val vals = alts.map { if (up) upperAlt(it) else it }
        cText = attrColor(R.attr.kbText); cAccent = attrColor(R.attr.accent); cAccentIcon = attrColor(R.attr.accentIcon)
        selBg = android.graphics.drawable.GradientDrawable().apply { setColor(cAccent); cornerRadius = dp(8).toFloat() }
        val cw = dp(42); val ch = dp(50); val pad = dp(5)
        val row = LinearLayout(tctx).apply {
            orientation = LinearLayout.HORIZONTAL
            setPadding(pad, pad, pad, pad)
            background = android.graphics.drawable.GradientDrawable().apply {
                setColor(attrColor(R.attr.fnColor)); cornerRadius = dp(12).toFloat()
            }
        }
        val cells = vals.map { t ->
            TextView(tctx).apply {
                text = t; gravity = Gravity.CENTER; textSize = 22f
                setTextColor(attrColor(R.attr.kbText))
                row.addView(this, LinearLayout.LayoutParams(cw, ch))
            }
        }
        row.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        val w = row.measuredWidth; val h = row.measuredHeight
        val loc = IntArray(2); v.getLocationOnScreen(loc)
        val sw = resources.displayMetrics.widthPixels
        val x = (loc[0] + v.width / 2 - w / 2).coerceIn(dp(4), maxOf(dp(4), sw - w - dp(4)))
        val y = maxOf(dp(2), loc[1] - h - dp(6))
        // showAtLocation koordinatları IME penceresine göre; ekran koordinatını pencereye çevir
        val wl = IntArray(2); wrapper.getLocationOnScreen(wl)
        val wi = IntArray(2); wrapper.getLocationInWindow(wi)
        val ox = wl[0] - wi[0]; val oy = wl[1] - wi[1]
        val pw = PopupWindow(row, w, h).apply {
            isTouchable = false; isFocusable = false; isClippingEnabled = false
            elevation = dp(8).toFloat()
            inputMethodMode = PopupWindow.INPUT_METHOD_NOT_NEEDED
        }
        try { pw.showAtLocation(wrapper, Gravity.NO_GRAVITY, x - ox, y - oy) } catch (_: Exception) { return }
        altPopup = pw; altCells = cells; altVals = vals; altSel = -1
        altX = x; altPad = pad; altCellW = cw
        altKeyTop = loc[1]; altKeyCx = loc[0] + v.width / 2; altKeyW = v.width
        if (haptic) v.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
    }

    private fun updateAltSel(rx: Float, ry: Float) {
        if (altPopup == null) return
        val active = ry < altKeyTop || Math.abs(rx - altKeyCx) > altKeyW * 0.6f
        val idx = if (active) ((rx - altX - altPad) / altCellW).toInt().coerceIn(0, altCells.size - 1) else -1
        if (idx == altSel) return
        altSel = idx
        altCells.forEachIndexed { i, c ->
            val on = i == idx
            c.background = if (on) selBg else null
            c.setTextColor(if (on) cAccentIcon else cText)
        }
    }

    private fun cancelAltPending() { handler.removeCallbacks(altRunnable) }

    private fun dismissAlts() {
        cancelAltPending()
        try { altPopup?.dismiss() } catch (_: Exception) {}
        altPopup = null; altSel = -1
    }

    private fun finishAlts() {
        cancelAltPending()
        if (altPopup != null && altSel >= 0 && typedSeq == altSeq) {
            val pick = altVals[altSel]
            back()          // basış anında yazılan düz harfi geri al
            commitRaw(pick)
        }
        dismissAlts()
    }

    // Ataç: küçük resimler yerine Fotoğraf / Video / Belge kategorileri
    private fun showCats(on: Boolean) {
        if (!::attachCats.isInitialized) return
        if (on) returnToCatsAt = 0L
        attachCats.visibility = if (on) View.VISIBLE else View.GONE
        thumbs.visibility = if (on) View.GONE else View.VISIBLE
    }

    private fun setTools(on: Boolean, persist: Boolean = true) {
        thumbsWrap.visibility = if (on) View.GONE else View.VISIBLE
        toolbar.visibility = if (on) View.VISIBLE else View.GONE
        if (persist) prefs().edit().putBoolean("tools", on).apply()
    }

    private val hlState = HashMap<View, Boolean>()
    private fun hl(v: ImageButton, on: Boolean) {
        if (hlState[v] == on) return
        hlState[v] = on
        v.setBackgroundResource(if (on) R.drawable.pill_sel else R.drawable.icon_btn)
        if (on) v.setColorFilter(0xFF0B2A5B.toInt()) else v.clearColorFilter()
    }

    private fun updateAlignChips() {
        alignBtns.forEachIndexed { i, b ->
            b.setBackgroundResource(if (i == kbAlign) R.drawable.chip_bg else R.drawable.key_bg)
            b.setTextColor(if (i == kbAlign) 0xFFFFFFFF.toInt() else attrColor(R.attr.kbText))
        }
    }

    private fun updateHapticBtn() { hapticBtn.text = if (haptic) "Titreşim: Açık" else "Titreşim: Kapalı" }

    private fun kbWidthPx(): Int {
        val sw = resources.displayMetrics.widthPixels
        return if (kbPct >= 100) sw else sw * kbPct / 100
    }

    private fun applyWidth() {
        if (!::kbRoot.isInitialized) return
        val h = when (kbAlign) { 0 -> Gravity.START; 2 -> Gravity.END; else -> Gravity.CENTER_HORIZONTAL }
        val g = h or Gravity.TOP
        val sig = "$kbPct/$kbAlign/$keyH/${kbWidthPx()}"
        if (sig == appliedSig) return
        appliedSig = sig
        kbRoot.layoutParams = FrameLayout.LayoutParams(if (kbPct >= 100) -1 else kbWidthPx(), -2, g)
        applyKeySize()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        hasSel = info != null && info.initialSelStart != info.initialSelEnd
        if (!::keys.isInitialized) return
        if (!restarting) { showPanel(0); showCats(false) } // aynı alanda tekrar açılınca panel/ayar sıfırlanmasın
        applyWidth()
        applyNavBar()
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) go(Mode.NUM)
        else if (mode == Mode.NUM) go(Mode.LETTERS)
        schedulePrebuild(1500)
        deliverPending()                       // bekleyen ek/ses önce (hafif iş)
        handler.removeCallbacks(thumbRunnable)
        handler.postDelayed(thumbRunnable, 120) // klavye önce çizilsin, önizlemeler sonra yüklensin
    }

    // ---------- Tuşlar ----------
    private fun typeText(s: String, letter: Boolean = false) {
        val loc = Locale.ENGLISH
        val up = shift && letter
        val out = if (up) s.uppercase(loc) else s
        typedFlag = true
        lastTypedUpper = up
        typedSeq++
        if (editing) editInsert(out)
        else if (translating) { tbuf.append(out); refreshTranslate() }
        else currentInputConnection?.commitText(out, 1)
        if (up && !caps) { shift = false; updateShift() }
    }

    private fun back() {
        if (editing) {
            if (editCur > 0) {
                val prev = tbuf.offsetByCodePoints(editCur, -1)
                tbuf.delete(prev, editCur); editCur = prev
                renderEdit()
            }
            return
        }
        if (translating) {
            if (tbuf.isNotEmpty()) {
                tbuf.setLength(tbuf.length - Character.charCount(tbuf.codePointBefore(tbuf.length)))
                refreshTranslate()
            }
            return
        }
        val ic = currentInputConnection ?: return
        lastDelAt = SystemClock.uptimeMillis()
        if (!hasSel) {
            if (!ic.deleteSurroundingTextInCodePoints(1, 0)) sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        } else { ic.commitText("", 1); hasSel = false }
    }

    private fun enter() {
        if (editing) { saveEdit(); return }
        if (translating) {
            if (tOut.isNotBlank()) currentInputConnection?.commitText(tOut, 1)
            showPanel(0)
        } else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
    }

    // Sadece gerçekten değişen kısmı güncelle: her büyük harften sonra 26 tuşun metnini/ikonunu yeniden kurmak gecikme yapıyordu
    private var shownUpper = false
    private var shownIcon = -1
    private fun updateShift() {
        if (shownUpper != shift) {
            shownUpper = shift
            for (v in letterViews) { val b = v.tag as String; v.text = if (shift) b.uppercase(Locale.ENGLISH) else b }
        }
        val ic = if (caps) R.drawable.ic_shift_caps else if (shift) R.drawable.ic_shift_on else R.drawable.ic_shift
        if (ic != shownIcon) {
            shownIcon = ic
            shiftView?.setIcon(ic, attrColor(R.attr.kbText))
        }
    }

    private fun onShift() {
        val now = SystemClock.uptimeMillis()
        if (caps) { caps = false; shift = false }
        else if (shift && now - lastShiftTap < 350) caps = true
        else shift = !shift
        lastShiftTap = now
        updateShift()
    }

    private fun ensureMode(m: Mode): LinearLayout = modeViews.getOrPut(m) {
        buildMode(m).also { it.visibility = View.GONE; keys.addView(it, LinearLayout.LayoutParams(-1, -2)) }
    }

    private fun go(m: Mode) {
        stopRepeat(); dismissAlts()
        mode = m
        ensureMode(m)
        for ((k, v) in modeViews) v.visibility = if (k == m) View.VISIBLE else View.GONE
    }

    private fun setEnterIcon(v: KeyView) =
        v.setIcon(if (translating || editing) R.drawable.ic_check else R.drawable.ic_enter, attrColor(R.attr.accentIcon))

    private fun digits() = "1234567890".map { c -> K(c.toString(), hf = 0.95f) { typeText(c.toString()) } }
    private fun lett(s: String) = s.map { c -> K(c.toString(), letter = true) { typeText(c.toString(), true) } }
    private fun sym(vararg s: String) = s.map { c -> K(c) { typeText(c) } }

    private val emojis = listOf(
        "😀","😂","🤣","😊","😍","😘","😎","🤔","😢","😭",
        "😡","😴","🙄","😅","😉","🙂","🥰","😇","🤗","😬",
        "👍","👎","👏","🙏","💪","🤝","👋","✌️","🤞","👌",
        "❤️","💔","🔥","⭐","🎉","🎂","🌹","☀️","🌙","✅"
    )

    private fun rowsFor(m: Mode): List<List<K>> {
        val del = K("", 1.5f, true, kind = 1, icon = R.drawable.ic_backspace) { back() }
        val ent = K("", 1.5f, isEnter = true, kind = 3, icon = R.drawable.ic_enter, hf = 1.1f) { enter() }
        val space = K("", 4f, hf = 1.1f) { typeText(" ") }
        val comma = K(",", hf = 1.1f) { typeText(",") }
        val dot = K(".", hf = 1.1f) { typeText(".") }
        fun abc(w: Float = 1.5f) = K("ABC", w, kind = 2, small = true, hf = 1.1f) { go(Mode.LETTERS) }
        return when (m) {
            Mode.LETTERS -> listOf(
                digits(),
                lett("qwertyuiop"),
                listOf(K("", 0.5f, spacer = true) {}) + lett("asdfghjkl") + listOf(K("", 0.5f, spacer = true) {}),
                listOf(K("", 1.5f, isShift = true, kind = 1, icon = R.drawable.ic_shift) { onShift() }) + lett("zxcvbnm") + del,
                listOf(
                    K("?123", 1.5f, kind = 2, small = true, hf = 1.1f) { go(Mode.SYM1) },
                    comma,
                    K("", 1f, icon = R.drawable.ic_emoji, hf = 1.1f) { go(Mode.EMOJI) },
                    space, dot, ent
                )
            )
            Mode.SYM1 -> listOf(
                digits(),
                sym("@", "#", "₺", "_", "&", "-", "+", "(", ")", "/"),
                listOf(K("=\\<", 1.5f, kind = 1, small = true) { go(Mode.SYM2) }) + sym("*", "\"", "'", ":", ";", "!", "?") + del,
                listOf(abc(), comma, K("123", kind = 1, small = true, hf = 1.1f) { go(Mode.NUM) }, space, dot, ent)
            )
            Mode.SYM2 -> listOf(
                digits(),
                sym("~", "`", "|", "•", "√", "π", "÷", "×", "¶", "∆"),
                listOf(K("?123", 1f, kind = 1, small = true) { go(Mode.SYM1) }) + sym("£", "€", "^", "°", "=", "{", "}", "\\") +
                    listOf(K("", 1f, true, kind = 1, icon = R.drawable.ic_backspace) { back() }),
                listOf(abc(), K("%", hf = 1.1f) { typeText("%") }, K("[", hf = 1.1f) { typeText("[") }, space, K("]", hf = 1.1f) { typeText("]") }, ent)
            )
            Mode.NUM -> listOf(
                sym("1", "2", "3"), sym("4", "5", "6"), sym("7", "8", "9"),
                listOf(abc(1f), comma, K("0") { typeText("0") }, dot, K("", 1f, true, kind = 1, icon = R.drawable.ic_backspace) { back() }, K("", 1f, isEnter = true, kind = 3, icon = R.drawable.ic_enter, hf = 1.1f) { enter() })
            )
            Mode.EMOJI -> listOf(
                emojis.subList(0, 10).map { e -> K(e) { typeText(e) } },
                emojis.subList(10, 20).map { e -> K(e) { typeText(e) } },
                emojis.subList(20, 30).map { e -> K(e) { typeText(e) } },
                emojis.subList(30, 40).map { e -> K(e) { typeText(e) } },
                listOf(abc(), K("", 5f, hf = 1.1f) { typeText(" ") }, K("", 1.5f, true, kind = 1, icon = R.drawable.ic_backspace, hf = 1.1f) { back() }, K("", 2f, isEnter = true, kind = 3, icon = R.drawable.ic_enter, hf = 1.1f) { enter() })
            )
        }
    }

    private fun buildMode(m: Mode): LinearLayout {
        val col = LinearLayout(tctx).apply { orientation = LinearLayout.VERTICAL; setPadding(dpf(2.2f), 0, dpf(2.2f), dp(4)) }
        for (r in rowsFor(m)) {
            val row = LinearLayout(tctx).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in r) {
                if (k.spacer) {
                    row.addView(View(tctx), LinearLayout.LayoutParams(0, dp(keyH), k.w).apply { setMargins(dpf(2.2f), 0, dpf(2.2f), 0) })
                    continue
                }
                val v = keyView(k)
                keyViews.add(v)
                row.addView(v, LinearLayout.LayoutParams(0, dpf(keyH * v.hf), k.w).apply { setMargins(dpf(2.2f), dpf(3.8f), dpf(2.2f), dpf(3.8f)) })
            }
            col.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        return col
    }

    private fun keyTextSp(): Float {
        val wDp = kbWidthPx() / resources.displayMetrics.density
        return minOf(keyH * 0.64f, wDp / 10f * 0.7f).coerceIn(12f, 30f)
    }

    private fun applyKeySize() {
        val ts = keyTextSp()
        for (v in keyViews) {
            val lp = v.layoutParams as LinearLayout.LayoutParams
            val nh = dpf(keyH * v.hf)
            if (lp.height != nh) { lp.height = nh; v.layoutParams = lp }
            val nt = ts * v.tf
            if (v.tag2 != nt) { v.tag2 = nt; v.textSize = nt }
        }
    }

    private var repeatView: View? = null
    private var hasSel = false

    private var lastDelAt = 0L
    private var lastSelAt = 0L

    override fun onUpdateSelection(os: Int, oe: Int, ns: Int, ne: Int, cs: Int, ce: Int) {
        super.onUpdateSelection(os, oe, ns, ne, cs, ce)
        lastSelAt = SystemClock.uptimeMillis()
        hasSel = ns != ne
    }

    private val repeater = object : Runnable {
        var action: (() -> Unit)? = null
        var delay = 80L
        var floor = 28L
        override fun run() {
            val v = repeatView
            // Parmak kalktıysa / tuş ekrandan gittiyse tekrar etmeyi HEMEN durdur
            if (action == null || v == null || !v.isPressed || !v.isAttachedToWindow) { stopRepeat(); return }
            // Uygulama yavaşsa silme komutları kuyrukta birikip parmak kalktıktan sonra da silmesin:
            // önceki silme henüz yansımadıysa bu turu atla
            val now = SystemClock.uptimeMillis()
            val busy = lastDelAt > lastSelAt && now - lastDelAt < 150
            if (!busy) action?.invoke()
            handler.postDelayed(this, delay)
            delay = (delay - 6L).coerceAtLeast(floor)
        }
    }

    private fun stopRepeat() {
        handler.removeCallbacks(repeater)
        repeater.action = null
        repeatView?.isPressed = false
        repeatView = null
    }

    override fun onFinishInputView(finishingInput: Boolean) { dismissAlts(); stopRepeat(); super.onFinishInputView(finishingInput) }
    override fun onWindowHidden() { dismissAlts(); stopRepeat(); handler.removeCallbacks(holdRunnable); handler.removeCallbacks(thumbRunnable); handler.removeCallbacks(prebuildRunnable); super.onWindowHidden() }

    private fun keyView(k: K): KeyView = KeyView(tctx).apply {
        hf = k.hf; tf = if (k.small) 0.62f else 1f
        text = k.label; setTextColor(attrColor(R.attr.kbText)); textSize = keyTextSp() * tf
        gravity = Gravity.CENTER
        background = DrawCache.get(tctx, when (k.kind) { 1 -> R.drawable.fn_bg; 2 -> R.drawable.pill_bg; 3 -> R.drawable.enter_bg; else -> R.drawable.key_bg })
        if (k.icon != 0) setIcon(k.icon, attrColor(if (k.kind == 3) R.attr.accentIcon else R.attr.kbText))
        if (k.letter) { tag = k.label; letterViews.add(this) }
        if (k.isShift) shiftView = this
        if (k.isEnter) { enterViews.add(this); setEnterIcon(this) }
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    stopRepeat()
                    v.isPressed = true
                    dismissAlts()
                    lastTypedUpper = false
                    k.act()   // önce karakteri uygulamaya gönder, titreşim/görsel işler sonra
                    if (haptic) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    if (k.letter) {
                        val alts = altMap[k.label[0]]
                        if (alts != null) {
                            altDownX = e.rawX; altDownY = e.rawY
                            altKeyView = v; altKeyAlts = alts; altKeyUp = lastTypedUpper; altSeq = typedSeq
                            handler.postDelayed(altRunnable, altDelayMs.toLong())
                        }
                    }
                    if (k.repeat) { repeatView = v; repeater.action = k.act; val st = 100L - 10L * repSpeed   // seviye 5 = 50 ms (Gboard)
                        repeater.delay = st; repeater.floor = st            // Gboard gibi sabit hız, ivmelenme yok
                        handler.postDelayed(repeater, holdMs + 100L) }  // Gboard: 300 ms uzun basış, 400 ms tekrar başlangıcı
                }
                MotionEvent.ACTION_MOVE -> {
                    if (v === altKeyView) {
                        if (altPopup == null) {
                            // Menü açılmadan parmak kaydıysa / tuştan çıktıysa hiç açma
                            val dx = e.rawX - altDownX; val dy = e.rawY - altDownY
                            val out = e.x < 0 || e.y < 0 || e.x > v.width || e.y > v.height
                            if (out || dx * dx + dy * dy > dp(10) * dp(10)) cancelAltPending()
                        } else updateAltSel(e.rawX, e.rawY)
                    }
                    if (k.repeat && (e.x < 0 || e.y < 0 || e.x > v.width || e.y > v.height)) stopRepeat()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    if (v === altKeyView) { if (e.actionMasked == MotionEvent.ACTION_UP) finishAlts() else dismissAlts() }
                    v.isPressed = false
                    if (k.repeat) stopRepeat()
                }
            }
            true
        }
    }

    // ---------- Çeviri (Türkçe <-> İngilizce) ----------
    private fun swapLang() {
        fromTr = !fromTr
        chipFrom.text = if (fromTr) "Türkçe" else "İngilizce"
        chipTo.text = if (fromTr) "İngilizce" else "Türkçe"
        if (tOut.isNotBlank()) { tbuf.setLength(0); tbuf.append(tOut) }
        refreshTranslate()
    }

    private fun refreshTranslate() {
        tInput.text = tbuf.toString()
        handler.removeCallbacks(trRunnable)
        if (tbuf.isBlank()) { tOut = ""; tOutput.text = ""; reqId++; return }
        handler.postDelayed(trRunnable, 250)
    }

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 6000; c.readTimeout = 8000
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124.0 Mobile Safari/537.36")
            c.setRequestProperty("Accept", "*/*")
            val code = c.responseCode
            if (code != 200) throw java.io.IOException("HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally { c.disconnect() }
    }

    // Birden çok servis dener; biri çalışmazsa sıradakine geçer
    private fun fetchTranslation(q: String, sl: String, tl: String): String? {
        val enc = URLEncoder.encode(q, "UTF-8")
        val tries = listOf<() -> String>(
            {
                val a = JSONArray(httpGet("https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=$tl&dt=t&q=$enc")).getJSONArray(0)
                val sb = StringBuilder()
                for (i in 0 until a.length()) sb.append(a.getJSONArray(i).optString(0, ""))
                sb.toString()
            },
            {
                val t = httpGet("https://clients5.google.com/translate_a/t?client=dict-chrome-ex&sl=$sl&tl=$tl&q=$enc").trim()
                if (t.startsWith("{")) {
                    val a = JSONObject(t).getJSONArray("sentences")
                    val sb = StringBuilder()
                    for (i in 0 until a.length()) sb.append(a.getJSONObject(i).optString("trans", ""))
                    sb.toString()
                } else {
                    val j = JSONArray(t)
                    val f = j.get(0)
                    if (f is JSONArray) f.getString(0) else j.getString(0)
                }
            },
            {
                val o = JSONObject(httpGet("https://api.mymemory.translated.net/get?q=$enc&langpair=$sl|$tl"))
                o.getJSONObject("responseData").getString("translatedText")
            }
        )
        for (t in tries) {
            try {
                val r = t()
                if (r.isNotBlank()) return r
            } catch (_: Exception) {}
        }
        return null
    }

    private fun doTranslate() {
        val q = tbuf.toString().take(1500)   // GET isteği çok uzun olursa servisler reddeder
        val id = ++reqId
        val sl = if (fromTr) "tr" else "en"
        val tl = if (fromTr) "en" else "tr"
        net.execute {
            if (id != reqId) return@execute // eski istek: boşuna ağa çıkma
            val res = fetchTranslation(q, sl, tl)
            handler.post {
                if (id == reqId) {
                    tOut = res ?: ""
                    tOutput.text = res ?: "Çeviri alınamadı (internet?)"
                }
            }
        }
    }

    // ---------- Ekran görüntüsü önizleme ----------
    private val thumbRunnable: Runnable = Runnable { loadThumbs() }

    private fun loadThumbs() {
        if (!::thumbs.isInitialized) return
        val gen = ++thumbGen
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            lastThumbKey = ""
            thumbs.removeAllViews()
            thumbs.addView(TextView(tctx).apply { text = "Önizleme için uygulamadan izin ver"; setTextColor(attrColor(R.attr.kbSub)); textSize = 12f })
            return
        }
        bg.execute {
            val ids = mutableListOf<Pair<Long, String>>()
            try {
                val sel = "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? OR ${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? OR ${MediaStore.Images.Media.DISPLAY_NAME} LIKE ?"
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.MIME_TYPE),
                    sel, arrayOf("%creenshot%", "%Ekran%", "%creenshot%"),
                    "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { c ->
                    while (c.moveToNext() && ids.size < 5) ids.add(Pair(c.getLong(0), c.getString(1) ?: "image/png"))
                }
            } catch (_: Exception) {}
            val key = ids.joinToString(",") { it.first.toString() }
            if (key == lastThumbKey || gen != thumbGen) return@execute
            if (thumbCache.size > 24) thumbCache.clear()   // bellek şişmesin
            val out = ids.map { (id, mime) ->
                val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                val bmp = thumbCache[uri.toString()] ?: try {
                    contentResolver.loadThumbnail(uri, Size(160, 160), null).also { thumbCache[uri.toString()] = it }
                } catch (e: Exception) { null }
                Shot(uri, mime, bmp)
            }
            handler.post {
                if (gen != thumbGen) return@post   // daha yeni bir yükleme başladı
                lastThumbKey = key
                thumbs.removeAllViews()
                for (s in out) {
                    val iv = ImageView(tctx).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        setBackgroundResource(R.drawable.thumb_bg)
                        outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
                        s.bmp?.let { setImageBitmap(it) }
                        setOnClickListener { sendImage(s) }
                    }
                    thumbs.addView(iv, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
                }
            }
        }
    }

    private fun sendImage(s: Shot) {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val ok = EditorInfoCompat.getContentMimeTypes(ei).any { ClipDescription.compareMimeTypes(s.mime, it) }
        if (ok) {
            val info = InputContentInfoCompat(s.uri, ClipDescription("screenshot", arrayOf(s.mime)), null)
            if (InputConnectionCompat.commitContent(ic, ei, info, InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null)) return
        }
        cm.setPrimaryClip(ClipData.newUri(contentResolver, "screenshot", s.uri))
        Toast.makeText(this, "Bu alan bunu kabul etmiyor; panoya kopyalandı, yapıştırabilirsin", Toast.LENGTH_LONG).show()
    }

    // ---------- Ataç: fotoğraf / video / belge seç, mikrofon: sesle yaz ----------
    private fun launchTransparent(cls: Class<*>, kind: Int = -1, err: String) {
        try {
            val i = Intent(this, cls).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            if (kind >= 0) i.putExtra(PickerActivity.EXTRA_KIND, kind)
            startActivity(i)
        } catch (_: Exception) {
            Toast.makeText(this, err, Toast.LENGTH_SHORT).show()
        }
    }

    private fun openPicker(kind: Int) {
        showCats(false)
        returnToCatsAt = SystemClock.elapsedRealtime()
        launchTransparent(PickerActivity::class.java, kind, "Dosya seçici açılamadı")
    }

    private fun openVoice() = launchTransparent(VoiceActivity::class.java, -1, "Sesle yazma açılamadı")

    // Seçici/ses ekranı kapanıp hedef uygulama tekrar bağlanana kadar bekler; bağlantı gecikirse kısa aralıklarla yeniden dener
    private val deliverRunnable: Runnable = object : Runnable {
        override fun run() {
            if (pending == null && pendingText == null) return
            if (SystemClock.elapsedRealtime() - pendingAt > PENDING_TTL_MS) { pending = null; pendingText = null; return }
            val ic = currentInputConnection
            if (ic == null || currentInputEditorInfo == null) {
                if (++deliverTries <= 20) handler.postDelayed(this, 200)   // en çok ~4 sn
                return                                                     // sonra: sonraki bağlanmada denenir
            }
            deliverTries = 0
            val t = pendingText
            if (t != null) { pendingText = null; ic.commitText(t, 1) }
            val p = pending
            if (p != null) { pending = null; sendImage(Shot(p.first, p.second, null)) }
        }
    }

    private fun deliverPending() {
        if (pending == null && pendingText == null) return
        deliverTries = 0
        handler.removeCallbacks(deliverRunnable)
        handler.postDelayed(deliverRunnable, 200)
    }

    override fun onStartInput(attribute: EditorInfo?, restarting: Boolean) {
        super.onStartInput(attribute, restarting)
        deliverPending()
    }

    // ---------- Paneller: 0 tuşlar, 1 pano, 2 tuş boyutu, 3 çeviri ----------
    private fun showPanel(which: Int) {
        if (!::clipPanel.isInitialized) return
        stopRepeat()
        translating = which == 3
        editing = which == 4
        if (which == 1 || which == 3 || which == 4) setTools(true, false)
        hl(btnTr, translating)
        hl(btnCl, which == 1 || which == 4)
        clipPanel.visibility = if (which == 1) View.VISIBLE else View.GONE
        sizePanel.visibility = if (which == 2) View.VISIBLE else View.GONE
        translatePanel.visibility = if (translating) View.VISIBLE else View.GONE
        editPanel.visibility = if (editing) View.VISIBLE else View.GONE
        keys.visibility = if (which == 1) View.INVISIBLE else View.VISIBLE
        if (!translating && !editing) {
            tbuf.setLength(0); tOut = ""; reqId++
            handler.removeCallbacks(trRunnable)
            tInput.text = ""; tOutput.text = ""
            tEdit.text = ""
        }
        val chk = translating || editing
        if (chk != enterChk) { enterChk = chk; for (v in enterViews) setEnterIcon(v) }
        if (which == 1) reloadClips()
    }

    private fun editInsert(t: String) {
        tbuf.insert(editCur, t); editCur += t.length
        renderEdit()
    }

    // Metni imleçle birlikte göster (uzun metinde imlecin çevresini)
    private fun renderEdit() {
        val n = tbuf.length
        val st = maxOf(0, editCur - 90)
        val en = minOf(n, editCur + 90)
        val pre = if (st > 0) "…" else ""
        val post = if (en < n) "…" else ""
        editStart = st; editPre = pre.length
        val b = SpannableStringBuilder()
        b.append(pre).append(tbuf.substring(st, editCur))
        val pos = b.length
        b.append("│").append(tbuf.substring(editCur, en)).append(post)
        b.setSpan(ForegroundColorSpan(attrColor(R.attr.accentText)), pos, pos + 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
        tEdit.text = b
    }

    private fun editTap(x: Float, y: Float) {
        val lay = tEdit.layout ?: return
        val px = x - tEdit.totalPaddingLeft + tEdit.scrollX
        val py = (y - tEdit.totalPaddingTop + tEdit.scrollY).toInt().coerceAtLeast(0)
        val line = lay.getLineForVertical(py)
        var off = lay.getOffsetForHorizontal(line, px)
        val dispCur = editPre + (editCur - editStart)
        if (off > dispCur) off -= 1
        editCur = (off - editPre + editStart).coerceIn(0, tbuf.length)
        renderEdit()
    }

    private fun startEdit(item: ClipItem) {
        editItem = item
        showPanel(4)
        tbuf.setLength(0); tbuf.append(item.text)
        editCur = tbuf.length
        renderEdit()
    }

    private fun saveEdit() {
        val it = editItem
        val t = tbuf.toString()
        if (it != null && t.isNotBlank() && t != it.text) store.replace(it.text, t, it.pinned)
        editItem = null
        showPanel(1)
    }

    private fun reloadClips() {
        // En son kopyalanan en üstte, onun altında sabitlenenler, sonra diğer geçmiş
        val hist = store.history().map { ClipItem(it, false) }
        val pins = store.pinned()
        val list = mutableListOf<ClipItem>()
        if (hist.isNotEmpty()) { list.add(ClipItem("En son", false, true)); list.add(hist[0]) }
        if (pins.isNotEmpty()) { list.add(ClipItem("Sabitlenenler", true, true)); pins.forEach { list.add(ClipItem(it, true)) } }
        if (hist.size > 1) { list.add(ClipItem("Geçmiş", false, true)); list.addAll(hist.drop(1)) }
        adapter.submit(list)
        updateUndo()
    }

    private fun updateUndo() {
        if (!::btnUndo.isInitialized) return
        val n = undoStack.size
        btnUndo.visibility = if (n > 0) View.VISIBLE else View.GONE
        clipHint.visibility = if (n > 0) View.GONE else View.VISIBLE
        clipPanel.findViewById<View>(R.id.undoSpacer).visibility = if (n > 0) View.VISIBLE else View.GONE
        if (n > 0) btnUndo.text = if (n > 1) "🗑 Geri al ($n)" else "🗑 Geri al"
    }
}
