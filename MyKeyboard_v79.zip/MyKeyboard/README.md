# MyKeyboard
- Üst sol yuvarlak buton: Google Çeviri (alandaki yazıyı çeviriye gönderir)
- Üstte: en başta SON KOPYALANAN METNİN önizlemesi (dokununca yapıştırır) + son 3 ekran görüntüsü
- Sağ üst pano: ☆ ile sabitle, "Sabitler" sekmesi, basılı tutup sürükleyerek sırala
- ?123 -> semboller, =\< -> 2. sembol sayfası, 1234 -> sayı tuşları

## APK nasıl alınır
A) Android Studio: klasörü aç -> Build > Build APK.
B) Sadece telefonla: GitHub'a yeni repo aç, dosyaları yükle -> Actions > "Build APK" -> Artifacts'tan APK indir.
Kurduktan sonra uygulamayı aç: 1) etkinleştir 2) seç 3) ekran görüntüsü izni.

## v1.5
- Sol üst: ▦ = Google Çeviri (Türkçe⇄İngilizce), yanında pano
- Sağ üst: boyut (yükseklik, genişlik %60-100, sol/orta/sağ hizalama, titreşim)
- Pano: öğeye basılı tut = sabitle/çöz, ≡ tutamacıyla sürükle = sırala
- Çift dokunuş ⇧ = Caps Lock, silme tuşu hızlanarak tekrar eder

## v3.0 (v61)
- Üst şerit: son kopyalanan metin önizlemesi + son 3 ekran görüntüsü (eskiden 5)
- Yandaki tuşa sıçrama koruması: aynı parmağın taşan "hayalet" dokunuşu yok sayılır
- Silme tuşu: sabit ritimli tekrar (bazı uygulamalarda ani hızlanma düzeltildi)
- Yazım denetimi: yanlış/Türkçeye uymayan kelime kırmızı altı çizili; kelimeye dokununca ya da basılı tutup seçince
  klavyenin üst şeridinde doğru yazılış önerileri çıkar (✓ Doğru = bir daha işaretleme)
  Tam sözlük için telefonun yazım denetimi açık + Türkçe olmalı; yerleşik kurallar (…br, q/w/x, ünlüsüz) her zaman çalışır

## v3.1
- Yanlış kelime artık kırmızı DÜZ çizgiyle (kırmızı alt çizgi) işaretlenir
- Doğru yazılış önerileri kelime bitince (boşluğa basınca) hemen üst şeritte çıkar; dokununca kelimeyi düzeltir, boşluk korunur

## v3.2
- Yanlış kelimeye basılı tutup seçince doğru yazılış önerileri üst şeritte çıkar (kelime önceden işaretlenmemiş olsa bile anında denetlenir)
- Tuş hedefleme: parmağın temas yaması hangi harfe daha çok basıyorsa o harf seçilir; komşu harfler yok sayılır
- Hayalet dokunuş koruması sıkılaştırıldı (yan tuşa taşan ikinci dokunuş daha geniş alanda ve daha uzun süre yok sayılır)

## v3.3
- Chrome/Brave gibi tarayıcı alanlarında yazım denetimi artık çalışır (eskiden bu alanlar yanlışlıkla dışlanıyordu)
- 4+ ünsüz arka arkaya gelen kelimeler (gecyrsn, beklyrm…) yanlış sayılır; öneri için telefonun yazım denetleyicisine de sorulur
- Üst şeritte yanlış kelime kırmızı altı çizili gösterilir (uygulama çizgiyi çizmese de görünür); metinde de hafif kırmızı zemin

## v3.4
- Öneri şeridi: başta sadece ✓ (dokun = normal şeride dön, basılı tut = bu kelime doğru), yanında en iyi 3 öneri TAM kelime olarak; sığmazsa 2'ye düşer
- Aynı önerinin büyük/küçük harf kopyaları (işle / İşle) tekrar gösterilmez

## v3.5
- Yazım denetimi diğer uygulamalarda bozuluyordu (kırmızı yanıp kelime kaybolması, silme/boşluk yazılamaması): işaretleme artık sadece "kelime + tek ayraç" halinde ve denetim sürerken yazmaya/silmeye devam edilmediyse yapılır
- İşaretlemeden sonra metin yerinde değilse kelime düz metin olarak geri yazılır ve o uygulamada işaretleme otomatik kapanır

## v3.6
- Yazım denetimi yine kırmızı işaretliyor ve öneri veriyor: denetim cevabı geç gelip sen sonraki kelimeye geçtiysen de kelime işaretlenir; öneriler her durumda kaydedilir (kelimeye dokununca çıkar)
- Bir uygulamada işaretleme artık tek seferlik yavaşlıkla kalıcı kapanmaz (iki kez bozulursa kapanır); önceki sürümlerde yanlışlıkla kapanmış uygulamalar sıfırlandı

## v3.7
- Otomatik yedek: Yedekle'de klasör seçilmişse klavye açılınca arka planda Drive klasörüne yedek alınır (en az 3 saatte bir, sadece pano/ayar değiştiyse; kendi aldığı son 10 dosyayı tutar, eskilerini siler; elle aldığın yedeklere dokunmaz)
- Yedek alınınca sağ üstte Google yedek bulutu çıkar: içinde yukarı süzülen ok, hareketli; ~6 sn sonra kaybolur, dokununca yedek bilgisi açılır. Ayrıca "Otomatik yedek alındı ✓ (klasör)" uyarısı verilir
- Yedek alınamazsa bulut kırmızı "!" olur ve neden yazılı uyarı çıkar; 1 saat sonra tekrar dener

## v3.8
- Otomatik yedek, klavye ilk açıldıktan 5 DAKİKA sonra alınır (alan değiştirdikçe sayaç sıfırlanmaz)
- Üst şerit: ekran görüntüsü 3 yerine 2; son kopyalanan metin önizlemesi daha geniş (yazı da biraz büyük)
- Menü: pano, çeviri ve açık/koyu tema simgeleri birbirine yaklaştırıldı

## v3.9
- Yedek klasöründe zaten yedek varsa YENİ dosya açılmaz: en son yedeğin üzerine yazılır (elle de, otomatik de); yoksa yeni dosya açılır
- Yedek adı: klavyeyedegim_BOYUT_SAAT_GÜN:AYYIL.json  (örn. klavyeyedegim_12.3KB_14_28:1026.json; yıl son iki hane)

## v4.0
- Yanlış kelime kırmızıyken öneriden seçince: önce eski kelime silinip sonra düzeltilmiş kelime yazılır (kırmızı işaret yeni kelimeye bulaşmaz), öneri şeridi hemen normale döner; kırmızı yine de kaldıysa düz metin olarak yeniden yazılır
- Sesle yazma: kendi dinleyicimiz. Konuşman bitince hemen kapanmaz, 1 saniye daha bekler (nefes araları); yeni ses gelirse metin birikerek devam eder. "Bitir" tuşu / dışına dokunma ile hemen bitirilir. İlk kullanımda mikrofon izni istenir (verilmezse eski Google penceresi açılır)

## v4.1
- Yanlış/eksik yazılan kelime (nrdsin, meslaa…) kırmızı dolgulu kare (arka plan kırmızı + alt çizgi) olur; yazı kendi rengiyle kalır
- Kırmızı kutu, yazmaya ara verince (0,4 sn) çizilir: yazarken klavye durmaz/takılmaz, tuş kaybolmaz; kelimeden sonra yazdığın metin ve eski kırmızı kutular korunur
- Öneriler artık kelime bitince kendiliğinden çıkmaz: kelimeye basılı tutup seçince (sistemin uzun basma süresi, genelde 0,5 sn) üst şeritte EN İYİ 2 öneri çıkar. Sistem yazım denetleyicisinin önerileri öne alındı; öneri yoksa denetleyiciden istenir

## v4.2
- Canlı yazım önerisi: yazarken (kısa duraklamada) imlecin yanındaki kelime taranır. Yanlışsa klavyenin üst şeridi (menü/pano/ekran görüntüleri)
  yerine EN İYİ 3 öneri tam genişlikte çıkar (en iyisi kalın). Öneriye dokununca kelime düzelir ve şerit normale döner.
- Kelime doğruya dönünce, başka kelimeye geçilince, Enter'a basılınca ya da ~6 sn yazılmazsa şerit normale döner.
- Kırmızı kutu/alt çizgi kaldırıldı: metne hiçbir şey çizilmez/yeniden yazılmaz, bu yüzden her uygulamada (sohbet, Instagram, tarayıcı…) aynı çalışır.
- Kelimeye dokununca ya da basılı tutup seçince de aynı 3'lü öneri şeridi çıkar.

## v4.3
- Otomatik yedek artık her 5 dakikada bir çalışır (eskiden en az 3 saatte bir). Her seferinde bilgi verir: "yedek alındı ✓", içerik değişmediyse "yedek güncel ✓", olmazsa nedeniyle uyarı; sağ üstte yedek bulutu da çıkar.
- Yedek klasörü hiç seçilmemişse bir kez "Otomatik yedek kapalı: Yedekle'den klasör seç" uyarısı gösterir.
- Başarısız olursa 5 dakika sonra tekrar dener.

## v4.5 (v78)
- 5. tema eklendi: 💼 Kurumsal (soğuk gri zemin, beyaz tuşlar, lacivert vurgu ve Enter)

## v4.4 (v77)
- Üst şeritte (menüyü açınca) güneş/ay düğmesinin yanında 4 tema yuvarlağı: ☕ Günlük (sıcak krem + yeşil), ⚽ Spor (koyu + neon yeşil/turuncu), 🌌 Gece (lacivert + mor-mavi), 🎉 Eğlenceli (pembe + sarı + mavi)
- Dokununca tema anında uygulanır ve hatırlanır; seçili temanın yuvarlağı kalın çerçeveli. Güneş/ay düğmesi özel temadan çıkıp klasik karanlık ↔ aydınlık arasında geçer.
- Tema seçimi yedeğe dahildir (geri yüklenince gelir).

## v4.6 (v79)
- Güneş/ay düğmesinin yanındaki 5 tema yuvarlağı kaldırıldı; yerine 🎨 palet düğmesi geldi.
- Palet düğmesine basınca önizlemeli tema paneli açılır: Karanlık, Aydınlık, Günlük, Spor, Gece, Eğlenceli, Kurumsal. Her kart küçük bir klavye önizlemesi gösterir.
- Karta dokununca seçilir (✓), "Uygula" ile klavyeye geçer ve hatırlanır; "Vazgeç" değişiklik yapmadan kapatır.
