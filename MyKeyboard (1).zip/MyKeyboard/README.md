# MyKeyboard
- Üst sol yuvarlak buton: Google Çeviri (alandaki yazıyı çeviriye gönderir)
- Üstte son 5 ekran görüntüsü önizlemesi; dokununca yazı alanına yapıştırır
- Sağ üst pano: ☆ ile sabitle, "Sabitler" sekmesi, basılı tutup sürükleyerek sırala
- ?123 -> semboller, =\< -> 2. sembol sayfası, 1234 -> sayı tuşları

## APK nasıl alınır
A) Android Studio: klasörü aç -> Build > Build APK.
B) Sadece telefonla: GitHub'a yeni repo aç, dosyaları yükle -> Actions > "Build APK" -> Artifacts'tan APK indir.
Kurduktan sonra uygulamayı aç: 1) etkinleştir 2) seç 3) ekran görüntüsü izni.

## v1.5
- Sol üst: ▦ = Google Çeviri (Türkçe⇄İngilizce), yanında pano
- Sağ üst: boyut (yükseklik, genişlik %60-100, sol/orta/sağ hizalama, titreşim)
- Pano: öğeye basılı tut = sabitle/çöz, ≡ tutamacıyla sürükle = sırala
- Çift dokunuş ⇧ = Caps Lock, silme tuşu hızlanarak tekrar eder
