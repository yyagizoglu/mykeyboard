package com.example.mykeyboard

import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class ClipItem(val text: String, val pinned: Boolean)

class ClipAdapter(
    private val onInsert: (ClipItem) -> Unit,
    private val onPin: (ClipItem) -> Unit,
    private val onDelete: (ClipItem) -> Unit,
    private val onDrag: (RecyclerView.ViewHolder) -> Unit
) : RecyclerView.Adapter<ClipAdapter.VH>() {

    var items: MutableList<ClipItem> = mutableListOf()

    fun submit(list: MutableList<ClipItem>) { items = list; notifyDataSetChanged() }

    fun move(from: Int, to: Int) {
        if (from < 0 || to < 0 || from >= items.size || to >= items.size) return
        items.add(to, items.removeAt(from))
        notifyItemMoved(from, to)
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val text: TextView = v.findViewById(R.id.clipText)
        val pin: TextView = v.findViewById(R.id.clipPin)
        val del: TextView = v.findViewById(R.id.clipDel)
        val drag: TextView = v.findViewById(R.id.clipDrag)
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(LayoutInflater.from(p.context).inflate(R.layout.item_clip, p, false))

    override fun getItemCount() = items.size

    private fun cur(h: VH): ClipItem? = items.getOrNull(h.bindingAdapterPosition)

    override fun onBindViewHolder(h: VH, i: Int) {
        val item = items[i]
        h.text.text = item.text
        h.pin.text = if (item.pinned) "★" else "☆"
        h.itemView.setBackgroundResource(if (item.pinned) R.drawable.pinned_bg else R.drawable.key_bg)
        h.text.setOnClickListener { cur(h)?.let(onInsert) }
        // Basılı tut: sabitle / sabitten çıkar
        h.text.setOnLongClickListener {
            val c = cur(h)
            if (c != null) {
                h.itemView.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                onPin(c)
            }
            true
        }
        h.pin.setOnClickListener { cur(h)?.let(onPin) }
        h.del.setOnClickListener { cur(h)?.let(onDelete) }
        h.drag.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) onDrag(h)
            false
        }
    }
}
