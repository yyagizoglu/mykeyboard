package com.example.mykeyboard

import android.Manifest
import android.content.ClipData
import android.content.ClipDescription
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.inputmethodservice.InputMethodService
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.provider.MediaStore
import android.text.InputType
import android.util.Size
import android.view.*
import android.view.inputmethod.EditorInfo
import android.widget.*
import androidx.core.view.inputmethod.EditorInfoCompat
import androidx.core.view.inputmethod.InputConnectionCompat
import androidx.core.view.inputmethod.InputContentInfoCompat
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.util.Locale
import java.util.concurrent.Executors

class ImeService : InputMethodService() {

    private enum class Mode { LETTERS, SYM1, SYM2, NUM }
    private class K(
        val label: String, val w: Float = 1f, val repeat: Boolean = false,
        val letter: Boolean = false, val isShift: Boolean = false, val isEnter: Boolean = false,
        val act: () -> Unit
    )
    private class Shot(val uri: Uri, val mime: String, val bmp: Bitmap?)

    private val tr = Locale("tr", "TR")
    private val handler = Handler(Looper.getMainLooper())
    private val bg = Executors.newSingleThreadExecutor()
    private val net = Executors.newSingleThreadExecutor()
    private lateinit var store: ClipStore
    private lateinit var cm: ClipboardManager
    private lateinit var keys: LinearLayout
    private lateinit var thumbs: LinearLayout
    private lateinit var kbRoot: View
    private lateinit var toolbar: View
    private lateinit var btnTr: ImageButton
    private lateinit var btnCl: ImageButton
    private lateinit var wrapper: FrameLayout
    private lateinit var widthLabel: TextView
    private lateinit var hapticBtn: TextView
    private lateinit var alignBtns: List<TextView>
    private lateinit var touchHelper: ItemTouchHelper
    private lateinit var clipPanel: View
    private lateinit var sizePanel: View
    private lateinit var translatePanel: View
    private lateinit var sizeLabel: TextView
    private lateinit var tInput: TextView
    private lateinit var tOutput: TextView
    private lateinit var chipFrom: TextView
    private lateinit var chipTo: TextView
    private lateinit var adapter: ClipAdapter

    private var mode = Mode.LETTERS
    private var shift = false
    private var keyH = 48
    private var kbPct = 100
    private var kbAlign = 1
    private var haptic = true
    private var caps = false
    private var lastShiftTap = 0L
    private val modeViews = HashMap<Mode, LinearLayout>()
    private val keyViews = ArrayList<TextView>()
    private val letterViews = ArrayList<TextView>()
    private val enterViews = ArrayList<TextView>()
    private var shiftView: TextView? = null

    // çeviri
    private var translating = false
    private var fromTr = true
    private val tbuf = StringBuilder()
    private var tOut = ""
    private var reqId = 0
    private val trRunnable = Runnable { doTranslate() }

    private val thumbCache = HashMap<String, Bitmap>()
    @Volatile private var lastThumbKey = ""

    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        val desc = cm.primaryClipDescription
        if (desc != null && (desc.hasMimeType("text/plain") || desc.hasMimeType("text/html"))) {
            val t = cm.primaryClip?.getItemAt(0)?.coerceToText(this)?.toString()
            if (!t.isNullOrBlank()) {
                store.addHistory(t)
                if (::clipPanel.isInitialized && clipPanel.visibility == View.VISIBLE) reloadClips()
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        store = ClipStore(this)
        cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.addPrimaryClipChangedListener(clipListener)
        val sp = getSharedPreferences("ui", Context.MODE_PRIVATE)
        keyH = sp.getInt("keyH", 48)
        kbPct = sp.getInt("kbPct", 100)
        kbAlign = sp.getInt("kbAlign", 1)
        haptic = sp.getBoolean("haptic", true)
    }

    override fun onDestroy() {
        cm.removePrimaryClipChangedListener(clipListener)
        super.onDestroy()
    }

    override fun onEvaluateFullscreenMode() = false

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun prefs() = getSharedPreferences("ui", Context.MODE_PRIVATE)

    override fun onCreateInputView(): View {
        modeViews.clear(); keyViews.clear(); letterViews.clear(); enterViews.clear(); shiftView = null
        val root = layoutInflater.inflate(R.layout.keyboard, null)
        kbRoot = root
        wrapper = FrameLayout(this).apply { setBackgroundColor(0xFF1B1B1D.toInt()) }
        wrapper.addView(root, FrameLayout.LayoutParams(-1, -2))
        keys = root.findViewById(R.id.keys)
        thumbs = root.findViewById(R.id.thumbs)
        toolbar = root.findViewById(R.id.toolbar)
        btnTr = root.findViewById(R.id.btnTranslate)
        btnCl = root.findViewById(R.id.btnClip)
        clipPanel = root.findViewById(R.id.clipPanel)
        sizePanel = root.findViewById(R.id.sizePanel)
        translatePanel = root.findViewById(R.id.translatePanel)
        sizeLabel = root.findViewById(R.id.sizeLabel)
        widthLabel = root.findViewById(R.id.widthLabel)
        hapticBtn = root.findViewById(R.id.btnHaptic)
        tInput = root.findViewById(R.id.tInput)
        tOutput = root.findViewById(R.id.tOutput)
        chipFrom = root.findViewById(R.id.chipFrom)
        chipTo = root.findViewById(R.id.chipTo)

        root.findViewById<View>(R.id.btnMenu).setOnClickListener { setTools(toolbar.visibility != View.VISIBLE) }
        btnTr.setOnClickListener { showPanel(if (translating) 0 else 3) }
        btnCl.setOnClickListener { showPanel(if (clipPanel.visibility == View.VISIBLE) 0 else 1) }
        setTools(prefs().getBoolean("tools", false), false)
        root.findViewById<View>(R.id.btnSize).setOnClickListener { showPanel(if (sizePanel.visibility == View.VISIBLE) 0 else 2) }
        root.findViewById<View>(R.id.btnBack).setOnClickListener { showPanel(0) }
        root.findViewById<View>(R.id.btnSizeOk).setOnClickListener { showPanel(0) }
        root.findViewById<View>(R.id.btnTBack).setOnClickListener { showPanel(0) }
        root.findViewById<View>(R.id.btnSwap).setOnClickListener { swapLang() }
        tOutput.setOnClickListener {
            if (tOut.isNotBlank()) { currentInputConnection?.commitText(tOut, 1); showPanel(0) }
        }

        // Yükseklik (canlı önizleme)
        val bar = root.findViewById<SeekBar>(R.id.sizeBar)
        bar.progress = (keyH - 36).coerceIn(0, 44)
        sizeLabel.text = "Yükseklik: $keyH"
        bar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                keyH = 36 + p
                sizeLabel.text = "Yükseklik: $keyH"
                applyKeySize()
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) { prefs().edit().putInt("keyH", keyH).apply() }
        })

        // Genişlik (bırakınca uygulanır; çubuk kendi içinde olduğu için canlı değişmez)
        val wbar = root.findViewById<SeekBar>(R.id.widthBar)
        wbar.progress = (kbPct - 60).coerceIn(0, 40)
        widthLabel.text = "Genişlik: %$kbPct"
        wbar.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                widthLabel.text = "Genişlik: %" + (60 + p)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {
                kbPct = 60 + (s?.progress ?: 40)
                prefs().edit().putInt("kbPct", kbPct).apply()
                applyWidth()
            }
        })

        alignBtns = listOf(
            root.findViewById<TextView>(R.id.btnAlignL),
            root.findViewById<TextView>(R.id.btnAlignC),
            root.findViewById<TextView>(R.id.btnAlignR)
        )
        alignBtns.forEachIndexed { i, b ->
            b.setOnClickListener {
                kbAlign = i
                prefs().edit().putInt("kbAlign", i).apply()
                updateAlignChips(); applyWidth()
            }
        }
        updateAlignChips()
        updateHapticBtn()
        hapticBtn.setOnClickListener {
            haptic = !haptic
            prefs().edit().putBoolean("haptic", haptic).apply()
            updateHapticBtn()
        }

        adapter = ClipAdapter(
            onInsert = { currentInputConnection?.commitText(it.text, 1) },
            onPin = { if (it.pinned) store.unpin(it.text) else store.pin(it.text); reloadClips() },
            onDelete = { store.delete(it.text, it.pinned); reloadClips() },
            onDrag = { touchHelper.startDrag(it) }
        )
        val rv = root.findViewById<RecyclerView>(R.id.clipList)
        rv.layoutManager = LinearLayoutManager(this)
        rv.adapter = adapter
        // Sol baştaki ≡ tutamacından sürükle: sabitler kendi aralarında, diğerleri kendi aralarında sıralanır
        touchHelper = ItemTouchHelper(object : ItemTouchHelper.SimpleCallback(ItemTouchHelper.UP or ItemTouchHelper.DOWN, 0) {
            override fun isLongPressDragEnabled() = false
            override fun onMove(r: RecyclerView, v: RecyclerView.ViewHolder, t: RecyclerView.ViewHolder): Boolean {
                val a = v.bindingAdapterPosition; val b = t.bindingAdapterPosition
                if (a < 0 || b < 0 || adapter.items[a].pinned != adapter.items[b].pinned) return false
                adapter.move(a, b); return true
            }
            override fun onSwiped(v: RecyclerView.ViewHolder, d: Int) {}
            override fun clearView(r: RecyclerView, v: RecyclerView.ViewHolder) {
                super.clearView(r, v)
                store.savePinned(adapter.items.filter { it.pinned }.map { it.text })
                store.saveHistory(adapter.items.filter { !it.pinned }.map { it.text })
            }
        })
        touchHelper.attachToRecyclerView(rv)

        go(Mode.LETTERS)
        applyWidth()
        // Diğer tuş sayfalarını önceden hazırla: sayfa değişirken takılma olmasın
        handler.post { if (::keys.isInitialized) for (md in Mode.values()) ensureMode(md) }
        return wrapper
    }

    private fun setTools(on: Boolean, persist: Boolean = true) {
        thumbs.visibility = if (on) View.GONE else View.VISIBLE
        toolbar.visibility = if (on) View.VISIBLE else View.GONE
        if (persist) prefs().edit().putBoolean("tools", on).apply()
    }

    private fun hl(v: ImageButton, on: Boolean) {
        v.setBackgroundResource(if (on) R.drawable.pill_sel else R.drawable.icon_btn)
        if (on) v.setColorFilter(0xFF0B2A5B.toInt()) else v.clearColorFilter()
    }

    private fun updateAlignChips() {
        alignBtns.forEachIndexed { i, b -> b.setBackgroundResource(if (i == kbAlign) R.drawable.chip_bg else R.drawable.key_bg) }
    }

    private fun updateHapticBtn() { hapticBtn.text = if (haptic) "Titreşim: Açık" else "Titreşim: Kapalı" }

    private fun kbWidthPx(): Int {
        val sw = resources.displayMetrics.widthPixels
        return if (kbPct >= 100) sw else sw * kbPct / 100
    }

    private fun applyWidth() {
        if (!::kbRoot.isInitialized) return
        val h = when (kbAlign) { 0 -> Gravity.START; 2 -> Gravity.END; else -> Gravity.CENTER_HORIZONTAL }
        val g = h or Gravity.TOP
        kbRoot.layoutParams = FrameLayout.LayoutParams(if (kbPct >= 100) -1 else kbWidthPx(), -2, g)
        applyKeySize()
    }

    override fun onStartInputView(info: EditorInfo?, restarting: Boolean) {
        super.onStartInputView(info, restarting)
        if (!::keys.isInitialized) return
        showPanel(0)
        applyWidth()
        val cls = (info?.inputType ?: 0) and InputType.TYPE_MASK_CLASS
        if (cls == InputType.TYPE_CLASS_NUMBER || cls == InputType.TYPE_CLASS_PHONE) go(Mode.NUM)
        else if (mode == Mode.NUM) go(Mode.LETTERS)
        loadThumbs()
    }

    // ---------- Tuşlar ----------
    private fun typeText(s: String, letter: Boolean = false) {
        val loc = if (translating && !fromTr) Locale.ENGLISH else tr
        val up = shift && letter
        val out = if (up) s.uppercase(loc) else s
        if (translating) { tbuf.append(out); refreshTranslate() }
        else currentInputConnection?.commitText(out, 1)
        if (up && !caps) { shift = false; updateShift() }
    }

    private fun back() {
        if (translating) {
            if (tbuf.isNotEmpty()) {
                tbuf.setLength(tbuf.length - Character.charCount(tbuf.codePointBefore(tbuf.length)))
                refreshTranslate()
            }
            return
        }
        val ic = currentInputConnection ?: return
        val sel = ic.getSelectedText(0)
        if (sel.isNullOrEmpty()) {
            if (!ic.deleteSurroundingTextInCodePoints(1, 0)) sendDownUpKeyEvents(KeyEvent.KEYCODE_DEL)
        } else ic.commitText("", 1)
    }

    private fun enter() {
        if (translating) {
            if (tOut.isNotBlank()) currentInputConnection?.commitText(tOut, 1)
            showPanel(0)
        } else sendDownUpKeyEvents(KeyEvent.KEYCODE_ENTER)
    }

    private fun updateShift() {
        for (v in letterViews) { val b = v.tag as String; v.text = if (shift) b.uppercase(tr) else b }
        shiftView?.text = if (caps) "⇪" else if (shift) "⬆" else "⇧"
    }

    private fun onShift() {
        val now = SystemClock.uptimeMillis()
        if (caps) { caps = false; shift = false }
        else if (shift && now - lastShiftTap < 350) caps = true
        else shift = !shift
        lastShiftTap = now
        updateShift()
    }

    private fun ensureMode(m: Mode): LinearLayout = modeViews.getOrPut(m) {
        buildMode(m).also { it.visibility = View.GONE; keys.addView(it, LinearLayout.LayoutParams(-1, -2)) }
    }

    private fun go(m: Mode) {
        stopRepeat()
        mode = m
        ensureMode(m)
        for ((k, v) in modeViews) v.visibility = if (k == m) View.VISIBLE else View.GONE
    }

    private fun digits() = "1234567890".map { c -> K(c.toString()) { typeText(c.toString()) } }
    private fun lett(s: String) = s.map { c -> K(c.toString(), letter = true) { typeText(c.toString(), true) } }
    private fun sym(vararg s: String) = s.map { c -> K(c) { typeText(c) } }

    private fun rowsFor(m: Mode): List<List<K>> {
        val del = K("⌫", 1.5f, true) { back() }
        val ent = K("↵", 1.5f, isEnter = true) { enter() }
        val space = K("", 5f) { typeText(" ") }
        val comma = K(",") { typeText(",") }
        val dot = K(".") { typeText(".") }
        return when (m) {
            Mode.LETTERS -> listOf(
                digits(),
                lett("qwertyuıopğü"),
                lett("asdfghjklşi"),
                listOf(K("⇧", 1.5f, isShift = true) { onShift() }) + lett("zxcvbnmöç") + del,
                listOf(K("?123", 1.5f) { go(Mode.SYM1) }, comma, space, dot, ent)
            )
            Mode.SYM1 -> listOf(
                digits(),
                sym("@", "#", "₺", "_", "&", "-", "+", "(", ")", "/"),
                listOf(K("=\\<", 1.5f) { go(Mode.SYM2) }) + sym("*", "\"", "'", ":", ";", "!", "?") + del,
                listOf(K("ABC", 1.5f) { go(Mode.LETTERS) }, comma, K("1234") { go(Mode.NUM) }, space, dot, ent)
            )
            Mode.SYM2 -> listOf(
                digits(),
                sym("~", "`", "|", "•", "√", "π", "÷", "×", "¶", "∆"),
                listOf(K("?123", 1.5f) { go(Mode.SYM1) }) + sym("£", "€", "^", "°", "=", "{", "}", "\\") + del,
                listOf(K("ABC", 1.5f) { go(Mode.LETTERS) }, K("%") { typeText("%") }, K("[") { typeText("[") }, space, K("]") { typeText("]") }, ent)
            )
            Mode.NUM -> listOf(
                sym("1", "2", "3"), sym("4", "5", "6"), sym("7", "8", "9"),
                listOf(K("ABC") { go(Mode.LETTERS) }, comma, K("0") { typeText("0") }, dot, del, ent)
            )
        }
    }

    private fun buildMode(m: Mode): LinearLayout {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(3), dp(3), dp(3), dp(3)) }
        for (r in rowsFor(m)) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (k in r) {
                val v = keyView(k)
                keyViews.add(v)
                row.addView(v, LinearLayout.LayoutParams(0, dp(keyH), k.w).apply { setMargins(dp(2), dp(3), dp(2), dp(3)) })
            }
            col.addView(row, LinearLayout.LayoutParams(-1, -2))
        }
        return col
    }

    private fun keyTextSp(): Float {
        val wDp = kbWidthPx() / resources.displayMetrics.density
        return minOf(keyH * 0.42f, wDp / 11f * 0.55f).coerceIn(12f, 28f)
    }

    private fun applyKeySize() {
        val ts = keyTextSp()
        for (v in keyViews) {
            val lp = v.layoutParams as LinearLayout.LayoutParams
            lp.height = dp(keyH)
            v.layoutParams = lp
            v.textSize = ts
        }
    }

    private var repeatView: View? = null

    private val repeater = object : Runnable {
        var action: (() -> Unit)? = null
        var delay = 80L
        override fun run() {
            val v = repeatView
            // Parmak kalktıysa / tuş ekrandan gittiyse tekrar etmeyi HEMEN durdur
            if (action == null || v == null || !v.isPressed || !v.isAttachedToWindow) { stopRepeat(); return }
            action?.invoke()
            handler.postDelayed(this, delay)
            delay = (delay - 6L).coerceAtLeast(28L)
        }
    }

    private fun stopRepeat() {
        handler.removeCallbacks(repeater)
        repeater.action = null
        repeatView?.isPressed = false
        repeatView = null
    }

    override fun onFinishInputView(finishingInput: Boolean) { stopRepeat(); super.onFinishInputView(finishingInput) }
    override fun onWindowHidden() { stopRepeat(); super.onWindowHidden() }

    private fun keyView(k: K): TextView = TextView(this).apply {
        text = k.label; setTextColor(0xFFFFFFFF.toInt()); textSize = keyTextSp()
        gravity = Gravity.CENTER; setBackgroundResource(R.drawable.key_bg)
        if (k.letter) { tag = k.label; letterViews.add(this) }
        if (k.isShift) shiftView = this
        if (k.isEnter) { enterViews.add(this); text = if (translating) "✓" else "↵" }
        setOnTouchListener { v, e ->
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    stopRepeat()
                    v.isPressed = true
                    if (haptic) v.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
                    k.act()
                    if (k.repeat) { repeatView = v; repeater.action = k.act; repeater.delay = 80L; handler.postDelayed(repeater, 320) }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (k.repeat && (e.x < 0 || e.y < 0 || e.x > v.width || e.y > v.height)) stopRepeat()
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    v.isPressed = false
                    if (k.repeat) stopRepeat()
                }
            }
            true
        }
    }

    // ---------- Çeviri (Türkçe <-> İngilizce) ----------
    private fun swapLang() {
        fromTr = !fromTr
        chipFrom.text = if (fromTr) "Türkçe" else "İngilizce"
        chipTo.text = if (fromTr) "İngilizce" else "Türkçe"
        if (tOut.isNotBlank()) { tbuf.setLength(0); tbuf.append(tOut) }
        refreshTranslate()
    }

    private fun refreshTranslate() {
        tInput.text = tbuf.toString()
        handler.removeCallbacks(trRunnable)
        if (tbuf.isBlank()) { tOut = ""; tOutput.text = ""; reqId++; return }
        handler.postDelayed(trRunnable, 250)
    }

    private fun doTranslate() {
        val q = tbuf.toString()
        val id = ++reqId
        val sl = if (fromTr) "tr" else "en"
        val tl = if (fromTr) "en" else "tr"
        net.execute {
            val res: String? = try {
                val u = URL("https://translate.googleapis.com/translate_a/single?client=gtx&sl=$sl&tl=$tl&dt=t&q=" + URLEncoder.encode(q, "UTF-8"))
                val c = u.openConnection() as HttpURLConnection
                c.connectTimeout = 5000; c.readTimeout = 5000
                val txt = c.inputStream.bufferedReader().use { it.readText() }
                val a = JSONArray(txt).getJSONArray(0)
                val sb = StringBuilder()
                for (i in 0 until a.length()) sb.append(a.getJSONArray(i).optString(0, ""))
                sb.toString()
            } catch (e: Exception) { null }
            handler.post {
                if (id == reqId) {
                    tOut = res ?: ""
                    tOutput.text = res ?: "Çeviri alınamadı (internet?)"
                }
            }
        }
    }

    // ---------- Ekran görüntüsü önizleme ----------
    private fun loadThumbs() {
        val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(perm) != PackageManager.PERMISSION_GRANTED) {
            lastThumbKey = ""
            thumbs.removeAllViews()
            thumbs.addView(TextView(this).apply { text = "Önizleme için uygulamadan izin ver"; setTextColor(0xFF999999.toInt()); textSize = 12f })
            return
        }
        bg.execute {
            val ids = mutableListOf<Pair<Long, String>>()
            try {
                val sel = "${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? OR ${MediaStore.Images.Media.RELATIVE_PATH} LIKE ? OR ${MediaStore.Images.Media.DISPLAY_NAME} LIKE ?"
                contentResolver.query(
                    MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.MIME_TYPE),
                    sel, arrayOf("%creenshot%", "%Ekran%", "%creenshot%"),
                    "${MediaStore.Images.Media.DATE_ADDED} DESC"
                )?.use { c ->
                    while (c.moveToNext() && ids.size < 5) ids.add(Pair(c.getLong(0), c.getString(1) ?: "image/png"))
                }
            } catch (_: Exception) {}
            val key = ids.joinToString(",") { it.first.toString() }
            if (key == lastThumbKey) return@execute
            val out = ids.map { (id, mime) ->
                val uri = Uri.withAppendedPath(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, id.toString())
                val bmp = thumbCache[uri.toString()] ?: try {
                    contentResolver.loadThumbnail(uri, Size(160, 160), null).also { thumbCache[uri.toString()] = it }
                } catch (e: Exception) { null }
                Shot(uri, mime, bmp)
            }
            handler.post {
                lastThumbKey = key
                thumbs.removeAllViews()
                for (s in out) {
                    val iv = ImageView(this).apply {
                        scaleType = ImageView.ScaleType.CENTER_CROP
                        setBackgroundResource(R.drawable.thumb_bg)
                        outlineProvider = ViewOutlineProvider.BACKGROUND; clipToOutline = true
                        s.bmp?.let { setImageBitmap(it) }
                        setOnClickListener { sendImage(s) }
                    }
                    thumbs.addView(iv, LinearLayout.LayoutParams(0, -1, 1f).apply { setMargins(dp(3), 0, dp(3), 0) })
                }
            }
        }
    }

    private fun sendImage(s: Shot) {
        val ic = currentInputConnection ?: return
        val ei = currentInputEditorInfo
        val ok = EditorInfoCompat.getContentMimeTypes(ei).any { ClipDescription.compareMimeTypes(s.mime, it) }
        if (ok) {
            val info = InputContentInfoCompat(s.uri, ClipDescription("screenshot", arrayOf(s.mime)), null)
            if (InputConnectionCompat.commitContent(ic, ei, info, InputConnectionCompat.INPUT_CONTENT_GRANT_READ_URI_PERMISSION, null)) return
        }
        cm.setPrimaryClip(ClipData.newUri(contentResolver, "screenshot", s.uri))
        Toast.makeText(this, "Bu alan görsel kabul etmiyor; panoya kopyalandı, yapıştırabilirsin", Toast.LENGTH_LONG).show()
    }

    // ---------- Paneller: 0 tuşlar, 1 pano, 2 tuş boyutu, 3 çeviri ----------
    private fun showPanel(which: Int) {
        if (!::clipPanel.isInitialized) return
        stopRepeat()
        translating = which == 3
        if (which == 1 || which == 3) setTools(true, false)
        hl(btnTr, translating)
        hl(btnCl, which == 1)
        clipPanel.visibility = if (which == 1) View.VISIBLE else View.GONE
        sizePanel.visibility = if (which == 2) View.VISIBLE else View.GONE
        translatePanel.visibility = if (translating) View.VISIBLE else View.GONE
        keys.visibility = if (which == 1) View.INVISIBLE else View.VISIBLE
        if (!translating) {
            tbuf.setLength(0); tOut = ""; reqId++
            handler.removeCallbacks(trRunnable)
            tInput.text = ""; tOutput.text = ""
        }
        for (v in enterViews) v.text = if (translating) "✓" else "↵"
        if (which == 1) reloadClips()
    }

    private fun reloadClips() {
        val list = (store.pinned().map { ClipItem(it, true) } + store.history().map { ClipItem(it, false) }).toMutableList()
        adapter.submit(list)
    }
}
