package com.example.mykeyboard

import android.content.Context
import android.net.Uri
import android.provider.DocumentsContract
import org.json.JSONArray
import org.json.JSONObject
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Otomatik yedek: BackupActivity ile aynı klasöre (Drive'da seçilmiş) AYNI biçimde "klavyeyedegim_TARİH_SAAT.json" yazar,
 * böylece "Yedekten geri yükle" en son otomatik yedeği de bulur. Klasör hiç seçilmediyse hiçbir şey yapmaz.
 * Klasörde zaten yedek varsa YENİ dosya açmaz: en son yedeğin üzerine yazar ve adını günceller.
 * Ad biçimi: klavyeyedegim_BOYUT_SAAT_GÜN:AYYIL  (örn. klavyeyedegim_12.3KB_14_28:1026.json)
 * Otomatikte: en az 3 saatte bir, sadece içerik değiştiyse.
 */
object AutoBackup {
    private const val MIN_GAP_MS = 3L * 60 * 60 * 1000
    private const val RETRY_MS = 60L * 60 * 1000

    class Result(val ok: Boolean, val folder: String, val msg: String?)
    class Written(val name: String, val doc: Uri, val bytes: Long, val overwrote: Boolean)

    private fun sizeLabel(b: Long): String = when {
        b < 1024 -> "${b}B"
        b < 1024 * 1024 -> String.format(Locale.US, "%.1fKB", b / 1024.0)
        else -> String.format(Locale.US, "%.2fMB", b / 1048576.0)
    }

    /** klavyeyedegim_BOYUT_SAAT_GÜN:AYYIL.json */
    fun backupName(bytes: Long, now: Long): String {
        val d = Date(now)
        val hh = SimpleDateFormat("HH", Locale.US).format(d)
        val dm = SimpleDateFormat("dd:MMyy", Locale.US).format(d)
        return "klavyeyedegim_${sizeLabel(bytes)}_${hh}_$dm.json"
    }

    /** Klasördeki en son "klavyeyedegim_*.json" dosyası (yoksa null). */
    private fun findLatest(ctx: Context, tree: Uri): Uri? {
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val cols = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_LAST_MODIFIED
        )
        var bestId: String? = null; var bestWhen = -1L
        ctx.contentResolver.query(children, cols, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val name = c.getString(1) ?: continue
                if (!name.startsWith("klavyeyedegim_") || !name.endsWith(".json")) continue
                val t = if (c.isNull(2)) 0L else c.getLong(2)
                if (t > bestWhen) { bestWhen = t; bestId = c.getString(0) }
            }
        }
        val id = bestId ?: return null
        return DocumentsContract.buildDocumentUriUsingTree(tree, id)
    }

    /** Yedeği yazar: klasörde yedek varsa üzerine yazar (adı güncellenir), yoksa yeni dosya açar. Arka plan iş parçacığında çağır. */
    fun write(ctx: Context, tree: Uri, root: JSONObject, now: Long): Written {
        val cr = ctx.contentResolver
        val bytes = root.toString(2).toByteArray(Charsets.UTF_8)
        val name = backupName(bytes.size.toLong(), now)
        val existing = try { findLatest(ctx, tree) } catch (_: Exception) { null }
        if (existing != null) {
            try {
                cr.openOutputStream(existing, "wt")?.use { it.write(bytes) } ?: throw IllegalStateException("Dosya yazılamadı")
                var doc = existing
                try { DocumentsContract.renameDocument(cr, existing, name)?.let { doc = it } } catch (_: Exception) {}
                return Written(name, doc, bytes.size.toLong(), true)
            } catch (_: Exception) { /* üzerine yazılamadıysa yeni dosya aç */ }
        }
        val parent = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        val doc = DocumentsContract.createDocument(cr, parent, "application/json", name)
            ?: throw IllegalStateException("Dosya oluşturulamadı")
        cr.openOutputStream(doc, "wt")?.use { it.write(bytes) } ?: throw IllegalStateException("Dosya yazılamadı")
        return Written(name, doc, bytes.size.toLong(), false)
    }

    private fun sp(ctx: Context) = ctx.getSharedPreferences("backup", Context.MODE_PRIVATE)

    fun due(ctx: Context): Boolean {
        val p = sp(ctx)
        if (p.getString("tree", null) == null) return false
        val last = p.getLong("autoAt", 0L)
        val now = System.currentTimeMillis()
        return last > now || now - last >= MIN_GAP_MS   // saat geri alındıysa da dene
    }

    private fun dump(ctx: Context, name: String): JSONObject {
        val o = JSONObject()
        val all = ctx.getSharedPreferences(name, Context.MODE_PRIVATE).all
        for (k in all.keys.sorted()) {
            when (val v = all[k]) {
                is Set<*> -> o.put(k, JSONArray(v.map { it.toString() }.sorted()))
                null -> {}
                else -> o.put(k, v)
            }
        }
        return o
    }

    private fun folderName(ctx: Context, tree: Uri): String = try {
        val doc = DocumentsContract.buildDocumentUriUsingTree(tree, DocumentsContract.getTreeDocumentId(tree))
        ctx.contentResolver.query(doc, arrayOf(DocumentsContract.Document.COLUMN_DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        } ?: "Drive"
    } catch (_: Exception) { "Drive" }

    /** Arka plan iş parçacığında çağır. null = yapılacak bir şey yok (içerik değişmemiş). */
    fun run(ctx: Context): Result? {
        val p = sp(ctx)
        val treeStr = p.getString("tree", null) ?: return null
        val tree = Uri.parse(treeStr)
        val now = System.currentTimeMillis()
        val folder = folderName(ctx, tree)
        try {
            val canWrite = ctx.contentResolver.persistedUriPermissions.any { it.uri == tree && it.isWritePermission }
            if (!canWrite) throw IllegalStateException("Klasör izni kalkmış; Yedekle'ye basıp klasörü yeniden seç")

            val root = JSONObject()
            root.put("app", "MyKeyboard")
            root.put("clips", dump(ctx, "clips"))
            root.put("ui", dump(ctx, "ui"))
            val hash = MessageDigest.getInstance("SHA-256").digest(root.toString().toByteArray(Charsets.UTF_8))
                .joinToString("") { "%02x".format(it) }
            if (hash == p.getString("autoHash", null)) { p.edit().putLong("autoAt", now).apply(); return null }
            root.put("savedAt", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(now)))

            write(ctx, tree, root, now)
            p.edit().putString("autoHash", hash).putLong("autoAt", now).apply()
            return Result(true, folder, null)
        } catch (e: Exception) {
            // Başarısızsa 1 saat sonra tekrar dene
            p.edit().putLong("autoAt", now - MIN_GAP_MS + RETRY_MS).apply()
            return Result(false, folder, e.message ?: e.javaClass.simpleName)
        }
    }
}
