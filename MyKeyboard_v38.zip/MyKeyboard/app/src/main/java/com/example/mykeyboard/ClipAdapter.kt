package com.example.mykeyboard

import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class ClipItem(val text: String, val pinned: Boolean, val header: Boolean = false, val title: String = "")

class ClipAdapter(
    private val onInsert: (ClipItem) -> Unit,
    private val onPin: (ClipItem) -> Unit,
    private val onDelete: (ClipItem) -> Unit,
    private val onEdit: (ClipItem) -> Unit,
    private val onDrag: (RecyclerView.ViewHolder) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var items: MutableList<ClipItem> = mutableListOf()

    fun submit(list: MutableList<ClipItem>) { items = list; notifyDataSetChanged() }

    fun move(from: Int, to: Int) {
        if (from < 0 || to < 0 || from >= items.size || to >= items.size) return
        items.add(to, items.removeAt(from))
        notifyItemMoved(from, to)
    }

    class VH(v: View) : RecyclerView.ViewHolder(v) {
        val text: TextView = v.findViewById(R.id.clipText)
        val title: TextView? = v.findViewById(R.id.clipTitle)          // sadece sabitlenen düzeninde var
        val body: View = v.findViewById<View>(R.id.clipBody) ?: text   // tıklanan alan (başlık + metin)
        val pin: TextView = v.findViewById(R.id.clipPin)
        val del: TextView = v.findViewById(R.id.clipDel)
        val drag: TextView = v.findViewById(R.id.clipDrag)
    }

    class HVH(v: View) : RecyclerView.ViewHolder(v) {
        val title: TextView = v.findViewById(R.id.clipHeader)
    }

    override fun getItemViewType(position: Int) = if (items[position].header) 2 else if (items[position].pinned) 1 else 0

    override fun onCreateViewHolder(p: ViewGroup, t: Int): RecyclerView.ViewHolder {
        val inf = LayoutInflater.from(p.context)
        return if (t == 2) HVH(inf.inflate(R.layout.item_header, p, false))
        else VH(inf.inflate(if (t == 1) R.layout.item_pinned else R.layout.item_clip, p, false))
    }

    override fun getItemCount() = items.size

    private fun cur(h: VH): ClipItem? = items.getOrNull(h.bindingAdapterPosition)

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, i: Int) {
        val item = items[i]
        if (holder is HVH) { holder.title.text = item.text; return }
        val h = holder as VH
        h.text.text = item.text
        h.title?.let { t ->
            if (item.pinned && item.title.isNotEmpty()) { t.text = item.title; t.visibility = View.VISIBLE }
            else t.visibility = View.GONE
        }
        h.pin.text = if (item.pinned) "★" else "☆"
        h.itemView.setBackgroundResource(if (item.pinned) R.drawable.pinned_bg else R.drawable.key_bg)
        h.body.setOnClickListener { cur(h)?.let(onInsert) }
        // Basılı tut: düzenle (sabitlerde başlık da eklenir; sabitlemek için ★ simgesi)
        h.body.setOnLongClickListener { cur(h)?.let(onEdit); true }
        h.pin.setOnClickListener { cur(h)?.let(onPin) }
        h.del.setOnClickListener { cur(h)?.let(onDelete) }
        h.drag.setOnTouchListener { _, e ->
            if (e.actionMasked == MotionEvent.ACTION_DOWN) onDrag(h)
            false
        }
    }
}
