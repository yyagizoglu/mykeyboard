package com.fotoliz.app

import java.io.File
import java.util.PriorityQueue
import kotlin.math.max
import kotlin.math.sqrt

// ---- AYARLAR (hassasiyet) -------------------------------------------------------------------
const val Q_GOOD = 0.35f        // Bu kalitenin altındaki yüzler (çok küçük / yandan / eğik) gruplamayı bozmasın diye sonradan eklenir
const val CORE_THR = 0.50f      // 1. aşama: çok emin olunan küçük gruplar (yüz → grup merkezi benzerliği)
const val MERGE_THR = 0.45f     // Analiz sırasında yapılan GÜVENLİ birleştirme. Asıl birleştirme sonuç ekranındaki/albüm ekranındaki benzerlik eşiğiyle (varsayılan 0.25) yapılır
const val LINK_PENALTY = 0.06f  // Gözlüklü↔gözlüksüz gibi "zincir" benzerliğinde merkez eşiğine göre ek güvenlik payı
const val WEAK_THR = 0.42f      // Düşük kaliteli yüzü bir gruba eklemek için gereken benzerlik
const val MAX_REPS = 8          // Her grubun içinde saklanan farklı görünümlü örnek sayısı (gözlüklü, sakallı, makyajlı...)
const val PREFILTER = 0.15f     // Merkezleri bundan uzak olan gruplar hiç karşılaştırılmaz (hız)

class FaceRec(val emb: FloatArray, val photo: String, val q: Float, val area: Int, val thumb: String)
class ClusterOut(val clusters: List<Cluster>, val weakSkipped: Int)

private class W(val photos: HashSet<String> = HashSet(), val embs: ArrayList<FloatArray> = ArrayList()) {
    var sum: FloatArray = FloatArray(0)
    var cent: FloatArray = FloatArray(0)
    var thumb = ""; var score = 0
    fun add(r: FaceRec) {
        if (sum.isEmpty()) sum = FloatArray(r.emb.size)
        for (i in sum.indices) sum[i] += r.emb[i]
        cent = normalize(sum)
        photos.add(r.photo); embs.add(r.emb)
        val sc = (r.area * r.q).toInt()
        if (r.thumb.isNotEmpty() && sc >= score) { score = sc; thumb = r.thumb }
    }
}

/** Bir grubu en iyi temsil eden, birbirinden FARKLI görünümdeki en fazla k yüzü seçer (farthest-point). */
fun pickReps(embs: List<FloatArray>, k: Int): List<FloatArray> {
    if (embs.size <= k) return ArrayList(embs)
    val mean = FloatArray(embs[0].size)
    for (e in embs) for (i in mean.indices) mean[i] += e[i]
    val m = normalize(mean)
    var first = 0; var fs = -2f
    for (i in embs.indices) { val s = dot(embs[i], m); if (s > fs) { fs = s; first = i } }
    val chosen = arrayListOf(embs[first])
    val maxSim = FloatArray(embs.size) { dot(embs[it], embs[first]) }
    while (chosen.size < k) {
        var bi = -1; var bv = 2f
        for (i in embs.indices) if (maxSim[i] < bv) { bv = maxSim[i]; bi = i }
        if (bi < 0) break
        chosen.add(embs[bi])
        for (i in embs.indices) { val s = dot(embs[i], embs[bi]); if (s > maxSim[i]) maxSim[i] = s }
    }
    return chosen
}

/**
 * İki grubun "aynı kişi" skoru.
 *  - Aynı fotoğrafta birlikte görünüyorlarsa kesinlikle farklı kişidir → -1.
 *  - Merkez benzerliği VEYA en benzer örnek çiftlerinin ortalaması (-LINK_PENALTY) → hangisi yüksekse.
 *    Böylece gözlüklü grup ile gözlüksüz grubun merkezleri uzak olsa bile, aralarındaki benzer örnekler köprü kurar.
 */
fun linkScore(a: Cluster, b: Cluster): Float {
    val cs = dot(a.centroid, b.centroid)
    if (cs < PREFILTER) return cs
    val small = if (a.photos.size <= b.photos.size) a else b
    val big = if (small === a) b else a
    for (p in small.photos) if (p in big.photos) return -1f
    if (a.reps.isEmpty() || b.reps.isEmpty()) return cs
    var t1 = -2f; var t2 = -2f; var t3 = -2f; var n = 0
    for (x in a.reps) for (y in b.reps) {
        val s = dot(x, y); n++
        if (s > t1) { t3 = t2; t2 = t1; t1 = s } else if (s > t2) { t3 = t2; t2 = s } else if (s > t3) t3 = s
    }
    val k = minOf(3, n)
    val mean = when (k) { 1 -> t1; 2 -> (t1 + t2) / 2f; else -> (t1 + t2 + t3) / 3f }
    return max(cs, mean - LINK_PENALTY)
}

private class E(val s: Float, val i: Int, val j: Int, val vi: Int, val vj: Int)

/** En benzer çiftten başlayarak, skor eşiği geçtiği sürece grupları birleştirir. */
fun agglomerate(list: List<Cluster>, thr: Float): List<Cluster> {
    val n = list.size
    if (n < 2) return list.sortedByDescending { it.photos.size }
    val cl = arrayOfNulls<Cluster>(n); for (i in 0 until n) cl[i] = list[i]
    val alive = BooleanArray(n) { true }; val ver = IntArray(n)
    val pq = PriorityQueue<E>(11, compareByDescending<E> { it.s })
    fun push(i: Int, j: Int) { val s = linkScore(cl[i]!!, cl[j]!!); if (s >= thr) pq.add(E(s, i, j, ver[i], ver[j])) }
    for (i in 0 until n) for (j in i + 1 until n) push(i, j)
    while (pq.isNotEmpty()) {
        val e = pq.poll() ?: break
        if (!alive[e.i] || !alive[e.j] || ver[e.i] != e.vi || ver[e.j] != e.vj) continue
        cl[e.i] = mergeTwo(cl[e.i]!!, cl[e.j]!!); alive[e.j] = false; ver[e.i]++
        for (k in 0 until n) if (alive[k] && k != e.i) push(e.i, k)
    }
    return (0 until n).filter { alive[it] }.map { cl[it]!! }.sortedByDescending { it.photos.size }
}

object Clusterer {
    fun run(recs: List<FaceRec>, key: String, thumbDir: File): ClusterOut {
        val good = recs.filter { it.q >= Q_GOOD }.sortedByDescending { it.q * sqrt(it.area.toFloat()) }
        val weak = recs.filter { it.q < Q_GOOD }

        // 1) En kaliteli yüzlerden başlayarak saf çekirdek gruplar kur (aynı fotoğraftaki iki yüz asla aynı gruba girmez)
        val ws = ArrayList<W>()
        for (r in good) {
            var best: W? = null; var bs = CORE_THR
            for (w in ws) {
                if (r.photo in w.photos) continue
                val s = dot(w.cent, r.emb)
                if (s >= bs) { bs = s; best = w }
            }
            if (best == null) { best = W(); ws.add(best) }
            best.add(r)
        }
        val init = ws.mapIndexed { i, w ->
            Cluster(i, w.cent, w.embs.size, LinkedHashSet(w.photos), w.thumb, w.score, pickReps(w.embs, MAX_REPS))
        }

        // 2) Gruplar arası derin birleştirme (gözlük/sakal/makyaj farkını örnek köprüleriyle aşar)
        val merged = agglomerate(init, MERGE_THR)

        // 3) Düşük kaliteli yüzleri, yeterince benziyorsa mevcut gruplara ekle (yeni grup açmaz)
        var skipped = 0
        for (r in weak) {
            var best: Cluster? = null; var bs = WEAK_THR
            for (c in merged) {
                if (r.photo in c.photos) continue
                var s = dot(c.centroid, r.emb)
                for (x in c.reps) { val t = dot(x, r.emb) - LINK_PENALTY / 2; if (t > s) s = t }
                if (s >= bs) { bs = s; best = c }
            }
            if (best == null) skipped++ else { best.photos.add(r.photo); best.count++ }
        }

        // 4) Küçük resimleri son isimlerine taşı, geçici dosyaları temizle
        val out = merged.filter { it.thumb.isNotEmpty() }.mapIndexed { i, c ->
            val dst = File(thumbDir, "${key}_$i.jpg")
            try { File(c.thumb).copyTo(dst, overwrite = true); HairStore.copy(c.thumb, dst.absolutePath) } catch (e: Exception) {}
            Cluster(i, c.centroid, c.count, c.photos, dst.absolutePath, c.area, c.reps)
        }
        thumbDir.listFiles()?.filter { it.name.startsWith(key + "_f") }?.forEach { it.delete() }
        return ClusterOut(out, skipped)
    }
}
