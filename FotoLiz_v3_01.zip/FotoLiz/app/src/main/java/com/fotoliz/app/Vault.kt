package com.fotoliz.app

import android.content.Context
import android.util.Base64
import androidx.compose.foundation.Canvas
import androidx.compose.material.icons.filled.Lock
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/** Silme koruması: şifre ya da desen. Gizli bilgi düz saklanmaz; tuzlu PBKDF2 özeti saklanır. */
object Vault {
    private fun sp(ctx: Context) = ctx.getSharedPreferences("vault", 0)
    /** Kilit tanımlı mı: şifre / desen özeti var ya da yöntem olarak parmak izi seçilmiş. */
    /** Kayıtlı bir şifre / desen / parmak izi yöntemi var mı (kilit kapalı olsa bile saklı kalır). */
    fun hasSecret(ctx: Context) = sp(ctx).contains("hash") || sp(ctx).getBoolean("bio_only", false)
    /** Şifreli / Şifresiz düğmesi. Eski kurulumlarda (düğme hiç kullanılmadıysa) kilit tanımlıysa açık sayılır. */
    fun enabled(ctx: Context) = sp(ctx).getBoolean("enabled", hasSecret(ctx))
    fun setEnabled(ctx: Context, on: Boolean) { sp(ctx).edit().putBoolean("enabled", on).apply(); if (on) AppLock.markAuth() }
    /** Kilit etkin mi: yöntem tanımlı VE "Şifreli" seçili. "Şifresiz"de program hiçbir yerde doğrulama istemez; yöntem silinmez. */
    fun isSet(ctx: Context) = hasSecret(ctx) && enabled(ctx)
    /** Seçili yöntem: "pin" (şifre) | "pattern" (desen) | "bio" (parmak izi). Yalnızca seçili yöntem kullanılır. */
    fun mode(ctx: Context) = if (sp(ctx).getBoolean("bio_only", false)) "bio" else (sp(ctx).getString("mode", "pin") ?: "pin")
    fun bioOn(ctx: Context) = mode(ctx) == "bio"
    /** Yöntem olarak parmak izini seç: şifre / desen özeti silinir. */
    fun setBioOnly(ctx: Context) { sp(ctx).edit().putBoolean("bio_only", true).putBoolean("enabled", true).putString("mode", "bio").remove("hash").remove("salt").apply(); AppLock.markAuth() }
    fun lockOnOpen(ctx: Context) = sp(ctx).getBoolean("lock_open", true)     // program açılırken sor
    /** Arka plandan dönünce kilit istenmeden önce geçmesi gereken süre (sn). 0 = uygulamadan her çıkışta. */
    val RELOCK_STEPS = intArrayOf(0, 10, 30, 60, 180, 300, 600)
    fun relockIndex(ctx: Context) = RELOCK_STEPS.indexOf(sp(ctx).getInt("relock_sec", 60)).let { if (it < 0) 3 else it }
    fun relockSec(ctx: Context) = RELOCK_STEPS[relockIndex(ctx)]
    fun setRelockIndex(ctx: Context, i: Int) { sp(ctx).edit().putInt("relock_sec", RELOCK_STEPS[i.coerceIn(0, RELOCK_STEPS.size - 1)]).apply() }
    fun relockLabel(sec: Int) = when { sec == 0 -> "Hemen (her çıkışta)"; sec < 60 -> "$sec sn"; else -> "${sec / 60} dk" }
    fun setLockOnOpen(ctx: Context, on: Boolean) { sp(ctx).edit().putBoolean("lock_open", on).apply() }

    private fun hash(secret: String, salt: ByteArray): String {
        val f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256")
        return Base64.encodeToString(f.generateSecret(PBEKeySpec(secret.toCharArray(), salt, 20000, 256)).encoded, Base64.NO_WRAP)
    }

    fun set(ctx: Context, mode: String, secret: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        sp(ctx).edit().putString("mode", mode).putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", hash(secret, salt)).putBoolean("bio_only", false).putBoolean("enabled", true).apply()
        AppLock.markAuth()      // yeni kilidi az önce sen tanımladın: süre şimdi başlar
    }

    fun verify(ctx: Context, secret: String): Boolean {
        val p = sp(ctx)
        val salt = Base64.decode(p.getString("salt", "") ?: return false, Base64.NO_WRAP)
        return hash(secret, salt) == p.getString("hash", null)
    }
}

/** 3x3 desen tahtası: parmakla noktaları birleştir, bırakınca nokta sırası döner. */
@Composable
fun PatternPad(onComplete: (List<Int>) -> Unit, modifier: Modifier = Modifier) {
    val done by rememberUpdatedState(onComplete)
    var path by remember { mutableStateOf(listOf<Int>()) }
    var cur by remember { mutableStateOf<Offset?>(null) }
    var box by remember { mutableStateOf(IntSize.Zero) }
    val primary = MaterialTheme.colorScheme.primary
    val dim = MaterialTheme.colorScheme.outline
    fun center(i: Int): Offset { val w = box.width / 3f; val h = box.height / 3f; return Offset(w * (i % 3) + w / 2, h * (i / 3) + h / 2) }
    fun hit(p: Offset): Int? { val r = box.width / 3f * 0.38f; return (0..8).firstOrNull { (center(it) - p).getDistance() < r } }
    Canvas(modifier.size(240.dp).onSizeChanged { box = it }.pointerInput(Unit) {
        detectDragGestures(
            onDragStart = { p -> path = emptyList(); hit(p)?.let { path = listOf(it) }; cur = p },
            onDrag = { change, _ -> val p = change.position; cur = p; hit(p)?.let { if (it !in path) path = path + it } },
            onDragEnd = { val r = path; path = emptyList(); cur = null; if (r.isNotEmpty()) done(r) },
            onDragCancel = { path = emptyList(); cur = null })
    }) {
        val w = 6.dp.toPx()
        for (k in 0 until path.size - 1) drawLine(primary, center(path[k]), center(path[k + 1]), strokeWidth = w, cap = StrokeCap.Round)
        val c = cur
        if (path.isNotEmpty() && c != null) drawLine(primary, center(path.last()), c, strokeWidth = w, cap = StrokeCap.Round)
        for (i in 0..8) {
            val on = i in path
            drawCircle(if (on) primary else dim, radius = if (on) 12.dp.toPx() else 7.dp.toPx(), center = center(i))
        }
    }
}

/**
 * Korumalı işlem penceresi.
 * Koruma tanımlıysa önce doğrulama ister; hiç tanımlı değilse (ilk kullanım) şifre ya da desen tanımlatır.
 * change = true: doğruladıktan sonra yeni şifre / desen tanımlatır.
 */
@Composable
fun VaultDialog(onDismiss: () -> Unit, onOk: () -> Unit, change: Boolean = false, message: String = "Kayıtlı sonuçları silmek için doğrulama gerekir.", startMode: String = "pin") {
    val ctx = LocalContext.current
    val had = remember { Vault.isSet(ctx) }
    val skip = had && AppLock.sessionActive(ctx)       // kilit süresi dolmadı: tekrar doğrulama istenmez
    if (skip && !change) { LaunchedEffect(Unit) { onOk() }; return }
    var verifying by remember { mutableStateOf(had && !skip) }
    if (verifying) {
        if (Vault.mode(ctx) == "bio") UnlockDialog(if (change) "Önce mevcut korumayı doğrulayın" else message, onSuccess = { if (change) verifying = false else onOk() }, onCancel = onDismiss)
        else VerifyStage(change, message, onDismiss) { if (change) verifying = false else onOk() }
    } else SetupStage(had, startMode, onDismiss, onOk)
}

@Composable
internal fun VerifyStage(change: Boolean, message: String, onDismiss: () -> Unit, onVerified: () -> Unit) {
    val ctx = LocalContext.current
    val pin = Vault.mode(ctx) == "pin"
    var err by remember { mutableStateOf<String?>(null) }
    var text by remember { mutableStateOf("") }
    fun check(secret: String) {
        if (Vault.verify(ctx, secret)) { err = null; AppLock.markAuth(); onVerified() }
        else err = if (pin) "Şifre yanlış." else "Desen yanlış."
    }
    AlertDialog(onDismissRequest = onDismiss,
        icon = { if (pin) Icon(androidx.compose.material.icons.Icons.Filled.Lock, null, tint = MaterialTheme.colorScheme.primary) else PatternIcon(MaterialTheme.colorScheme.primary, 28.dp) },
        title = { Text(if (pin) "Şifreyi gir" else "Deseni çiz") },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text(if (change) "Önce mevcut korumayı doğrula." else message, style = MaterialTheme.typography.bodyMedium)
                if (pin) FieldPassword(text, { text = it; err = null }, "Şifre")
                else PatternPad({ check(it.joinToString("-")) })
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            }
        },
        confirmButton = { if (pin) TextButton(onClick = { check(text) }, enabled = text.isNotEmpty()) { Text("Onayla") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } })
}

@Composable
private fun SetupStage(had: Boolean, startMode: String, onDismiss: () -> Unit, onOk: () -> Unit) {
    val ctx = LocalContext.current
    var err by remember { mutableStateOf<String?>(null) }
    var mode by remember { mutableStateOf(if (startMode == "pattern") "pattern" else "pin") }
    var a by remember { mutableStateOf("") }
    var b by remember { mutableStateOf("") }
    var first by remember { mutableStateOf<String?>(null) }   // desen: ilk çizim
    fun save(secret: String) { Vault.set(ctx, mode, secret); onOk() }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (had) "Yeni koruma tanımla" else "Uygulama kilidi tanımla") },
        text = {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Bir şifre ya da desen belirle. Bundan sonra program açılırken, Ayarlar açılırken ve kayıt silinirken bu (ya da açtıysan parmak izi) istenecek.", style = MaterialTheme.typography.bodyMedium)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = mode == "pin", onClick = { mode = "pin"; err = null; first = null }, label = { Text("Şifre") },
                        leadingIcon = { Icon(androidx.compose.material.icons.Icons.Filled.Lock, null, Modifier.size(18.dp)) })
                    FilterChip(selected = mode == "pattern", onClick = { mode = "pattern"; err = null; first = null }, label = { Text("Desen") },
                        leadingIcon = { PatternIcon(MaterialTheme.colorScheme.onSurface, 18.dp) })
                }
                if (mode == "pin") {
                    FieldPassword(a, { a = it; err = null }, "Yeni şifre (en az 4 karakter)")
                    FieldPassword(b, { b = it; err = null }, "Şifre tekrar")
                } else {
                    Text(if (first == null) "Deseni çiz (en az 4 nokta)" else "Aynı deseni tekrar çiz", style = MaterialTheme.typography.titleSmall)
                    PatternPad({ p ->
                        val s = p.joinToString("-")
                        if (p.size < 4) err = "En az 4 nokta birleştir."
                        else if (first == null) { first = s; err = null }
                        else if (first == s) save(s)
                        else { first = null; err = "Desenler uyuşmadı, baştan çiz." }
                    })
                }
                err?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                Text("Şifreni ya da desenini unutursan programa yalnızca uygulama verisi temizlenerek (kayıtlar silinir) yeniden girilebilir. Bu yüzden Drive yedeğini açık tut.", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            if (mode == "pin") TextButton(onClick = { if (a.length < 4) err = "En az 4 karakter." else if (a != b) err = "Şifreler uyuşmuyor." else save(a) },
                enabled = a.isNotEmpty() && b.isNotEmpty()) { Text("Kaydet") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } })
}

@Composable
internal fun FieldPassword(value: String, onChange: (String) -> Unit, label: String) {
    OutlinedTextField(value, onChange, singleLine = true, label = { Text(label) }, modifier = Modifier.fillMaxWidth(),
        visualTransformation = PasswordVisualTransformation(), shape = androidx.compose.foundation.shape.RoundedCornerShape(14.dp),
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password))
}
