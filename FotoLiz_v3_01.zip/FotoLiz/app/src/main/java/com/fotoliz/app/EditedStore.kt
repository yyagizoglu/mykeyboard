package com.fotoliz.app

import android.content.Context
import org.json.JSONArray
import java.io.File

/** "Albümden seç" ile netleştirilen fotoğrafların (kişi/yüz gruplarına bağlı olmayan) kalıcı listesi. Ana ekrandaki Düzenlenenler bölümü bunu da gösterir. */
object EditedStore {
    private fun file(ctx: Context) = File(ctx.filesDir, "edited_standalone.json")

    fun load(ctx: Context): List<String> = try {
        val f = file(ctx)
        if (!f.exists()) emptyList() else { val a = JSONArray(f.readText()); (0 until a.length()).map { a.getString(it) } }
    } catch (e: Exception) { emptyList() }

    fun save(ctx: Context, list: List<String>) {
        val f = file(ctx); val tmp = File(f.parentFile, f.name + ".tmp")
        tmp.writeText(JSONArray(list).toString())
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
    }

    private fun orderFile(ctx: Context) = File(ctx.filesDir, "edited_order.json")
    /** Kullanıcının sürükleyerek verdiği sıra (Düzenlenenler sayfası). */
    fun loadOrder(ctx: Context): List<String> = try {
        val f = orderFile(ctx)
        if (!f.exists()) emptyList() else { val a = JSONArray(f.readText()); (0 until a.length()).map { a.getString(it) } }
    } catch (e: Exception) { emptyList() }
    fun saveOrder(ctx: Context, list: List<String>) {
        try {
            val f = orderFile(ctx); val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(JSONArray(list).toString())
            if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
        } catch (e: Exception) { }
    }

    /** Yeni eklenenler listenin başına gelir (en yeni önce). */
    fun add(ctx: Context, uris: List<String>) { save(ctx, (uris.reversed() + load(ctx)).distinct()) }

    fun remove(ctx: Context, uris: Set<String>) { val cur = load(ctx); if (cur.any { it in uris }) save(ctx, cur.filter { it !in uris }) }
}
