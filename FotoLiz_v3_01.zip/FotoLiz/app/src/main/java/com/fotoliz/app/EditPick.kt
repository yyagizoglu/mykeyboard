package com.fotoliz.app

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/** Düzenlenenler → "Albümden seç": albümlerde gezinip tek tek fotoğraf seç; seçilenler altta görünür; Netleştir ile işlenip Düzenlenenler'e kaydedilir. */
@Composable
fun EditPickScreen(vm: VM) {
    val picked = vm.editPicked
    val album = vm.editAlbum
    Column(Modifier.fillMaxSize()) {
        Box(Modifier.weight(1f)) {
            if (album == null) {
                if (vm.editAlbums.isEmpty()) Text(if (vm.editLoading) "Albümler okunuyor…" else "Albüm bulunamadı. Fotoğraf iznini kontrol edin.", Modifier.padding(16.dp))
                else LazyVerticalGrid(GridCells.Fixed(2), contentPadding = PaddingValues(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(vm.editAlbums, key = { it.id }) { al ->
                        Column(Modifier.clickable { vm.openEditAlbum(al) }) {
                            AsyncImage(al.cover, null, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.Crop)
                            Text(al.name, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                            Text("${al.count} fotoğraf", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            } else {
                LazyVerticalGrid(GridCells.Fixed(3), contentPadding = PaddingValues(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    items(vm.editAlbumPhotos, key = { it }) { u ->
                        val on = u in picked
                        Box(Modifier.aspectRatio(1f).clickable { vm.toggleEditPick(u) }) {
                            AsyncImage(Uri.parse(u), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            if (on) Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.primary.copy(alpha = 0.30f)))
                            Box(Modifier.align(Alignment.TopStart).padding(6.dp).size(24.dp).clip(CircleShape)
                                .background(if (on) MaterialTheme.colorScheme.primary else Color(0x66000000))
                                .border(2.dp, Color.White, CircleShape), contentAlignment = Alignment.Center) {
                                if (on) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
                            }
                        }
                    }
                }
            }
        }
        // Seçilenler: tüm albümler boyunca birikir, burada görünür (dokununca çıkar)
        Surface(tonalElevation = 3.dp) {
            Column(Modifier.fillMaxWidth().padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(if (picked.isEmpty()) "Seçilen yok. Albümlerde gezip fotoğraflara dokunarak seç."
                    else "${picked.size} fotoğraf seçildi • dokununca listeden çıkar", style = MaterialTheme.typography.bodySmall)
                if (picked.isNotEmpty()) LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    items(picked, key = { it }) { u ->
                        Box(Modifier.size(56.dp).clip(RoundedCornerShape(10.dp)).clickable { vm.toggleEditPick(u) }) {
                            AsyncImage(Uri.parse(u), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                            Box(Modifier.align(Alignment.TopEnd).padding(2.dp).size(16.dp).clip(CircleShape).background(Color(0xAA000000)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Filled.Close, null, tint = Color.White, modifier = Modifier.size(11.dp))
                            }
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    if (album != null) OutlinedButton(onClick = { vm.editAlbum = null }, modifier = Modifier.height(52.dp), shape = RoundedCornerShape(14.dp)) { Text("Albümler") }
                    PrimaryAction("Netleştir (${picked.size})", { vm.enhancePicked() }, Modifier.weight(1f), enabled = picked.isNotEmpty() && !vm.enhancing)
                }
            }
        }
    }
}

/** Bulunan kişiye dokununca açılır: kişinin fotoğrafları. Birine dokununca baş bölgesi (saç + boyun üstü) kırpılır, en yüksek kalitede netleştirilip Kaydedilen yüzler'e eklenir. */
@Composable
fun PickFacePhotoScreen(vm: VM) {
    val c = vm.facePickChoice
    val photos = remember(c) { c?.cluster?.photos?.toList().orEmpty() }
    Box(Modifier.fillMaxSize()) {
        LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxSize(), contentPadding = PaddingValues(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            item(span = { androidx.compose.foundation.lazy.grid.GridItemSpan(maxLineSpan) }) {
                Column(Modifier.padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("${c?.label.orEmpty()} • ${photos.size} fotoğraf", style = MaterialTheme.typography.titleMedium)
                    Text("Bir fotoğrafa dokun: yalnızca baş (saç dahil, boyundan yukarısı) kırpılır, en yüksek kalitede netleştirilir ve Kaydedilen yüzler'e eklenir.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    TextButton(onClick = { vm.addFacePlain() }) { Text("Küçük resmi olduğu gibi ekle") }
                }
            }
            items(photos, key = { it }) { u ->
                AsyncImage(Uri.parse(u), null, Modifier.aspectRatio(1f).clickable(enabled = !vm.faceBusy) { vm.addHeadFromPhoto(u) }, contentScale = ContentScale.Crop)
            }
        }
        if (vm.faceBusy) Box(Modifier.fillMaxSize().background(Color(0x99000000)), contentAlignment = Alignment.Center) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                CircularProgressIndicator()
                Text("Baş kırpılıyor ve netleştiriliyor…", color = Color.White, modifier = Modifier.padding(top = 12.dp))
            }
        }
    }
}
