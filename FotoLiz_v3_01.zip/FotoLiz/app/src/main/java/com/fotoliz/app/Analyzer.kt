package com.fotoliz.app

import android.content.Context
import android.graphics.*
import android.net.Uri
import androidx.exifinterface.media.ExifInterface
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetector
import com.google.mlkit.vision.face.FaceLandmark
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.label.ImageLabeler
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.CancellationException
import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ArrayBlockingQueue
import kotlin.math.abs
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

const val MAX_SIDE = 1280          // Analiz için fotoğrafın en uzun kenarı (küçük = hızlı, büyük = küçük yüzleri daha iyi bulur)
const val FAST_DETECT = false      // false = hassas yüz bulma + doğru poz açıları (yavaş ama doğru), true = hızlı
const val FLIP_TTA = false         // true = her yüzü ayna görüntüsüyle de ölçüp ortalar (biraz daha kararlı ama 2x yavaş)
const val MIN_FACE_PX = 40         // Bundan küçük yüzler atlanır

class FaceData(val crop: Bitmap, val emb: FloatArray, val area: Int, val q: Float, val box: Rect = Rect(), val hair: String = "?")   // box: yüzün çözülmüş fotoğraftaki konumu
class Prep(val faces: List<FaceData>, val err: String?, val obj: String? = null, val objThumb: Bitmap? = null)

/** ML Kit ile yüz bulur, MobileFaceNet (TFLite) ile her yüzün "parmak izi" vektörünü çıkarır. Çok iş parçacıklı çalışır. */
class Analyzer(ctx: Context, parallel: Int = 3, private val genderFilter: String? = null) {   // genderFilter: "M" / "F" / null (hepsi)
    private val detectors = ArrayBlockingQueue<FaceDetector>(parallel)
    private val labelers = ArrayBlockingQueue<ImageLabeler>(parallel)
    private val gLabelers = ArrayBlockingQueue<ImageLabeler>(parallel)   // yalnızca cinsiyet filtresi açıksa dolar
    private val env: OrtEnvironment = OrtEnvironment.getEnvironment()
    private val session: OrtSession
    private val inName: String
    private val size = 112

    init {
        repeat(parallel) {
            detectors.add(FaceDetection.getClient(
                FaceDetectorOptions.Builder()
                    .setPerformanceMode(if (FAST_DETECT) FaceDetectorOptions.PERFORMANCE_MODE_FAST else FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
                    .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
                    .setMinFaceSize(0.04f).build()))
        }
        if (genderFilter != null) repeat(parallel) { gLabelers.add(ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.3f).build())) }
        repeat(parallel) { labelers.add(ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.5f).build())) }
        // Model: elle seçilen model.onnx varsa o, yoksa APK içindeki ArcFace (arcface.onnx) dosyası
        val manual = java.io.File(ctx.filesDir, "model.onnx")
        val path = if (manual.exists()) manual else {
            val dst = java.io.File(ctx.filesDir, "arcface.onnx")
            if (!(dst.exists() && dst.length() > 100_000_000L)) try {
                val len = ctx.assets.openFd("arcface.onnx").use { it.declaredLength }
                if (!dst.exists() || dst.length() != len) {
                    val tmp = java.io.File(ctx.filesDir, "arcface.tmp")
                    ctx.assets.open("arcface.onnx").use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                    dst.delete(); tmp.renameTo(dst)
                }
            } catch (e: Exception) {
                throw Exception("Yüz tanıma modeli henüz indirilmedi. Ana ekranda indirme bitene kadar bekleyin.")
            }
            dst
        }
        session = try {
            env.createSession(path.absolutePath, OrtSession.SessionOptions().apply {
                setIntraOpNumThreads((Runtime.getRuntime().availableProcessors() / parallel).coerceIn(2, 4))
                setInterOpNumThreads(1)
            })
        } catch (e: Exception) { throw Exception("Model okunamadı (geçerli bir .onnx değil): ${e.message}") }
        inName = session.inputNames.iterator().next()
    }

    /** Analize başlamadan modelin gerçekten çalıştığını doğrular; bozuksa 10 dk beklemeden hemen hata verir. */
    fun selfTest() {
        try { embed(Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)) }
        catch (e: Exception) { throw Exception("Model çalıştırılamadı: ${e.javaClass.simpleName}: ${e.message}") }
    }

    fun close() {
        detectors.forEach { try { it.close() } catch (e: Exception) {} }
        labelers.forEach { try { it.close() } catch (e: Exception) {} }
        gLabelers.forEach { try { it.close() } catch (e: Exception) {} }
        try { session.close() } catch (e: Exception) {}
    }

    /** Tek fotoğraf: çöz → yüzleri bul → parmak izi çıkar. Hata olursa sessizce yutmaz, mesajını döndürür. */
    fun process(ctx: Context, uri: Uri): Prep = try {
        val bmp = decode(ctx, uri)
        if (bmp == null) Prep(emptyList(), "Fotoğraf çözülemedi") else {
            val f = faces(bmp, if (genderFilter != null) ({ c: Bitmap -> genderOk(c) }) else null)
            if (genderFilter != null) Prep(f, null)   // cinsiyet filtresi açık: nesne gruplaması yapılmaz
            // Yüz yoksa: fotoğraftaki nesneye bakıp (evrak, araba, motor...) o ada göre gruplamak için etiketle
            else if (f.isEmpty()) Prep(f, null, try { objectName(bmp) } catch (e: CancellationException) { throw e } catch (e: Throwable) { null }, thumbOf(bmp))
            else Prep(f, null)
        }
    } catch (e: CancellationException) { throw e
    } catch (e: Throwable) { Prep(emptyList(), "${e.javaClass.simpleName}: ${e.message}") }

    /** Yüz kırpmasının cinsiyeti filtreyle uyuşuyor mu? Belirsiz (?) yüzler alınmaz. */
    private fun genderOk(crop: Bitmap): Boolean {
        val want = genderFilter ?: return true
        val lab = gLabelers.take()
        val g = try { FaceAttrs.genderOf(Tasks.await(lab.process(InputImage.fromBitmap(crop, 0)))) }
            catch (e: CancellationException) { throw e } catch (e: Throwable) { "?" } finally { gLabelers.put(lab) }
        return g == want
    }

    private fun objectName(bmp: Bitmap): String? {
        val lab = labelers.take()
        val res = try { Tasks.await(lab.process(InputImage.fromBitmap(bmp, 0))) } finally { labelers.put(lab) }
        return ObjectNames.pick(res.map { it.text to it.confidence })
    }

    /** Grup küçük resmi için ortadan kare kırpılmış 160x160 önizleme. */
    private fun thumbOf(b: Bitmap): Bitmap {
        val side = min(b.width, b.height)
        val sq = Bitmap.createBitmap(b, (b.width - side) / 2, (b.height - side) / 2, side, side)
        return Bitmap.createScaledBitmap(sq, 160, 160, true)
    }

    private fun argb(b: Bitmap): Bitmap = if (b.config == Bitmap.Config.ARGB_8888) b else b.copy(Bitmap.Config.ARGB_8888, false)

    fun decode(ctx: Context, uri: Uri): Bitmap? {
        try {
            // Tek geçişte çöz + küçült + EXIF yönünü otomatik uygula (eski yöntemden çok daha hızlı)
            val src = ImageDecoder.createSource(ctx.contentResolver, uri)
            val bmp = ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val w = info.size.width; val h = info.size.height; val m = max(w, h)
                if (m > MAX_SIDE) {
                    val sc = MAX_SIDE.toFloat() / m
                    dec.setTargetSize((w * sc).toInt().coerceAtLeast(1), (h * sc).toInt().coerceAtLeast(1))
                }
            }
            return argb(bmp)
        } catch (e: CancellationException) { throw e
        } catch (e: Exception) { return decodeLegacy(ctx, uri) }
    }

    private fun decodeLegacy(ctx: Context, uri: Uri): Bitmap? {
        val cr = ctx.contentResolver
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        cr.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, o) }
        if (o.outWidth <= 0) return null
        var s = 1
        while (max(o.outWidth, o.outHeight) / s > MAX_SIDE) s *= 2
        val bmp = cr.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, BitmapFactory.Options().apply { inSampleSize = s })
        } ?: return null
        val ori = try {
            cr.openInputStream(uri)?.use { ExifInterface(it).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1) } ?: 1
        } catch (e: Exception) { 1 }
        val deg = when (ori) { 6 -> 90f; 3 -> 180f; 8 -> 270f; else -> 0f }
        return argb(if (deg == 0f) bmp else Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, Matrix().apply { postRotate(deg) }, true))
    }

    // ArcFace/MobileFaceNet 112x112 standart hizalama şablonu (sol göz, sağ göz, burun, sol ağız, sağ ağız)
    private val TPL = floatArrayOf(38.2946f, 51.6963f, 73.5318f, 51.5014f, 56.0252f, 71.7366f, 41.5493f, 92.3655f, 70.7299f, 92.2041f)

    /** 5 nokta (göz, burun, ağız) ile yüzü döndürüp/ölçekleyip modelin eğitildiği standart poza getirir. Başarısızsa null. */
    private fun align(bmp: Bitmap, f: Face): Bitmap? {
        fun lm(t: Int) = f.getLandmark(t)?.position
        val le = lm(FaceLandmark.LEFT_EYE); val re = lm(FaceLandmark.RIGHT_EYE); val nb = lm(FaceLandmark.NOSE_BASE)
        val ml = lm(FaceLandmark.MOUTH_LEFT); val mr = lm(FaceLandmark.MOUTH_RIGHT)
        if (le == null || re == null || nb == null || ml == null || mr == null) return null
        // Sağ/sol karışıklığı olmasın diye görüntüdeki x sırasına göre diz
        val e1 = if (le.x <= re.x) le else re; val e2 = if (le.x <= re.x) re else le
        val m1 = if (ml.x <= mr.x) ml else mr; val m2 = if (ml.x <= mr.x) mr else ml
        val src = floatArrayOf(e1.x, e1.y, e2.x, e2.y, nb.x, nb.y, m1.x, m1.y, m2.x, m2.y)
        val k = size / 112f
        var mpx = 0f; var mpy = 0f; var mqx = 0f; var mqy = 0f
        for (i in 0 until 5) { mpx += src[2 * i]; mpy += src[2 * i + 1]; mqx += TPL[2 * i] * k; mqy += TPL[2 * i + 1] * k }
        mpx /= 5; mpy /= 5; mqx /= 5; mqy /= 5
        var na = 0f; var nb2 = 0f; var den = 0f
        for (i in 0 until 5) {
            val ax = src[2 * i] - mpx; val ay = src[2 * i + 1] - mpy
            val bx = TPL[2 * i] * k - mqx; val by = TPL[2 * i + 1] * k - mqy
            na += ax * bx + ay * by; nb2 += ax * by - ay * bx; den += ax * ax + ay * ay
        }
        if (den < 1e-3f) return null
        val sa = na / den; val sb = nb2 / den
        if (hypot(sa, sb) < 1e-4f) return null
        val tx = mqx - (sa * mpx - sb * mpy); val ty = mqy - (sb * mpx + sa * mpy)
        val m = Matrix().apply { setValues(floatArrayOf(sa, -sb, tx, sb, sa, ty, 0f, 0f, 1f)) }
        val out = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(bmp, m, Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG))
        return out
    }

    /** Küçük resim için yüzü dik hâle getirir: göz çizgisinin eğimi ölçülür, yüz merkezi etrafında ters yönde döndürülür.
     *  (Eski yöntem kırpılmış resmi yanlış yönde döndürüp siyah köşeler bırakıyordu.) Landmark yoksa düz kırpma. */
    private fun uprightCrop(bmp: Bitmap, f: Face, l: Int, t: Int, r: Int, bt: Int): Bitmap {
        val plain = Bitmap.createBitmap(bmp, l, t, r - l, bt - t)
        val le = f.getLandmark(FaceLandmark.LEFT_EYE)?.position
        val re = f.getLandmark(FaceLandmark.RIGHT_EYE)?.position
        if (le == null || re == null) return plain
        val e1 = if (le.x <= re.x) le else re; val e2 = if (le.x <= re.x) re else le
        val ang = Math.toDegrees(kotlin.math.atan2((e2.y - e1.y).toDouble(), (e2.x - e1.x).toDouble())).toFloat()
        if (abs(ang) < 3f || abs(ang) > 100f) return plain
        val side = (max(r - l, bt - t) * 1.15f).toInt().coerceAtLeast(8)
        val big = (side * 1.5f).toInt()                    // döndürme sonrası köşe boşluğu kalmasın diye geniş çalış
        val cx = (l + r) / 2f; val cy = (t + bt) / 2f
        val work = Bitmap.createBitmap(big, big, Bitmap.Config.ARGB_8888)
        val m = Matrix().apply { postTranslate(big / 2f - cx, big / 2f - cy); postRotate(-ang, big / 2f, big / 2f) }
        Canvas(work).drawBitmap(bmp, m, Paint(Paint.FILTER_BITMAP_FLAG))
        val o = (big - side) / 2
        return Bitmap.createBitmap(work, o, o, side, side)
    }

    fun faces(bmp: Bitmap, keep: ((Bitmap) -> Boolean)? = null): List<FaceData> {
        val det = detectors.take()
        val found = try { Tasks.await(det.process(InputImage.fromBitmap(bmp, 0))) } finally { detectors.put(det) }
        val out = ArrayList<FaceData>()
        for (f in found) {
            val b = f.boundingBox
            val m = (0.1f * max(b.width(), b.height())).toInt()
            val l = max(0, b.left - m); val t = max(0, b.top - m)
            val r = minOf(bmp.width, b.right + m); val bt = minOf(bmp.height, b.bottom + m)
            if (r - l < MIN_FACE_PX || bt - t < MIN_FACE_PX) continue
            val crop = uprightCrop(bmp, f, l, t, r, bt)
            if (keep != null && !keep(crop)) continue   // filtreye uymayan yüz için parmak izi hesaplanmaz (hız)
            // Yüz kalitesi: boyut x poz (yüze doğrudan bakan, büyük yüz = 1.0)
            val sizeF = (min(b.width(), b.height()) / 90f).coerceAtMost(1f)
            val poseF = (1f - max(abs(f.headEulerAngleY) / 50f, abs(f.headEulerAngleX) / 40f)).coerceIn(0f, 1f)
            var q = sizeF * poseF
            val aligned = align(bmp, f)
            if (aligned == null) q = min(q, 0.2f)   // landmark yok → güvenilmez, sadece sonradan eklenir
            out.add(FaceData(crop, embedTta(aligned ?: crop), (r - l) * (bt - t), q, Rect(b), HairColor.fromPhoto(bmp, b)))
        }
        return out
    }

    /** Düz + ayna görüntü parmak izlerinin ortalaması. */
    private fun embedTta(face: Bitmap): FloatArray {
        val e1 = embed(face)
        if (!FLIP_TTA) return e1
        val fl = Bitmap.createBitmap(face, 0, 0, face.width, face.height, Matrix().apply { preScale(-1f, 1f) }, true)
        val e2 = embed(fl)
        return normalize(FloatArray(e1.size) { e1[it] + e2[it] })
    }

    /** ArcFace (w600k_r50) girişi: RGB, (x-127.5)/127.5, NCHW 1x3x112x112. Çıkış: 512 boyutlu parmak izi. */
    private fun embed(face: Bitmap): FloatArray {
        val sc = Bitmap.createScaledBitmap(face, size, size, true)
        val px = IntArray(size * size); sc.getPixels(px, 0, size, 0, 0, size, size)
        val fb = ByteBuffer.allocateDirect(4 * 3 * size * size).order(ByteOrder.nativeOrder()).asFloatBuffer()
        for (p in px) fb.put((((p shr 16) and 255) - 127.5f) / 127.5f)
        for (p in px) fb.put((((p shr 8) and 255) - 127.5f) / 127.5f)
        for (p in px) fb.put(((p and 255) - 127.5f) / 127.5f)
        fb.rewind()   // ÖNEMLİ: rewind olmadan model boş tampon görür
        @Suppress("UNCHECKED_CAST")
        val raw: FloatArray = OnnxTensor.createTensor(env, fb, longArrayOf(1, 3, size.toLong(), size.toLong())).use { t ->
            session.run(mapOf(inName to t)).use { r -> (r[0].value as Array<FloatArray>)[0].copyOf() }
        }
        return normalize(raw)
    }
}

fun normalize(v: FloatArray): FloatArray {
    var s = 0f; for (x in v) s += x * x
    val n = sqrt(s).coerceAtLeast(1e-9f)
    return FloatArray(v.size) { v[it] / n }
}
fun dot(a: FloatArray, b: FloatArray): Float { var s = 0f; for (i in a.indices) s += a[i] * b[i]; return s }
