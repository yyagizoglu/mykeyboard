package com.fotoliz.app

import ai.onnxruntime.OnnxTensor
import ai.onnxruntime.OrtEnvironment
import ai.onnxruntime.OrtSession
import ai.onnxruntime.TensorInfo
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.nio.FloatBuffer
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.max
import kotlin.math.min

/**
 * Galeri > Nesne filtresinde "göğüs / penis / vajina" gibi vücut bölümü aramalarını KESKİN yapar.
 * ML Kit etiketleri bu bölümleri ayırt edemediği için (chest, skin, human body... kıyafetli fotoğrafları da getiriyordu)
 * cihazda (internetsiz) çalışan NudeNet (YOLOv8, ONNX) dedektörü kullanılır: yalnızca AÇIKTA görünen bölümü bulur;
 * kıyafetle kapalı olanlar ayrı sınıftır ve sonuca girmez.
 *
 * Model: filesDir/nudenet.onnx. Yoksa sırayla: APK içindeki assets/nudenet.onnx, sonra internetten 320n (~12 MB, tek sefer).
 * Daha isabetli 640m modeli istenirse assets/nudenet.onnx olarak konabilir; giriş boyutu modelden okunur.
 *
 * Saklama (nudelabels.json): fotoğraf adresi -> "|v2|3:83|14:61|"  (sınıf numarası:puan%). Yalnızca eşik üstü, yeterince büyük kutular yazılır;
 * puanlar saklandığı için eşik sonradan değişirse yeniden taramaya gerek kalmaz.
 */
object NudeDetector {
    // NudeNet v3 sınıf sırası
    const val BUTTOCKS = 2
    const val BREAST_F = 3
    const val GENITAL_F = 4
    const val BREAST_M = 5
    const val ANUS = 6
    const val GENITAL_M = 14
    /** Çıplaklık sayılan "açıkta" sınıflar (erkek göğsü hariç: tek başına çıplaklık değil). */
    val NUDE_ANY = setOf(BREAST_F, GENITAL_F, GENITAL_M, BUTTOCKS, ANUS)
    private val TRACKED = setOf(BUTTOCKS, BREAST_F, GENITAL_F, BREAST_M, ANUS, GENITAL_M)
    private const val NC = 18

    const val MODEL_URL = "https://github.com/notAI-tech/NudeNet/releases/download/v3.4-weights/320n.onnx"
    private const val MODEL_MIN = 3_000_000L
    private const val VER = "v2"

    /** Bu puanın altındaki tespitler sonuca girmez (keskinlik ayarı: yükselt = daha az ama daha kesin). */
    const val MIN_SCORE = 0.50f
    /** Tespit edilen bölgenin fotoğrafın en az bu kadarını kaplaması gerekir (küçük rastlantısal kutular elenir). */
    private const val MIN_AREA = 0.006f
    private const val DECODE_SIDE = 1024
    private const val RAW_THRESHOLD = 0.25f
    private const val NMS_IOU = 0.45f

    private val map = ConcurrentHashMap<String, String>()
    @Volatile private var loaded = false
    private fun store(ctx: Context) = File(ctx.filesDir, "nudelabels.json")
    private fun modelFile(ctx: Context) = File(ctx.filesDir, "nudenet.onnx")

    @Synchronized fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try { val f = store(ctx); if (f.exists()) { val o = JSONObject(f.readText()); for (k in o.keys()) map[k] = o.getString(k) } } catch (e: Exception) { }
    }

    @Synchronized private fun persist(ctx: Context) {
        try {
            val o = JSONObject(); for ((k, v) in map) o.put(k, v)
            val tmp = File(ctx.filesDir, "nudelabels.tmp"); tmp.writeText(o.toString())
            if (!tmp.renameTo(store(ctx))) { store(ctx).delete(); tmp.renameTo(store(ctx)) }
        } catch (e: Exception) { }
    }

    private fun current(v: String?) = v != null && v.startsWith("|$VER|")

    /** Fotoğraf güncel yöntemle taranmış mı? */
    fun scanned(uri: String): Boolean = current(map[uri])

    /** Fotoğrafta istenen sınıflardan biri, eşik puanın üstünde AÇIKTA görünüyor mu? */
    fun matches(uri: String, classes: Set<Int>, minScore: Float = MIN_SCORE): Boolean {
        val v = map[uri] ?: return false
        if (!current(v)) return false
        for (p in v.split('|')) {
            val i = p.indexOf(':'); if (i < 0) continue
            val c = p.substring(0, i).toIntOrNull() ?: continue
            val s = p.substring(i + 1).toIntOrNull() ?: continue
            if (c in classes && s / 100f >= minScore) return true
        }
        return false
    }

    // ---------- model edinme ----------

    /** Model hazır değilse APK'dan kopyalar ya da indirir. Başarısızsa anlaşılır bir hata mesajıyla Exception. */
    fun ensureModel(ctx: Context) {
        val dst = modelFile(ctx)
        if (dst.exists() && dst.length() > MODEL_MIN) return
        try {
            ctx.assets.open("nudenet.onnx").use { i ->
                val tmp = File(ctx.filesDir, "nudenet.tmp")
                tmp.outputStream().use { o -> i.copyTo(o, 256 * 1024) }
                if (tmp.length() > MODEL_MIN) {
                    dst.delete()
                    if (tmp.renameTo(dst)) return
                } else {
                    tmp.delete()
                }
                Unit
            }
        } catch (e: Exception) { /* APK içinde yok: indirmeye geç */ }
        var last = ""
        val tmp = File(ctx.filesDir, "nudenet.tmp")
        try {
            val conn = URL(MODEL_URL).openConnection() as HttpURLConnection
            conn.connectTimeout = 20000; conn.readTimeout = 30000; conn.instanceFollowRedirects = true
            if (conn.responseCode != 200) last = "HTTP ${conn.responseCode}"
            else {
                conn.inputStream.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
                if (tmp.length() > MODEL_MIN) { dst.delete(); if (tmp.renameTo(dst)) { conn.disconnect(); return } } else last = "dosya eksik indi"
            }
            conn.disconnect()
        } catch (e: Exception) { last = e.message ?: e.javaClass.simpleName }
        tmp.delete()
        throw Exception("Vücut bölümü modeli indirilemedi ($last). İnternete bağlanıp tekrar dene ya da nudenet.onnx dosyasını uygulamanın assets klasörüne koy.")
    }

    // ---------- tarama ----------

    private fun decode(ctx: Context, uri: Uri): Bitmap? = try {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(info.size.width, info.size.height)
            if (m > DECODE_SIDE) { val sc = DECODE_SIDE.toFloat() / m; dec.setTargetSize((info.size.width * sc).toInt().coerceAtLeast(1), (info.size.height * sc).toInt().coerceAtLeast(1)) }
        }.let { if (it.config == Bitmap.Config.ARGB_8888) it else it.copy(Bitmap.Config.ARGB_8888, false) }
    } catch (e: CancellationException) { throw e } catch (e: Throwable) { null }

    /** Henüz taranmamış fotoğrafları tarar; iptal edilse de o ana kadarki sonuçlar saklanır. */
    /** Ağır iş (dosya okuma / yazma, model yükleme, tarama) HER ZAMAN arka plan iş parçacığında yürür; ana iş parçacığı (yazı yazma, kaydırma) donmaz. */
    suspend fun ensure(ctx: Context, uris: List<String>, onProgress: (Int, Int) -> Unit) = kotlinx.coroutines.withContext(Dispatchers.Default) { ensureImpl(ctx, uris, onProgress) }

    private suspend fun ensureImpl(ctx: Context, uris: List<String>, onProgress: (Int, Int) -> Unit) {
        load(ctx)
        val todo = uris.filter { !current(map[it]) }
        if (todo.isEmpty()) return
        ensureModel(ctx)
        val env = OrtEnvironment.getEnvironment()
        val session = try {
            env.createSession(modelFile(ctx).absolutePath, OrtSession.SessionOptions().apply { setIntraOpNumThreads(2); setInterOpNumThreads(1) })
        } catch (e: Exception) { modelFile(ctx).delete(); throw Exception("Vücut bölümü modeli okunamadı, bir sonraki aramada yeniden indirilecek: ${e.message}") }
        val inName = session.inputNames.iterator().next()
        val shape = try { (session.inputInfo[inName]!!.info as TensorInfo).shape } catch (e: Exception) { longArrayOf(1, 3, 320, 320) }
        val size = (shape.getOrNull(2) ?: 320L).let { if (it > 0) it.toInt() else 320 }
        val queue = ConcurrentLinkedQueue(todo)
        val count = AtomicInteger(0)
        try {
            coroutineScope {
                for (w in 0 until 2) launch(Dispatchers.Default) {
                    while (true) {
                        val u = queue.poll() ?: break
                        ensureActive()
                        map[u] = scanOne(ctx, env, session, inName, size, u)
                        val d = count.incrementAndGet()
                        if (d % 100 == 0) persist(ctx)
                        if (d % 5 == 0 || d == todo.size) onProgress(d, todo.size)
                    }
                }
            }
        } finally {
            try { session.close() } catch (e: Exception) { }
            persist(ctx)
        }
    }

    private class Det(val cls: Int, val score: Float, val x1: Float, val y1: Float, val x2: Float, val y2: Float)

    private fun scanOne(ctx: Context, env: OrtEnvironment, session: OrtSession, inName: String, size: Int, u: String): String {
        val bmp = decode(ctx, Uri.parse(u)) ?: return "|$VER|"   // çözülemedi: tekrar tekrar denenmesin
        return try {
            val dets = detect(env, session, inName, size, bmp)
            val best = HashMap<Int, Int>()
            val area = bmp.width.toFloat() * bmp.height
            for (d in dets) {
                if (d.cls !in TRACKED) continue
                val frac = (d.x2 - d.x1) * (d.y2 - d.y1) / area
                if (frac < MIN_AREA) continue
                val pct = (d.score * 100).toInt()
                if (pct > (best[d.cls] ?: 0)) best[d.cls] = pct
            }
            "|$VER|" + best.entries.joinToString("|") { "${it.key}:${it.value}" } + (if (best.isEmpty()) "" else "|")
        } catch (e: CancellationException) { throw e
        } catch (e: Throwable) { "|$VER|" } finally { bmp.recycle() }
    }

    @Suppress("UNCHECKED_CAST")
    private fun detect(env: OrtEnvironment, session: OrtSession, inName: String, S: Int, bmp: Bitmap): List<Det> {
        // Kareye tamamlama (sağ/alt siyah) + S x S küçültme, RGB, 0..1, NCHW
        val side = max(bmp.width, bmp.height)
        val sc = S.toFloat() / side
        val sq = Bitmap.createBitmap(S, S, Bitmap.Config.ARGB_8888)
        Canvas(sq).apply { drawColor(Color.BLACK); drawBitmap(bmp, null, RectF(0f, 0f, bmp.width * sc, bmp.height * sc), Paint(Paint.FILTER_BITMAP_FLAG)) }
        val px = IntArray(S * S); sq.getPixels(px, 0, S, 0, 0, S, S); sq.recycle()
        val data = FloatArray(3 * S * S)
        for (i in px.indices) {
            val p = px[i]
            data[i] = ((p shr 16) and 255) / 255f
            data[S * S + i] = ((p shr 8) and 255) / 255f
            data[2 * S * S + i] = (p and 255) / 255f
        }
        val out: Array<FloatArray> = OnnxTensor.createTensor(env, FloatBuffer.wrap(data), longArrayOf(1, 3, S.toLong(), S.toLong())).use { t ->
            session.run(mapOf(inName to t)).use { r -> (r.get(0).value as Array<Array<FloatArray>>)[0] }
        }
        val chFirst = out.size < out[0].size            // [4+NC][N] mi, [N][4+NC] mi
        val n = if (chFirst) out[0].size else out.size
        fun at(c: Int, i: Int) = if (chFirst) out[c][i] else out[i][c]
        val back = side.toFloat() / S
        val cand = ArrayList<Det>()
        for (i in 0 until n) {
            var bc = -1; var bs = RAW_THRESHOLD
            for (c in 0 until NC) { val s = at(4 + c, i); if (s >= bs) { bs = s; bc = c } }
            if (bc < 0) continue
            val cx = at(0, i); val cy = at(1, i); val w = at(2, i); val h = at(3, i)
            cand.add(Det(bc, bs, (cx - w / 2) * back, (cy - h / 2) * back, (cx + w / 2) * back, (cy + h / 2) * back))
        }
        // Sınıftan bağımsız NMS: aynı bölgede "kapalı" ve "açık" sınıfı yarışırsa yüksek puanlı olan kazanır
        cand.sortByDescending { it.score }
        val keep = ArrayList<Det>()
        for (d in cand) if (keep.none { iou(it, d) > NMS_IOU }) keep.add(d)
        return keep
    }

    private fun iou(a: Det, b: Det): Float {
        val ix = max(0f, min(a.x2, b.x2) - max(a.x1, b.x1)); val iy = max(0f, min(a.y2, b.y2) - max(a.y1, b.y1))
        val inter = ix * iy
        val u = (a.x2 - a.x1) * (a.y2 - a.y1) + (b.x2 - b.x1) * (b.y2 - b.y1) - inter
        return if (u <= 0f) 0f else inter / u
    }
}
