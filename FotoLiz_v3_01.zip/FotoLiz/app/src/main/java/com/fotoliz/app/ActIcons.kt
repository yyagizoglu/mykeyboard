package com.fotoliz.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.unit.dp

enum class Ic { Edit, Crop, Enhance, Move, Delete, Close, SelectAll, SelectNone }

/** Yazısız, çizgi simgeli işlem düğmesi (ek kütüphane gerektirmez; simgeler Canvas ile çizilir). */
@Composable
fun ActIcon(kind: Ic, desc: String, tint: Color, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(modifier.size(48.dp).clip(CircleShape).clickable(onClick = onClick).semantics { contentDescription = desc },
        contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(26.dp)) {
            val s = size.width / 24f
            val st = Stroke(width = 2f * s, cap = StrokeCap.Round, join = StrokeJoin.Round)
            fun o(x: Float, y: Float) = Offset(x * s, y * s)
            fun poly(close: Boolean, vararg pts: Pair<Float, Float>) {
                val path = Path()
                pts.forEachIndexed { i, (x, y) -> if (i == 0) path.moveTo(x * s, y * s) else path.lineTo(x * s, y * s) }
                if (close) path.close()
                drawPath(path, tint, style = st)
            }
            when (kind) {
                Ic.Edit -> {
                    poly(true, 4f to 20f, 5f to 15f, 16f to 4f, 20f to 8f, 9f to 19f)
                    drawLine(tint, o(13f, 7f), o(17f, 11f), strokeWidth = 2f * s, cap = StrokeCap.Round)
                }
                Ic.Crop -> {
                    poly(false, 7f to 2f, 7f to 17f, 22f to 17f)
                    poly(false, 2f to 7f, 17f to 7f, 17f to 22f)
                }
                Ic.Enhance -> {
                    poly(true, 10f to 4f, 12f to 10f, 18f to 12f, 12f to 14f, 10f to 20f, 8f to 14f, 2f to 12f, 8f to 10f)
                    drawLine(tint, o(19f, 2f), o(19f, 8f), strokeWidth = 2f * s, cap = StrokeCap.Round)
                    drawLine(tint, o(16f, 5f), o(22f, 5f), strokeWidth = 2f * s, cap = StrokeCap.Round)
                }
                Ic.Move -> {
                    poly(true, 3f to 6f, 10f to 6f, 12f to 8f, 21f to 8f, 21f to 19f, 3f to 19f)
                    poly(false, 8f to 13.5f, 16f to 13.5f)
                    poly(false, 13.5f to 11f, 16f to 13.5f, 13.5f to 16f)
                }
                Ic.Delete -> {
                    poly(false, 4f to 6f, 20f to 6f)
                    poly(false, 9f to 6f, 9f to 3f, 15f to 3f, 15f to 6f)
                    poly(false, 6f to 6f, 7f to 21f, 17f to 21f, 18f to 6f)
                    poly(false, 10f to 10f, 10f to 17f)
                    poly(false, 14f to 10f, 14f to 17f)
                }
                Ic.SelectAll -> {   // kutu + tik: hepsini seç
                    poly(true, 4f to 4f, 20f to 4f, 20f to 20f, 4f to 20f)
                    poly(false, 8f to 12.5f, 11f to 15.5f, 16.5f to 8.5f)
                }
                Ic.SelectNone -> {  // boş kutu + çapraz çizgi: seçimi temizle
                    poly(true, 4f to 4f, 20f to 4f, 20f to 20f, 4f to 20f)
                    poly(false, 8f to 12f, 16f to 12f)
                }
                Ic.Close -> {
                    poly(false, 5f to 5f, 19f to 19f)
                    poly(false, 19f to 5f, 5f to 19f)
                }
            }
        }
    }
}
