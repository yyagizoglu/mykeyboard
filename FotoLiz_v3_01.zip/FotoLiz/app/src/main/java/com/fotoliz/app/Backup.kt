package com.fotoliz.app

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.material3.*
import androidx.compose.runtime.*
import org.json.JSONObject
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/**
 * Kayıtların yedeği. Android, uygulama kaldırılınca program klasörünü siler; bu yüzden kayıtlar (analiz sonuçları + küçük yüz resimleri)
 * tek bir zip dosyasına yedeklenir. Güncelleme kayıtlara dokunmaz (paket adı + imza sabit); kaldırıp yeniden kurulursa yedekten geri yüklenir.
 *  - Elle: Ayarlar > Veriler > Yedekle / Yedekten geri yükle (istediğin yere kaydedersin).
 *  - Otomatik: uygulamadan çıkarken Download/FotoLiz/FotoLiz_yedek.zip güncellenir (kayıt değiştiyse).
 */
object Backup {
    private const val AUTO_NAME = "FotoLiz_yedek.zip"
    private fun results(ctx: Context) = File(ctx.filesDir, "results")

    private val SKIP_KEYS = setOf("auto_backup_stamp", "restore_asked", "battery_asked", "model_copy_done", "last_backup_time", "last_backup_folder", "last_backup_count")

    /** Program ayarları (tema, benzerlik eşiği…) tür etiketiyle JSON'a çevrilir. Şifre/desen (vault) ve Drive bilgileri yedeğe girmez. */
    fun settingsJson(ctx: Context): JSONObject {
        val o = JSONObject()
        val prefs = ctx.getSharedPreferences("app", 0); val all = prefs.all
        for (k in all.keys.sorted()) {
            if (k in SKIP_KEYS) continue
            val v = all[k]
            val e = JSONObject()
            when (v) {
                is Boolean -> e.put("t", "b").put("v", v)
                is Int -> e.put("t", "i").put("v", v)
                is Long -> e.put("t", "l").put("v", v)
                is Float -> e.put("t", "f").put("v", v.toDouble())
                is String -> e.put("t", "s").put("v", v)
                else -> continue
            }
            o.put(k, e)
        }
        return o
    }

    private fun applySettings(ctx: Context, o: JSONObject) {
        val ed = ctx.getSharedPreferences("app", 0).edit()
        for (k in o.keys()) {
            if (k in SKIP_KEYS) continue
            val e = o.getJSONObject(k)
            when (e.getString("t")) {
                "b" -> ed.putBoolean(k, e.getBoolean("v"))
                "i" -> ed.putInt(k, e.getInt("v"))
                "l" -> ed.putLong(k, e.getLong("v"))
                "f" -> ed.putFloat(k, e.getDouble("v").toFloat())
                "s" -> ed.putString(k, e.getString("v"))
            }
        }
        ed.apply()
    }

    /** Tüm yedeği (kayıtlar, küçük yüz resimleri, ayarlar, kaydedilen yüzler) bir akışa zip olarak yazar. Yazılan kayıt sayısını döndürür. */
    fun writeZip(ctx: Context, out: OutputStream): Int {
        var n = 0
        ZipOutputStream(out.buffered()).use { z ->
            results(ctx).listFiles()?.filter { it.extension == "json" }?.forEach { f ->
                z.putNextEntry(ZipEntry("results/" + f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry(); n++
            }
            Store.thumbDir(ctx).listFiles()?.forEach { f ->
                z.putNextEntry(ZipEntry("thumbs/" + f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry()
            }
            z.putNextEntry(ZipEntry("settings.json")); z.write(settingsJson(ctx).toString().toByteArray(Charsets.UTF_8)); z.closeEntry()
            val idx = File(ctx.filesDir, "savedfaces.json")
            if (idx.exists()) { z.putNextEntry(ZipEntry("savedfaces.json")); idx.inputStream().use { it.copyTo(z) }; z.closeEntry() }
            File(ctx.filesDir, "savedfaces").listFiles()?.forEach { f ->
                z.putNextEntry(ZipEntry("savedfaces/" + f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry()
            }
            File(ctx.filesDir, "celebs.json").takeIf { it.exists() }?.let { z.putNextEntry(ZipEntry("celebs.json")); it.inputStream().use { i -> i.copyTo(z) }; z.closeEntry() }
            File(ctx.filesDir, "celebs").listFiles()?.forEach { f ->
                z.putNextEntry(ZipEntry("celebs/" + f.name)); f.inputStream().use { it.copyTo(z) }; z.closeEntry()
            }
        }
        return n
    }

    /** Tüm kayıtları verilen adrese zip olarak yazar. Yazılan kayıt sayısını döndürür. */
    fun export(ctx: Context, uri: Uri): Int {
        val out = ctx.contentResolver.openOutputStream(uri, "wt") ?: throw IllegalStateException("Dosya açılamadı")
        return writeZip(ctx, out)
    }

    /** Seçilen klasöre FotoLiz_yedek.zip yazar; klasörde varsa üzerine yazar. (kayıt sayısı, üzerine yazıldı mı, klasör adı) döndürür. */
    fun exportToFolder(ctx: Context, tree: Uri): Triple<Int, Boolean, String> {
        val dir = androidx.documentfile.provider.DocumentFile.fromTreeUri(ctx, tree) ?: throw IllegalStateException("Klasör açılamadı")
        val old = dir.findFile(AUTO_NAME)?.takeIf { it.isFile }
        val target = old ?: dir.createFile("application/zip", AUTO_NAME) ?: throw IllegalStateException("Bu klasöre yazılamıyor, başka bir klasör seç")
        val n = export(ctx, target.uri)
        val name = dir.name ?: "seçilen klasör"
        ctx.getSharedPreferences("app", 0).edit().putLong("last_backup_time", System.currentTimeMillis())
            .putString("last_backup_folder", name).putInt("last_backup_count", n).apply()
        return Triple(n, old != null, name)
    }

    /** Ekranda gösterilecek son yedek satırı (yoksa null). */
    fun lastInfo(ctx: Context): String? {
        val p = ctx.getSharedPreferences("app", 0); val t = p.getLong("last_backup_time", 0L)
        if (t == 0L) return null
        return "En son yedek: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(t))} • klasör: ${p.getString("last_backup_folder", "")} • ${p.getInt("last_backup_count", 0)} kayıt"
    }

    /** Yedeği geri yükler: mevcut kayıtlar silinmez; aynı kayıt varsa yedektekiyle değişir. Yüklenen kayıt sayısını döndürür. */
    fun import(ctx: Context, uri: Uri): Int {
        val ins = ctx.contentResolver.openInputStream(uri) ?: throw IllegalStateException("Dosya açılamadı")
        return ins.use { importStream(ctx, it) }
    }

    fun importStream(ctx: Context, ins: InputStream): Int {
        val thumbs = Store.thumbDir(ctx); val res = results(ctx).apply { mkdirs() }
        val sfDir = File(ctx.filesDir, "savedfaces").apply { mkdirs() }
        var n = 0
        var savedFacesJson: String? = null
        var celebsJson: String? = null
        val celebDir = File(ctx.filesDir, "celebs").apply { mkdirs() }
        ZipInputStream(ins.buffered()).use { z ->
            while (true) {
                val e = z.nextEntry ?: break
                if (e.isDirectory) continue
                val fname = File(e.name).name                       // yalnızca dosya adı: klasör dışına yazmayı engeller
                if (e.name.startsWith("results/") && fname.endsWith(".json")) {
                    val o = JSONObject(String(z.readBytes(), Charsets.UTF_8))
                    val cl = o.getJSONArray("clusters")
                    for (i in 0 until cl.length()) {                  // küçük resim yollarını bu cihazdaki klasöre çevir
                        val c = cl.getJSONObject(i); val t = c.optString("thumb", "")
                        if (t.isNotBlank()) c.put("thumb", File(thumbs, File(t).name).absolutePath)
                    }
                    File(res, fname).writeText(o.toString()); n++
                } else if (e.name.startsWith("thumbs/")) {
                    File(thumbs, fname).outputStream().use { z.copyTo(it) }
                } else if (e.name == "settings.json") {
                    try { applySettings(ctx, JSONObject(String(z.readBytes(), Charsets.UTF_8))) } catch (x: Exception) { }
                } else if (e.name == "savedfaces.json") {
                    savedFacesJson = String(z.readBytes(), Charsets.UTF_8)
                } else if (e.name == "celebs.json") {
                    celebsJson = String(z.readBytes(), Charsets.UTF_8)
                } else if (e.name.startsWith("celebs/")) {
                    File(celebDir, fname).outputStream().use { z.copyTo(it) }
                } else if (e.name.startsWith("savedfaces/")) {
                    File(sfDir, fname).outputStream().use { z.copyTo(it) }
                }
            }
        }
        savedFacesJson?.let { try { SavedFaces.mergeFromJson(ctx, it) } catch (x: Exception) { } }
        celebsJson?.let { try { Celebs.mergeFromJson(ctx, it) } catch (x: Exception) { } }
        return n
    }

    /** Kayıt değiştiyse Download/FotoLiz/FotoLiz_yedek.zip dosyasını günceller (sessizce; hata olursa yok sayılır). */
    fun auto(ctx: Context) {
        try {
            val files = results(ctx).listFiles()?.filter { it.extension == "json" }.orEmpty()
            if (files.isEmpty() || Build.VERSION.SDK_INT < 29) return
            val prefs = ctx.getSharedPreferences("app", 0)
            val newest = (files.maxOf { it.lastModified() }) + files.size   // sayı da değişimi yakalasın (silme)
            if (newest == prefs.getLong("auto_backup_stamp", -1L)) return
            val cr = ctx.contentResolver; val coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            val rel = "Download/FotoLiz/"
            var uri: Uri? = cr.query(coll, arrayOf(MediaStore.MediaColumns._ID),
                "${MediaStore.MediaColumns.DISPLAY_NAME}=? AND ${MediaStore.MediaColumns.RELATIVE_PATH}=?", arrayOf(AUTO_NAME, rel), null)
                ?.use { if (it.moveToFirst()) ContentUris.withAppendedId(coll, it.getLong(0)) else null }
            if (uri == null) uri = cr.insert(coll, ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, AUTO_NAME); put(MediaStore.MediaColumns.MIME_TYPE, "application/zip")
                put(MediaStore.MediaColumns.RELATIVE_PATH, rel)
            })
            if (uri != null) { export(ctx, uri); prefs.edit().putLong("auto_backup_stamp", newest).apply() }
        } catch (e: Exception) { }
    }
}

/** Yedekle / Yedekten geri yükle düğmelerinin kullandığı seçiciler (Ayarlar'da). */
@Composable
fun rememberBackupActions(vm: VM): Pair<() -> Unit, () -> Unit> {
    val create = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { u -> if (u != null) vm.backupToFolder(u) }
    val open = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u -> if (u != null) vm.restoreFrom(u) }
    return Pair({ create.launch(null) }, { open.launch(arrayOf("application/zip", "application/octet-stream", "*/*")) })
}

/** Yeni kurulumda kayıt yokken bir kez sorulur: "1) Yedekten geri yükle  2) Yok, devam et". */
@Composable
fun RestoreAskDialog(vm: VM) {
    if (!vm.askRestore) return
    val (_, restore) = rememberBackupActions(vm)
    AlertDialog(onDismissRequest = { vm.dismissRestoreAsk() },
        title = { Text("Eski kayıtların var mı?") },
        text = { Text("1) Yedek dosyan varsa (Download/FotoLiz/FotoLiz_yedek.zip ya da kendi kaydettiğin) şimdi geri yükleyebilirsin; eski kayıtlar olduğu gibi gelir, yeniden analiz gerekmez.\n\n2) Yoksa “Yok, devam et” de.") },
        confirmButton = { Button(onClick = { vm.dismissRestoreAsk(); restore() }) { Text("Yedekten geri yükle") } },
        dismissButton = { TextButton(onClick = { vm.dismissRestoreAsk() }) { Text("Yok, devam et") } })
}
