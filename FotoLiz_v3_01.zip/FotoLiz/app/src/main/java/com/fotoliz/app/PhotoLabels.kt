package com.fotoliz.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeler
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger

/**
 * Fotoğraflardaki nesne etiketleri (cihazda, internetsiz). "Bulunan yüzler"de nesne adına göre süzmek için kullanılır.
 * Her fotoğraf bir kez etiketlenir; sonuç telefonda saklanır (sonraki aramalar anında olur).
 */
object PhotoLabels {
    private val map = ConcurrentHashMap<String, String>()     // fotoğraf adresi -> "|etiket|etiket|"
    @Volatile private var loaded = false
    private const val SIDE = 480
    private val WORKERS = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 4)
    private fun file(ctx: Context) = File(ctx.filesDir, "photolabels3.json")   // v2.77: kati etiketleme (güven >= 0.60); eski gevşek kayıtlar kullanılmaz, fotoğraflar bir kez yeniden etiketlenir

    @Synchronized fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try { val f = file(ctx); if (f.exists()) { val o = JSONObject(f.readText()); for (k in o.keys()) map[k] = o.getString(k) } } catch (e: Exception) { }
    }

    /** Fotoğraf daha önce etiketlenmiş mi? */
    fun scanned(uri: String): Boolean = map.containsKey(uri)

    fun has(uri: String, keys: Set<String>): Boolean { val s = map[uri] ?: return false; for (k in keys) if (s.contains("|" + k + "|")) return true; return false }

    @Synchronized private fun persist(ctx: Context) {
        try {
            val o = JSONObject(); for ((k, v) in map) o.put(k, v)
            val tmp = File(ctx.filesDir, "photolabels.tmp"); tmp.writeText(o.toString())
            if (!tmp.renameTo(file(ctx))) { file(ctx).delete(); tmp.renameTo(file(ctx)) }
        } catch (e: Exception) { }
    }

    private fun decode(ctx: Context, uri: Uri): Bitmap? = try {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = maxOf(info.size.width, info.size.height)
            if (m > SIDE) { val sc = SIDE.toFloat() / m; dec.setTargetSize((info.size.width * sc).toInt().coerceAtLeast(1), (info.size.height * sc).toInt().coerceAtLeast(1)) }
        }.let { if (it.config == Bitmap.Config.ARGB_8888) it else it.copy(Bitmap.Config.ARGB_8888, false) }
    } catch (e: CancellationException) { throw e } catch (e: Throwable) { null }

    private fun labelsOf(ctx: Context, lab: ImageLabeler, u: String): String {
        val bmp = decode(ctx, Uri.parse(u)) ?: return "|"
        return try {
            val res = Tasks.await(lab.process(InputImage.fromBitmap(bmp, 0)))
            "|" + res.joinToString("|") { it.text.lowercase(Locale.ENGLISH) } + "|"
        } catch (e: CancellationException) { throw e } catch (e: Throwable) { "|" } finally { bmp.recycle() }
    }

    /** Henüz etiketlenmemiş fotoğrafları 3 paralel işle etiketler; iptal edilse de o ana kadarki sonuçlar saklanır. */
    /** Ağır iş (dosya okuma / yazma, model yükleme, tarama) HER ZAMAN arka plan iş parçacığında yürür; ana iş parçacığı (yazı yazma, kaydırma) donmaz. */
    suspend fun ensure(ctx: Context, uris: List<String>, onProgress: (Int, Int) -> Unit) = kotlinx.coroutines.withContext(Dispatchers.Default) { ensureImpl(ctx, uris, onProgress) }

    private suspend fun ensureImpl(ctx: Context, uris: List<String>, onProgress: (Int, Int) -> Unit) {
        load(ctx)
        val todo = uris.filter { !map.containsKey(it) }
        if (todo.isEmpty()) return
        val queue = ConcurrentLinkedQueue(todo)
        val count = AtomicInteger(0)
        val labelers = List(WORKERS) { ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.70f).build()) }
        try {
            coroutineScope {
                for (lab in labelers) launch(Dispatchers.Default) {
                    while (true) {
                        val u = queue.poll() ?: break
                        ensureActive()
                        map[u] = labelsOf(ctx, lab, u)
                        val d = count.incrementAndGet()
                        if (d % 5 == 0 || d == todo.size) onProgress(d, todo.size)
                    }
                }
            }
        } finally {
            labelers.forEach { try { it.close() } catch (e: Exception) { } }
            persist(ctx)
        }
    }
}
