package com.fotoliz.app

/** ML Kit görsel etiketlerini (İngilizce) Türkçe nesne gruplarına çevirir. Yüzü olmayan fotoğraflar bu adla gruplanır. */
object ObjectNames {
    private val map = HashMap<String, Pair<String, Float>>()
    /** Grup adı -> (etiket, ağırlık) listesi; nesne aramada kullanılır. */
    val groups = LinkedHashMap<String, MutableList<Pair<String, Float>>>()
    private fun add(tr: String, w: Float, vararg keys: String) {
        for (k in keys) { map[k] = tr to w; groups.getOrPut(tr) { ArrayList() }.add(k to w) }
    }

    init {
        add("Evrak / Belge", 1.0f, "document", "receipt", "newspaper", "envelope", "menu", "certificate", "invoice", "form", "page")
        add("Evrak / Belge", 0.9f, "paper", "paper product", "book", "publication", "poster", "handwriting", "writing", "notebook")
        add("Evrak / Belge", 0.75f, "text", "font")
        add("Araba", 1.0f, "car", "sedan", "sports car", "supercar", "taxi", "hatchback", "suv", "mid-size car", "compact car", "station wagon",
            "coupé", "luxury vehicle", "family car", "city car", "race car", "convertible", "windshield", "bumper", "hood", "vehicle door",
            "rim", "alloy wheel", "automotive lighting", "headlamp", "grille", "steering wheel", "dashboard", "car seat")
        add("Araba", 0.8f, "vehicle", "land vehicle", "motor vehicle", "automotive design", "automotive exterior", "wheel", "tire",
            "automotive tire", "license plate", "vehicle registration plate", "automotive", "transport")
        add("Motosiklet", 1.0f, "motorcycle", "scooter", "moped", "motorcycling", "motorcycle racing", "motorcycle helmet", "cruiser")
        add("Bisiklet", 1.0f, "bicycle", "bicycle wheel", "bicycle frame", "mountain bike", "road bicycle", "cycling", "bicycle tire", "bmx")
        add("Kamyon / Kamyonet", 1.0f, "truck", "van", "pickup truck", "commercial vehicle", "trailer truck", "minivan")
        add("Otobüs", 1.0f, "bus", "minibus", "public transport")
        add("Uçak", 1.0f, "airplane", "aircraft", "airliner", "aviation", "jet", "helicopter")
        add("Gemi / Tekne", 1.0f, "boat", "ship", "watercraft", "yacht", "sailboat", "water transportation", "vessel")
        add("Tren", 1.0f, "train", "rail transport", "railway", "locomotive")
        add("Kedi", 1.0f, "cat", "kitten", "whiskers", "small to medium-sized cats", "felidae")
        add("Köpek", 1.0f, "dog", "puppy", "dog breed", "canidae")
        add("Kuş", 1.0f, "bird", "beak", "water bird", "seabird", "feather", "parrot")
        add("At", 1.0f, "horse", "mane", "pony", "stallion")
        add("Balık", 1.0f, "fish", "aquarium")
        add("Hayvan", 0.6f, "animal", "mammal", "pet", "wildlife", "terrestrial animal", "carnivore", "insect", "reptile")
        add("Yemek", 1.0f, "food", "dish", "cuisine", "meal", "ingredient", "fast food", "pizza", "dessert", "cake", "baked goods",
            "junk food", "breakfast", "sandwich", "recipe", "burger", "hamburger", "lunch", "dinner", "snack", "chocolate", "bread")
        add("Meyve / Sebze", 1.0f, "fruit", "vegetable", "produce", "natural foods", "salad", "apple", "banana", "tomato")
        add("İçecek", 0.9f, "drink", "coffee", "tea", "beverage", "cocktail", "juice", "wine", "beer", "bottle", "cup", "mug", "drinkware")
        add("Çiçek", 1.0f, "flower", "petal", "flowering plant", "rose", "bouquet", "floral design")
        add("Bitki / Ağaç", 0.9f, "tree", "plant", "leaf", "woody plant", "forest", "grass", "garden", "shrub", "houseplant")
        add("Gökyüzü / Manzara", 0.9f, "sky", "cloud", "sunset", "sunrise", "horizon", "landscape", "natural landscape", "mountain", "hill",
            "valley", "atmospheric phenomenon", "nature", "field", "sunlight", "dusk", "night")
        add("Deniz / Göl / Plaj", 1.0f, "sea", "ocean", "beach", "coast", "shore", "wave", "lake", "river", "water", "body of water", "waterfall", "pool", "swimming pool")
        add("Kar / Kış", 1.0f, "snow", "winter", "ice", "freezing")
        add("Bina / Mimari", 1.0f, "building", "architecture", "skyscraper", "tower", "facade", "city", "urban area", "house", "home", "roof",
            "bridge", "mosque", "church", "castle", "monument", "landmark", "street", "road", "town", "window")
        add("Oda / Mobilya", 0.9f, "furniture", "table", "chair", "couch", "sofa", "bed", "room", "interior design", "shelf", "lamp",
            "living room", "kitchen", "bedroom", "bathroom", "curtain", "floor", "wall", "desk", "cabinetry", "wood")
        add("Telefon / Ekran", 0.9f, "mobile phone", "smartphone", "gadget", "communication device", "portable communications device", "screenshot",
            "multimedia", "electronic device", "display device", "computer monitor", "computer", "laptop", "personal computer", "output device",
            "television", "technology", "electronics", "tablet computer", "software", "website", "video game", "game")
        add("Giysi / Moda", 0.9f, "clothing", "dress", "shoe", "footwear", "jacket", "sleeve", "fashion", "jeans", "outerwear", "t-shirt",
            "sportswear", "handbag", "bag", "sneakers", "hat", "sunglasses", "jewellery", "watch", "necklace", "ring")
        add("Çizim / Sanat", 0.9f, "drawing", "painting", "art", "cartoon", "illustration", "visual arts", "sketch", "anime", "graphics", "sculpture", "mural", "graffiti")
        add("Spor", 0.9f, "sports", "ball", "football", "soccer", "basketball", "team sport", "stadium", "gym", "sports equipment", "tennis", "player", "athlete", "running", "swimming")
        add("Müzik / Konser", 0.9f, "concert", "guitar", "musical instrument", "piano", "stage", "performing arts", "music", "microphone", "audience", "crowd")
        add("Oyuncak", 1.0f, "toy", "doll", "stuffed toy", "lego", "teddy bear")
        add("Silah / Alet", 0.8f, "tool", "hammer", "gun", "knife", "machine", "engine", "machine tool")
        add("İnsan (yüz seçilemedi)", 0.6f, "person", "people", "human", "skin", "hair", "smile", "selfie", "face", "cheek", "chin", "forehead",
            "nose", "lip", "eyebrow", "eyelash", "neck", "shoulder", "arm", "leg", "hand", "finger", "thigh", "muscle", "long hair", "hairstyle",
            "beauty", "eye", "mouth", "ear", "abdomen", "chest", "photo shoot", "model", "child", "baby", "fun", "event", "party", "wedding", "bride")
    }

    /** labels: (etiket, güven). En iyi grubu döndürür; hiçbiri uymazsa güvenli en üst etiket ya da "Diğer". */
    fun pick(labels: List<Pair<String, Float>>): String? {
        if (labels.isEmpty()) return null
        var best: String? = null; var bs = 0f
        for ((l, c) in labels) {
            val m = map[l.lowercase()] ?: continue
            val s = c * m.second
            if (s > bs) { bs = s; best = m.first }
        }
        if (best != null && bs >= 0.40f) return best
        val top = labels.maxByOrNull { it.second }!!
        return if (top.second >= 0.80f) top.first.replaceFirstChar { it.uppercase() } else "Diğer"
    }
}
