package com.fotoliz.app

import android.content.Context
import android.content.ContextWrapper
import android.os.Build
import android.os.SystemClock
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity

/** Program kilidi durumu. Şifre / desen tanımlıysa uygulama açılırken ve uzun süre arka plandan dönünce kilitlenir. */
object AppLock {
    var locked by mutableStateOf(false)
    private var inited = false
    private var leftAt = 0L

    // ---- Oturum: bir kez doğrulanınca, kilit süresi dolana kadar programın hiçbir yerinde (Ayarlar, silme, Drive, geri yükleme…) tekrar sorulmaz
    private var authAt = 0L
    private var leftSinceAuth = false
    /** Başarılı her doğrulamadan (şifre / desen / parmak izi) ya da yeni kilit tanımlamadan sonra çağrılır: süre yeniden başlar. */
    fun markAuth() { authAt = SystemClock.elapsedRealtime(); leftSinceAuth = false }
    /** Kilit süresi içinde miyiz? Süre 0 ise (Hemen) uygulamadan çıkılana kadar geçerli. */
    fun sessionActive(ctx: Context): Boolean {
        if (authAt == 0L || !Vault.isSet(ctx)) return false
        val sec = Vault.relockSec(ctx)
        return if (sec == 0) !leftSinceAuth else SystemClock.elapsedRealtime() - authAt < sec * 1000L
    }

    // Uygulama arka planda sistem tarafından kapatılsa bile (süreç ölse de) süre dolmadan tekrar sorulmaz: son çıkış saati kalıcı tutulur
    private fun sp(ctx: Context) = ctx.applicationContext.getSharedPreferences("applock_state", Context.MODE_PRIVATE)
    private fun savedLeft(ctx: Context) = sp(ctx).getLong("left_wall", 0L)
    private fun expired(ctx: Context): Boolean {
        val l = savedLeft(ctx)
        return l == 0L || System.currentTimeMillis() - l >= Vault.relockSec(ctx) * 1000L
    }

    fun init(ctx: Context) {
        if (inited) return; inited = true
        locked = Vault.isSet(ctx) && Vault.lockOnOpen(ctx) && expired(ctx)
        if (!locked) { authAt = SystemClock.elapsedRealtime(); leftSinceAuth = false }
    }
    // Kilit ekranındayken (ör. parmak izi penceresi) çıkış sayılmaz; yoksa açar açmaz yeniden kilitlenirdi
    fun onLeave(ctx: Context) {
        leftSinceAuth = true; leftAt = if (locked) 0L else SystemClock.elapsedRealtime()
        if (!locked) sp(ctx).edit().putLong("left_wall", System.currentTimeMillis()).apply()
    }
    fun onReturn(ctx: Context) {
        if (leftAt > 0 && Vault.isSet(ctx) && Vault.lockOnOpen(ctx) && SystemClock.elapsedRealtime() - leftAt >= Vault.relockSec(ctx) * 1000L) { locked = true; authAt = 0L }
        else if (!locked) { leftAt = 0L; sp(ctx).edit().putLong("left_wall", System.currentTimeMillis()).apply() }   // süre dolmadan döndü: kilit açık kalır
    }
}

fun findActivity(ctx: Context): FragmentActivity? {
    var c: Context? = ctx
    while (c != null) {
        if (c is FragmentActivity) return c
        c = (c as? ContextWrapper)?.baseContext
    }
    return null
}

fun bioAvailable(ctx: Context): Boolean = try {
    BiometricManager.from(ctx).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) == BiometricManager.BIOMETRIC_SUCCESS
} catch (e: Exception) { false }

private fun askBio(ctx: Context, subtitle: String, ok: () -> Unit, fail: () -> Unit) {
    val act = findActivity(ctx)
    if (act == null) { fail(); return }
    val prompt = BiometricPrompt(act, ContextCompat.getMainExecutor(act), object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) { AppLock.markAuth(); ok() }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) { fail() }
    })
    val b = BiometricPrompt.PromptInfo.Builder().setTitle("FotoLiz").setSubtitle(subtitle)
    // Android 11+: parmak izi okunmazsa telefonun kendi ekran kilidi (PIN / desen) yedek olarak kullanılabilir; eski sürümlerde yalnızca parmak izi
    if (Build.VERSION.SDK_INT >= 30) b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK or BiometricManager.Authenticators.DEVICE_CREDENTIAL)
    else { b.setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK); b.setNegativeButtonText("Vazgeç") }
    try { prompt.authenticate(b.build()) } catch (e: Exception) { fail() }
}

/**
 * Doğrulama penceresi: seçili yönteme göre parmak izi ya da şifre ya da desen sorulur (yalnızca seçili yöntem).
 * onCancel null ise pencere kapatılamaz.
 */
@Composable
fun UnlockDialog(message: String, onSuccess: () -> Unit, onCancel: (() -> Unit)?) {
    val ctx = LocalContext.current
    val ok by rememberUpdatedState(onSuccess)
    // Kilit süresi dolmadıysa hiçbir şey sorulmadan geçilir
    if (AppLock.sessionActive(ctx)) { LaunchedEffect(Unit) { ok() }; return }
    if (Vault.mode(ctx) == "bio") {
        var attempt by remember { mutableStateOf(0) }
        var failed by remember { mutableStateOf(false) }
        LaunchedEffect(attempt) { failed = false; askBio(ctx, message, { ok() }, { failed = true }) }
        AlertDialog(onDismissRequest = { onCancel?.invoke() },
            icon = { FingerprintIcon(MaterialTheme.colorScheme.primary, 32.dp) }, title = { Text("Parmak izi") },
            text = { Text(if (failed) "Doğrulama yapılamadı. Tekrar dene." else "Parmak izini okut.") },
            confirmButton = { TextButton(onClick = { attempt++ }) { Text("Tekrar dene") } },
            dismissButton = if (onCancel != null) ({ TextButton(onClick = { onCancel() }) { Text("Vazgeç") } }) else null)
    } else {
        VerifyStage(false, message, { onCancel?.invoke() }) { ok() }
    }
}

/** Program kilitliyken görünen tam ekran; doğrulama başarılı olunca kilit açılır. */
@Composable
fun LockScreen() {
    Surface(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
            Icon(Icons.Filled.Lock, null, Modifier.size(56.dp), tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(12.dp))
            Text("FotoLiz kilitli", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
        }
        UnlockDialog("Programı açmak için doğrulayın", onSuccess = { AppLock.locked = false }, onCancel = null)
    }
}
