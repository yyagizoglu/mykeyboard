package com.fotoliz.app

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Galeri işlemlerinin (geri dönüşüme atma, ad değiştirme…) kalıcı kısa geçmişi. Galeri sayfasının altında "Son İşlemler" olarak görünür. */
object RecentOps {
    data class Op(val time: Long, val text: String)

    val items = mutableStateListOf<Op>()          // en yeni en başta
    private var loaded = false
    private const val KEY = "recent_ops"
    private const val MAX = 30

    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("app", 0)

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        val raw = prefs(ctx).getString(KEY, "") ?: ""
        val list = raw.split("\n").mapNotNull { line ->
            val i = line.indexOf('\t'); if (i <= 0) return@mapNotNull null
            val t = line.substring(0, i).toLongOrNull() ?: return@mapNotNull null
            Op(t, line.substring(i + 1))
        }
        items.clear(); items.addAll(list)
    }

    fun add(ctx: Context, text: String) {
        load(ctx)
        items.add(0, Op(System.currentTimeMillis(), text.replace('\n', ' ').replace('\t', ' ')))
        while (items.size > MAX) items.removeAt(items.size - 1)
        save(ctx)
    }

    fun clear(ctx: Context) { items.clear(); save(ctx) }

    private fun save(ctx: Context) {
        prefs(ctx).edit().putString(KEY, items.joinToString("\n") { "${it.time}\t${it.text}" }).apply()
    }

    /** Albüm adlarını kısa özetler: "A, B ve 2 albüm daha". */
    fun names(list: List<String>): String = when {
        list.isEmpty() -> ""
        list.size <= 2 -> list.joinToString(", ")
        else -> list.take(2).joinToString(", ") + " ve ${list.size - 2} albüm daha"
    }
}

/** Galeri sayfasının altı: "Son İşlemler" — Kayıtlı sonuçlardaki kartlarla aynı görünüm (çağla yeşili kart, kırmızı "SON İŞLEM" rozeti). */
@Composable
fun RecentOpsSection() {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    LaunchedEffect(Unit) { RecentOps.load(ctx) }
    val fmt = remember { SimpleDateFormat("dd.MM.yy HH:mm", Locale.getDefault()) }
    Column(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 8.dp)) {
        Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Son İşlemler", Modifier.weight(1f), style = MaterialTheme.typography.titleMedium)
            if (RecentOps.items.isNotEmpty()) TextButton({ RecentOps.clear(ctx) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Temizle", fontSize = 12.sp) }
        }
        if (RecentOps.items.isEmpty()) {
            Text("Henüz işlem yok. Albüm silme ve ad değiştirme işlemleri burada görünür.", style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            val rowH = 64.dp; val gap = 6.dp
            Column(Modifier.fillMaxWidth().heightIn(max = rowH * 10 + gap * 9).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(gap)) {
                RecentOps.items.forEachIndexed { idx, op ->
                    Card(Modifier.fillMaxWidth().height(rowH), shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFA5CF92), contentColor = Color(0xFF14210E))) {
                        Row(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                                Text(op.text, style = MaterialTheme.typography.titleSmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                Text(fmt.format(Date(op.time)), style = MaterialTheme.typography.bodySmall, fontSize = 11.sp, maxLines = 1)
                            }
                            if (idx == 0) Text("SON İŞLEM", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, maxLines = 1, softWrap = false,
                                modifier = Modifier.padding(start = 6.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFFC62828)).padding(horizontal = 6.dp, vertical = 2.dp))
                        }
                    }
                }
            }
        }
    }
}
