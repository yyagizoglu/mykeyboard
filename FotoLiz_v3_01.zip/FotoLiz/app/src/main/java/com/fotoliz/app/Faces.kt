package com.fotoliz.app

import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.zIndex
import kotlin.math.abs
import android.content.Context
import org.json.JSONArray
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.Row
import androidx.compose.ui.platform.LocalContext
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File

/** Kullanıcının "Bulunan yüzler"de basılı tutup sürükleyerek verdiği kalıcı sıra. Her kişi, üyelerinin yüz resmi yollarıyla tanınır (en net kare değişse de sıra korunur). */
object FaceOrder {
    var version by mutableStateOf(0)       // sıra değişince listeleri yeniden hesaplatır
    private var order: List<List<String>> = emptyList()
    private var loaded = false
    private var file: File? = null

    fun ensure(ctx: Context) {
        if (loaded) return
        loaded = true
        val f = File(ctx.applicationContext.filesDir, "faces_order.json"); file = f
        order = try {
            if (!f.exists()) emptyList() else JSONArray(f.readText()).let { a ->
                (0 until a.length()).map { i -> a.getJSONArray(i).let { b -> (0 until b.length()).map { b.getString(it) } } }
            }
        } catch (e: Exception) { emptyList() }
    }

    fun save(list: List<FaceEntry>) {
        order = list.map { f -> f.members.map { it.second.thumb }.distinct() }
        version++
        try {
            val f = file ?: return; val tmp = File(f.parentFile, f.name + ".tmp")
            tmp.writeText(JSONArray(order.map { JSONArray(it) }).toString())
            if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
        } catch (e: Exception) { }
    }

    /** Sırası kaydedilmiş kişiler o sırayla önde; yeni / sırasız kişiler varsayılan sırayla (en çok fotoğraf) sonda. */
    fun apply(faces: List<FaceEntry>): List<FaceEntry> {
        if (order.isEmpty()) return faces
        val pos = HashMap<String, Int>()
        order.forEachIndexed { i, l -> l.forEach { pos.putIfAbsent(it, i) } }
        return faces.sortedBy { f -> f.members.mapNotNull { pos[it.second.thumb] }.minOrNull() ?: Int.MAX_VALUE }   // sortedBy kararlı
    }
}

/** Tekrarsız bir kişi: aynı kişinin tüm analizlerdeki grupları tek kayıtta toplanır, en net yüz kullanılır. */
class FaceEntry(val thumb: String, val name: String, val photos: Int, val members: List<Pair<Result, Cluster>>)

private const val DEDUP = 0.50f   // Bu benzerliğin üstündeki gruplar aynı kişi sayılır

/** Programın bugüne dek bulduğu tüm yüzler: aynı kişi bir kez, en net (en kaliteli) hâliyle; en çok fotoğrafı olan başta. */
fun collectFaces(saved: List<Result>): List<FaceEntry> {
    val all = ArrayList<Pair<Result, Cluster>>()
    for (r in saved) for (c in r.clusters)
        if (!c.obj && c.photos.isNotEmpty() && c.centroid.isNotEmpty() && c.thumb.isNotBlank() && File(c.thumb).exists()) all.add(r to c)
    all.sortByDescending { it.second.area }   // area = kalite puanı; en iyi kare önce gelir ve temsilci olur
    class Acc(val rep: Cluster, val members: ArrayList<Pair<Result, Cluster>>)
    val groups = ArrayList<Acc>()
    for (p in all) {
        val g = groups.firstOrNull { it.rep.centroid.size == p.second.centroid.size && dot(it.rep.centroid, p.second.centroid) >= DEDUP }
        if (g != null) g.members.add(p) else groups.add(Acc(p.second, arrayListOf(p)))
    }
    return groups.filter { g -> !Celebs.matches(g.rep.centroid) }.map { g ->     // Ünlüler'e taşınanlar bu panodan çıkar
        val photos = HashSet<String>(); g.members.forEach { photos.addAll(it.second.photos) }
        val nm = g.members.map { it.second.tag }.firstOrNull { it.isNotBlank() } ?: ""
        FaceEntry(g.rep.thumb, nm, photos.size, g.members)
    }.sortedByDescending { it.photos }.let { FaceOrder.apply(it) }
}

/** Ana ekran önizlemesi: üstte altı, altta altı yüz (12). Pencere boyutu değişmez, daireler küçülür. Dokununca tüm yüzler panosu açılır. */
@Composable
fun FacesPreviewCard(faces: List<FaceEntry>, onOpen: () -> Unit) {
    SectionCard(Icons.Filled.Face, "Bulunan yüzler", "${faces.size} farklı kişi • tekrarsız, en net kareler") {
        for (row in faces.take(12).chunked(6)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(5.dp)) {
                for (f in row) Column(Modifier.weight(1f).clickable(onClick = onOpen), horizontalAlignment = Alignment.CenterHorizontally) {
                    AsyncImage(File(f.thumb), null, Modifier.fillMaxWidth().aspectRatio(1f).clip(CircleShape), contentScale = ContentScale.Crop)
                    Text(f.name.ifBlank { "Adsız" }, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                repeat(6 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
        TonalAction("Tüm yüzleri gör (${faces.size})", onOpen, Modifier.fillMaxWidth(), icon = Icons.Filled.Person)
    }
}

/** Tüm yüzler panosu: bugüne dek bulunan her farklı kişi bir kez; dokununca adı düzenlenir. Sağ üstteki filtre cinsiyet ve saç rengine göre süzer. */
@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun FacesScreen(vm: VM) {
    val ctx = LocalContext.current
    FaceOrder.ensure(ctx)
    val faces = remember(vm.saved, Celebs.items, Engine.found, FaceOrder.version) { collectFaces(vm.saved.filter { it.key in Engine.found }) }
    var editing by remember { mutableStateOf<FaceEntry?>(null) }
    var filter by remember { mutableStateOf(FaceFilter.ALL) }
    var menu by remember { mutableStateOf(false) }
    var attrRev by remember { mutableStateOf(0) }    // elle düzeltme/sıfırlama sonrası analizi yeniden tetikler
    var tick by remember { mutableStateOf(0) }       // analiz ilerledikçe listeyi tazeler
    var progress by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    LaunchedEffect(faces, attrRev) {
        withContext(Dispatchers.Default) { FaceAttrs.load(ctx) }
        val paths = faces.map { it.thumb }
        if (paths.none { FaceAttrs.get(it) == null }) { progress = null; tick++; return@LaunchedEffect }
        try {
            withContext(Dispatchers.Default) {
                FaceAttrs.analyzeMissing(ctx, paths) { done, all -> progress = done to all; tick++ }
            }
        } finally { progress = null; tick++ }
    }
    // Nesne ismine göre süzme: kişinin (en fazla 40) fotoğrafında yazılan nesne görünüyorsa kişi listede kalır
    var objText by remember { mutableStateOf("") }
    var objQuery by remember { mutableStateOf("") }
    var objProgress by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    var objTick by remember { mutableStateOf(0) }
    val objKeys = remember(objQuery) { if (objQuery.isBlank()) emptySet<String>() else TrObjects.resolve(objQuery) }
    fun sample(f: FaceEntry): List<String> = f.members.flatMap { it.second.photos }.distinct().take(40)
    LaunchedEffect(objQuery, faces) {
        if (objQuery.isBlank()) { objProgress = null; return@LaunchedEffect }
        withContext(Dispatchers.Default) { PhotoLabels.load(ctx) }
        val uris = faces.flatMap { sample(it) }.distinct()
        try { PhotoLabels.ensure(ctx, uris) { d, t -> objProgress = d to t; objTick++ } } finally { objProgress = null; objTick++ }
    }
    val shown = remember(faces, filter, tick, objQuery, objTick) {
        faces.filter { f -> filter.matches(FaceAttrs.get(f.thumb)) && (objQuery.isBlank() || sample(f).any { u -> PhotoLabels.has(u, objKeys) }) }
    }
    // Basılı tutup sürükleyerek sıra değiştirme (kıpırdatmadan bırakırsan eskisi gibi düzenleme penceresi açılır)
    val shownNow by rememberUpdatedState(shown)
    val facesNow by rememberUpdatedState(faces)
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragX by remember { mutableStateOf(0f) }
    var dragY by remember { mutableStateOf(0f) }
    var cellW by remember { mutableStateOf(1f) }
    var cellH by remember { mutableStateOf(1f) }
    val gapPx = with(LocalDensity.current) { 12.dp.toPx() }
    fun moveFace(from: Int, to: Int) {
        val s = shownNow; if (from !in s.indices || to !in s.indices || from == to) return
        val moved = s[from]; val target = s[to]
        val list = facesNow.toMutableList()
        list.remove(moved)
        val idx = list.indexOf(target).takeIf { it >= 0 } ?: list.size
        list.add(if (to > from) idx + 1 else idx, moved)
        FaceOrder.save(list)
    }
    val barProgress = progress ?: objProgress
    val barTitle = if (progress != null) "Yüzler analiz ediliyor" else "Nesneler taranıyor"
    Box(Modifier.fillMaxSize()) {
    LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxSize(), contentPadding = PaddingValues(start = 12.dp, top = 12.dp, end = 12.dp, bottom = if (barProgress != null) 110.dp else 12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text(if (filter == FaceFilter.ALL && objQuery.isBlank()) "${faces.size} farklı kişi"
                        else "${shown.size} kişi" + (if (filter != FaceFilter.ALL) " • ${filter.label}" else "") + (if (objQuery.isNotBlank()) " • “$objQuery”" else ""),
                        style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                    Box {
                        FilledTonalButton(onClick = { menu = true }) { Text(if (filter == FaceFilter.ALL) (if (objQuery.isNotBlank()) "“$objQuery” ▾" else "Filtre ▾") else "${filter.label} ▾") }
                        DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                            for (opt in FaceFilter.values()) DropdownMenuItem(
                                text = { Text(if (opt == filter) "✓ ${opt.label}" else opt.label) },
                                onClick = { filter = opt; menu = false })
                            // Eski "Belirsiz" seçeneğinin yerinde: nesne ismi kutusu (silik ipucu); yazılana göre süzer, boşaltınca süzme kalkar
                            FieldBox(objText, { objText = it; if (it.isBlank()) objQuery = "" }, "Nesne ismi", null,
                                Modifier.padding(horizontal = 8.dp, vertical = 4.dp).widthIn(min = 200.dp),
                                search = true, onSearch = { objQuery = objText.trim(); menu = false })
                        }
                    }
                }
                Text("Son analizde (ve kayıtlı sonuçlardan açtıklarında) bulunan yüzler; her kişi bir kez, en net hâliyle. Yüze dokununca o kişinin tüm fotoğrafları açılır; adı, cinsiyeti ve saç rengini düzeltmek için yüze basılı tutup bırak; basılı tutup sürüklersen yerini değiştirirsin (sıra kalıcıdır).",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                barProgress?.let { (d, t) ->
                    Text("$barTitle: $d / $t", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.padding(top = 4.dp))
                }
            }
        }
        if (faces.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { Text("Henüz bulunmuş yüz yok. Bir analiz yaptığında burada görünür.") }
        else if (shown.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) {
            Text(if (barProgress != null) "Analiz sürüyor, sonuçlar geldikçe burada görünür." else "Bu filtreye uyan yüz yok.")
        }
        itemsIndexed(shown, key = { _, f -> f.thumb }) { i, f ->
            val curIdx by rememberUpdatedState(i)
            val dragging = dragKey == f.thumb
            Column(Modifier.fillMaxWidth()
                .onSizeChanged { cellW = it.width + gapPx; cellH = it.height + gapPx }
                .zIndex(if (dragging) 1f else 0f)
                .graphicsLayer {
                    translationX = if (dragging) dragX else 0f; translationY = if (dragging) dragY else 0f
                    scaleX = if (dragging) 1.1f else 1f; scaleY = if (dragging) 1.1f else 1f; alpha = if (dragging) 0.85f else 1f
                }
                .pointerInput(f.thumb) { detectTapGestures(onTap = { vm.openFace(f) }) }
                .pointerInput(f.thumb) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { dragKey = f.thumb; dragX = 0f; dragY = 0f },
                        onDrag = { change, amount -> change.consume(); dragX += amount.x; dragY += amount.y },
                        onDragEnd = {
                            val n = shownNow.size; val cols = 3; val rowsN = (n + cols - 1) / cols
                            val from = curIdx
                            val col = ((((from % cols) + 0.5f) * cellW + dragX) / cellW).toInt().coerceIn(0, cols - 1)
                            val rw = ((((from / cols) + 0.5f) * cellH + dragY) / cellH).toInt().coerceIn(0, rowsN - 1)
                            val to = (rw * cols + col).coerceIn(0, n - 1)
                            val still = abs(dragX) < 24f && abs(dragY) < 24f   // sürüklenmeden bırakıldı: düzenleme penceresi
                            dragKey = null; dragX = 0f; dragY = 0f
                            if (still) editing = f else if (to != from) moveFace(from, to)
                        },
                        onDragCancel = { dragKey = null; dragX = 0f; dragY = 0f })
                },
                horizontalAlignment = Alignment.CenterHorizontally) {
                AsyncImage(File(f.thumb), null, Modifier.size(96.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                Text(f.name.ifBlank { "Adsız" }, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${f.photos} fotoğraf", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    // Filtre için yüzler analiz edilirken ekranın altında temaya uygun ilerleme çubuğu
    barProgress?.let { (d, t) ->
        val frac = (d.toFloat() / t.coerceAtLeast(1)).coerceIn(0f, 1f)
        val anim by androidx.compose.animation.core.animateFloatAsState(frac, androidx.compose.animation.core.tween(300), label = "attrProgress")
        Surface(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(12.dp), shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.primaryContainer, contentColor = MaterialTheme.colorScheme.onPrimaryContainer, tonalElevation = 6.dp, shadowElevation = 6.dp) {
            Column(Modifier.padding(14.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(barTitle, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold, modifier = Modifier.weight(1f))
                    Text("$d / $t  •  %${(anim * 100).toInt()}", fontWeight = androidx.compose.ui.text.font.FontWeight.SemiBold)
                }
                Spacer(Modifier.height(8.dp))
                LinearProgressIndicator(progress = { anim }, modifier = Modifier.fillMaxWidth().height(10.dp).clip(androidx.compose.foundation.shape.RoundedCornerShape(5.dp)),
                    color = MaterialTheme.colorScheme.primary, trackColor = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.2f),
                    strokeCap = androidx.compose.ui.graphics.StrokeCap.Round)
            }
        }
    }
    }
    editing?.let { f ->
        var text by remember(f) { mutableStateOf(f.name) }
        val cur = FaceAttrs.get(f.thumb)
        var gSel by remember(f) { mutableStateOf(if (cur?.m == true) cur.g else null) }   // null = otomatik
        var hSel by remember(f) { mutableStateOf(if (cur?.m == true) cur.h else null) }
        AlertDialog(onDismissRequest = { editing = null }, title = { Text("Kişiyi düzenle") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AsyncImage(File(f.thumb), null, Modifier.size(88.dp).clip(CircleShape).align(Alignment.CenterHorizontally), contentScale = ContentScale.Crop)
                    FieldBox(text, { text = it }, "Ad", Icons.Filled.Person)
                    Text("Cinsiyet" + (cur?.takeIf { !it.m }?.let { " (otomatik: ${genderName(it.g)})" } ?: ""), style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(gSel == null, { gSel = null }, { Text("Otomatik") })
                        FilterChip(gSel == "M", { gSel = "M" }, { Text("Erkek") })
                        FilterChip(gSel == "F", { gSel = "F" }, { Text("Kadın") })
                    }
                    Text("Saç rengi" + (cur?.takeIf { !it.m }?.let { " (otomatik: ${hairName(it.h)})" } ?: ""), style = MaterialTheme.typography.labelMedium)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(hSel == null, { hSel = null }, { Text("Otomatik") })
                        FilterChip(hSel == "B", { hSel = "B" }, { Text("Sarışın") })
                        FilterChip(hSel == "D", { hSel = "D" }, { Text("Esmer") })
                        FilterChip(hSel == "R", { hSel = "R" }, { Text("Kızıl") })
                    }
                    TonalAction("Kaydedilen yüzlere ekle", { vm.addSavedFromEntry(f); editing = null }, Modifier.fillMaxWidth(), icon = Icons.Filled.Face)
                    TonalAction("Ünlülere taşı", { vm.moveToCelebs(f, text); editing = null }, Modifier.fillMaxWidth(), icon = Icons.Filled.Star)
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    vm.renameMembers(f.members, text)
                    if (gSel == null && hSel == null) {
                        if (cur?.m == true) { FaceAttrs.remove(f.thumb); FaceAttrs.persist(ctx); attrRev++ }   // elle düzeltme kalktı: yeniden otomatik analiz
                    } else {
                        FaceAttrs.put(f.thumb, FaceAttrs.A(gSel ?: cur?.g ?: "?", hSel ?: cur?.h ?: "?", true))
                        FaceAttrs.persist(ctx); tick++
                    }
                    editing = null
                }) { Text("Kaydet") }
            },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Vazgeç") } })
    }
}

private fun genderName(g: String) = when (g) { "M" -> "erkek"; "F" -> "kadın"; else -> "belirsiz" }
private fun hairName(h: String) = when (h) { "B" -> "sarışın"; "D" -> "esmer"; "R" -> "kızıl"; else -> "belirsiz" }
