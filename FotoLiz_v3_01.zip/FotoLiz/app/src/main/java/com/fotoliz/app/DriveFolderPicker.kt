package com.fotoliz.app

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Drive'daki klasörlerde gezinip birini seçtiren pencere (yeni klasör de oluşturulabilir). onPicked(kimlik, ad). */
@Composable
fun DriveFolderPicker(onPicked: (String, String) -> Unit, onNeedConsent: () -> Unit, onDismiss: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var stack by remember { mutableStateOf(listOf(Pair("root", "Drive ana dizini"))) }
    var folders by remember { mutableStateOf(listOf<Pair<String, String>>()) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var newName by remember { mutableStateOf<String?>(null) }
    val cur = stack.last()

    LaunchedEffect(cur.first) {
        loading = true; error = null
        try { folders = withContext(Dispatchers.IO) { DriveBackup.listFolders(ctx, cur.first) } }
        catch (e: CancellationException) { throw e }
        catch (e: DriveBackup.NeedConsent) { folders = emptyList(); error = "Drive klasörlerini listelemek için Google izni gerekiyor; izin ekranı açılıyor…"; onNeedConsent() }
        catch (e: Throwable) { folders = emptyList(); error = DriveBackup.explain(e) }
        loading = false
    }

    AlertDialog(onDismissRequest = onDismiss, title = { Text("Drive klasörü seç") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(stack.joinToString(" › ") { it.second }, style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold)
                if (stack.size > 1) TextButton(onClick = { stack = stack.dropLast(1) }) { Text("Üst klasöre çık") }
                if (loading) LinearProgressIndicator(Modifier.fillMaxWidth())
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                if (!loading && error == null && folders.isEmpty())
                    Text("Bu klasörde alt klasör yok. İstersen bu klasörü seç.", style = MaterialTheme.typography.bodySmall)
                Column(Modifier.fillMaxWidth().heightIn(max = 280.dp).verticalScroll(rememberScrollState())) {
                    if (stack.size == 1 && error == null) {
                        Text("👥  Benimle paylaşılanlar", Modifier.fillMaxWidth().clickable { stack = stack + Pair("shared", "Benimle paylaşılanlar") }.padding(vertical = 12.dp))
                        HorizontalDivider()
                    }
                    folders.forEach { f ->
                        Text("📁  " + f.second, Modifier.fillMaxWidth().clickable { stack = stack + f }.padding(vertical = 12.dp))
                        HorizontalDivider()
                    }
                }
                TextButton(onClick = { newName = "" }) { Text("Yeni klasör oluştur") }
            }
        },
        confirmButton = { TextButton(enabled = !loading && error == null && cur.first != "shared", onClick = { onPicked(cur.first, cur.second) }) { Text("Bu klasörü seç") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } })

    newName?.let { nm ->
        AlertDialog(onDismissRequest = { newName = null }, title = { Text("Yeni klasör") },
            text = { FieldBox(nm, { newName = it }, "Klasör adı") },
            confirmButton = {
                TextButton(enabled = nm.isNotBlank(), onClick = {
                    val n = nm.trim(); val parent = cur.first
                    newName = null; loading = true; error = null
                    scope.launch {
                        try {
                            val c = withContext(Dispatchers.IO) { DriveBackup.createFolder(ctx, parent, n) }
                            stack = stack + c
                        } catch (e: CancellationException) { throw e }
                        catch (e: Throwable) { error = DriveBackup.explain(e); loading = false }
                    }
                }) { Text("Oluştur") }
            },
            dismissButton = { TextButton(onClick = { newName = null }) { Text("Vazgeç") } })
    }
}
