package com.fotoliz.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.media.RingtoneManager
import android.net.Uri
import android.os.Handler
import android.os.Looper
import androidx.core.app.NotificationCompat
import kotlin.math.PI
import kotlin.math.exp
import kotlin.math.sin

/**
 * Biten işlem sesi + "yarım kalan işlem" uyarısı.
 * Ses: Ayarlar > Sesler > "Biten Analiz" ile değiştirilir. Varsayılan: yazarkasa açılma ("ka-ching") sesi (kod ile üretilir, dosya gerekmez).
 */
object DoneSound {
    private const val PREF = "fotoliz_sound"; private const val KEY = "done_uri"   // "" = yazarkasa, "silent" = sessiz, aksi halde seçilen sesin adresi
    private const val CH_WARN = "unfinished"; private const val WARN_ID = 3

    /** run=false: "Biten Analiz" sesi (analiz / tarama / yüz gruplama / arama bitince); run=true: "Devam Eden Analiz" sesi (bir analiz başlayıp sürerken BİR KERE çalar). */
    private fun key(run: Boolean) = if (run) "run_uri" else KEY
    private fun muteKey(run: Boolean) = if (run) "run_mute" else "done_mute"
    /** Devam eden analiz sesi bu çalışma için çalındı mı? (bir kere çalsın) Yeni bir çalışma başlayınca ya da biten ses çalınca sıfırlanır. */
    @Volatile var runPlayed = false

    fun getUri(ctx: Context, run: Boolean = false): String = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getString(key(run), "") ?: ""
    fun setUri(ctx: Context, v: String, run: Boolean = false) { ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putString(key(run), v).apply() }
    fun isMuted(ctx: Context, run: Boolean = false): Boolean = ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(muteKey(run), false)
    fun setMuted(ctx: Context, run: Boolean, m: Boolean) { ctx.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(muteKey(run), m).apply() }

    fun label(ctx: Context, run: Boolean = false): String {
        val v = getUri(ctx, run)
        if (v.isEmpty()) return if (run) "Kısa bip (varsayılan)" else "Yazarkasa (varsayılan)"
        if (v == "silent") return "Sessiz"
        return try { RingtoneManager.getRingtone(ctx, Uri.parse(v))?.getTitle(ctx) ?: "Seçilen ses" } catch (e: Throwable) { "Seçilen ses" }
    }

    /** İşlem bitince çalar. Hata verirse sessizce geçer (program kapanmaz). */
    fun play(ctx: Context, run: Boolean = false, force: Boolean = false) {
        try {
            val app = ctx.applicationContext
            if (!run) runPlayed = false   // bir işlem bitti: sıradaki analizde "devam ediyor" sesi yine bir kere çalar
            if (!force && isMuted(app, run)) return   // "Sessize al" açıksa hiçbir şey çalmaz ("Dene" düğmesi force ile yine çalar)
            val v = getUri(app, run)
            when {
                v == "silent" -> {}
                v.isEmpty() -> if (run) blip() else kaChing()
                else -> RingtoneManager.getRingtone(app, Uri.parse(v))?.let { r ->
                    r.audioAttributes = AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build()
                    r.play()
                } ?: (if (run) blip() else kaChing())
            }
        } catch (e: Throwable) { }
    }

    /** Devam eden analiz: yumuşak, kısa iki "bip" (kod ile üretilir). */
    private fun blip() {
        val sr = 22050
        val n = (sr * 0.45).toInt()
        val pcm = ShortArray(n)
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            var s = 0.0
            for ((st, f) in listOf(0.0 to 880.0, 0.2 to 1175.0)) { val u = t - st; if (u >= 0 && u < 0.18) s += sin(2 * PI * f * u) * exp(-u * 14) * 0.5 }
            pcm[i] = (s.coerceIn(-1.0, 1.0) * 26000).toInt().toShort()
        }
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(n * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
        track.write(pcm, 0, n)
        track.play()
        Handler(Looper.getMainLooper()).postDelayed({ try { track.release() } catch (e: Throwable) { } }, 900)
    }

    /** Kısa "tık" + iki çan sesi (yazarkasa). */
    private fun kaChing() {
        val sr = 22050
        val n = (sr * 1.1).toInt()
        val pcm = ShortArray(n)
        val rnd = java.util.Random(7)
        for (i in 0 until n) {
            val t = i / sr.toDouble()
            var s = 0.0
            if (t < 0.05) s += (rnd.nextDouble() * 2 - 1) * exp(-t * 90) * 0.6 + sin(2 * PI * 520 * t) * exp(-t * 70) * 0.4   // "ka": çekmece tıkırtısı
            val t2 = t - 0.07
            if (t2 >= 0) for ((f, a) in listOf(2093.0 to 0.30, 2637.0 to 0.24, 4186.0 to 0.12, 5587.0 to 0.06)) s += sin(2 * PI * f * t2) * a * exp(-t2 * 5.5)   // "çing": çan
            pcm[i] = (s.coerceIn(-1.0, 1.0) * 30000).toInt().toShort()
        }
        val track = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_NOTIFICATION).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
            .setAudioFormat(AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sr).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
            .setBufferSizeInBytes(n * 2).setTransferMode(AudioTrack.MODE_STATIC).build()
        track.write(pcm, 0, n)
        track.play()
        Handler(Looper.getMainLooper()).postDelayed({ try { track.release() } catch (e: Throwable) { } }, 1600)
    }

    private const val CH_PEND = "pending_analysis"; private const val PEND_ID = 4

    /** Yarım kalan analiz bildirimi: kırmızı ışıklı, dokununca uygulamayı açar; analiz devam ettirilene / silinene kadar bildirim çubuğunda kalır. */
    fun notifyPending(ctx: Context, text: String) {
        try {
            val app = ctx.applicationContext
            val nm = app.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(CH_PEND, "Yarım kalan analiz", NotificationManager.IMPORTANCE_DEFAULT)
            ch.enableLights(true); ch.lightColor = android.graphics.Color.RED; ch.setSound(null, null); ch.enableVibration(false)
            nm.createNotificationChannel(ch)
            val pi = android.app.PendingIntent.getActivity(app, 4,
                android.content.Intent(app, MainActivity::class.java).addFlags(android.content.Intent.FLAG_ACTIVITY_SINGLE_TOP or android.content.Intent.FLAG_ACTIVITY_NEW_TASK),
                android.app.PendingIntent.FLAG_IMMUTABLE or android.app.PendingIntent.FLAG_UPDATE_CURRENT)
            val b = NotificationCompat.Builder(app, CH_PEND).setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("Yarım kalan analiz").setContentText(text).setContentIntent(pi)
                .setLights(android.graphics.Color.RED, 400, 600).setOnlyAlertOnce(true).setAutoCancel(false)
            nm.notify(PEND_ID, b.build())
        } catch (e: Throwable) { }
    }
    fun cancelPending(ctx: Context) { try { ctx.applicationContext.getSystemService(NotificationManager::class.java).cancel(PEND_ID) } catch (e: Throwable) { } }

    /** Yarım kalan işlem uyarısı: 5 sn süren, ışıklı (LED) bildirim. Uygulama içi yanıp sönen şerit ayrıca Galeri ekranında gösterilir. */
    fun warnUnfinished(ctx: Context, text: String) {
        try {
            GalleryState.unfinishedUntil = System.currentTimeMillis() + 5000L
            val app = ctx.applicationContext
            val nm = app.getSystemService(NotificationManager::class.java)
            val ch = NotificationChannel(CH_WARN, "Yarım kalan işlem", NotificationManager.IMPORTANCE_DEFAULT)
            ch.enableLights(true); ch.lightColor = android.graphics.Color.rgb(255, 160, 0); ch.setSound(null, null); ch.enableVibration(false)
            nm.createNotificationChannel(ch)
            val b = NotificationCompat.Builder(app, CH_WARN).setSmallIcon(android.R.drawable.stat_notify_sync)
                .setContentTitle("FotoLiz").setContentText(text).setLights(android.graphics.Color.rgb(255, 160, 0), 300, 300)
                .setTimeoutAfter(5000L).setAutoCancel(true).setOnlyAlertOnce(true)
            nm.notify(WARN_ID, b.build())
        } catch (e: Throwable) { }
    }
}
