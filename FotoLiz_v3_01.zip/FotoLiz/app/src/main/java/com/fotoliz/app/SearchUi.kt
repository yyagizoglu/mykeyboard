package com.fotoliz.app

import android.net.Uri
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/** Nesne arama sonuç ekranı: tarama ilerlemesi + bulunan fotoğrafların canlı küçük resimleri. */
@Composable
fun SearchScreen(vm: VM) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val running = SearchEngine.running
    val hits = SearchEngine.hits.toList()
    val fgGroups = FoundGroup.valid("search", hits)
    val fgOpen = if (fgGroups != null) FoundGroup.openGroup else null
    Column(Modifier.fillMaxSize()) {
        PanelCard(Modifier.padding(12.dp)) {
            Text("“${SearchEngine.query}”", style = MaterialTheme.typography.titleMedium)
            Text(SearchEngine.status, style = MaterialTheme.typography.bodyMedium)
            if (running || SearchEngine.resumable) GreenProgress(SearchEngine.done.toFloat() / SearchEngine.total.coerceAtLeast(1))
            val labels = SearchEngine.matchedLabels
            if (labels.isNotEmpty()) Text("Aranan etiketler: " + labels.take(10).joinToString(", ") + if (labels.size > 10) " …" else "",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            SearchEngine.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
            // Kırmızı Durdur + yeşil Devam et yan yana: Durdur aramayı duraklatır, Devam et kaldığı fotoğraftan sürdürür
            if (running || SearchEngine.resumable) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ColorAction("Durdur", Color(0xFFD32F2F), { SearchEngine.cancel() }, Modifier.weight(1f), enabled = running)
                ColorAction("Devam et", Color(0xFF2E7D32), { SearchEngine.resume(ctx.applicationContext as android.app.Application) }, Modifier.weight(1f), enabled = SearchEngine.resumable)
            }
            if (!running || hits.isNotEmpty()) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                if (!running) TonalAction("Yeni arama", { vm.screen = Screen.Main }, Modifier.weight(1f))
                if (hits.isNotEmpty()) TonalAction("Seç / incele (${hits.size})", { vm.openSearchResults() }, Modifier.weight(1f))
            }
            PrimaryAction("Kaydet: albüm seç / oluştur (${hits.size})", { vm.beginSave(false) }, enabled = !running && hits.isNotEmpty(), icon = Icons.Filled.Check)
            Text(if (running) "Arama arka planda sürer; ekranı kapatabilir veya uygulamadan çıkabilirsiniz. Durdur'a basarsanız o ana kadar bulunanlar bitmiş sonuç sayılır ve kaydedilebilir."
                else if (SearchEngine.resumable) "Arama durduruldu (${SearchEngine.done}/${SearchEngine.total}). Devam et ile kaldığı yerden sürdürebilir ya da bulunan ${hits.size} fotoğrafı Kaydet ile albüme alabilirsin."
                else if (SearchEngine.stopped) "Arama durduruldu; bulunan ${hits.size} fotoğraf hafızada. Kaydet'e basıp istediklerini seçebilirsin."
                else "Kaydet'e basınca bulunanlardan istediklerini seçer, sonra hangi albüme taşıyacağını belirlersin (yeni albüm de açabilirsin).",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        FoundGroupBar("search", hits, running || SearchEngine.resumable)
        if (!running && hits.isEmpty() && SearchEngine.error == null)
            Text("Seçtiğiniz albümlerde “${SearchEngine.query}” bulunamadı. Nesne adlarını boşlukla ayırarak yazın (örn. araba kedi) ya da İngilizcesini deneyin (car). " +
                "Not: arama, telefonun tanıyabildiği yaygın nesnelerle çalışır.", Modifier.padding(16.dp), style = MaterialTheme.typography.bodyMedium)
        LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), contentPadding = PaddingValues(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            foundItems(fgGroups, fgOpen, hits) { i, l -> vm.openSearchResults(i, l) }
        }
    }
}

/** Ana ekrandaki arama kutusu. Kelimeler boşlukla ayrılır; virgül gerekmez. */
@Composable
fun SearchBox(vm: VM, pickAlbums: () -> Unit) {
    val go = { if (vm.searchText.isNotBlank()) { vm.searchMode = true; vm.searchPickOnly = false; vm.personMode = false; pickAlbums() } }
    // Albümler daha önce "Albüm Seç" ile seçildiyse doğrudan arar; seçilmediyse önce albüm seçtirir
    val doSearch = {
        if (vm.searchText.isNotBlank()) {
            if (vm.searchPicked && vm.chosenAlbums.isNotEmpty()) { vm.searchMode = true; vm.searchPickOnly = false; vm.personMode = false; vm.startSearch() } else go()
        }
    }
    SectionCard(Icons.Filled.Search, "Nesne ara", "Her kelime ayrı bir nesne olarak aranır", compact = true) {
        FieldBox(vm.searchText, { vm.searchText = it }, "Örn. evrak araba kedi", Icons.Filled.Search, search = true, onSearch = { doSearch() })
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PrimaryAction(if (vm.searchPicked && vm.chosenAlbums.isNotEmpty()) "Albüm Seç (${vm.chosenAlbums.size})" else "Albüm Seç",
                { vm.searchMode = true; vm.searchPickOnly = true; vm.personMode = false; pickAlbums() }, Modifier.weight(1f), h = 42.dp)
            // Albüm ekranındaki "Sayı Girin" ile aynı değer: rakam burada da görünür ve değiştirilebilir (boş = hepsi)
            CountField(vm.photoLimit, { vm.photoLimit = it }, Modifier.width(92.dp), placeholder = "Sayı")
            Button(onClick = { doSearch() }, enabled = vm.searchText.isNotBlank(), modifier = Modifier.height(42.dp),
                shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(horizontal = 14.dp)) {
                Icon(Icons.Filled.Search, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Ara", fontWeight = FontWeight.SemiBold)
            }
        }
        Text("Seçtiğin albümlerdeki fotoğraflardan bu nesnelerden herhangi biri görünenleri bulur. Virgül koymana gerek yok.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (SearchEngine.query.isNotBlank() && (SearchEngine.running || SearchEngine.resumable || SearchEngine.hits.isNotEmpty())) {
            RecentRow(if (SearchEngine.running) "Arama sürüyor: “${SearchEngine.query}” (${SearchEngine.hits.size})"
                else if (SearchEngine.resumable) "Arama durduruldu: “${SearchEngine.query}” • ${SearchEngine.hits.size} fotoğraf"
                else "Son arama: “${SearchEngine.query}” • ${SearchEngine.hits.size} fotoğraf") { vm.screen = Screen.Search }
            // Arama sürerken (ya da duraklatılmışken) ana ekranda da yeşil, içi dolan ilerleme çubuğu
            if (SearchEngine.running || SearchEngine.resumable) {
                val pct = (SearchEngine.done.toFloat() / SearchEngine.total.coerceAtLeast(1) * 100).toInt()
                GreenProgress(SearchEngine.done.toFloat() / SearchEngine.total.coerceAtLeast(1))
                Text("%$pct • ${SearchEngine.done}/${SearchEngine.total} fotoğraf tarandı • ${SearchEngine.hits.size} bulundu" + if (SearchEngine.running) "" else " • duraklatıldı",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}
