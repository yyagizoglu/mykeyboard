package com.fotoliz.app

import android.app.Application
import android.content.ContentUris
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.*
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeler
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import java.util.Locale
import java.util.concurrent.ArrayBlockingQueue
import kotlin.math.max

/** Türkçe nesne adı -> ML Kit (İngilizce) etiketleri. Arama kutusuna yazılan kelime buradan çözülür. */
object TrObjects {
    private val tr = Locale("tr", "TR")
    private val dict = HashMap<String, List<String>>()
    private fun add(words: String, vararg labels: String) { for (w in words.split(",")) { val k = w.trim(); dict[k] = ((dict[k] ?: emptyList()) + labels).distinct() } }

    init {
        add("araba,otomobil,araç,oto,taksi,cip,spor araba", "car", "sedan", "sports car", "supercar", "taxi", "hatchback", "suv", "mid-size car",
            "compact car", "station wagon", "coupé", "luxury vehicle", "family car", "city car", "race car", "convertible", "full-size car", "pickup truck")
        add("motor,motosiklet,scooter", "motorcycle", "scooter", "moped", "motorcycling", "motorcycle racing", "motorcycle helmet", "cruiser")
        add("bisiklet", "bicycle", "bicycle wheel", "bicycle frame", "mountain bike", "road bicycle", "cycling", "bicycle tire", "bmx")
        add("kamyon,kamyonet,tır", "truck", "van", "pickup truck", "commercial vehicle", "trailer truck", "minivan")
        add("otobüs,minibüs", "bus", "minibus", "public transport")
        add("uçak,helikopter,havaalanı", "airplane", "aircraft", "airliner", "aviation", "jet", "helicopter")
        add("gemi,tekne,yat,vapur,kayık", "boat", "ship", "watercraft", "yacht", "sailboat", "water transportation", "vessel", "cruise ship")
        add("tren,lokomotif,raylı sistem", "train", "rail transport", "railway", "locomotive")
        add("tekerlek,lastik,jant", "wheel", "tire", "automotive tire", "rim", "alloy wheel")
        add("kedi,kedicik,yavru kedi", "cat", "kitten", "whiskers", "small to medium-sized cats", "felidae")
        add("köpek,köpekçik,yavru köpek", "dog", "puppy", "dog breed", "canidae")
        add("kuş,papağan,martı,güvercin", "bird", "beak", "water bird", "seabird", "feather", "parrot")
        add("at,midilli", "horse", "mane", "pony", "stallion")
        add("balık,akvaryum", "fish", "aquarium")
        add("inek,sığır,boğa", "cattle", "cow")
        add("koyun,kuzu,keçi", "sheep", "goat")
        add("tavşan", "rabbit")
        add("tavuk,horoz,ördek,kaz", "chicken", "rooster", "duck", "goose", "bird")
        add("fil", "elephant")
        add("aslan,kaplan,leopar", "lion", "tiger", "leopard", "big cats")
        add("ayı", "bear")
        add("maymun", "monkey", "primate")
        add("kelebek", "butterfly", "moths and butterflies")
        add("böcek,örümcek,arı", "insect", "spider", "bee", "arthropod", "bug")
        add("yılan,kaplumbağa,kertenkele,kurbağa", "snake", "turtle", "lizard", "frog", "reptile")
        add("hayvan,evcil hayvan", "animal", "mammal", "pet", "wildlife", "terrestrial animal", "carnivore", "cat", "dog", "bird", "horse", "fish")
        add("yemek,yiyecek,yemek fotoğrafı", "food", "dish", "cuisine", "meal", "fast food", "recipe", "lunch", "dinner", "breakfast", "snack", "ingredient")
        add("pizza", "pizza"); add("pasta,kek,tatlı,börek", "cake", "dessert", "baked goods", "pastry", "birthday cake", "cookie")
        add("ekmek", "bread", "baked goods"); add("çikolata", "chocolate"); add("dondurma", "ice cream")
        add("hamburger,sandviç,burger", "hamburger", "burger", "sandwich", "fast food")
        add("salata", "salad"); add("peynir", "cheese"); add("yumurta", "egg")
        add("meyve,elma,muz,portakal,çilek,üzüm", "fruit", "apple", "banana", "orange", "strawberry", "grape", "natural foods")
        add("sebze,domates,patates", "vegetable", "tomato", "potato", "produce")
        add("içecek,kahve,çay,meşrubat", "drink", "coffee", "tea", "beverage", "juice", "drinkware", "cup", "mug")
        add("bardak,fincan,kupa", "cup", "mug", "drinkware", "coffee cup", "tableware")
        add("şişe", "bottle", "water bottle", "glass bottle")
        add("şarap,bira,kokteyl", "wine", "beer", "cocktail", "alcoholic beverage")
        add("çiçek,gül,lale,buket", "flower", "petal", "flowering plant", "rose", "bouquet", "floral design", "tulip")
        add("ağaç,orman,bitki,yaprak,çimen,bahçe", "tree", "plant", "leaf", "woody plant", "forest", "grass", "garden", "shrub", "houseplant")
        add("gökyüzü,bulut", "sky", "cloud", "cumulus"); add("gün batımı,gün doğumu,gündoğumu", "sunset", "sunrise", "dusk", "afterglow")
        add("manzara,doğa", "landscape", "natural landscape", "nature", "mountain", "hill", "valley", "field", "sky")
        add("dağ,tepe,zirve", "mountain", "hill", "mountainous landforms", "mountain range", "summit", "highland")
        add("deniz,okyanus,sahil", "sea", "ocean", "coast", "shore", "wave", "beach", "bay", "horizon")
        add("plaj,kumsal", "beach", "sand", "coast", "shore")
        add("göl,nehir,dere,şelale", "lake", "river", "waterfall", "stream", "body of water", "water", "pond")
        add("havuz,yüzme havuzu", "swimming pool", "pool")
        add("kar,kış,buz", "snow", "winter", "ice", "freezing", "frost")
        add("ateş,şömine,mum", "fire", "flame", "fireplace", "candle", "bonfire")
        add("havai fişek,havaifişek", "fireworks")
        add("bina,yapı,mimari,gökdelen", "building", "architecture", "skyscraper", "tower", "facade", "tower block", "commercial building")
        add("ev,konut", "house", "home", "roof", "residential area", "cottage", "villa")
        add("köprü", "bridge", "arch bridge", "suspension bridge")
        add("cami,minare,kilise,şato,kale,anıt", "mosque", "church", "castle", "monument", "landmark", "place of worship", "tower", "statue", "memorial")
        add("heykel,heykeltıraşlık", "statue", "sculpture", "monument")
        add("sokak,cadde,yol,şehir,kent", "street", "road", "city", "urban area", "town", "alley", "neighbourhood", "metropolis")
        add("pencere,kapı,duvar", "window", "door", "wall", "facade")
        add("oda,iç mekan,salon", "room", "interior design", "living room", "bedroom", "kitchen", "bathroom")
        add("mobilya,masa,sandalye,koltuk,kanepe,yatak,dolap", "furniture", "table", "chair", "couch", "sofa", "bed", "shelf", "desk", "cabinetry", "bookcase")
        add("mutfak", "kitchen", "cooking", "kitchen appliance"); add("banyo", "bathroom", "bathtub", "toilet")
        add("lamba,avize,aydınlatma", "lamp", "light fixture", "lighting", "chandelier")
        add("saat,duvar saati", "watch", "clock", "wall clock", "analog watch")
        add("ayna", "mirror"); add("perde", "curtain")
        add("telefon,cep telefonu,akıllı telefon", "mobile phone", "smartphone", "gadget", "communication device", "portable communications device", "telephone")
        add("ekran görüntüsü", "screenshot", "multimedia", "software", "website", "font")
        add("bilgisayar,laptop,dizüstü,monitör,klavye", "computer", "laptop", "personal computer", "computer monitor", "computer keyboard", "netbook", "output device", "computer hardware")
        add("televizyon,tv", "television", "television set", "flat panel display", "display device")
        add("tablet", "tablet computer"); add("kamera,fotoğraf makinesi", "camera", "digital camera", "camera lens", "photographic equipment")
        add("kulaklık,hoparlör", "headphones", "audio equipment", "loudspeaker", "speaker")
        add("oyun,video oyunu,konsol", "video game", "game", "game console", "pc game", "gamer")
        add("evrak,belge,kağıt,fatura,makbuz,dilekçe,sözleşme,form", "document", "receipt", "paper", "paper product", "text", "invoice", "form", "page", "certificate", "handwriting", "writing")
        add("kitap,dergi,gazete,defter", "book", "publication", "newspaper", "notebook", "magazine", "paperback", "novel")
        add("afiş,poster,tabela", "poster", "signage", "sign", "banner", "advertising")
        add("giysi,elbise,kıyafet,ceket,tişört,pantolon,gömlek", "clothing", "dress", "jacket", "sleeve", "t-shirt", "jeans", "outerwear", "shirt", "trousers", "fashion", "suit", "coat")
        add("ayakkabı,bot,spor ayakkabı,terlik", "shoe", "footwear", "sneakers", "boot", "sandal")
        add("şapka,bere,kep", "hat", "cap", "beanie", "fedora")
        add("gözlük,güneş gözlüğü", "glasses", "sunglasses", "eyewear", "goggles")
        add("çanta,sırt çantası,cüzdan", "bag", "handbag", "backpack", "luggage and bags", "wallet", "suitcase")
        add("takı,mücevher,yüzük,kolye,küpe", "jewellery", "ring", "necklace", "earrings", "bracelet", "gemstone", "body jewelry", "wedding ring")
        add("gelinlik,düğün,gelin,nişan", "wedding", "bride", "wedding dress", "bridal clothing", "wedding ceremony", "groom", "veil", "bridal party dress")
        add("doğum günü,parti,kutlama,balon,hediye", "birthday", "party", "balloon", "birthday cake", "celebration", "event", "gift", "confetti", "party supply")
        add("resim,çizim,sanat,tablo,karikatür,illüstrasyon,boyama", "drawing", "painting", "art", "cartoon", "illustration", "visual arts", "sketch", "anime", "mural", "graffiti", "modern art", "watercolor paint")
        add("spor,top,futbol,basketbol,tenis,voleybol,maç,stadyum", "sports", "ball", "football", "soccer", "basketball", "team sport", "stadium", "tennis", "athlete", "player", "volleyball", "sports equipment", "ball game")
        add("koşu,yüzme,fitness,spor salonu", "running", "swimming", "gym", "physical fitness", "exercise", "marathon", "jogging")
        add("müzik,konser,gitar,piyano,sahne,enstrüman", "concert", "guitar", "musical instrument", "piano", "stage", "performing arts", "music", "microphone", "audience", "crowd", "drum")
        add("oyuncak,bebek,peluş,lego,ayıcık", "toy", "doll", "stuffed toy", "lego", "teddy bear", "action figure", "plush")
        add("alet,çekiç,tamir,makine,motor parçası", "tool", "hammer", "machine", "engine", "machine tool", "hand tool", "screwdriver", "wrench")
        add("silah,bıçak", "gun", "knife", "firearm", "weapon", "sword")
        add("kask", "helmet", "motorcycle helmet", "hard hat", "bicycle helmet")
        add("insan,kişi,adam,kadın,erkek,portre", "person", "people", "human", "face", "selfie", "portrait", "child", "baby", "toddler")
        add("bebek,çocuk,yavru", "baby", "toddler", "child", "infant", "kid", "boy", "girl")
        add("gülümseme,selfie,özçekim", "smile", "selfie", "facial expression")
        add("kalabalık,topluluk,grup", "crowd", "people", "audience", "team", "community", "social group")
        add("ayak,ayak parmağı,tabanı,taban", "foot", "toe", "barefoot", "human leg", "leg", "ankle", "sandal", "flip-flops")
        add("el,parmak,avuç,tırnak", "hand", "finger", "nail", "thumb", "wrist", "manicure", "nail polish", "gesture")
        // İnsan uzuvları / vücut bölümleri: etiket varsa fotoğraf süzülmeden olduğu gibi getirilir
        add("kol,kollar,pazı,biceps", "arm", "shoulder", "muscle", "elbow", "sleeve", "human body", "joint")
        add("bacak,bacaklar,but,uyluk", "leg", "human leg", "thigh", "knee", "muscle", "joint", "barefoot", "human body")
        add("kalça,kalçalar,basen,bel", "hip", "waist", "thigh", "abdomen", "trunk", "human body", "swimwear", "undergarment", "briefs")
        add("diz,dirsek,bilek,eklem", "knee", "elbow", "wrist", "ankle", "joint")
        add("göz,gözler,kirpik,kaş", "eye", "eyes", "eyelash", "eyebrow", "iris", "eye shadow", "eyelid")
        add("burun", "nose", "nostril", "face", "snout")
        add("kulak", "ear", "earrings", "face")
        add("ağız,dudak,dil", "mouth", "lip", "tongue", "smile", "lipstick", "jaw")
        add("yüz,surat,çene,yanak,alın", "face", "chin", "cheek", "forehead", "head", "jaw", "facial expression", "skin")
        add("boyun,omuz,köprücük", "neck", "shoulder", "collarbone", "human body", "trunk")
        add("göğüs,karın,göbek,sırt,gövde,omurga", "chest", "abdomen", "barechested", "trunk", "back", "human body", "muscle", "waist")
        add("vücut,beden,uzuv,uzuvlar,ten,cilt,çıplak", "human body", "skin", "barechested", "trunk", "muscle", "arm", "leg", "thigh", "abdomen", "chest", "shoulder", "neck", "joint", "hand", "foot", "human leg")
        add("saç,kuaför,sakal,bıyık", "hair", "hairstyle", "long hair", "beard", "moustache", "hair coloring", "hair care")
        add("diş", "tooth", "teeth", "smile")
        add("kum,çöl", "sand", "desert", "dune", "aeolian landform")
        add("taş,kaya,kayalık", "rock", "stone", "boulder", "bedrock", "geology", "rubble")
        add("tarla,çiftlik,çayır", "field", "farm", "meadow", "agriculture", "pasture", "grassland", "plain")
        add("güneş,gün ışığı", "sun", "sunlight", "sunrise", "sunset", "daylight")
        add("gece,yıldız,ay", "night", "star", "moon", "midnight", "astronomical object", "constellation")
        add("yağmur,şemsiye", "rain", "umbrella", "drop", "wet")
        add("trafik,otoyol,yol", "road", "highway", "traffic", "asphalt", "lane", "road surface", "road trip")
        add("plaka", "license plate", "vehicle registration plate")
        add("market,mağaza,alışveriş", "supermarket", "shopping", "retail", "grocery store", "shopping mall", "market", "boutique")
        add("restoran,kafe,lokanta", "restaurant", "cafe", "bar", "coffeehouse", "tableware", "table")
        add("tabak,çatal,kaşık", "tableware", "dishware", "plate", "cutlery", "fork", "spoon", "dish")
        add("hastane,doktor,ilaç,sağlık", "hospital", "medicine", "health care", "medical", "pill", "stethoscope")
        add("okul,sınıf,öğrenci,ders", "school", "classroom", "student", "education", "teacher", "learning", "class")
        add("toplantı,ofis,iş", "meeting", "office", "business", "conference", "desk", "conference hall")
        add("harita,plan,grafik,tablo", "map", "diagram", "chart", "plan", "technical drawing")
        add("mektup,kart,zarf", "envelope", "card", "greeting card", "paper", "letter")
        add("para,banknot,madeni para", "money", "currency", "cash", "coin", "banknote", "dollar")
        add("bayrak", "flag", "flagpole")
        add("tabela,levha", "signage", "sign", "street sign", "traffic sign", "billboard")
    }

    private fun norm(s: String) = s.trim().lowercase(tr).replace(Regex("\\s+"), " ")
    private val suffixes = listOf("lar", "ler", "ları", "leri", "ın", "in", "un", "ün", "yı", "yi", "yu", "yü", "nı", "ni", "ı", "i", "u", "ü", "a", "e", "ya", "ye", "sı", "si", "su", "sü", "ları", "leri")

    /** KATI ARAMA: sık aranan kelimeler için yalnızca o nesnenin kendi etiketleri (geniş gruplar yok): "ağaç" artık "çimen / bahçe / bitki" etiketlerini getirmez. */
    private val core = HashMap<String, List<String>>()
    private fun cadd(words: String, vararg labels: String) { for (w in words.split(",")) core[w.trim()] = labels.toList() }
    init {
        cadd("ağaç", "tree", "woody plant"); cadd("orman", "forest"); cadd("bitki", "plant", "houseplant", "flowering plant"); cadd("yaprak", "leaf")
        cadd("çimen", "grass"); cadd("bahçe", "garden")
        cadd("çiçek", "flower", "petal", "flowering plant", "bouquet"); cadd("gül", "rose"); cadd("lale", "tulip"); cadd("buket", "bouquet")
        cadd("kahve", "coffee", "coffee cup"); cadd("çay", "tea"); cadd("içecek,meşrubat", "drink", "beverage"); cadd("bardak,fincan,kupa", "cup", "mug", "coffee cup")
        cadd("elma", "apple"); cadd("muz", "banana"); cadd("portakal", "orange"); cadd("çilek", "strawberry"); cadd("üzüm", "grape")
        cadd("domates", "tomato"); cadd("patates", "potato"); cadd("meyve", "fruit", "natural foods"); cadd("sebze", "vegetable", "produce")
        cadd("taksi", "taxi"); cadd("cip", "suv"); cadd("spor araba", "sports car", "supercar")
        cadd("gökyüzü", "sky"); cadd("bulut", "cloud", "cumulus"); cadd("deniz,okyanus", "sea", "ocean", "wave"); cadd("dağ", "mountain", "mountain range", "summit")
        cadd("göl", "lake"); cadd("nehir,dere", "river", "stream"); cadd("şelale", "waterfall"); cadd("plaj,kumsal", "beach")
        cadd("kuş", "bird", "beak", "feather"); cadd("papağan", "parrot"); cadd("martı", "seabird", "bird"); cadd("güvercin", "bird"); cadd("ördek", "duck"); cadd("kaz", "goose")
        cadd("tavuk", "chicken"); cadd("horoz", "rooster")
        cadd("tişört", "t-shirt"); cadd("pantolon", "trousers", "jeans"); cadd("gömlek", "shirt"); cadd("ceket", "jacket", "coat", "outerwear"); cadd("elbise", "dress")
        cadd("yüzük", "ring", "wedding ring"); cadd("kolye", "necklace"); cadd("küpe", "earrings")
        cadd("insan,kişi,adam,kadın,erkek", "person", "people", "human"); cadd("portre", "portrait")
        cadd("saç", "hair", "hairstyle", "long hair"); cadd("sakal", "beard"); cadd("bıyık", "moustache")
        cadd("gözlük", "glasses", "eyewear"); cadd("güneş gözlüğü", "sunglasses", "glasses")
        cadd("masa", "table", "desk"); cadd("sandalye", "chair"); cadd("koltuk", "couch"); cadd("kanepe", "couch", "sofa"); cadd("yatak", "bed", "bedroom"); cadd("dolap", "cabinetry", "shelf")
        cadd("pencere", "window"); cadd("kapı", "door"); cadd("duvar", "wall")
    }
    private val scarfWords = setOf("eşarp", "esarp", "eşarplı", "esarplı", "başörtü", "başörtüsü", "basortu", "basortusu", "başörtülü", "türban", "turban", "türbanlı", "turbanlı",
        "hijab", "hicab", "tesettür", "tesettur", "bandana", "yazma", "şal", "headscarf", "scarf")
    /** Sorgu eşarp / başörtüsü / türban türünden mi? Öyleyse etiket yerine yüz tabanlı katı örtü kontrolü kullanılır. */
    fun isHeadscarf(q: String): Boolean = norm(q).split(Regex("[\\s,;/+&]+")).any { w -> w in scarfWords || scarfWords.any { s -> s.length >= 5 && w.startsWith(s) } }
    private fun dictGet(k: String): List<String>? = core[k] ?: dict[k]

    private fun lookupWord(w: String): List<String>? {
        dictGet(w)?.let { return it }
        // ek soy: arabalar, kediyi, çiçekleri…
        for (suf in suffixes) {
            if (w.length > suf.length + 2 && w.endsWith(suf)) {
                val base = w.dropLast(suf.length)
                dictGet(base)?.let { return it }
                // yumuşama: kitabı -> kitap, çiçeği -> çiçek, ağacı -> ağaç, köpeği -> köpek
                val soft = when (base.lastOrNull()) { 'b' -> base.dropLast(1) + "p"; 'c' -> base.dropLast(1) + "ç"; 'ğ' -> base.dropLast(1) + "k"; 'd' -> base.dropLast(1) + "t"; else -> null }
                if (soft != null) dictGet(soft)?.let { return it }
            }
        }
        return null
    }

    // ---- Açıkta görünen vücut bölümü aramaları: ML Kit yerine NudeDetector (keskin) ile çözülür
    class NudeQuery(val classes: Set<Int>, val rest: Set<String>)
    private val nudeDict = HashMap<String, Set<Int>>()
    private fun nadd(words: String, vararg cls: Int) { for (w in words.split(",")) nudeDict[w.trim()] = cls.toSet() }
    init {
        // göğüs: kıyafetsiz kadın ve erkek göğsü; meme/breast: yalnızca kadın göğsü
        nadd("göğüs,göğsü,göğüsler,gogus,gogsu,göğüsleri", NudeDetector.BREAST_F, NudeDetector.BREAST_M)
        nadd("meme,memeler,memesi,memeleri,meme ucu,breast,breasts,boob,boobs,nipple,nipples", NudeDetector.BREAST_F)
        nadd("penis,penisi,penisler,erkeklik organı,erkek cinsel organı,erkek organı", NudeDetector.GENITAL_M)
        nadd("vajina,vajinası,vajinalar,vagina,vulva,kadın cinsel organı,kadın organı", NudeDetector.GENITAL_F)
        nadd("cinsel organ,cinsel organlar,genital,genitaller,mahrem,mahrem yer", NudeDetector.GENITAL_F, NudeDetector.GENITAL_M)
        nadd("popo,popoyu,kıç,buttocks,butt", NudeDetector.BUTTOCKS)
        nadd("çıplak,ciplak,nude,naked,nsfw,kıyafetsiz", *NudeDetector.NUDE_ANY.toIntArray())
    }
    private fun nudeLookup(word: String): Set<Int>? {
        // Türkçe küçük harfe çevirme "VAGINA" -> "vagına" yapar; İngilizce yazımı da yakalamak için ı -> i denenir
        for (w in listOf(word, word.replace('ı', 'i'))) {
            nudeDict[w]?.let { return it }
            for (suf in suffixes) if (w.length > suf.length + 2 && w.endsWith(suf)) nudeDict[w.dropLast(suf.length)]?.let { return it }
        }
        return null
    }

    /**
     * Sorguda göğüs / penis / vajina gibi bir vücut bölümü varsa o sınıfları döndürür (yoksa null: normal etiket araması).
     * Sorgudaki diğer kelimeler ("göğüs plaj") `rest` içinde kalır; sonuç hem bölümü hem bu etiketlerden birini taşımak zorundadır.
     */
    fun nude(query: String): NudeQuery? {
        val cls = LinkedHashSet<Int>(); val restWords = ArrayList<String>()
        val skip = setOf("ve", "ile", "veya", "ya", "da", "de")
        for (chunk in norm(query).split(Regex("[,;/+&]")).map { it.trim() }.filter { it.isNotEmpty() }) {
            val whole = nudeLookup(chunk)
            if (whole != null) { cls.addAll(whole); continue }
            for (w in chunk.split(Regex("\\s+")).filter { it.isNotEmpty() && it !in skip }) {
                val f = nudeLookup(w)
                if (f != null) cls.addAll(f) else restWords.add(w)
            }
        }
        if (cls.isEmpty()) return null
        return NudeQuery(cls, if (restWords.isEmpty()) emptySet() else resolve(restWords.joinToString(" ")))
    }

    /**
     * Aranan ifadeden etiket kümesi çıkarır. Nesneleri virgülle ayırmak zorunlu değil:
     * "evrak belge fatura" üç ayrı nesne olarak aranır. "spor araba" gibi sözlükte bulunan çok kelimeli adlar ise tek parça kalır.
     */
    fun resolve(query: String): Set<String> {
        val out = LinkedHashSet<String>()
        val skip = setOf("ve", "ile", "veya", "ya", "da", "de")
        val chunks = norm(query).split(Regex("[,;/+&]")).map { it.trim() }.filter { it.isNotEmpty() }
        val terms = ArrayList<String>()
        for (c in chunks) {
            if (lookupWord(c) != null) terms.add(c)
            else terms.addAll(c.split(Regex("\\s+")).filter { it.isNotEmpty() && it !in skip })
        }
        for (t in terms) {
            val found = lookupWord(t)
            if (found != null) out.addAll(found)
            else {
                // KATI: yalnızca grup adının TAM eşleşmesi (Araba, Köpek…); "içeren / içerilen" gibi bulanık eşleşme yok
                for ((g, keys) in ObjectNames.groups) {
                    if (g.lowercase(tr) == t) out.addAll(keys.filter { it.second >= 0.9f }.map { it.first })
                }
            }
            // İngilizce yazıldıysa (car, dog…) doğrudan etiket adı olarak da ara
            out.add(t.lowercase(Locale.ENGLISH))
        }
        return out
    }
}

/** Nesne arama: seçilen albümlerdeki her fotoğrafı ML Kit görsel etiketleyiciyle tarar, aranan nesne geçenleri toplar. */
object SearchEngine {
    var running by mutableStateOf(false)
    var query by mutableStateOf("")
    var done by mutableStateOf(0)
    var total by mutableStateOf(1)
    var status by mutableStateOf("")
    var error by mutableStateOf<String?>(null)
    var finished by mutableStateOf(false)
    var stopped by mutableStateOf(false)   // Durdur'a basıldı: o ana kadar bulunanlar bitmiş sonuç gibi sunulur
    var matchedLabels by mutableStateOf<List<String>>(emptyList())
    val hits = mutableStateListOf<String>()
    @Volatile var doneText = ""
    @Volatile var notifyDone = false

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private val IMG = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    private const val SIDE = 512
    private const val MIN_CONF = 0.70f   // kati: düşük güvenli (belirsiz) etiketler nesne sayılmaz

    fun cancel() { job?.cancel() }

    private fun decode(app: Application, uri: Uri): Bitmap? = try {
        val src = ImageDecoder.createSource(app.contentResolver, uri)
        ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(info.size.width, info.size.height)
            if (m > SIDE) { val sc = SIDE.toFloat() / m; dec.setTargetSize((info.size.width * sc).toInt().coerceAtLeast(1), (info.size.height * sc).toInt().coerceAtLeast(1)) }
        }.let { if (it.config == Bitmap.Config.ARGB_8888) it else it.copy(Bitmap.Config.ARGB_8888, false) }
    } catch (e: CancellationException) { throw e } catch (e: Throwable) { null }

    private var allFiles: List<Uri> = emptyList()   // taranacak tüm fotoğraflar (Devam et için saklanır)
    private var keySet: Set<String> = emptySet()
    var resumable by mutableStateOf(false)           // Durdur'a basıldı ve taranmamış fotoğraf kaldı: "Devam et" açılır

    fun start(app: Application, q: String, albumIds: List<String>) {
        if (running) return
        keySet = TrObjects.resolve(q)
        running = true; finished = false; stopped = false; resumable = false; error = null; query = q.trim(); hits.clear(); done = 0; total = 1
        allFiles = emptyList()
        matchedLabels = keySet.toList(); status = "Fotoğraflar listeleniyor…"; doneText = ""; notifyDone = false; Engine.doneText = ""
        ScanService.start(app)
        launchJob(app, albumIds, 0)
    }

    /** Durdurulan aramayı kaldığı fotoğraftan sürdürür; o ana kadar bulunanlar korunur. */
    fun resume(app: Application) {
        if (running || !resumable || allFiles.isEmpty()) return
        running = true; finished = false; stopped = false; resumable = false; error = null; doneText = ""; notifyDone = false; Engine.doneText = ""
        status = "“$query” aranıyor: $done/${allFiles.size} • ${hits.size} fotoğraf bulundu"
        ScanService.start(app)
        launchJob(app, emptyList(), done)
    }

    private fun launchJob(app: Application, albumIds: List<String>, startAt: Int) {
        val keys = keySet
        job = scope.launch {
            val labelers = ArrayBlockingQueue<ImageLabeler>(PARALLEL)
            repeat(PARALLEL) { labelers.add(ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.60f).build())) }
            try {
                if (allFiles.isEmpty()) {
                    val ids = albumIds.mapNotNull { it.toLongOrNull() }.joinToString(",")
                    val list = ArrayList<Uri>()
                    if (ids.isNotEmpty()) app.contentResolver.query(IMG, arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.BUCKET_ID),
                        "${MediaStore.Images.Media.BUCKET_ID} IN ($ids)", null, "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
                        val lim = albumIds.firstOrNull { it.startsWith("~N") }?.substring(2)?.toIntOrNull() ?: 0   // Sayı Seç: albüm başına ilk N
                        val cnt = HashMap<Long, Int>()
                        while (c.moveToNext()) {
                            if (lim > 0) { val n = (cnt[c.getLong(1)] ?: 0) + 1; cnt[c.getLong(1)] = n; if (n > lim) continue }
                            list.add(ContentUris.withAppendedId(IMG, c.getLong(0)))
                        }
                    }
                    if (list.isEmpty()) throw Exception("Seçilen albümlerde fotoğraf bulunamadı.")
                    allFiles = list
                }
                val files = allFiles
                total = files.size
                val todo = files.subList(startAt.coerceIn(0, files.size), files.size)
                val chan = Channel<Deferred<Boolean>>(PARALLEL)
                coroutineScope {
                    launch {
                        for (u in todo) chan.send(async {
                            val bmp = decode(app, u) ?: return@async false
                            val lab = labelers.take()
                            try {
                                val res = Tasks.await(lab.process(InputImage.fromBitmap(bmp, 0)))
                                res.any { it.confidence >= MIN_CONF && it.text.lowercase(Locale.ENGLISH) in keys }
                            } catch (e: CancellationException) { throw e } catch (e: Throwable) { false }
                            finally { labelers.put(lab); bmp.recycle() }
                        })
                        chan.close()
                    }
                    for (i in todo.indices) {
                        if (chan.receive().await()) hits.add(todo[i].toString())
                        done = startAt + i + 1
                        status = "“$query” aranıyor: $done/${files.size} • ${hits.size} fotoğraf bulundu"
                    }
                }
                doneText = "“$query”: ${hits.size} fotoğraf bulundu (${files.size} taranan)"
                status = doneText
                finished = true; notifyDone = true
            } catch (e: CancellationException) {
                stopped = true; finished = true; resumable = allFiles.isNotEmpty() && done < allFiles.size
                doneText = "“$query”: ${hits.size} fotoğraf bulundu ($done/$total tarandı, durduruldu)"; status = doneText; notifyDone = true; throw e
            } catch (e: Throwable) { error = e.message ?: e.javaClass.simpleName; doneText = "Arama hatası: $error"
            } finally {
                labelers.forEach { try { it.close() } catch (e: Exception) {} }
                running = false
            }
        }
    }
}
