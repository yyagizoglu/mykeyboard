package com.fotoliz.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.graphics.Rect
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import android.net.Uri
import kotlin.math.abs
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/**
 * En iyi kalite için otomatik düzeltme: (1) küçük fotoğrafı 2x büyütür, (2) renk dengesi (beyaz dengesi), (3) ışık dengesi
 * (siyah/beyaz noktası, karanlık fotoğrafı aydınlatma, hafif kontrast), (4) hafif canlılık, (5) düz alanlardaki (cilt, gökyüzü)
 * gürültüyü yumuşatıp kenar/detayları keskinleştirme, (6) fotoğrafın üstüne yazılmış yazıları (altyazı, filigran, emoji karakterli satırlar) bulup çevre renkleriyle doldurarak silme.
 */
object Enhancer {
    private const val LIM_SIDE = 4096
    private const val LIM_PIXELS = 10_000_000

    fun enhance(ctx: Context, uri: Uri): Bitmap {
        var bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(info.size.width, info.size.height)
            if (m > LIM_SIDE) dec.setTargetSampleSize(ceil(m / LIM_SIDE.toDouble()).toInt())
        }
        if (bmp.config != Bitmap.Config.ARGB_8888) bmp = bmp.copy(Bitmap.Config.ARGB_8888, true)
        var up = false
        val m = max(bmp.width, bmp.height)
        if (m < 3000) {
            val sc = min(2f, LIM_SIDE.toFloat() / m)
            if (sc > 1.05f) { bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).roundToInt(), (bmp.height * sc).roundToInt(), true); up = true }
        }
        val px = bmp.width.toLong() * bmp.height
        if (px > LIM_PIXELS) {
            val sc = Math.sqrt(LIM_PIXELS.toDouble() / px).toFloat()
            bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).roundToInt(), (bmp.height * sc).roundToInt(), true)
        }
        bmp = removeOverlays(bmp)
        bmp = daylight(bmp)                      // gündüz çekimi kuralı: tüm kareye / arka plana yayılır
        return refine(bmp, if (up) 3 else 2, if (up) 1.1f else 0.8f)
    }

    /** "Gündüz çekimi" modu (Düzenlenenler'de Netleştir): (1) siyah/beyaz kenar şeritlerini kırpıp kareyi tam doldurur, (2) 2x'e kadar büyütür,
     *  (3) yazı / emoji / simge karakterlerini siler, (4) gündüz ışığı: pozu yükseltir, gölgeleri açar, beyaz dengesini nötr-gün ışığına çeker,
     *  (5) gürültüyü yumuşatıp detayı keskinleştirir (pürüzsüz, yüksek çözünürlük). */
    fun enhanceDaylight(ctx: Context, uri: Uri): Bitmap {
        var bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(ctx.contentResolver, uri)) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = max(info.size.width, info.size.height)
            if (m > LIM_SIDE) dec.setTargetSampleSize(ceil(m / LIM_SIDE.toDouble()).toInt())
        }
        if (bmp.config != Bitmap.Config.ARGB_8888) bmp = bmp.copy(Bitmap.Config.ARGB_8888, true)
        bmp = trimBars(bmp)
        var up = false
        val m = max(bmp.width, bmp.height)
        if (m < 3000) {
            val sc = min(2f, LIM_SIDE.toFloat() / m)
            if (sc > 1.05f) { bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).roundToInt(), (bmp.height * sc).roundToInt(), true); up = true }
        }
        val px = bmp.width.toLong() * bmp.height
        if (px > LIM_PIXELS) {
            val sc = Math.sqrt(LIM_PIXELS.toDouble() / px).toFloat()
            bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).roundToInt(), (bmp.height * sc).roundToInt(), true)
        }
        bmp = removeOverlays(bmp)
        bmp = daylight(bmp)
        return refine(bmp, if (up) 3 else 2, if (up) 1.1f else 0.8f)
    }

    /** Kenarlardaki düz siyah / beyaz şeritleri (ekran görüntüsü çubukları, letterbox) kırpar; en fazla her kenardan %20. */
    private fun trimBars(src: Bitmap): Bitmap {
        val w = src.width; val h = src.height
        fun lum(p: Int) = (77 * ((p shr 16) and 255) + 150 * ((p shr 8) and 255) + 29 * (p and 255)) shr 8
        fun rowBar(y: Int): Boolean {
            var mn = 255; var mx = 0; val st = max(1, w / 64); var x = 0
            while (x < w) { val l = lum(src.getPixel(x, y)); if (l < mn) mn = l; if (l > mx) mx = l; x += st }
            return mx - mn <= 10 && (mx <= 24 || mn >= 235)
        }
        fun colBar(x: Int): Boolean {
            var mn = 255; var mx = 0; val st = max(1, h / 64); var y = 0
            while (y < h) { val l = lum(src.getPixel(x, y)); if (l < mn) mn = l; if (l > mx) mx = l; y += st }
            return mx - mn <= 10 && (mx <= 24 || mn >= 235)
        }
        var top = 0; while (top < h * 0.2f && rowBar(top)) top++
        var bottom = h; while (h - bottom < h * 0.2f && rowBar(bottom - 1)) bottom--
        var left = 0; while (left < w * 0.2f && colBar(left)) left++
        var right = w; while (w - right < w * 0.2f && colBar(right - 1)) right--
        if (top == 0 && bottom == h && left == 0 && right == w) return src
        if (right - left < w / 2 || bottom - top < h / 2) return src
        return Bitmap.createBitmap(src, left, top, right - left, bottom - top)
    }

    /** Gündüz ışığı görünümü, TÜM kareye ve arka plana yayılır: (1) yerel aydınlatma dengesi: karanlık bölgeler (arka plan dahil) kare genelinde
     *  yumuşak bir ışık haritasına göre gündüz seviyesine çekilir, zaten parlak yerler korunur; (2) poz yükseltme (yalnızca aydınlatır);
     *  (3) gün ışığına yakın beyaz dengesi; (4) canlı renk. */
    private fun daylight(src: Bitmap): Bitmap {
        val w = src.width; val h = src.height
        val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        val n = px.size
        fun lum(p: Int) = (77 * ((p shr 16) and 255) + 150 * ((p shr 8) and 255) + 29 * (p and 255)) shr 8

        // 1) Yerel aydınlatma haritası (küçük kopyada, geniş yarıçaplı bulanıklık) → piksel başına kazanç
        run {
            val sc = max(w, h) / 192f
            val w2 = max(2, (w / sc).roundToInt()); val h2 = max(2, (h / sc).roundToInt())
            val small = Bitmap.createScaledBitmap(src, w2, h2, true)
            val sp = IntArray(w2 * h2); small.getPixels(sp, 0, w2, 0, 0, w2, h2)
            if (small !== src) small.recycle()
            var y = IntArray(sp.size) { lum(sp[it]) }
            val r = max(2, min(w2, h2) / 8)
            y = blur(blur(y, w2, h2, r), w2, h2, r)
            val gmap = FloatArray(y.size) { i -> Math.pow((0.56f * 255f / max(y[i], 18)).toDouble(), 0.65).toFloat().coerceIn(1f, 2.6f) }
            val dx = (w2 - 1).toFloat() / (w - 1).coerceAtLeast(1); val dy = (h2 - 1).toFloat() / (h - 1).coerceAtLeast(1)
            for (yy in 0 until h) {
                val fy = yy * dy; val y0 = fy.toInt().coerceAtMost(h2 - 2); val ty = fy - y0
                for (xx in 0 until w) {
                    val fx = xx * dx; val x0 = fx.toInt().coerceAtMost(w2 - 2); val tx = fx - x0
                    val i0 = y0 * w2 + x0
                    val g = (gmap[i0] * (1 - tx) + gmap[i0 + 1] * tx) * (1 - ty) + (gmap[i0 + w2] * (1 - tx) + gmap[i0 + w2 + 1] * tx) * ty
                    if (g <= 1.01f) continue
                    val p = px[yy * w + xx]
                    val rr = (p shr 16) and 255; val gg = (p shr 8) and 255; val bb = p and 255
                    val l = (77 * rr + 150 * gg + 29 * bb) shr 8
                    val eff = 1f + (g - 1f) * (1f - l / 255f)            // parlak pikseller az yükselir (patlama olmaz)
                    px[yy * w + xx] = (p and 0xFF000000.toInt()) or ((rr * eff).toInt().coerceIn(0, 255) shl 16) or
                        ((gg * eff).toInt().coerceIn(0, 255) shl 8) or (bb * eff).toInt().coerceIn(0, 255)
                }
            }
        }

        // 2) Genel poz + gün ışığı beyaz dengesi + canlılık (yerel dengelemeden sonraki değerlere göre)
        val step = max(1, n / 250_000)
        var sr = 0L; var sg = 0L; var sb = 0L; var cnt = 0; var sl = 0L; var tot = 0
        var i = 0
        while (i < n) {
            val p = px[i]; val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
            val l = (77 * r + 150 * g + 29 * b) shr 8
            sl += l; tot++
            if (l in 20..235) { sr += r; sg += g; sb += b; cnt++ }
            i += step
        }
        var gr = 1f; var gg = 1f; var gb = 1f
        if (cnt >= 100) {
            val mr = sr.toFloat() / cnt; val mg = sg.toFloat() / cnt; val mb = sb.toFloat() / cnt
            val avg = (mr + mg + mb) / 3f
            fun gain(m: Float) = if (m < 1f) 1f else (avg / m).coerceIn(0.82f, 1.22f)
            gr = gain(mr) * 1.02f; gg = gain(mg); gb = gain(mb) * 0.97f   // hafif sıcak güneş tonu
        }
        val meanN = ((sl.toFloat() / tot.coerceAtLeast(1)) / 255f).coerceIn(0.04f, 0.9f)
        val gamma = (Math.log(0.56) / Math.log(meanN.toDouble())).toFloat().coerceIn(0.6f, 1f)   // 1'den büyük olmaz: yalnızca aydınlatır
        val lut = IntArray(256) { x ->
            var v = Math.pow(x / 255.0, gamma.toDouble()).toFloat()
            v += 0.06f * (1f - v) * (1f - v)
            (v.coerceIn(0f, 1f) * 255f).roundToInt()
        }
        val sat = 1.14f
        for (k in 0 until n) {
            val p = px[k]
            val r = lut[(((p shr 16) and 255) * gr).toInt().coerceIn(0, 255)]
            val g = lut[(((p shr 8) and 255) * gg).toInt().coerceIn(0, 255)]
            val b = lut[((p and 255) * gb).toInt().coerceIn(0, 255)]
            val l = (77 * r + 150 * g + 29 * b) shr 8
            px[k] = (p and 0xFF000000.toInt()) or ((l + (r - l) * sat).toInt().coerceIn(0, 255) shl 16) or
                ((l + (g - l) * sat).toInt().coerceIn(0, 255) shl 8) or (l + (b - l) * sat).toInt().coerceIn(0, 255)
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** Yüz/baş kırpığı için en yüksek kalite: kademeli (2x) büyütme ile uzun kenar ~2048 px'e çıkarır, sonra renk/ışık/keskinlik düzeltmesi uygular.
     *  Yazı silme uygulanmaz (kırpık zaten yalnızca baş-boyun bölgesidir). */
    fun enhanceCrop(src: Bitmap): Bitmap {
        var bmp = if (src.config != Bitmap.Config.ARGB_8888) src.copy(Bitmap.Config.ARGB_8888, true) else src
        val target = 2048
        var up = false
        while (max(bmp.width, bmp.height) < target * 0.9f) {
            val sc = min(2f, target.toFloat() / max(bmp.width, bmp.height))
            if (sc < 1.05f) break
            bmp = Bitmap.createScaledBitmap(bmp, (bmp.width * sc).roundToInt(), (bmp.height * sc).roundToInt(), true); up = true
        }
        return refine(bmp, if (up) 3 else 2, if (up) 1.1f else 0.8f)
    }

    /** Fotoğraf üstündeki yazıları (ve yazı olarak okunan emoji / simge karakterlerini) bulur, kutularını çevre renkleriyle doldurur.
     *  Hata olursa ya da kutular fotoğrafın çok büyük kısmını kaplıyorsa (belge / ekran görüntüsü) hiçbir şey silmez. */
    private fun removeOverlays(src: Bitmap): Bitmap {
        val w = src.width; val h = src.height
        val boxes = ArrayList<Rect>()
        try {
            val rec = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            try {
                val res = Tasks.await(rec.process(InputImage.fromBitmap(src, 0)))
                for (b in res.textBlocks) for (ln in b.lines) {
                    val r = ln.boundingBox ?: continue
                    val t = ln.text.trim()
                    if (t.isEmpty() || ln.confidence < 0.55f) continue
                    if (t.length < 2 && t.all { it.isLetterOrDigit() }) continue      // tek harf/rakam çoğu zaman yanlış alarm
                    val pad = max(4, (r.height() * 0.2f).roundToInt())
                    boxes.add(Rect(max(0, r.left - pad), max(0, r.top - pad), min(w, r.right + pad), min(h, r.bottom + pad)))
                }
            } finally { rec.close() }
        } catch (e: Throwable) { return src }
        if (boxes.isEmpty()) return src
        val full = BooleanArray(w * h); var area = 0L
        for (r in boxes) for (yy in r.top until r.bottom) { val o = yy * w; for (xx in r.left until r.right) if (!full[o + xx]) { full[o + xx] = true; area++ } }
        if (area > w.toLong() * h * 0.3) return src
        val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)

        // 1) Kutunun tamamını çevreden doldurup "yazısız arka plan" tahmini çıkar
        val bg = px.copyOf(); inpaint(bg, w, h, full, 0)

        // 2) Kutu içinde yalnızca yazı/simge piksellerini (arka plandan belirgin farklı olanları) ve kenar halesini maskele:
        //    kutunun geri kalanı orijinal dokusuyla aynen kalır → dikdörtgen leke / iz oluşmaz
        val mask = BooleanArray(w * h)
        for (r in boxes) {
            val bw = r.width(); val bh = r.height()
            val stroke = BooleanArray(bw * bh); var sc = 0
            for (yy in 0 until bh) for (xx in 0 until bw) {
                val i = (r.top + yy) * w + (r.left + xx)
                val a = px[i]; val b = bg[i]
                val d = abs(((a shr 16) and 255) - ((b shr 16) and 255)) + abs(((a shr 8) and 255) - ((b shr 8) and 255)) + abs((a and 255) - (b and 255))
                if (d > 90) { stroke[yy * bw + xx] = true; sc++ }
            }
            val total = bw * bh
            val dd = max(2, (bh * 0.14f).roundToInt())
            if (sc < total * 0.01f) { for (yy in r.top until r.bottom) for (xx in r.left until r.right) mask[yy * w + xx] = true; continue }   // düşük kontrast: kutuyu tamamen doldur
            val dil = BooleanArray(total); var dc = 0
            for (yy in 0 until bh) for (xx in 0 until bw) if (stroke[yy * bw + xx]) {
                for (y2 in max(0, yy - dd)..min(bh - 1, yy + dd)) for (x2 in max(0, xx - dd)..min(bw - 1, xx + dd)) if (!dil[y2 * bw + x2]) { dil[y2 * bw + x2] = true; dc++ }
            }
            if (dc > total * 0.6f) { for (yy in r.top until r.bottom) for (xx in r.left until r.right) mask[yy * w + xx] = true; continue }   // düz bant/şerit: kutuyu tamamen doldur
            for (yy in 0 until bh) for (xx in 0 until bw) if (dil[yy * bw + xx]) mask[(r.top + yy) * w + (r.left + xx)] = true
        }

        // 3) Maskeyi gerçek komşu piksellerden doldur, sonra çevredeki fotoğraf gürültüsüyle (tanecik) eşle
        var nS = 0.0; var nC = 0
        run {
            val st = max(1, (w * h) / 60_000)
            var i = w + 1
            while (i < w * h - w - 1) {
                if (!full[i]) {
                    fun l(k: Int) = (77 * ((px[k] shr 16) and 255) + 150 * ((px[k] shr 8) and 255) + 29 * (px[k] and 255)) shr 8
                    val m4 = (l(i - 1) + l(i + 1) + l(i - w) + l(i + w)) / 4
                    nS += abs(l(i) - m4); nC++
                }
                i += st
            }
        }
        val sigma = if (nC > 0) (nS / nC * 1.25).coerceIn(0.0, 7.0) else 0.0
        inpaint(px, w, h, mask, 3)
        if (sigma > 0.6) {
            val rnd = java.util.Random(7)
            for (i in px.indices) if (mask[i]) {
                val nz = (rnd.nextGaussian() * sigma).toInt()
                val p = px[i]
                px[i] = (p and 0xFF000000.toInt()) or ((((p shr 16) and 255) + nz).coerceIn(0, 255) shl 16) or ((((p shr 8) and 255) + nz).coerceIn(0, 255) shl 8) or ((p and 255) + nz).coerceIn(0, 255)
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** Maskeli piksellerı dıştan içe halka halka, bilinen komşuların ortalamasıyla doldurur; sonra maske içini hafifçe yumuşatır. */
    private fun inpaint(px: IntArray, w: Int, h: Int, mask: BooleanArray, smoothIters: Int = 6) {
        val state = ByteArray(px.size) { if (mask[it]) 1 else 0 }       // 0 bilinen, 1 doldurulacak, 2 sırada
        val dx = intArrayOf(-1, 0, 1, -1, 1, -1, 0, 1); val dy = intArrayOf(-1, -1, -1, 0, 0, 1, 1, 1)
        var front = ArrayList<Int>()
        for (i in px.indices) if (state[i].toInt() == 1) {
            val x = i % w; val y = i / w
            for (k in 0 until 8) { val nx = x + dx[k]; val ny = y + dy[k]
                if (nx in 0 until w && ny in 0 until h && state[ny * w + nx].toInt() == 0) { state[i] = 2; front.add(i); break } }
        }
        while (front.isNotEmpty()) {
            val vals = IntArray(front.size)
            for ((n, i) in front.withIndex()) {
                val x = i % w; val y = i / w; var r = 0; var g = 0; var b = 0; var c = 0
                for (k in 0 until 8) { val nx = x + dx[k]; val ny = y + dy[k]
                    if (nx in 0 until w && ny in 0 until h) { val j = ny * w + nx
                        if (state[j].toInt() == 0) { val p = px[j]; r += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255; c++ } } }
                vals[n] = if (c == 0) px[i] else (0xFF shl 24) or ((r / c) shl 16) or ((g / c) shl 8) or (b / c)
            }
            val next = ArrayList<Int>()
            for ((n, i) in front.withIndex()) { px[i] = vals[n]; state[i] = 0 }
            for (i in front) { val x = i % w; val y = i / w
                for (k in 0 until 8) { val nx = x + dx[k]; val ny = y + dy[k]
                    if (nx in 0 until w && ny in 0 until h) { val j = ny * w + nx; if (state[j].toInt() == 1) { state[j] = 2; next.add(j) } } } }
            front = next
        }
        // yumuşatma: yalnızca maske içi, 4 komşu ortalaması
        repeat(smoothIters) {
            val copy = px.copyOf()
            for (i in px.indices) if (mask[i]) {
                val x = i % w; val y = i / w; var r = 0; var g = 0; var b = 0; var c = 0
                for (k in 0 until 4) { val nx = x + intArrayOf(-1, 1, 0, 0)[k]; val ny = y + intArrayOf(0, 0, -1, 1)[k]
                    if (nx in 0 until w && ny in 0 until h) { val p = copy[ny * w + nx]; r += (p shr 16) and 255; g += (p shr 8) and 255; b += p and 255; c++ } }
                if (c > 0) px[i] = (0xFF shl 24) or ((r / c) shl 16) or ((g / c) shl 8) or (b / c)
            }
        }
    }

    private fun refine(src: Bitmap, r: Int, amount: Float): Bitmap {
        val w = src.width; val h = src.height
        val px = IntArray(w * h); src.getPixels(px, 0, w, 0, 0, w, h)
        balance(px)
        val y = IntArray(px.size) { val p = px[it]; (77 * ((p shr 16) and 255) + 150 * ((p shr 8) and 255) + 29 * (p and 255)) shr 8 }
        val b = blur(y, w, h, r)
        for (i in px.indices) {
            val d = y[i] - b[i]; val ad = abs(d)
            val t = ((ad - 3) / 5f).coerceIn(0f, 1f)          // düz alan → yumuşat, kenar → keskinleştir
            val k = -0.55f + (amount + 0.55f) * t
            val delta = (k * d).roundToInt().coerceIn(-48, 48)
            if (delta != 0) {
                val p = px[i]
                val rr = (((p shr 16) and 255) + delta).coerceIn(0, 255)
                val gg = (((p shr 8) and 255) + delta).coerceIn(0, 255)
                val bb = ((p and 255) + delta).coerceIn(0, 255)
                px[i] = (p and 0xFF000000.toInt()) or (rr shl 16) or (gg shl 8) or bb
            }
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        return out
    }

    /** Renk ve ışık dengesi (yerinde): ölçülü beyaz dengesi, siyah/beyaz noktası, parlaklık gamması, hafif S-eğrisi ve %7 canlılık. */
    private fun balance(px: IntArray) {
        val n = px.size; val step = max(1, n / 250_000)
        var sr = 0L; var sg = 0L; var sb = 0L; var cnt = 0
        var i = 0
        while (i < n) {
            val p = px[i]; val r = (p shr 16) and 255; val g = (p shr 8) and 255; val b = p and 255
            val l = (77 * r + 150 * g + 29 * b) shr 8
            if (l in 25..230) { sr += r; sg += g; sb += b; cnt++ }
            i += step
        }
        var gr = 1f; var gg = 1f; var gb = 1f
        if (cnt >= 100) {
            val mr = sr.toFloat() / cnt; val mg = sg.toFloat() / cnt; val mb = sb.toFloat() / cnt
            val avg = (mr + mg + mb) / 3f
            fun gain(m: Float) = if (m < 1f) 1f else (1f + 0.6f * (avg / m - 1f)).coerceIn(0.88f, 1.15f)   // %60 karışım: sıcak/soğuk ortam tamamen bozulmaz
            gr = gain(mr); gg = gain(mg); gb = gain(mb)
        }
        val hist = IntArray(256); var total = 0; var sum = 0L
        i = 0
        while (i < n) {
            val p = px[i]
            val r = (((p shr 16) and 255) * gr).toInt().coerceIn(0, 255); val g = (((p shr 8) and 255) * gg).toInt().coerceIn(0, 255); val b = ((p and 255) * gb).toInt().coerceIn(0, 255)
            val l = (77 * r + 150 * g + 29 * b) shr 8
            hist[l]++; total++; sum += l
            i += step
        }
        if (total == 0) return
        var acc = 0; var lo = 0; var hi = 255
        for (v in 0..255) { acc += hist[v]; if (acc >= total * 0.005) { lo = v; break } }
        acc = 0
        for (v in 0..255) { acc += hist[v]; if (acc >= total * 0.995) { hi = v; break } }
        val black = lo.coerceAtMost(45); val white = hi.coerceAtLeast(175)
        val mean = sum.toFloat() / total
        val meanN = ((mean - black) / (white - black)).coerceIn(0.05f, 0.95f)
        var gamma = (Math.log(0.47) / Math.log(meanN.toDouble())).toFloat().coerceIn(0.72f, 1.4f)
        gamma = 1f + 0.8f * (gamma - 1f)
        val lut = IntArray(256) { x ->
            var v = ((x - black).toFloat() / (white - black)).coerceIn(0f, 1f)
            v = Math.pow(v.toDouble(), gamma.toDouble()).toFloat()
            v += 0.22f * (v * v * (3f - 2f * v) - v)          // hafif S-eğrisi (kontrast)
            (v * 255f).roundToInt().coerceIn(0, 255)
        }
        val sat = 1.07f
        for (k in 0 until n) {
            val p = px[k]
            val r = lut[(((p shr 16) and 255) * gr).toInt().coerceIn(0, 255)]
            val g = lut[(((p shr 8) and 255) * gg).toInt().coerceIn(0, 255)]
            val b = lut[((p and 255) * gb).toInt().coerceIn(0, 255)]
            val l = (77 * r + 150 * g + 29 * b) shr 8
            val rr = (l + (r - l) * sat).toInt().coerceIn(0, 255)
            val g2 = (l + (g - l) * sat).toInt().coerceIn(0, 255)
            val bb = (l + (b - l) * sat).toInt().coerceIn(0, 255)
            px[k] = (p and 0xFF000000.toInt()) or (rr shl 16) or (g2 shl 8) or bb
        }
    }

    private fun blur(y: IntArray, w: Int, h: Int, r: Int): IntArray {
        val tmp = IntArray(y.size); val out = IntArray(y.size); val d = 2 * r + 1
        for (row in 0 until h) {
            val o = row * w; var sum = 0
            for (i in -r..r) sum += y[o + i.coerceIn(0, w - 1)]
            for (x in 0 until w) {
                tmp[o + x] = sum / d
                sum += y[o + (x + r + 1).coerceAtMost(w - 1)] - y[o + (x - r).coerceAtLeast(0)]
            }
        }
        for (col in 0 until w) {
            var sum = 0
            for (i in -r..r) sum += tmp[i.coerceIn(0, h - 1) * w + col]
            for (row in 0 until h) {
                out[row * w + col] = sum / d
                sum += tmp[(row + r + 1).coerceAtMost(h - 1) * w + col] - tmp[(row - r).coerceAtLeast(0) * w + col]
            }
        }
        return out
    }
}
