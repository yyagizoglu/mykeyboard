package com.fotoliz.app

import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Ünlü: kullanıcının "Ünlüler" bölümüne taşıdığı kişi. Küçük resim program klasöründe kopya olarak durur; yüz vektörü sonradan gelen fotoğrafları da eşleştirir. */
class Celeb(val id: String, var name: String, val file: String, val centroid: FloatArray, val photos: LinkedHashSet<String>)

const val CELEB_THR = 0.50f   // bu benzerliğin üstü aynı kişi sayılır

object Celebs {
    /** Compose durumu: değişince ekranlar kendiliğinden tazelenir. */
    var items by mutableStateOf<List<Celeb>>(emptyList())
        private set

    private fun dir(ctx: Context) = File(ctx.filesDir, "celebs").apply { mkdirs() }
    private fun index(ctx: Context) = File(ctx.filesDir, "celebs.json")
    fun path(ctx: Context, c: Celeb): String = File(dir(ctx), c.file).absolutePath

    private fun parse(text: String): List<Celeb> {
        val a = JSONObject(text).getJSONArray("celebs")
        return (0 until a.length()).mapNotNull { i ->
            try {
                val o = a.getJSONObject(i)
                val cj = o.getJSONArray("c"); val pj = o.optJSONArray("p") ?: JSONArray()
                Celeb(o.getString("id"), o.optString("name", ""), o.getString("file"),
                    FloatArray(cj.length()) { cj.getDouble(it).toFloat() }, LinkedHashSet<String>().also { s -> for (k in 0 until pj.length()) s.add(pj.getString(k)) })
            } catch (e: Exception) { null }
        }
    }

    fun load(ctx: Context) {
        items = try { index(ctx).takeIf { it.exists() }?.let { parse(it.readText()) } ?: emptyList() } catch (e: Exception) { emptyList() }
    }

    private fun persist(ctx: Context, l: List<Celeb>) {
        val a = JSONArray()
        for (c in l) a.put(JSONObject().put("id", c.id).put("name", c.name).put("file", c.file)
            .put("c", JSONArray().also { j -> c.centroid.forEach { j.put(it.toDouble()) } }).put("p", JSONArray(c.photos.toList())))
        try { index(ctx).writeText(JSONObject().put("celebs", a).toString()) } catch (e: Exception) { }
        items = l
    }

    /** Bu yüz vektörü bir ünlüye ait mi (Bulunan yüzler panosundan gizlemek için). */
    fun matches(centroid: FloatArray): Boolean = items.any { it.centroid.size == centroid.size && dot(it.centroid, centroid) >= CELEB_THR }

    /** Kişiyi Ünlüler'e ekler; aynı kişi zaten varsa fotoğrafları ona eklenir. true = yeni eklendi. */
    fun add(ctx: Context, name: String, thumbPath: String, centroid: FloatArray, photos: Collection<String>): Boolean {
        val same = items.firstOrNull { it.centroid.size == centroid.size && dot(it.centroid, centroid) >= CELEB_THR }
        if (same != null) {
            same.photos.addAll(photos); if (same.name.isBlank()) same.name = name
            persist(ctx, items.toList()); return false
        }
        val id = System.currentTimeMillis().toString() + "_" + (Math.random() * 1000).toInt()
        val fname = "$id.jpg"
        try { File(thumbPath).copyTo(File(dir(ctx), fname), overwrite = true) } catch (e: Exception) { }
        persist(ctx, items + Celeb(id, name, fname, centroid, LinkedHashSet(photos)))
        return true
    }

    /** Silinen fotoğrafları ünlülerin kayıtlı listelerinden çıkarır. */
    fun dropPhotos(ctx: Context, uris: Set<String>) {
        var changed = false
        for (c in items) if (c.photos.removeAll(uris)) changed = true
        if (changed) persist(ctx, items.toList())
    }

    fun rename(ctx: Context, c: Celeb, name: String) { c.name = name.trim(); persist(ctx, items.toList()) }
    fun remove(ctx: Context, c: Celeb) { try { File(path(ctx, c)).delete() } catch (e: Exception) { }; persist(ctx, items.filter { it.id != c.id }) }

    /** Ünlünün fotoğrafları: taşındığında kaydedilenler + sonradan yapılan analizlerde aynı kişiyle eşleşen gruplar. */
    fun photosOf(c: Celeb, saved: List<Result>): List<String> {
        val all = LinkedHashSet<String>(c.photos)
        for (r in saved) for (g in r.clusters)
            if (!g.obj && g.centroid.size == c.centroid.size && g.centroid.isNotEmpty() && dot(g.centroid, c.centroid) >= CELEB_THR) all.addAll(g.photos)
        return all.toList()
    }

    /** Yedekten gelen ünlüleri (id'si olmayanları) mevcut listeye ekler. */
    fun mergeFromJson(ctx: Context, text: String) {
        val have = items.map { it.id }.toSet()
        val add = parse(text).filter { it.id !in have }
        if (add.isNotEmpty()) persist(ctx, items + add) else load(ctx)
    }
}

/** Ünlüler ekranı: taşınan kişiler; dokununca fotoğrafları, basılı tutunca ad düzenleme / çıkarma. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun CelebsScreen(vm: VM) {
    val ctx = LocalContext.current
    val list = Celebs.items
    var editing by remember { mutableStateOf<Celeb?>(null) }
    val counts = remember(vm.saved, list) { list.associate { it.id to Celebs.photosOf(it, vm.saved).size } }
    LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                Text("${list.size} ünlü", style = MaterialTheme.typography.titleMedium)
                Text("Bulunan yüzlerde bir kişiye basılı tutup “Ünlülere taşı” de; kişi buraya gelir. Dokununca kaydedilen fotoğrafları açılır; basılı tutunca adını değiştirir ya da ünlülerden çıkarırsın.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (list.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) { Text("Henüz ünlü eklenmedi.") }
        items(list, key = { it.id }) { c ->
            Column(Modifier.combinedClickable(onClick = { vm.openCeleb(c) }, onLongClick = { editing = c }), horizontalAlignment = Alignment.CenterHorizontally) {
                AsyncImage(File(Celebs.path(ctx, c)), null, Modifier.size(96.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                Text(c.name.ifBlank { "Adsız" }, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("${counts[c.id] ?: c.photos.size} fotoğraf", style = MaterialTheme.typography.bodySmall)
            }
        }
    }
    editing?.let { c ->
        var text by remember(c) { mutableStateOf(c.name) }
        AlertDialog(onDismissRequest = { editing = null }, title = { Text("Ünlüyü düzenle") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    AsyncImage(File(Celebs.path(ctx, c)), null, Modifier.size(88.dp).clip(CircleShape).align(Alignment.CenterHorizontally), contentScale = ContentScale.Crop)
                    FieldBox(text, { text = it }, "Ad", Icons.Filled.Person)
                    OutlinedButton(onClick = { Celebs.remove(ctx, c); vm.rev++; editing = null }, Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Ünlülerden çıkar (Bulunan yüzlere döner)") }
                }
            },
            confirmButton = { TextButton(onClick = { Celebs.rename(ctx, c, text); editing = null }) { Text("Kaydet") } },
            dismissButton = { TextButton(onClick = { editing = null }) { Text("Vazgeç") } })
    }
}
