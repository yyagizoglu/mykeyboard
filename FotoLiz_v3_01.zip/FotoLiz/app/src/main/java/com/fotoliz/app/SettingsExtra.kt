package com.fotoliz.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.animation.core.animateFloat
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.DateFormat
import java.util.Date
import kotlin.math.roundToInt

private fun fmtTime(t: Long) = DateFormat.getDateTimeInstance().format(Date(t))

/** Korumalı işlem kapısı: kilit tanımlıysa parmak izi / desen / şifre ister; hiç tanımlı değilse önce tanımlatır. */
@Composable
internal fun Gate(message: String, onOk: () -> Unit, onCancel: () -> Unit) {
    val ctx = LocalContext.current
    if (Vault.isSet(ctx)) UnlockDialog(message, onSuccess = onOk, onCancel = onCancel)
    else VaultDialog(onDismiss = onCancel, onOk = onOk, message = message)
}

/** Ayarlar > Google Drive yedeği: hesap bağla, klasör seç; bağlandıktan sonra ayarlar kilitlenir (değiştirmek için doğrulama gerekir). */
@Composable
fun DriveGroup(vm: VM) {
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(2000); tick++ } }
    val i = tick.let { DriveBackup.info(ctx) }
    val auth = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r -> vm.driveAuthResult(r.data) }
    val pickAccount = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val name = r.data?.getStringExtra(android.accounts.AccountManager.KEY_ACCOUNT_NAME)
        if (r.resultCode == android.app.Activity.RESULT_OK && name != null)
            vm.driveConnect(name) { sender -> auth.launch(IntentSenderRequest.Builder(sender).build()) }
    }
    val busy = DriveBackup.running
    var pickFolder by remember { mutableStateOf(false) }
    var gateMsg by remember { mutableStateOf<String?>(null) }
    var gateAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    fun protect(msg: String, action: () -> Unit) { gateAction = action; gateMsg = msg }
    val hasFolder = i.folderId.isNotBlank()
    var askRestore by remember { mutableStateOf(false) }       // 1. adım: "geri yüklenecek, evet mi hayır mı?"
    var verifyRestore by remember { mutableStateOf(false) }    // 2. adım: şifre / desen / parmak izi
    // Yeşil lamba: bağlı + klasör seçili + otomatik yedek açık + hata yok + son kontrol taze
    val now = System.currentTimeMillis()
    val lightState = when {
        !i.connected || !hasFolder -> 0                                            // gri: kurulum bitmedi
        i.lastError.isNotBlank() -> 2                                              // kırmızı: hata var
        i.enabled && i.lastOk > 0L && (now - maxOf(i.lastCheck, i.lastOk)) < 30 * 60_000L -> 1   // yeşil: düzgün çalışıyor
        else -> 3                                                                  // sarı: bekliyor / kapalı
    }

    // Hesap yeni bağlandı ama klasör seçilmedi: seçim penceresi kendiliğinden açılır
    LaunchedEffect(i.connected, i.folderId, vm.driveConnectTick) { if (i.connected && i.folderId.isBlank()) pickFolder = true }

    // Hesap + klasör hazır ama klasördeki eski yedek henüz sorulmadı (ör. yeniden kurulum): Drive'a bakılır
    LaunchedEffect(i.connected, i.folderId, i.restoreChecked) {
        if (i.connected && hasFolder && !i.restoreChecked && vm.driveFound == null) vm.driveCheckBackup()
    }
    vm.driveFound?.let { m ->
        AlertDialog(onDismissRequest = {},
            title = { Text("Drive'da yedek bulundu") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Seçtiğin “${i.folder}” klasöründe daha önce alınmış bir FotoLiz yedeği var:")
                    Text("Son alınma: ${if (m.time > 0) fmtTime(m.time) else "bilinmiyor"}", fontWeight = FontWeight.SemiBold)
                    Text("Dosya: ${m.name} • ${fmtSize(m.size)}", style = MaterialTheme.typography.bodySmall)
                    Text("İçinde program ayarları, analiz kayıtları, yüz küçük resimleri ve kaydedilen yüzler var.", style = MaterialTheme.typography.bodySmall)
                    Text("Yüklensin mi?", fontWeight = FontWeight.Bold)
                    Text("Hayır dersen yedek yüklenmez ve sonraki otomatik yedek bu yedeğin üzerine yazılır.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            },
            confirmButton = { ColorAction("Evet", Color(0xFF2E7D32), { vm.driveFound = null; verifyRestore = true }, Modifier.width(96.dp)) },
            dismissButton = { ColorAction("Hayır", Color(0xFFC62828), { vm.driveDeclineRestore() }, Modifier.width(96.dp)) })
    }
    gateMsg?.let { gm ->
        Gate(gm, onOk = { val a = gateAction; gateMsg = null; gateAction = null; a?.invoke(); tick++ },
            onCancel = { gateMsg = null; gateAction = null })
    }
    if (pickFolder) DriveFolderPicker(
        onPicked = { id, name -> DriveBackup.setFolderChosen(ctx, id, name); pickFolder = false; tick++ },   // ilk yedekten önce eski yedek aranır
        onNeedConsent = {
            pickFolder = false
            vm.driveConnect(i.account.ifBlank { null }) { sender -> auth.launch(IntentSenderRequest.Builder(sender).build()) }
        },
        onDismiss = { pickFolder = false })

    vm.driveError?.let { msg ->
        AlertDialog(onDismissRequest = { vm.driveError = null }, title = { Text("Google bağlantısı kurulamadı") },
            text = {
                androidx.compose.foundation.layout.Column(Modifier.fillMaxWidth()) {
                    androidx.compose.foundation.text.selection.SelectionContainer {
                        androidx.compose.foundation.layout.Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(msg, style = MaterialTheme.typography.bodySmall)
                            Text("Paket adı: ${ctx.packageName}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Text("Bu APK'nın SHA-1'i:\n${DriveBackup.signingSha1(ctx)}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
                            Text("Google Cloud > Kimlik bilgileri > Android OAuth istemcisindeki SHA-1 ve paket adı bununla birebir aynı olmalı.", style = MaterialTheme.typography.bodySmall)
                        }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { vm.driveError = null }) { Text("Tamam") } })
    }
    if (askRestore) AlertDialog(onDismissRequest = { askRestore = false },
        title = { Text("Yedek geri yüklenecek") },
        text = { Text("Drive'daki “${i.folder}” klasöründeki yedek geri yüklenecek. Telefondaki mevcut kayıtlar, ayarlar ve kaydedilen yüzler yedekteki hâlleriyle değişebilir.\n\nDevam edilsin mi?") },
        confirmButton = { ColorAction("Evet", Color(0xFF2E7D32), { askRestore = false; verifyRestore = true }, Modifier.width(96.dp)) },
        dismissButton = { ColorAction("Hayır", Color(0xFFC62828), { askRestore = false }, Modifier.width(96.dp)) })
    // Kilit tanımlıysa (şifre / desen / parmak izi hangisiyse) o istenir; doğrulanmadan geri yükleme başlamaz
    if (verifyRestore) {
        if (Vault.isSet(ctx)) UnlockDialog("Drive yedeğini geri yüklemek için doğrulayın",
            onSuccess = { verifyRestore = false; vm.driveRestore() }, onCancel = { verifyRestore = false })
        else { verifyRestore = false; vm.driveRestore() }
    }
    Group("Google Drive yedeği", trailing = { DriveLight(lightState, busy) }) {
        if (!i.connected) {
            // ---- 1. adım: hesap bağla (ayarlar henüz kilitli değil)
            Text("Google hesabı bağlı değil", fontWeight = FontWeight.SemiBold)
            Text("Önce hesabı bağla, sonra yedeğin konacağı Drive klasörünü seç. Bağlandıktan sonra bu ayarlar kilitlenir; değiştirmek için parmak izi / desen / şifre istenir.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Button(onClick = {
                // Telefondaki Google hesapları listelenir; istediğin hesabı seçersin
                val opts = com.google.android.gms.common.AccountPicker.AccountChooserOptions.Builder().setAllowableAccountsTypes(listOf("com.google")).build()
                pickAccount.launch(com.google.android.gms.common.AccountPicker.newChooseAccountIntent(opts))
            }, modifier = Modifier.fillMaxWidth()) {
                Text("Google hesabını seç ve bağla")
            }
        } else {
            // ---- bağlı: hesap + klasör kilitli
            Text(if (i.account.isNotBlank()) "Bağlı hesap: ${i.account}" else "Google hesabı bağlı", fontWeight = FontWeight.SemiBold)
            if (hasFolder) {
                Text("Yedek klasörü: ${i.folder}", fontWeight = FontWeight.SemiBold)
                Text("🔒 Hesap ve klasör kilitli. Değiştirmek ya da bağlantıyı kaldırmak için parmak izi / desen / şifre istenir.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    ColorAction("Klasörü değiştir", MaterialTheme.colorScheme.primary, { protect("Drive klasörünü değiştirmek için doğrulayın") { pickFolder = true } }, Modifier.weight(1f).height(50.dp), enabled = !busy)
                }
            } else {
                Text("Yedek klasörü seçilmedi: yedek alınmaz.", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                Button(onClick = { pickFolder = true }, modifier = Modifier.fillMaxWidth()) { Text("Drive klasörünü seç") }
            }

            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Otomatik yedek", fontWeight = FontWeight.SemiBold)
                    Text("Her ${DriveBackup.INTERVAL_MIN} dakikada bir, uygulama kapalıyken de (veri değiştiyse)", style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = i.enabled, onCheckedChange = { v -> protect("Otomatik yedek ayarını değiştirmek için doğrulayın") { vm.driveSetEnabled(v) } })
            }
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Yalnızca Wi‑Fi'de yedekle", fontWeight = FontWeight.SemiBold)
                    Text("Mobil veri kullanılmaz", style = MaterialTheme.typography.bodySmall)
                }
                Switch(checked = i.wifiOnly, onCheckedChange = { v -> protect("Wi‑Fi ayarını değiştirmek için doğrulayın") { DriveBackup.setWifiOnly(ctx, v) } })
            }

            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ColorAction("Şimdi yedekle", Color(0xFF2E7D32), { vm.driveBackupNow() }, Modifier.weight(1f).height(50.dp), enabled = hasFolder && !busy)
                ColorAction("Drive'dan geri yükle", Color(0xFF1565C0), { askRestore = true }, Modifier.weight(1f).height(50.dp), enabled = hasFolder && !busy)
            }
        }
        if (busy) { Text("Drive işlemi sürüyor…", style = MaterialTheme.typography.bodySmall); LinearProgressIndicator(Modifier.fillMaxWidth()) }

        // ---- En son alınan yedeğin bilgileri
        HorizontalDivider()
        Text("En son alınan yedek", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        if (i.lastOk > 0L) {
            val cs = MaterialTheme.colorScheme
            val d = Date(i.lastOk)
            Column(Modifier.fillMaxWidth().clip(androidx.compose.foundation.shape.RoundedCornerShape(14.dp)).background(cs.primaryContainer)
                .border(2.dp, cs.primary, androidx.compose.foundation.shape.RoundedCornerShape(14.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(Modifier.fillMaxWidth()) {
                    BackupFact("TARİH", DateFormat.getDateInstance(DateFormat.LONG).format(d), Modifier.weight(1f))
                    BackupFact("SAAT", DateFormat.getTimeInstance(DateFormat.MEDIUM).format(d), Modifier.weight(1f))
                }
                Row(Modifier.fillMaxWidth()) {
                    BackupFact("BOYUT", fmtSize(i.lastSize), Modifier.weight(1f))
                    BackupFact("İÇERİK", "${i.lastCount} analiz kaydı", Modifier.weight(1f))
                }
                Text("Dosya: ${i.lastName}", style = MaterialTheme.typography.bodySmall, color = cs.onPrimaryContainer)
            }
        } else Text("Henüz Drive'a yedek alınmadı.", style = MaterialTheme.typography.bodySmall)
        if (i.lastCheck > 0L) Text("Son kontrol: ${fmtTime(i.lastCheck)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (i.lastError.isNotBlank()) Text("Son hata: ${i.lastError}", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
        Text("Yedeğe girenler: program ayarları, analiz kayıtları, bulunan yüzlerin küçük resimleri ve kaydedilen yüzler. Fotoğrafların yedeklenmez; şifre / desen yedeğe girmez.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Not: Android pil tasarrufu 10 dakikalık düzeni geciktirebilir; “Arka planda çalışma” maddesini yeşil yap. Zamanlama kesin değil, yaklaşıktır.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (i.connected) TextButton(onClick = {
            protect("Drive bağlantısını kaldırmak için doğrulayın. Kaldırınca hesap ve klasör seçimi baştan yapılır.") { vm.driveDisconnect() }
        }) { Text("Drive bağlantısını kaldır", color = MaterialTheme.colorScheme.error) }
    }
}

/** Son yedek kutusunda büyük punto bilgi: üstte küçük etiket, altında kalın değer. */
@Composable
private fun BackupFact(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier) {
        Text(label, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f))
        Text(value, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

/** Drive durum lambası: 1 = yeşil (düzgün çalışıyor, yumuşakça yanıp söner), 2 = kırmızı (hata), 3 = sarı (bekliyor/kapalı), 0 = gri. */
@Composable
internal fun DriveLight(state: Int, busy: Boolean) {
    val color = when (state) { 1 -> Color(0xFF2ECC40); 2 -> Color(0xFFE53935); 3 -> Color(0xFFFFB300); else -> Color(0xFF9E9E9E) }
    val t = androidx.compose.animation.core.rememberInfiniteTransition(label = "driveLight")
    val glow by t.animateFloat(0.25f, 0.9f, androidx.compose.animation.core.infiniteRepeatable(
        androidx.compose.animation.core.tween(if (busy) 600 else 1400), androidx.compose.animation.core.RepeatMode.Reverse), label = "glow")
    val a = if (state == 1 || busy) glow else 0.35f
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(when (state) { 1 -> "Çalışıyor"; 2 -> "Hata"; 3 -> "Bekliyor"; else -> "Kurulmadı" }, style = MaterialTheme.typography.labelSmall, color = color, fontWeight = FontWeight.Bold)
        Box(Modifier.size(22.dp), contentAlignment = Alignment.Center) {
            Box(Modifier.size(22.dp).clip(androidx.compose.foundation.shape.CircleShape).background(color.copy(alpha = a * 0.45f)))   // hale
            Box(Modifier.size(12.dp).clip(androidx.compose.foundation.shape.CircleShape).background(color))                           // lamba
        }
    }
}

/** Ayarlar > Uygulama kilidi: Şifre / Desen / Parmak izi seçeneklerinden biri seçilir; yalnızca seçili yöntem kullanılır. */
@Composable
fun LockGroup(vm: VM) {
    val ctx = LocalContext.current
    var set by remember { mutableStateOf(Vault.isSet(ctx)) }
    var lockOn by remember { mutableStateOf(Vault.isSet(ctx)) }       // Şifreli (true) / Şifresiz (false) düğmesi; varsayılan Şifresiz
    var askOff by remember { mutableStateOf(false) }                  // Şifresiz'e geçerken mevcut korumayı doğrulat
    var mode by remember { mutableStateOf(Vault.mode(ctx)) }
    var onOpen by remember { mutableStateOf(Vault.lockOnOpen(ctx)) }
    var relock by remember { mutableStateOf(Vault.relockIndex(ctx).toFloat()) }      // kaydırıcının gösterdiği (henüz uygulanmamış olabilir)
    var relockApplied by remember { mutableStateOf(Vault.relockIndex(ctx)) }        // gerçekten uygulanan; yalnızca OK ile değişir
    var target by remember { mutableStateOf<String?>(null) }     // geçiş yapılmak istenen yöntem
    val bioOk = remember { bioAvailable(ctx) }
    fun applyBio() { Vault.setBioOnly(ctx); set = true; lockOn = true; mode = "bio"; target = null; vm.toast("Kilit yöntemi: parmak izi.") }
    fun label(m: String) = when (m) { "pin" -> "şifre"; "pattern" -> "desen"; else -> "parmak izi" }
    Group("Uygulama kilidi") {
        Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
            Text(if (set) "Kilit açık: ${label(mode)}" else if (lockOn) "Kilit tanımlı değil." else "Kilit kapalı (Şifresiz).", fontWeight = FontWeight.SemiBold)
            Text("Seçtiğin yöntem açılışta, Ayarlar'da, kayıt silerken ve Drive ayarında istenir.",
                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        // Şifreli / Şifresiz: Şifresiz'de kilit pasif (kayıtlı yöntem silinmez); Şifreli seçilince mevcut şifre / desen / parmak izi yeniden aktif olur
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LockTile("Şifresiz", !lockOn, true, { t -> Icon(Icons.Filled.Lock, null, Modifier.size(24.dp).alpha(0.5f), tint = t) }, Modifier.weight(1f)) {
                if (lockOn) { if (set) askOff = true else lockOn = false }
            }
            LockTile("Şifreli", lockOn, true, { t -> Icon(Icons.Filled.Lock, null, Modifier.size(24.dp), tint = t) }, Modifier.weight(1f)) {
                if (!lockOn) {
                    lockOn = true
                    if (Vault.hasSecret(ctx)) { Vault.setEnabled(ctx, true); set = true; mode = Vault.mode(ctx); vm.toast("Kilit açıldı: ${label(mode)}.") }
                }
            }
        }
        if (!lockOn) Text("Şifresiz: program şifre / desen / parmak izi istemez." + (if (Vault.hasSecret(ctx)) " Kayıtlı koruman saklı; Şifreli'yi seçince yeniden aktif olur." else ""),
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        else if (!set) Text("Şifreli: aşağıdan bir yöntem seç (şifre, desen ya da parmak izi).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
        if (lockOn) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            LockTile("Şifre", set && mode == "pin", true, { t -> Icon(Icons.Filled.Lock, null, Modifier.size(24.dp), tint = t) }, Modifier.weight(1f)) { target = "pin" }
            LockTile("Desen", set && mode == "pattern", true, { t -> PatternIcon(t) }, Modifier.weight(1f)) { target = "pattern" }
            LockTile("Parmak izi", set && mode == "bio", bioOk, { t -> FingerprintIcon(t) }, Modifier.weight(1f)) { if (set) target = "bio" else applyBio() }
        }
        if (!bioOk) Text("Bu telefonda parmak izi tanımlı değil ya da desteklenmiyor.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (set) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text("Program açılırken sor", Modifier.weight(1f))
                Switch(checked = onOpen, onCheckedChange = { onOpen = it; Vault.setLockOnOpen(ctx, it) })
            }
            if (onOpen) {
                val pendingChange = relock.toInt() != relockApplied
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    ClockBadge(); Spacer(Modifier.width(10.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Kilit isteme süresi", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text(Vault.relockLabel(Vault.RELOCK_STEPS[relock.toInt()]), fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                    }
                    // Minik OK düğmesi: basılmadan süre uygulanmaz
                    Button(onClick = { Vault.setRelockIndex(ctx, relock.toInt()); relockApplied = relock.toInt(); vm.toast("Kilit süresi uygulandı: " + Vault.relockLabel(Vault.RELOCK_STEPS[relockApplied])) },
                        enabled = pendingChange, modifier = Modifier.height(32.dp), contentPadding = PaddingValues(horizontal = 14.dp, vertical = 0.dp),
                        shape = androidx.compose.foundation.shape.RoundedCornerShape(10.dp)) {
                        Text(if (pendingChange) "OK" else "✓", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                    }
                }
                if (pendingChange) Text("Seçtiğin süre OK'a basınca uygulanır; o zamana kadar eski süre geçerli (${Vault.relockLabel(Vault.RELOCK_STEPS[relockApplied])}).",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.primary)
                Slider(value = relock, onValueChange = { relock = it.roundToInt().toFloat() },
                    valueRange = 0f..(Vault.RELOCK_STEPS.size - 1).toFloat(), steps = Vault.RELOCK_STEPS.size - 2)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    for (sec in Vault.RELOCK_STEPS) Text(if (sec == 0) "0" else if (sec < 60) "${sec}sn" else "${sec / 60}dk", style = MaterialTheme.typography.labelSmall)
                }
                Text("Çıkıp bu süreden önce dönersen kilit sorulmaz.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
    if (askOff) UnlockDialog("Kilidi kapatmak için mevcut korumayı doğrulayın", onSuccess = { askOff = false; Vault.setEnabled(ctx, false); set = false; lockOn = false; vm.toast("Kilit kapatıldı (Şifresiz).") }, onCancel = { askOff = false })
    target?.let { m ->
        if (m == "bio") UnlockDialog("Parmak izine geçmek için mevcut korumayı doğrulayın", onSuccess = { applyBio() }, onCancel = { target = null })
        else VaultDialog(onDismiss = { target = null }, onOk = { target = null; set = true; lockOn = true; mode = Vault.mode(ctx); vm.toast("Kilit güncellendi.") },
            change = set, startMode = m, message = "Önce mevcut korumayı doğrula.")
    }
}

/** Kilit yöntemi düğmesi: seçiliyken dolu (tema rengi), değilken çerçeveli; üstte simge, altta ad. */
@Composable
private fun LockTile(label: String, selected: Boolean, enabled: Boolean, icon: @Composable (Color) -> Unit, modifier: Modifier, onClick: () -> Unit) {
    val cs = MaterialTheme.colorScheme
    val shape = androidx.compose.foundation.shape.RoundedCornerShape(12.dp)
    val fg = (if (selected) cs.onPrimary else cs.onSurface).let { if (enabled) it else it.copy(alpha = 0.4f) }
    Column(
        modifier.clip(shape)
            .background(if (selected) cs.primary else cs.surface)
            .then(if (selected) Modifier else Modifier.border(1.dp, cs.outline, shape))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(vertical = 10.dp),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        icon(fg)
        Text(label, color = fg, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelLarge)
    }
}
