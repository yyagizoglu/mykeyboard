package com.fotoliz.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap

/**
 * Saç rengi (B sarışın, D esmer, R kızıl, ? belirsiz) — KATI kurallar: yeterli kanıt yoksa "?" döner (eskiden her şüpheli durum "esmer" sayılıyordu).
 * Kaynak: (1) analiz sırasında ORİJİNAL fotoğraftan, yüzün hemen üstündeki gerçek saç bölgesi (en güvenilir),
 *         (2) yoksa küçük yüz resminin üst/yan şeridi (eski yöntem, daha katı kararla).
 */
object HairColor {
    private class Acc {
        var n = 0; var dark = 0; var brown = 0; var blond = 0; var red = 0; var light = 0   // light: açık tonlu (sarıya yakın) her piksel
        val hist = IntArray(20)
    }

    private fun add(a: Acc, r: Int, g: Int, b: Int, skipBlack: Boolean, hsv: FloatArray) {
        Color.RGBToHSV(r, g, b, hsv)
        val h = hsv[0]; val s = hsv[1]; val v = hsv[2]
        if (skipBlack && v < 0.04f) return                                        // küçük resimdeki dönme artığı siyah köşeler
        val cb = 128 - 0.168736f * r - 0.331264f * g + 0.5f * b
        val cr = 128 + 0.5f * r - 0.418688f * g - 0.081312f * b
        if (cb in 77f..127f && cr in 138f..173f && v > 0.35f && s in 0.12f..0.68f && h <= 50f) return   // ten
        if (s < 0.08f && v > 0.35f) return                                        // beyaz / gri arka plan
        a.n++; a.hist[(v * 19.99f).toInt().coerceIn(0, 19)]++
        if (h in 20f..65f && s in 0.10f..0.85f && v >= 0.50f) a.light++
        when {
            (h <= 22f || h >= 345f) && s >= 0.55f && v >= 0.40f -> a.red++
            h in 30f..62f && s in 0.20f..0.80f && v >= 0.62f -> a.blond++
            v < 0.32f -> a.dark++
            h in 8f..45f && s >= 0.20f && v < 0.55f -> a.brown++   // açık kahve / koyu sarı "esmer" sayılmaz
        }
    }

    private fun decide(a: Acc, minN: Int): String {
        if (a.n < minN) return "?"
        var cum = 0; var med = 0
        for (i in 0 until 20) { cum += a.hist[i]; if (cum * 2 >= a.n) { med = i; break } }
        val medV = (med + 0.5f) / 20f
        val dk = a.dark + a.brown
        return when {
            a.red * 100 >= a.n * 40 && a.red > a.blond * 2 -> "R"
            a.blond * 100 >= a.n * 55 && dk * 100 <= a.n * 25 && medV >= 0.60f -> "B"
            dk * 100 >= a.n * 65 && a.blond * 100 <= a.n * 8 && a.light * 100 <= a.n * 15 && a.red * 100 <= a.n * 20 && medV <= 0.42f -> "D"
            else -> "?"
        }
    }

    /** Orijinal fotoğraf + yüz kutusu: kutunun hemen üstündeki saç bölgesine bakar. Bölge fotoğraf dışına taşıyorsa "?". */
    fun fromPhoto(bmp: Bitmap, box: Rect): String {
        try {
            val bw = box.width(); val bh = box.height()
            if (bw < 24 || bh < 24) return "?"
            val x0 = (box.left + bw * 0.12f).toInt().coerceIn(0, bmp.width - 1)
            val x1 = (box.right - bw * 0.12f).toInt().coerceIn(x0 + 1, bmp.width)
            val yTop = box.top - (bh * 0.40f).toInt()
            val y0 = yTop.coerceAtLeast(0)
            val y1 = (box.top + (bh * 0.05f).toInt()).coerceIn(0, bmp.height)
            if (y1 - y0 < (bh * 0.18f).toInt() || y1 <= y0) return "?"            // üstte yeterli saç bölgesi yok
            val w = x1 - x0; val h = y1 - y0
            val px = IntArray(w * h); bmp.getPixels(px, 0, w, x0, y0, w, h)
            val a = Acc(); val hsv = FloatArray(3)
            var i = 0
            while (i < px.size) {                                                 // her 2. piksel: hız
                val c = px[i]; add(a, Color.red(c), Color.green(c), Color.blue(c), false, hsv); i += 2
            }
            return decide(a, 60)
        } catch (e: Throwable) { return "?" }
    }

    /** Küçük yüz resmi: üst şerit + yan şeritler (eski yöntem; daha katı karar). */
    fun fromThumb(b: Bitmap): String {
        val w = b.width; val h = b.height
        val px = IntArray(w * h); b.getPixels(px, 0, w, 0, 0, w, h)
        val hsv = FloatArray(3); val a = Acc()
        val cx = w / 2f; val cy = h / 2f; val rad = minOf(w, h) / 2f
        for (y in 0 until h) for (x in 0 until w) {
            val fx = x.toFloat() / w; val fy = y.toFloat() / h
            val top = fy <= 0.24f && fx in 0.10f..0.90f
            val side = fy in 0.15f..0.70f && (fx <= 0.13f || fx >= 0.87f)
            if (!top && !side) continue
            val dx = x - cx; val dy = y - cy
            if (dx * dx + dy * dy > rad * rad * 0.9f) continue
            val c = px[y * w + x]
            add(a, Color.red(c), Color.green(c), Color.blue(c), true, hsv)
        }
        return decide(a, 80)
    }
}

/** Analiz sırasında orijinal fotoğraftan bulunan saç rengi: yüz küçük resminin yoluna göre saklanır (telefonda kalıcı). */
object HairStore {
    private val map = ConcurrentHashMap<String, String>()
    @Volatile private var loaded = false
    private fun file(ctx: Context) = File(ctx.filesDir, "hairstore.json")

    @Synchronized fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try { val f = file(ctx); if (f.exists()) { val o = JSONObject(f.readText()); for (k in o.keys()) map[k] = o.getString(k) } } catch (e: Exception) { }
    }
    fun get(path: String): String? = map[path]
    fun put(path: String, h: String) { map[path] = h }
    fun copy(from: String, to: String) { map[from]?.let { map[to] = it } }
    fun forgetPrefix(prefix: String) { map.keys.removeAll { it.startsWith(prefix) } }
    @Synchronized fun persist(ctx: Context) {
        try {
            val o = JSONObject()
            for ((k, v) in map) if (File(k).exists()) o.put(k, v)      // silinmiş küçük resimlerin kayıtları atılır
            val tmp = File(ctx.filesDir, "hairstore.tmp"); tmp.writeText(o.toString())
            if (!tmp.renameTo(file(ctx))) { file(ctx).delete(); tmp.renameTo(file(ctx)) }
        } catch (e: Exception) { }
    }
}
