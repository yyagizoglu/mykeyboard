package com.fotoliz.app

import androidx.activity.compose.rememberLauncherForActivityResult
import android.content.Context
import android.content.Intent
import android.os.Build
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/* ---------------------------------------------------------------- Yasal metinler (genel şablon) */

object Legal {
    const val TERMS = """KULLANIM KOŞULLARI

1. Kapsam. FotoLiz ("Program"), cihazınızdaki fotoğraflarda bulunan kişileri yüzlerine, nesneleri nesne türlerine ve materyallere göre bulan, gruplayan, sıralayan ve aranan nesneyi içeren fotoğrafları listeleyen bir araçtır. Programı kurarak ve kullanarak bu koşulları kabul etmiş olursunuz.

2. Kullanım amacı. Program yalnızca kendi fotoğraflarınız ya da fotoğraflarında görünen kişilerin açık rızasını aldığınız içerikler üzerinde kullanılmalıdır. Başkalarını izlemek, takip etmek, kimliklerini tespit etmek, ayrımcılık yapmak veya hukuka aykırı herhangi bir amaçla kullanmak yasaktır.

3. Sorumluluk. Gruplama sonuçları otomatik bir yapay zekâ modeliyle üretilir; hatalı eşleşmeler (aynı kişinin ayrı, farklı kişilerin aynı grupta görünmesi) olabilir. Sonuçlar kesin doğru kabul edilmemelidir. Programın "Sil", "Taşı", "Netleştir" ve "Kırp" işlemleri cihazınızdaki dosyaları değiştirebilir veya silebilir; bu işlemleri onaylamadan önce kontrol etmek ve gerekirse yedek almak sizin sorumluluğunuzdadır.

4. Garanti verilmemesi. Program "olduğu gibi" sunulur. Kesintisiz ve hatasız çalışacağına, her cihazla uyumlu olacağına dair açık veya zımni garanti verilmez. Yasaların izin verdiği ölçüde, programın kullanımından doğabilecek doğrudan veya dolaylı zararlardan geliştirici sorumlu tutulamaz.

5. Fikri mülkiyet. Programın arayüzü ve kodu geliştiriciye aittir. Kullanılan üçüncü taraf bileşenler kendi lisanslarına tabidir ("Açık kaynak ve model lisansları" bölümüne bakın).

6. Değişiklik. Bu koşullar güncellenebilir; güncel metin programın Ayarlar bölümünde yer alır.

7. Uygulanacak hukuk. Bu koşullar Türkiye Cumhuriyeti hukukuna tabidir."""

    const val PRIVACY = """GİZLİLİK POLİTİKASI VE KVKK AYDINLATMA METNİ

Veri sorumlusu: Programı kendi cihazında kullanan kişi (kullanıcı). Program, verilerinizi geliştiriciye veya herhangi bir sunucuya göndermez.

İşlenen veriler. Fotoğraflarınızdaki yüz görüntüleri ve bunlardan üretilen sayısal yüz vektörleri. Yüz verisi, 6698 sayılı KVKK kapsamında "biyometrik veri" olarak özel nitelikli kişisel veri sayılabilir.

İşleme amacı. Yüzlerin gruplanması ve kişilere göre listelenmesi. Başka bir amaçla kullanılmaz.

Verilerin işlendiği yer. Tüm analiz cihazınızın üzerinde yapılır. Fotoğraflar ve yüz vektörleri internete yüklenmez, reklam veya istatistik amacıyla paylaşılmaz.

İnternet kullanımı. İnternet bağlantısı yalnızca ilk açılışta yüz tanıma modelinin indirilmesi için kullanılır; bu sırada fotoğraflarınızdan hiçbir veri gönderilmez.

Saklama. Analiz sonuçları (küçük yüz resimleri, yüz vektörleri, grup bilgileri) yalnızca program klasörünüzde saklanır. Ayarlar > Veriler bölümünden "Kayıtlı sonuçları sil" ile veya programı kaldırarak tamamen silebilirsiniz.

İzinler. Fotoğraflara erişim (analiz için), bildirim ve ön plan servisi (analiz arka planda sürerken), pil kısıtlaması muafiyeti (analizin kesilmemesi için), internet (model indirme).

Üçüncü kişilerin verileri. Fotoğraflarınızda başka kişiler varsa onların yüz verilerini işlemiş olursunuz. Bu işlemin hukuka uygunluğundan (gerekiyorsa açık rıza alınmasından) kullanıcı sorumludur.

Haklarınız. Verileriniz yalnızca cihazınızda bulunduğundan, silme ve erişim haklarınızı doğrudan program içinden ve cihaz ayarlarından kullanabilirsiniz."""

    const val LICENSES = """AÇIK KAYNAK VE MODEL LİSANSLARI

• Google ML Kit Face Detection — yüz bulma. Google ML Kit koşullarına tabidir.
• ONNX Runtime (Microsoft) — modeli cihazda çalıştırma. MIT Lisansı.
• ArcFace (InsightFace "buffalo_l / w600k_r50") — yüz tanıma modeli. InsightFace modelleri yalnızca ticari olmayan araştırma ve kişisel kullanım için sunulur; programı ticari amaçla dağıtmadan önce model lisansını kontrol edin.
• Coil — görüntü yükleme. Apache 2.0 Lisansı.
• AndroidX / Jetpack Compose / Material 3 — Apache 2.0 Lisansı.

Marka ve ürün adları ilgili sahiplerine aittir."""

    const val DISCLAIMER = """SORUMLULUK REDDİ

Bu program yapay zekâ tabanlı otomatik bir araçtır. Yüz eşleştirme sonuçları hata içerebilir ve bir kişinin kimliğini kanıtlamak, hukuki veya resmi bir karar vermek için kullanılamaz. Programı yalnızca kendi içeriklerinizi düzenlemek amacıyla ve ilgili kişilerin haklarına saygı göstererek kullanın.

Not: Bu metinler genel bilgilendirme amaçlı bir şablondur ve hukuki danışmanlık değildir. Programı başkalarına dağıtacaksanız metinleri bir hukuk uzmanına kontrol ettirin."""
}

/* ---------------------------------------------------------------- Ayarlar ekranı */

@Composable
fun SettingsScreen(vm: VM, pickModel: () -> Unit) {
    val ctx = LocalContext.current
    val ver = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { "?" } }
    var doc by remember { mutableStateOf<Pair<String, String>?>(null) }
    var contact by remember { mutableStateOf(false) }
    var askClear by remember { mutableStateOf(false) }
    var vault by remember { mutableStateOf(false) }          // silmeden önce şifre / desen penceresi
    var changeVault by remember { mutableStateOf(false) }
    var vaultSet by remember { mutableStateOf(Vault.isSet(ctx)) }
    val batteryOk = ctx.getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {

        // ---- En üstte sistem sağlığı bilgilendirmesi
        Card(shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(4.dp)) {
            Column(Modifier.padding(16.dp)) { HealthPanel(vm) }
        }

        // ---- Program bilgilendirme formu
        Card(shape = RoundedCornerShape(20.dp), elevation = CardDefaults.cardElevation(4.dp)) {
            Column {
                Row(Modifier.fillMaxWidth()
                    .background(Brush.horizontalGradient(listOf(Color(0xFF7E57C2), Color(0xFF5E35B1), Color(0xFF3949AB))))
                    .padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                    AppLogo(64.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("FotoLiz", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                        Text("Sürüm $ver", color = Color(0xCCFFFFFF), fontSize = 13.sp)
                        Text("Galerinizdeki tüm kişileri yüzlere, nesneleri nesnelere, materyallere göre bulur, gruplandırır, sıralar; tüm olanakları sağlar", color = Color(0xCCFFFFFF), fontSize = 12.sp)
                    }
                }
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("Program bilgilendirme formu", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
                    InfoRow("Ne yapar", "Galerindeki tüm kişileri yüzlere, nesneleri nesnelere, materyalleri malzeme türlerine göre bulur, gruplar ve sıralar. Arama kutusuna nesne adını (örn. araba) yazıp albüm seçerek o nesnenin göründüğü fotoğrafları bulur. “Kişiye göre ara” bölümünde bir yüz seçip albüm seçersen o kişinin göründüğü tüm fotoğrafları bulur; adını düzenleyip Kaydet dediğinde galeride o adla albüm oluşturup hepsini oraya taşır. Seçtiğin fotoğrafları netleştirir, kırpar, taşır veya silmeni sağlar.")
                    InfoRow("Çalışma şekli", "Tamamen cihaz üzerinde. Fotoğrafların internete gönderilmez.")
                    InfoRow("İnternet", "Yalnızca ilk açılışta yüz tanıma modelini indirmek için.")
                    InfoRow("Yüz / nesne bulma", "Google ML Kit (yüzü olmayan fotoğraflar nesne adına göre gruplanır)")
                    InfoRow("Yüz tanıma", "ArcFace (ONNX Runtime)")
                    InfoRow("Model durumu", if (vm.modelReady) "Hazır ✓" else "Hazır değil")
                    InfoRow("Kayıtlı sonuç", "${vm.saved.size} analiz")
                    InfoRow("İzinler", "Fotoğraflar, bildirim, ön plan servisi")
                    InfoRow("Paket", ctx.packageName)
                }
            }
        }

        // ---- Sesler
        Group("Sesler") {
            SoundSection(ctx, false)
            SoundSection(ctx, true)
        }

        // ---- Analiz
        Group("Analiz") {
            Text("Başlangıç benzerlik eşiği: ${"%.2f".format(vm.startThr)}", fontWeight = FontWeight.SemiBold)
            Slider(value = vm.startThr, onValueChange = { vm.saveStartThr(Math.round(it * 100) / 100f) }, valueRange = 0.15f..0.70f)
            Text("Düşük = aynı kişiyi daha çok birleştirir, yüksek = daha ayrı tutar. Sonuç ekranında da değiştirebilirsin.", style = MaterialTheme.typography.bodySmall)
            if (Math.abs(vm.startThr - 0.25f) < 0.005f) Text("0,25 en iyi verim için uygundur ✓", style = MaterialTheme.typography.bodySmall, color = Color(0xFF2E7D32), fontWeight = FontWeight.SemiBold)
            else Text("Uyarı: en iyi verim için 0,25 uygundur. Daha yüksek değer yüzleri daha belirgin ayırır ama aynı kişiyi bölebilir.",
                style = MaterialTheme.typography.bodySmall, color = Color(0xFFB26A00), fontWeight = FontWeight.SemiBold)
            TextButton(onClick = { vm.saveStartThr(0.25f) }) { Text("0,25'e sıfırla") }
            if (!batteryOk) OutlinedButton(onClick = {
                try { ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS)) }
                catch (e: Exception) { ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}"))) }
            }, modifier = Modifier.fillMaxWidth()) { Text("Arka planda durmasın: pil kısıtlamasını kaldır") }
            else Text("Pil kısıtlaması: kaldırılmış ✓", style = MaterialTheme.typography.bodySmall)
        }

        // ---- Model
        Group("Yüz tanıma modeli") {
            Text(if (vm.modelReady) "Model hazır ✓" else (vm.modelMsg ?: "Model hazır değil"))
            OutlinedButton(onClick = pickModel, modifier = Modifier.fillMaxWidth()) { Text("Modeli dosyadan yükle (.onnx)") }
            if (!vm.modelReady && !vm.downloading) OutlinedButton(onClick = { vm.downloadModel() }, modifier = Modifier.fillMaxWidth()) { Text("Modeli indir") }
        }

        // ---- Veriler
        Group("Veriler") {
            Text("Kayıtlı analiz sonucu: ${vm.saved.size}")
            val (doBackup, doRestore) = rememberBackupActions(vm)
            Text("Kayıtların güncellemede asla silinmez. Uygulamayı kaldırıp yeniden kurmayı düşünüyorsan önce yedekle; sonra yedekten geri yükle. Ayrıca uygulamadan çıkarken kayıtlar otomatik olarak Download/FotoLiz/FotoLiz_yedek.zip dosyasına da yedeklenir.", style = MaterialTheme.typography.bodySmall)
            Button(onClick = doBackup, enabled = vm.saved.isNotEmpty(), modifier = Modifier.fillMaxWidth()) { Text("Kayıtları yedekle (klasör seç)") }
            LaunchedEffect(Unit) { vm.refreshLastBackup() }
            Text(vm.lastBackup ?: "Henüz elle yedek alınmadı.", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold)
            Text("Her seferinde klasör seçersin; seçtiğin klasörde FotoLiz_yedek.zip varsa üzerine yazılır, yoksa oluşturulur.", style = MaterialTheme.typography.bodySmall)
            OutlinedButton(onClick = doRestore, modifier = Modifier.fillMaxWidth()) { Text("Yedekten geri yükle") }
            OutlinedButton(onClick = { vault = true }, enabled = vm.saved.isNotEmpty(), modifier = Modifier.fillMaxWidth(),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Kayıtlı sonuçları sil") }
            Text(if (vaultSet) "Silmek için şifre / desen istenir. Fotoğrafların silinmez; yalnızca programın kendi kayıtları temizlenir."
                else "İlk silmede şifre ya da desen tanımlaman istenir. Fotoğrafların silinmez; yalnızca programın kendi kayıtları temizlenir.", style = MaterialTheme.typography.bodySmall)
            if (vaultSet) TextButton(onClick = { changeVault = true }) { Text("Şifreyi / deseni değiştir") }
        }

        // ---- Google Drive yedeği + uygulama kilidi
        DriveGroup(vm)
        LockGroup(vm)

        // ---- Yapımcıya ulaş: şikâyet / öneri e-postası + sosyal medya
        Group("Yapımcıya ulaş") {
            fun launchLink(value: String, intent: () -> Intent) {
                if (value.isBlank()) { vm.toast("Yapımcının bu bağlantısı henüz eklenmedi."); return }
                try { ctx.startActivity(intent().addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { vm.toast("Açılamadı: uygun uygulama bulunamadı.") }
            }
            Text("Şikâyet ve önerilerinizi yapımcıya e-posta ile iletebilirsiniz.", style = MaterialTheme.typography.bodySmall)
            Button(onClick = {
                launchLink(Dev.EMAIL) {
                    Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${Dev.EMAIL}")).putExtra(Intent.EXTRA_EMAIL, arrayOf(Dev.EMAIL))
                        .putExtra(Intent.EXTRA_SUBJECT, "FotoLiz $ver - Şikâyet / Öneri")
                        .putExtra(Intent.EXTRA_TEXT, "\n\n—\nFotoLiz $ver • Android ${Build.VERSION.RELEASE} • ${Build.MANUFACTURER} ${Build.MODEL}")
                }
            }, modifier = Modifier.fillMaxWidth()) { Text("Şikâyet ve önerileriniz: e-posta gönder") }
            HorizontalDivider()
            Text("Sosyal medya ve iletişim (dokununca yapımcının profili açılır)", style = MaterialTheme.typography.bodySmall)
            Column {
            LinkRow("Instagram", { InstagramIcon() }) {
                // Instagram uygulaması kuruluysa profil doğrudan uygulamada açılır; yoksa tarayıcıda açılır
                if (!openInApp(ctx, "com.instagram.android", Dev.INSTAGRAM)) launchLink(Dev.INSTAGRAM) { Intent(Intent.ACTION_VIEW, Uri.parse(Dev.INSTAGRAM)) }
            }
            LinkRow("Facebook", { FacebookIcon() }) {
                // Facebook uygulaması kuruluysa profil uygulamada açılır; yoksa tarayıcıda
                if (!openInApp(ctx, "com.facebook.katana", Dev.FACEBOOK)) launchLink(Dev.FACEBOOK) { Intent(Intent.ACTION_VIEW, Uri.parse(Dev.FACEBOOK)) }
            }
            LinkRow("WhatsApp", { WhatsAppIcon() }) {
                // WhatsApp (ya da WhatsApp Business) kuruluysa doğrudan mesaj yazma ekranı açılır; yoksa tarayıcıda
                val wa = "https://wa.me/${Dev.WHATSAPP}"
                if (!openInApp(ctx, "com.whatsapp", wa) && !openInApp(ctx, "com.whatsapp.w4b", wa)) launchLink(Dev.WHATSAPP) { Intent(Intent.ACTION_VIEW, Uri.parse(wa)) }
            }
            LinkRow("İletişim", { ContactIcon() }) { contact = true }
            }
        }

        // ---- Yasal
        Group("Yasal ve hakkında") {
            Column {
            LinkRow("Kullanım koşulları") { doc = "Kullanım koşulları" to Legal.TERMS }
            LinkRow("Gizlilik politikası ve KVKK aydınlatma") { doc = "Gizlilik ve KVKK" to Legal.PRIVACY }
            LinkRow("Açık kaynak ve model lisansları") { doc = "Lisanslar" to Legal.LICENSES }
            LinkRow("Sorumluluk reddi") { doc = "Sorumluluk reddi" to Legal.DISCLAIMER }
            }
        }
        Column(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                AppLogo(18.dp)
                Text("FotoLiz • Sürüm $ver", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Spacer(Modifier.height(14.dp))
            Text("YAPIMCI", fontSize = 12.sp, fontWeight = FontWeight.Bold, letterSpacing = 2.sp, color = MaterialTheme.colorScheme.primary)
            Text("Yağız Yağızoğlu", fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = MaterialTheme.colorScheme.onSurface, textAlign = TextAlign.Center)
            Spacer(Modifier.height(8.dp))
            Text("Bu programın tüm kodlaması ve yapımı Yağız Yağızoğlu'na aittir. Programın kaynak kodu, tasarımı, arayüzü ve adı dahil tüm mülkiyet ve telif (fikri mülkiyet) hakları yapımcıya aittir. © 2026 Yağız Yağızoğlu. Tüm hakları saklıdır. Önceden yazılı izin alınmadan çoğaltılamaz, dağıtılamaz, satılamaz veya değiştirilerek yeniden yayımlanamaz.",
                fontSize = 12.sp, lineHeight = 17.sp, textAlign = TextAlign.Center, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }

    if (contact) AlertDialog(onDismissRequest = { contact = false }, title = { Text("İletişim") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                ContactRow(Icons.Filled.Email, "E-posta", Dev.CONTACT_EMAIL) {
                    safeStart(ctx, Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:${Dev.CONTACT_EMAIL}"))) { vm.toast("E-posta uygulaması bulunamadı.") }
                }
                ContactRow(Icons.Filled.Phone, "Telefon", Dev.PHONE_SHOW) {
                    safeStart(ctx, Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Dev.PHONE}"))) { vm.toast("Arama uygulaması bulunamadı.") }
                }
                ContactRow(Icons.Filled.LocationOn, "Adres", Dev.ADDRESS) {
                    safeStart(ctx, Intent(Intent.ACTION_VIEW, Uri.parse("geo:0,0?q=" + Uri.encode(Dev.ADDRESS)))) { vm.toast("Harita uygulaması bulunamadı.") }
                }
            }
        },
        confirmButton = { TextButton(onClick = { contact = false }) { Text("Kapat") } })
    doc?.let { (t, body) ->
        AlertDialog(onDismissRequest = { doc = null }, title = { Text(t) },
            text = { Column(Modifier.heightIn(max = 420.dp).verticalScroll(rememberScrollState())) { Text(body, style = MaterialTheme.typography.bodyMedium) } },
            confirmButton = { TextButton(onClick = { doc = null }) { Text("Kapat") } })
    }
    if (vault) VaultDialog(onDismiss = { vault = false }, onOk = { vault = false; vaultSet = true; askClear = true })
    if (changeVault) VaultDialog(onDismiss = { changeVault = false }, onOk = { changeVault = false; vaultSet = true; vm.toast("Koruma güncellendi.") }, change = true)
    if (askClear) AlertDialog(onDismissRequest = { askClear = false },
        title = { Text("Kayıtlı sonuçlar silinsin mi?") },
        text = { Text("Tüm analiz kayıtları ve küçük yüz resimleri silinir. Fotoğraflarına dokunulmaz.") },
        confirmButton = { TextButton(onClick = { askClear = false; vm.clearSaved() }) { Text("Sil", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton(onClick = { askClear = false }) { Text("Vazgeç") } })
}

@Composable
internal fun Group(title: String, trailing: (@Composable () -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(18.dp), elevation = CardDefaults.cardElevation(2.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Filled.Settings, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                trailing?.invoke()
            }
            content()
        }
    }
}

@Composable
private fun InfoRow(k: String, v: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(k, modifier = Modifier.width(110.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, fontWeight = FontWeight.SemiBold)
        Text(v, modifier = Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
    }
}

@Composable
private fun LinkRow(t: String, icon: (@Composable () -> Unit)? = null, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(10.dp)).clickable(onClick = onClick).padding(vertical = 6.dp, horizontal = 4.dp),
        verticalAlignment = Alignment.CenterVertically) {
        if (icon != null) { icon(); Spacer(Modifier.width(12.dp)) }
        Text(t, modifier = Modifier.weight(1f))
        Text("›", fontSize = 22.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}


/** Uygulamayı verilen paketle açmayı dener (kuruluysa açılır). Açılamazsa false döner. */
private fun openInApp(ctx: android.content.Context, pkg: String, url: String): Boolean = try {
    ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).setPackage(pkg).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); true
} catch (e: Exception) { false }

private fun safeStart(ctx: android.content.Context, intent: Intent, onFail: () -> Unit) {
    try { ctx.startActivity(intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { onFail() }
}

@Composable
private fun ContactRow(icon: ImageVector, label: String, value: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).clickable { onClick() }.padding(horizontal = 6.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
        Spacer(Modifier.width(14.dp))
        Column {
            Text(label, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, fontWeight = FontWeight.SemiBold)
        }
    }
}


/** Ses ayarı bölümü. run=false: Biten Analiz (analiz / tarama / gruplama / arama bitince); run=true: Devam Eden Analiz (analiz sürerken bir kere). Dene + Sessize al yan yana. */
@Composable
private fun SoundSection(ctx: Context, run: Boolean) {
    var soundLabel by remember { mutableStateOf(DoneSound.label(ctx, run)) }
    var muted by remember { mutableStateOf(DoneSound.isMuted(ctx, run)) }
    val pick = rememberLauncherForActivityResult(androidx.activity.result.contract.ActivityResultContracts.StartActivityForResult()) { r ->
        if (r.resultCode == android.app.Activity.RESULT_OK) {
            @Suppress("DEPRECATION") val u: Uri? = r.data?.getParcelableExtra(android.media.RingtoneManager.EXTRA_RINGTONE_PICKED_URI)
            DoneSound.setUri(ctx, u?.toString() ?: "silent", run); soundLabel = DoneSound.label(ctx, run)
        }
    }
    // Dar, şık görünüm: tek yuvarlak kutu; başlık + ses adı tek satırda, 4 küçük düğme tek satırda
    val btn = Modifier.weight(1f).height(34.dp)
    val pad = PaddingValues(horizontal = 2.dp)
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (run) "Devam Eden Analiz" else "Biten Analiz", fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Text("  •  " + soundLabel + (if (muted) " (sessiz)" else ""), fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            Button(onClick = {
                val cur = DoneSound.getUri(ctx, run)
                val pi = Intent(android.media.RingtoneManager.ACTION_RINGTONE_PICKER)
                    .putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TYPE, android.media.RingtoneManager.TYPE_ALL)
                    .putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_TITLE, if (run) "Devam Eden Analiz sesi" else "Biten Analiz sesi")
                    .putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_DEFAULT, false)
                    .putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_SHOW_SILENT, true)
                if (cur.isNotEmpty() && cur != "silent") pi.putExtra(android.media.RingtoneManager.EXTRA_RINGTONE_EXISTING_URI, Uri.parse(cur))
                try { pick.launch(pi) } catch (e: Exception) { }
            }, modifier = btn, contentPadding = pad, shape = RoundedCornerShape(10.dp)) { Text("Değiştir", fontSize = 12.sp, maxLines = 1) }
            OutlinedButton(onClick = { DoneSound.play(ctx, run, force = true) }, modifier = btn, contentPadding = pad, shape = RoundedCornerShape(10.dp)) { Text("Dene", fontSize = 12.sp, maxLines = 1) }
            OutlinedButton(onClick = { muted = !muted; DoneSound.setMuted(ctx, run, muted) }, modifier = btn, contentPadding = pad, shape = RoundedCornerShape(10.dp)) { Text(if (muted) "Sesi aç" else "Sessize al", fontSize = 12.sp, maxLines = 1) }
            OutlinedButton(onClick = { DoneSound.setUri(ctx, "", run); soundLabel = DoneSound.label(ctx, run) }, modifier = btn, contentPadding = pad, shape = RoundedCornerShape(10.dp)) { Text("Sıfırla", fontSize = 12.sp, maxLines = 1) }
        }
    }
}
