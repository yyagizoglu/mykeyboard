package com.fotoliz.app

/**
 * Yapımcı iletişim bilgileri. Ayarlar > "Yapımcıya ulaş" bölümündeki düğmeler buradaki değerleri açar.
 * Boş bırakılan alan için düğmeye basınca "henüz eklenmedi" uyarısı çıkar; değeri yazınca düğme çalışır.
 */
object Dev {
    const val NAME = "Yağız Yağızoğlu"
    const val EMAIL = "dyagizoglu@gmail.com"       // şikâyet / öneri e-posta adresi, örn. "ornek@gmail.com"
    const val INSTAGRAM = "https://www.instagram.com/yagizyagizogluu/"   // profil bağlantısı, örn. "https://instagram.com/kullaniciadi"
    const val FACEBOOK = "https://www.facebook.com/duyguyagizoglu"    // profil bağlantısı, örn. "https://facebook.com/kullaniciadi"
    const val WHATSAPP = "905531659893"    // ülke kodlu numara, + ve boşluksuz, örn. "905551112233"
    const val PHONE = "+905531659893"       // İletişim: telefon numarası
    const val PHONE_SHOW = "+90 553 165 98 93"
    const val CONTACT_EMAIL = "fotoliz@gmail.com"   // İletişim penceresindeki e-posta
    const val ADDRESS = "Tire, İzmir 35900"         // İletişim penceresindeki adres
}
