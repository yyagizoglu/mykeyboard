package com.fotoliz.app

import android.net.Uri
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import java.io.File

/** Ana ekrandaki "Kişiye göre ara" kartı (nesne arama kutusunun altında). */
@Composable
fun PersonBox(vm: VM, pickPhoto: () -> Unit, pickAlbums: () -> Unit) {
    val ref = vm.refChoice
    SectionCard(Icons.Filled.Face, "Kişiye göre ara", "Bir yüz seç, albümlerde o kişiyi bul", compact = true) {
        if (ref != null) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                AsyncImage(File(ref.thumb), null,
                    Modifier.size(64.dp).clip(CircleShape).border(2.dp, MaterialTheme.colorScheme.primary, CircleShape), contentScale = ContentScale.Crop)
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Seçilen yüz", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    FieldBox(vm.personName, { vm.personName = it }, "Kişi / albüm adı", Icons.Filled.Person)
                    // Sayı Seç: her albümden yalnızca en yeni N fotoğrafta ara (boş = hepsi). Albüm ekranındaki kutuyla aynı değer.
                    CountField(vm.photoLimit, { vm.photoLimit = it }, Modifier.fillMaxWidth())
                }
            }
            PrimaryAction("Albüm seç ve kişiyi ara", { vm.searchMode = false; vm.searchPickOnly = false; vm.personMode = true; pickAlbums() }, enabled = vm.modelReady, icon = Icons.Filled.Search, h = 42.dp)
        }
        if (vm.detecting) Text("Fotoğraftaki yüzler bulunuyor…", style = MaterialTheme.typography.bodySmall)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TonalAction(if (ref == null) "Fotoğraftan yüz seç" else "Başka yüz seç", pickPhoto, Modifier.weight(1f), enabled = vm.modelReady && !vm.detecting, icon = Icons.Filled.Face, h = 40.dp)
            if (vm.savedPeople().isNotEmpty())
                TonalAction("Kayıtlı kişiler", { vm.pickForSaved = false; vm.photoChoices = emptyList(); vm.screen = Screen.PickFace }, Modifier.weight(1f), icon = Icons.Filled.Person, h = 40.dp)
        }
        Text("Bir fotoğraftan ya da önceki analizlerden bir yüz seç; seçtiğin albümlerde o kişinin göründüğü tüm fotoğraflar bulunur.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        if (PersonEngine.refThumb.isNotBlank() && (PersonEngine.running || PersonEngine.scores.isNotEmpty()))
            RecentRow(if (PersonEngine.running) "Arama sürüyor: “${PersonEngine.name.ifBlank { "Kişi" }}” (${PersonEngine.hits().size})"
                else "Son arama: “${PersonEngine.name.ifBlank { "Kişi" }}” • ${PersonEngine.hits().size} fotoğraf") { vm.screen = Screen.Person }
    }
}

/** Yüz seçme ekranı: seçilen fotoğraftaki yüzler + önceki analizlerde bulunan kişiler. Kayıtlı kişide basılı tutunca isim değişir. */
@Composable
fun PickFaceScreen(vm: VM) {
    val photo = vm.photoChoices
    val people = vm.savedPeople()
    var renaming by remember { mutableStateOf<FaceChoice?>(null) }
    LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxSize(), contentPadding = PaddingValues(12.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (photo.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(if (vm.pickForSaved) "Kaydedilecek yüze dokun" else "Aranacak yüze dokun", style = MaterialTheme.typography.titleMedium)
            }
            items(photo) { c -> FaceCell(c, vm.refChoice === c, onClick = { vm.chooseRef(c) }) }
        }
        if (people.isNotEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Column(Modifier.padding(top = if (photo.isEmpty()) 0.dp else 8.dp)) {
                    Text(if (photo.isEmpty()) "Önceki analizlerde bulunan kişiler" else "veya önceki analizlerdeki kişiler", style = MaterialTheme.typography.titleMedium)
                    Text(if (vm.pickForSaved) "Dokununca “Kaydedilen yüzler”e eklenir" else "Dokununca aranır • İsmini değiştirmek için yüze basılı tut", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
            items(people) { c -> FaceCell(c, vm.refChoice === c, onClick = { vm.chooseRef(c) }, onLongClick = { renaming = c }) }
        }
        if (photo.isEmpty() && people.isEmpty()) item(span = { GridItemSpan(maxLineSpan) }) {
            Text("Gösterilecek yüz yok. Ana ekrandan bir fotoğraf seçin.")
        }
    }
    renaming?.let { c ->
        var text by remember(c) { mutableStateOf(c.name) }
        AlertDialog(onDismissRequest = { renaming = null },
            title = { Text("Kişinin ismini değiştir") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    AsyncImage(File(c.thumb), null, Modifier.size(72.dp).clip(CircleShape).align(Alignment.CenterHorizontally), contentScale = ContentScale.Crop)
                    FieldBox(text, { text = it }, "İsim", Icons.Filled.Person)
                }
            },
            confirmButton = { TextButton(onClick = { vm.renamePerson(c, text); renaming = null }) { Text("Kaydet") } },
            dismissButton = { TextButton(onClick = { renaming = null }) { Text("Vazgeç") } })
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FaceCell(c: FaceChoice, on: Boolean, onClick: () -> Unit, onLongClick: (() -> Unit)? = null) {
    Column(Modifier.combinedClickable(onClick = onClick, onLongClick = onLongClick), horizontalAlignment = Alignment.CenterHorizontally) {
        AsyncImage(File(c.thumb), null,
            Modifier.size(96.dp).clip(CircleShape).then(if (on) Modifier.border(4.dp, MaterialTheme.colorScheme.primary, CircleShape) else Modifier),
            contentScale = ContentScale.Crop)
        Text(c.label, style = MaterialTheme.typography.titleSmall, maxLines = 1)
    }
}

/** Kişi arama sonuç ekranı: ilerleme, eşik, ad düzenleme, Kaydet (bulunanlardan seç → albüm seç/oluştur) ve bulunan fotoğraflar. */
@Composable
fun PersonScreen(vm: VM) {
    val running = PersonEngine.running
    val hits = PersonEngine.hits()
    val fgGroups = FoundGroup.valid("person", hits)
    val fgOpen = if (fgGroups != null) FoundGroup.openGroup else null
    LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxSize(), contentPadding = PaddingValues(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            PanelCard(Modifier.padding(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    if (PersonEngine.refThumb.isNotBlank())
                        AsyncImage(File(PersonEngine.refThumb), null, Modifier.size(64.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                    Column(Modifier.weight(1f)) {
                        Text(PersonEngine.status, style = MaterialTheme.typography.bodyMedium)
                        if (running) GreenProgress(PersonEngine.done.toFloat() / PersonEngine.total.coerceAtLeast(1))
                    }
                }
                PersonEngine.error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
                Text("Benzerlik eşiği: %.2f".format(PersonEngine.threshold), style = MaterialTheme.typography.titleSmall)
                Slider(value = PersonEngine.threshold, onValueChange = { PersonEngine.threshold = it }, valueRange = 0.25f..0.70f)
                Text("Düşük = daha çok fotoğraf (yanlış kişi de girebilir), yüksek = daha kesin. Sonuçlar eşiğe göre anında güncellenir.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                FieldBox(vm.personName, { vm.personName = it }, "Albüm adı (düzenleyebilirsin)", Icons.Filled.Person)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    if (running) TonalAction("Durdur", { PersonEngine.cancel() }, Modifier.weight(1f))
                    else TonalAction("Yeni arama", { vm.screen = Screen.Main }, Modifier.weight(1f))
                    if (hits.isNotEmpty()) TonalAction("Seç / incele (${hits.size})", { vm.openPersonResults() }, Modifier.weight(1f))
                }
                PrimaryAction("Kaydet: albüm seç / oluştur (${hits.size})", { vm.beginSave(true) }, enabled = !running && hits.isNotEmpty(), icon = Icons.Filled.Check)
                Text(if (running) "Arama arka planda sürer; ekranı kapatabilir veya uygulamadan çıkabilirsiniz. Durdur'a basarsanız o ana kadar bulunanlar bitmiş sonuç sayılır ve kaydedilebilir."
                    else if (PersonEngine.stopped) "Arama durduruldu; bulunan ${hits.size} fotoğraf hafızada. Kaydet'e basıp istediklerini seçebilirsin."
                    else "Kaydet'e basınca bulunanlardan istediklerini seçer, sonra hangi albüme taşıyacağını belirlersin (yeni albüm de açabilirsin).",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (!running && hits.isEmpty() && PersonEngine.error == null) item(span = { GridItemSpan(maxLineSpan) }) {
            Text("Bu eşikte eşleşen fotoğraf yok. Eşiği düşürmeyi veya yüzü daha net bir fotoğraftan seçmeyi deneyin.", Modifier.padding(16.dp))
        }
        item(span = { GridItemSpan(maxLineSpan) }) { FoundGroupBar("person", hits, running) }
        foundItems(fgGroups, fgOpen, hits) { i, l -> vm.openPersonResults(i, l) }
    }
}
