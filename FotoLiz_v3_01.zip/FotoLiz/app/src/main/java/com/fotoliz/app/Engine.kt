package com.fotoliz.app

import android.app.Application
import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import java.io.File

const val PARALLEL = 3   // Aynı anda işlenen fotoğraf sayısı

/**
 * Analiz motoru. Activity/ViewModel'den bağımsız, uygulama düzeyinde çalışır; ScanService (ön plan servisi)
 * sayesinde ekran kapansa / uygulamadan çıkılsa bile durmaz. Bitince sonuç kaydedilir.
 */
object Engine {
    var running by mutableStateOf(false)
    var done by mutableStateOf(0)
    var total by mutableStateOf(1)
    var status by mutableStateOf("")
    var startMs by mutableStateOf(0L)        // bu analizin başlangıç zamanı (geçen süre için)
    var etaSec by mutableStateOf(-1L)        // tahmini kalan süre (sn); -1 = henüz hesaplanamadı
    var error by mutableStateOf<String?>(null)
    var finished by mutableStateOf<Result?>(null)   // bitince dolar; arayüz alıp otomatik açar
    var summary by mutableStateOf("")
    var currentPhoto by mutableStateOf<Uri?>(null)          // tarama ekranında gösterilen, şu an analiz edilen fotoğraf
    val liveFaces = mutableStateListOf<String>()            // bulunan yüzlerin küçük resim yolları (canlı önizleme)
    class LiveFace(val photo: String, val emb: FloatArray)
    val liveInfo = java.util.concurrent.ConcurrentHashMap<String, LiveFace>()   // önizleme dosyası -> hangi fotoğraftan, yüz vektörü
    var people by mutableStateOf(0)                         // bulunan GERÇEK kişi sayısı (aynı kişi birden çok fotoğrafta olsa da bir kez sayılır)
    @Volatile var cancelled = false
    // Biten ama henüz açılıp bakılmamış son analizin anahtarı (ana ekranda yeşil, 3 sn'de bir yanıp sönen kart)
    var unseenKey by mutableStateOf<String?>(null)
    fun loadUnseen(ctx: Context) { unseenKey = foundPrefs(ctx).getString("unseen_key", null) }
    fun setUnseen(ctx: Context, k: String?) { unseenKey = k; foundPrefs(ctx).edit().apply { if (k == null) remove("unseen_key") else putString("unseen_key", k) }.apply() }

    // "Bulunan yüzler" panosunda gösterilen sonuçlar (Result.key listesi): her yeni analizde temizlenir; kayıtlı sonuç açılınca eklenir
    var found by mutableStateOf<Set<String>>(emptySet())
    private fun foundPrefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("app", 0)
    /** Açılışta bir kez: kayıt yoksa (eski sürümden geliyorsa) mevcut tüm kayıtlı sonuçlar gösterilir. */
    fun loadFound(ctx: Context, legacyKeys: List<String>) {
        found = foundPrefs(ctx).getStringSet("found_keys", null)?.toSet() ?: legacyKeys.toSet()
    }
    fun setFound(ctx: Context, s: Set<String>) { found = s; foundPrefs(ctx).edit().putStringSet("found_keys", HashSet(s)).apply() }
    fun addFound(ctx: Context, key: String) { if (key !in found) setFound(ctx, found + key) }
    @Volatile var doneText = ""

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private val IMG = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

    fun cancel() { job?.cancel() }

    fun albumSource(sel: List<String>): (Context) -> Pair<String, List<Uri>> = { ctx ->
        val ids = sel.mapNotNull { it.toLongOrNull() }.joinToString(",")
        val limit = sel.firstOrNull { it.startsWith("~N") }?.substring(2)?.toIntOrNull() ?: 0   // albüm başına en fazla bu kadar (en yeniden başlayarak)
        val out = ArrayList<Uri>()
        val perAlbum = HashMap<Long, Int>()
        if (ids.isNotEmpty()) ctx.contentResolver.query(IMG, arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.BUCKET_ID),
            "${MediaStore.Images.Media.BUCKET_ID} IN ($ids)", null, if (limit > 0) "${MediaStore.Images.Media.DATE_ADDED} DESC" else null)?.use { c ->
            while (c.moveToNext()) {
                if (limit > 0) { val n = (perAlbum[c.getLong(1)] ?: 0) + 1; perAlbum[c.getLong(1)] = n; if (n > limit) continue }
                out.add(ContentUris.withAppendedId(IMG, c.getLong(0)))
            }
        }
        // Başlıkta taranan albümlerin tam adları görünsün (bucket id → görünen ad)
        val names = LinkedHashSet<String>()
        if (ids.isNotEmpty()) try {
            ctx.contentResolver.query(IMG, arrayOf(MediaStore.Images.Media.BUCKET_ID, MediaStore.Images.Media.BUCKET_DISPLAY_NAME),
                "${MediaStore.Images.Media.BUCKET_ID} IN ($ids)", null, MediaStore.Images.Media.BUCKET_DISPLAY_NAME)?.use { c ->
                val seen = HashSet<Long>()
                while (c.moveToNext()) { if (seen.add(c.getLong(0))) c.getString(1)?.takeIf { it.isNotBlank() }?.let { names.add(it) } }
            }
        } catch (e: Exception) { }
        Pair(if (names.isEmpty()) "Albümler" else names.joinToString(", "), out)
    }

    private fun collect(d: DocumentFile, out: MutableList<DocumentFile>) {
        for (f in d.listFiles()) {
            if (f.isDirectory) collect(f, out)
            else if (f.type?.startsWith("image/") == true) out.add(f)
        }
    }

    fun folderSource(uri: Uri, sel: List<String>): (Context) -> Pair<String, List<Uri>> = { ctx ->
        val root = DocumentFile.fromTreeUri(ctx, uri) ?: throw Exception("Klasör açılamadı.")
        val all = sel.isEmpty()
        val files = ArrayList<DocumentFile>()
        for (f in root.listFiles()) {
            if (f.isDirectory) { if (all || f.name in sel) collect(f, files) }
            else if ((all || ROOT in sel) && f.type?.startsWith("image/") == true) files.add(f)
        }
        Pair(root.name ?: "Klasör", files.map { it.uri })
    }

    fun fmt(sec: Long): String = if (sec >= 3600) "%d:%02d:%02d".format(sec / 3600, sec % 3600 / 60, sec % 60) else "%02d:%02d".format(sec / 60, sec % 60)
    private const val LIVE_THR = 0.40f   // canlı sayımda bu benzerlikten yüksek yüzler aynı kişi sayılır

    fun start(app: Application, resUri: String, sel: List<String>, source: (Context) -> Pair<String, List<Uri>>, resume: Boolean = false) {
        if (running) return
        running = true; cancelled = false; error = null; finished = null; summary = ""; doneText = ""
        setFound(app, emptySet())     // yeni analiz: önceki bulunan yüzler temizlenir
        startMs = System.currentTimeMillis(); etaSec = -1L
        done = 0; total = 1; status = if (resume) "Yarım kalan analiz sürdürülüyor…" else "Fotoğraflar listeleniyor…"
        currentPhoto = null; liveFaces.clear(); liveInfo.clear(); people = 0
        ScanService.start(app)
        job = scope.launch {
            var analyzer: Analyzer? = null
            try {
                val gf = sel.firstOrNull { it == "~M" || it == "~F" }?.substring(1)   // albüm analizinde cinsiyet filtresi (sel içinde işaret olarak tutulur)
                HairStore.load(app)
                val an = Analyzer(app, PARALLEL, gf).also { analyzer = it }
                an.selfTest()
                val (rootName, files) = source(app)
                if (files.isEmpty()) throw Exception("Seçilen yerde fotoğraf bulunamadı.")
                total = files.size
                val key = Store.keyOf(resUri, sel)
                val label = if (resUri == "media") "${sel.count { !it.startsWith("~") }} albüm" + (if (gf == "M") " • Erkek" else if (gf == "F") " • Kadın" else "") else if (sel.isEmpty()) "tümü" else "${sel.size} seçim"
                // Albümlerden taramada: "3 albüm • Albüm1, Albüm2, Albüm3" (sayı + tam adlar); klasör taramasında eskisi gibi
                val resName = if (resUri == "media") "$label • $rootName" else "$rootName • $label"
                val recs = ArrayList<FaceRec>()
                val objPhotos = LinkedHashMap<String, LinkedHashSet<String>>()   // nesne adı -> yüzü olmayan fotoğraflar
                val objThumbs = HashMap<String, String>()
                var noFace = 0; var failed = 0; var firstErr: String? = null
                // Devam: diske yazılmış ilerleme okunur, yalnızca işlenmemiş fotoğraflar taranır
                val prior = if (resume) Partial.load(app, key) else null
                if (prior != null) {
                    recs.addAll(prior.recs); objPhotos.putAll(prior.objPhotos); objThumbs.putAll(prior.objThumbs)
                    noFace = prior.noFace; failed = prior.failed
                } else {
                    Store.thumbDir(app).listFiles()?.filter { it.name.startsWith(key + "_") }?.forEach { it.delete() }
                    File(Store.thumbDir(app), key + "_").absolutePath.let { pre -> HairStore.forgetPrefix(pre); FaceAttrs.forgetPrefix(app, pre) }
                    Partial.begin(app, key, resUri, sel, files.size, resName)
                }
                val todo = if (prior != null) files.filter { it.toString() !in prior.processed } else files
                val before = files.size - todo.size
                done = before
                val previewDir = File(app.cacheDir, "preview").apply { deleteRecursively(); mkdirs() }
                var faceCount = recs.size
                val reps = ArrayList<FloatArray>()   // her gerçek kişi için temsilci yüz vektörü
                fun isNewPerson(e: FloatArray): Boolean {
                    if (e.isEmpty()) return false
                    for (r in reps) if (r.size == e.size && dot(r, e) >= LIVE_THR) return false
                    reps.add(e); return true
                }
                for (r in recs) isNewPerson(r.emb)
                people = reps.size
                val t0 = System.currentTimeMillis()
                val chan = Channel<Deferred<Prep>>(PARALLEL)
                coroutineScope {
                    launch {
                        for (u in todo) chan.send(async { an.process(app, u) })
                        chan.close()
                    }
                    for (i in todo.indices) {
                        val p = chan.receive().await()
                        val u = todo[i]
                        val mine = ArrayList<FaceRec>()
                        var newObj: String? = null; var newObjThumb: String? = null
                        if (p.err != null) {
                            failed++; if (firstErr == null) firstErr = p.err
                            if (i == 7 && failed == 8) throw Exception("İlk 8 fotoğrafın hepsinde hata oluştu: $firstErr")
                        } else if (p.faces.isEmpty()) {
                            noFace++
                            val name = p.obj
                            if (name != null) {
                                objPhotos.getOrPut(name) { LinkedHashSet() }.add(u.toString())
                                newObj = name
                                val ot = p.objThumb
                                if (ot != null && name !in objThumbs) try {
                                    val tf = File(Store.thumbDir(app), "${key}_o${objThumbs.size}.jpg")
                                    tf.outputStream().use { ot.compress(Bitmap.CompressFormat.JPEG, 85, it) }
                                    objThumbs[name] = tf.absolutePath; newObjThumb = tf.absolutePath
                                } catch (e: Exception) { }
                            }
                        }
                        currentPhoto = u
                        for (fd in p.faces) {
                            faceCount++
                            var tp = ""
                            if (fd.q >= Q_GOOD) {   // küçük resmi hemen diske yaz, bellekte tutma
                                val tf = File(Store.thumbDir(app), "${key}_f${recs.size}.jpg")
                                tf.outputStream().use { Bitmap.createScaledBitmap(fd.crop, 160, 160, true).compress(Bitmap.CompressFormat.JPEG, 85, it) }
                                tp = tf.absolutePath
                                HairStore.put(tp, fd.hair)      // saç rengi orijinal fotoğraftan
                            }
                            // Canlı önizleme: yalnızca YENİ kişi için daire resmi eklenir; aynı kişinin diğer fotoğrafları sayıya/önizlemeye eklenmez
                            val isNew = isNewPerson(fd.emb)
                            if (isNew) {
                                people = reps.size
                                try {
                                    val pf = File(previewDir, "p${faceCount}.jpg")
                                    pf.outputStream().use { Bitmap.createScaledBitmap(fd.crop, 96, 96, true).compress(Bitmap.CompressFormat.JPEG, 80, it) }
                                    liveInfo[pf.absolutePath] = LiveFace(u.toString(), fd.emb)
                                    liveFaces.add(pf.absolutePath)
                                } catch (e: Exception) { }
                            } else liveInfo["dup$faceCount"] = LiveFace(u.toString(), fd.emb)   // gösterilmez; yüze dokununca aynı kişinin fotoğraflarını bulmak için
                            val rec = FaceRec(fd.emb, u.toString(), fd.q, fd.area, tp)
                            recs.add(rec); mine.add(rec)
                        }
                        Partial.append(app, key, u.toString(), p.err != null, mine, newObj, newObjThumb)   // ilerleme diske yazılır (yarım kalırsa devam edilir)
                        done = before + i + 1
                        val el = (System.currentTimeMillis() - t0) / 1000
                        etaSec = if (i >= 3) el * (todo.size - i - 1) / (i + 1) else -1L
                        status = "Analiz Edilen Sayı:${before + i + 1} / Toplam Bakılacak Sayı:${files.size} • Bulunan Yüz:$people"
                    }
                }
                status = "Yüzler gruplanıyor ($faceCount yüz)…"
                val grouped = Clusterer.run(recs, key, Store.thumbDir(app))
                if (failed == files.size) throw Exception("Hiçbir fotoğraf işlenemedi. İlk hata: $firstErr")
                // Yüzü olmayan fotoğraflar: bulunan nesnenin adıyla gruplanır (Evrak / Belge, Araba, Motosiklet...)
                val objClusters = objPhotos.entries.filter { objThumbs.containsKey(it.key) }.sortedByDescending { it.value.size }
                    .mapIndexed { i, e -> Cluster(100000 + i, FloatArray(0), e.value.size, LinkedHashSet(e.value), objThumbs[e.key]!!, 0, emptyList(), e.key, LinkedHashSet(), true) }
                val res = Result(resUri, resName, files.size, System.currentTimeMillis(),
                    grouped.clusters.sortedByDescending { it.photos.size } + objClusters, sel,
                    (System.currentTimeMillis() - startMs) / 1000)
                if (res.clusters.isNotEmpty()) { Store.save(app, res); setFound(app, setOf(res.key)) }   // otomatik kaydet; bulunan yüzler bu analizin sonucu olur
                Partial.clear(app, key)                               // tamamlandı: yarım kayıt artık gerekmez
                summary = "$people kişi ($faceCount yüz karesi) bulundu • ${files.size} fotoğraftan $noFace tanesinde yüz yok" +
                    (if (grouped.weakSkipped > 0) " • ${grouped.weakSkipped} düşük kaliteli yüz atlandı" else "") +
                    (if (failed > 0) " • $failed fotoğraf okunamadı (ilk hata: $firstErr)" else "")
                doneText = if (res.clusters.isEmpty()) "Yüz ya da nesne bulunamadı" else "${grouped.clusters.size} kişi • ${objClusters.size} nesne grubu • ${files.size} fotoğraf"
                currentPhoto = null
                finished = res
            } catch (e: CancellationException) { cancelled = true; throw e
            } catch (e: Throwable) {
                error = e.message ?: e.javaClass.simpleName; doneText = "Analiz hatası: $error"
            } finally {
                analyzer?.close()
                HairStore.persist(app)
                running = false
            }
        }
    }
}
