package com.fotoliz.app

import android.app.Application
import android.content.ContentUris
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.runtime.*
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel

/** Seçilen yüzü (referans) temsil eden küçük resim + yüz vektörleri. */
class FaceChoice(val thumb: String, val embs: List<FloatArray>, val label: String, val name: String = "",
                 val cluster: Cluster? = null, val result: Result? = null)   // kayıtlı kişide: ismi değiştirmek için ait olduğu grup ve sonuç

/**
 * Kişiye göre arama: seçilen albümlerdeki her fotoğrafta yüzleri bulur, referans yüze benzerliğini ölçer.
 * Her fotoğrafın en yüksek benzerliği saklanır; sonuç ekranındaki eşik kaydırıcısı yeniden taramadan listeyi günceller.
 */
object PersonEngine {
    const val KEEP = 0.25f          // Bunun altındaki benzerlikler hiç saklanmaz
    const val DEFAULT_THR = 0.40f   // Varsayılan "aynı kişi" eşiği

    var running by mutableStateOf(false)
    var done by mutableStateOf(0)
    var total by mutableStateOf(1)
    var status by mutableStateOf("")
    var error by mutableStateOf<String?>(null)
    var finished by mutableStateOf(false)
    var stopped by mutableStateOf(false)   // Durdur'a basıldı: o ana kadar bulunanlar "bitmiş sonuç" gibi sunulur
    var name by mutableStateOf("")
    var refThumb by mutableStateOf("")
    var threshold by mutableStateOf(DEFAULT_THR)
    val scores = mutableStateMapOf<String, Float>()
    @Volatile var doneText = ""
    @Volatile var notifyDone = false

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var job: Job? = null
    private val IMG = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

    fun cancel() { job?.cancel() }

    /** Eşiği geçen fotoğraflar, en benzerden en aza doğru. */
    fun hits(): List<String> = scores.entries.filter { it.value >= threshold }.sortedByDescending { it.value }.map { it.key }

    private fun best(a: Analyzer, app: Application, u: Uri, refs: List<FloatArray>): Float {
        try {
            val bmp = a.decode(app, u) ?: return -1f
            var b = -1f
            try {
                for (f in a.faces(bmp)) for (r in refs) { val d = dot(f.emb, r); if (d > b) b = d }
            } finally { bmp.recycle() }
            return b
        } catch (e: CancellationException) { throw e } catch (e: Throwable) { return -1f }
    }

    fun start(app: Application, refs: List<FloatArray>, thumb: String, personName: String, albumIds: List<String>) {
        if (running) return
        running = true; finished = false; stopped = false; error = null; scores.clear(); done = 0; total = 1
        name = personName.trim(); refThumb = thumb; threshold = DEFAULT_THR
        status = "Fotoğraflar listeleniyor…"; doneText = ""; notifyDone = false; Engine.doneText = ""
        ScanService.start(app)
        job = scope.launch {
            var an: Analyzer? = null
            try {
                val a = Analyzer(app, PARALLEL); an = a
                a.selfTest()
                val ids = albumIds.mapNotNull { it.toLongOrNull() }.joinToString(",")
                val files = ArrayList<Uri>()
                if (ids.isNotEmpty()) app.contentResolver.query(IMG, arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.BUCKET_ID),
                    "${MediaStore.Images.Media.BUCKET_ID} IN ($ids)", null, "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
                    val lim = albumIds.firstOrNull { it.startsWith("~N") }?.substring(2)?.toIntOrNull() ?: 0   // Sayı Seç: albüm başına ilk N
                    val cnt = HashMap<Long, Int>()
                    while (c.moveToNext()) {
                        if (lim > 0) { val n = (cnt[c.getLong(1)] ?: 0) + 1; cnt[c.getLong(1)] = n; if (n > lim) continue }
                        files.add(ContentUris.withAppendedId(IMG, c.getLong(0)))
                    }
                }
                if (files.isEmpty()) throw Exception("Seçilen albümlerde fotoğraf bulunamadı.")
                total = files.size
                val label = if (name.isBlank()) "Kişi" else name
                val chan = Channel<Deferred<Float>>(PARALLEL)
                coroutineScope {
                    launch {
                        for (u in files) chan.send(async { best(a, app, u, refs) })
                        chan.close()
                    }
                    for (i in files.indices) {
                        val s = chan.receive().await()
                        if (s >= KEEP) scores[files[i].toString()] = s
                        done = i + 1
                        if (i % 5 == 0 || i == files.lastIndex)
                            status = "“$label” aranıyor: ${i + 1}/${files.size} • ${scores.values.count { it >= threshold }} fotoğraf bulundu"
                    }
                }
                doneText = "“$label”: ${scores.values.count { it >= threshold }} fotoğraf bulundu (${files.size} taranan)"
                status = doneText
                finished = true; notifyDone = true
            } catch (e: CancellationException) {
                // Durdurulunca o ana kadar bulunanlar hafızada kalır ve tamamlanmış sonuç gibi sunulur
                stopped = true; finished = true
                val n = scores.values.count { it >= threshold }
                doneText = "“${if (name.isBlank()) "Kişi" else name}”: $n fotoğraf bulundu ($done/$total tarandı, durduruldu)"
                status = doneText
                notifyDone = true
                throw e
            } catch (e: Throwable) {
                error = e.message ?: e.javaClass.simpleName; doneText = "Arama hatası: $error"
            } finally {
                try { an?.close() } catch (e: Exception) { }
                running = false
            }
        }
    }
}
