package com.fotoliz.app

import android.app.Application
import android.app.RecoverableSecurityException
import android.content.ContentValues
import android.content.Intent
import android.content.IntentSender
import android.os.Build
import android.widget.Toast
import android.content.ContentUris
import android.net.Uri
import android.provider.MediaStore
import android.graphics.Bitmap
import androidx.compose.runtime.*
import androidx.documentfile.provider.DocumentFile
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.*
import kotlinx.coroutines.sync.withLock
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import com.google.android.gms.auth.api.identity.Identity

class Album(val id: String, val name: String, val count: Int, val cover: Uri)
enum class Screen { Main, Select, Albums, Scanning, Clusters, Photos, Viewer, Crop, Settings, Search, PickFace, Person, Faces, Celebs, PickEdit, PickFacePhoto, Gallery }
val MODEL_URLS = listOf(
    "https://huggingface.co/globalnebula/insightface-buffalo-l-onnx/resolve/main/arcface_w600k_r50.onnx",
    "https://huggingface.co/lithiumice/insightface/resolve/main/models/buffalo_l/w600k_r50.onnx",
    "https://huggingface.co/public-data/insightface/resolve/main/models/buffalo_l/w600k_r50.onnx")
const val THRESHOLD = 0.50f   // Aynı kişi eşiği. Farklı kişiler birleşiyorsa artır (0.55), aynı kişi bölünüyorsa azalt (0.45).

class VM(app: Application) : AndroidViewModel(app) {
    var screen by mutableStateOf(if (Engine.running) Screen.Scanning else Screen.Main)
    private val initialSaved = Store.loadAll(app).also { Engine.loadFound(app, it.map { r -> r.key }) }       // açılışta yalnızca bir kez okunur
    var saved by mutableStateOf(initialSaved)
    var current by mutableStateOf<Result?>(null)
    var selected by mutableStateOf<Cluster?>(null)
    var askFor by mutableStateOf<Result?>(null)
    // Yeni kurulumda (kayıt yokken) bir kez "yedekten geri yükle / yok, devam et" sorusu
    var askRestore by mutableStateOf(app.getSharedPreferences("app", 0).let { !it.getBoolean("restore_asked", false) && initialSaved.isEmpty() })
    fun dismissRestoreAsk() { askRestore = false; getApplication<Application>().getSharedPreferences("app", 0).edit().putBoolean("restore_asked", true).apply() }
    fun backupTo(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val msg = try { "${Backup.export(getApplication(), uri)} kayıt yedeklendi." } catch (e: Exception) { "Yedekleme başarısız: ${e.message}" }
            withContext(Dispatchers.Main) { toast(msg) }
        }
    }
    var lastBackup by mutableStateOf<String?>(null)    // Ayarlar'da gösterilen "En son yedek" satırı
    fun refreshLastBackup() { lastBackup = Backup.lastInfo(getApplication()) }
    /** "Yedekle": her seferinde klasör seçtirir; klasörde FotoLiz_yedek.zip varsa üzerine yazar. */
    fun backupToFolder(tree: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val msg = try {
                val (n, over, name) = Backup.exportToFolder(getApplication(), tree)
                "$n kayıt yedeklendi (${name}) • " + (if (over) "eski yedeğin üzerine yazıldı" else "yeni yedek oluşturuldu")
            } catch (e: Exception) { "Yedekleme başarısız: ${e.message}" }
            withContext(Dispatchers.Main) { refreshLastBackup(); toast(msg) }
        }
    }
    fun restoreFrom(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            val msg = try { "${Backup.import(getApplication(), uri)} kayıt geri yüklendi." } catch (e: Exception) { "Geri yükleme başarısız: ${e.message}" }
            val all = Store.loadAll(getApplication())
            Celebs.load(getApplication())
            val sf = SavedFaces.load(getApplication())
            val thr = getApplication<Application>().getSharedPreferences("app", 0).getFloat("startThr", 0.25f)
            withContext(Dispatchers.Main) { saved = all; savedFaces = sf; startThr = thr; toast(msg) }
        }
    }

    // ------------------------------------------------------------------ Google Drive yedeği
    var driveError by mutableStateOf<String?>(null)   // Google bağlantı hatasının tam metni (Ayarlar'da pencerede gösterilir)
    var driveConnectTick by mutableStateOf(0)           // bağlantı/izin tamamlanınca artar: klasör seçici yeniden açılır
    private var pendingAccount: String? = null
    /** accountName: kullanıcının hesap penceresinde seçtiği Google hesabı (null = bağlı hesap). */
    fun driveConnect(accountName: String?, startAuth: (IntentSender) -> Unit) {
        pendingAccount = accountName
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            try {
                val r = DriveBackup.authorize(app, accountName?.let { android.accounts.Account(it, "com.google") })
                val pi = r.pendingIntent
                if (r.hasResolution() && pi != null) withContext(Dispatchers.Main) { startAuth(pi.intentSender) }
                else finishDriveConnect(r.accessToken)
            } catch (e: Throwable) { withContext(Dispatchers.Main) { driveError = "${DriveBackup.explain(e)}\n\nTeknik ayrıntı: ${e.javaClass.simpleName}: ${e.cause?.message ?: e.message}" } }
        }
    }
    fun driveAuthResult(data: Intent?) {
        if (data == null) { toast("Google izni verilmedi."); return }
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            try { finishDriveConnect(Identity.getAuthorizationClient(app).getAuthorizationResultFromIntent(data).accessToken) }
            catch (e: Throwable) { withContext(Dispatchers.Main) { driveError = "${DriveBackup.explain(e)}\n\nTeknik ayrıntı: ${e.javaClass.simpleName}: ${e.cause?.message ?: e.message}" } }
        }
    }
    private suspend fun finishDriveConnect(token: String?) {
        val app = getApplication<Application>()
        DriveBackup.onConnected(app, token, pendingAccount)
        withContext(Dispatchers.Main) { driveConnectTick++; toast("Google Drive bağlandı. Şimdi yedek klasörünü seç.") }
    }
    var driveFound by mutableStateOf<DriveBackup.Meta?>(null)   // klasörde bulunan eski yedek: "yüklensin mi?" sorulur
    var driveChecking by mutableStateOf(false)
    /** Hesap bağlanıp klasör seçilince: Drive'da yedek var mı bakar. Varsa sorar; yoksa ilk yedeği alır. */
    fun driveCheckBackup() {
        if (driveChecking) return
        driveChecking = true
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            try {
                val m = DriveBackup.latestMeta(app)
                if (m == null) { DriveBackup.markRestoreChecked(app); val msg = DriveBackup.runOnce(app, force = true); withContext(Dispatchers.Main) { toast(msg) } }
                else withContext(Dispatchers.Main) { driveFound = m }
            } catch (e: Throwable) { withContext(Dispatchers.Main) { toast("Drive yedeği kontrol edilemedi: ${DriveBackup.explain(e)}") } }
            finally { withContext(Dispatchers.Main) { driveChecking = false } }
        }
    }
    /** "Hayır": eski yedek yüklenmez; bundan sonraki yedekler onun üzerine yazar. */
    fun driveDeclineRestore() {
        val app = getApplication<Application>()
        driveFound = null; DriveBackup.markRestoreChecked(app)
        viewModelScope.launch(Dispatchers.IO) { val m = DriveBackup.runOnce(app, force = true); withContext(Dispatchers.Main) { toast(m) } }
    }
    fun driveBackupNow() {
        viewModelScope.launch(Dispatchers.IO) { val m = DriveBackup.runOnce(getApplication(), force = true); withContext(Dispatchers.Main) { toast(m) } }
    }
    fun driveRestore() {
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val m = DriveBackup.restoreLatest(app)
            val all = Store.loadAll(app); val sf = SavedFaces.load(app); Celebs.load(app)
            val thr = app.getSharedPreferences("app", 0).getFloat("startThr", 0.25f)
            withContext(Dispatchers.Main) { saved = all; savedFaces = sf; startThr = thr; toast(m) }
        }
    }
    fun driveSetEnabled(on: Boolean) { DriveBackup.setEnabled(getApplication(), on) }
    fun driveDisconnect() { DriveBackup.disconnect(getApplication()); toast("Drive bağlantısı kaldırıldı.") }

    // ------------------------------------------------------------------ Yarım kalan analiz
    var pending by mutableStateOf(Partial.pending(app))
    var askResume by mutableStateOf<Partial.Pending?>(null)
    fun refreshPending() { val app = getApplication<Application>(); viewModelScope.launch(Dispatchers.IO) { val l = Partial.pending(app); withContext(Dispatchers.Main) { pending = l } } }
    fun resumePending(p: Partial.Pending) {
        askResume = null
        if (needModel() || busy()) return
        error = null; screen = Screen.Scanning
        val src = if (p.uri == "media") Engine.albumSource(p.sel) else Engine.folderSource(Uri.parse(p.uri), p.sel)
        Engine.start(getApplication(), p.uri, p.sel, src, resume = true)
    }
    fun restartPending(p: Partial.Pending) {
        askResume = null
        if (p.uri == "media") scanAlbums(p.sel) else scan(Uri.parse(p.uri), p.sel)
    }
    fun discardPending(p: Partial.Pending) {
        askResume = null
        val app = getApplication<Application>()
        Partial.clear(app, p.key)
        Store.thumbDir(app).listFiles()?.filter { it.name.startsWith(p.key + "_f") }?.forEach { it.delete() }
        pending = Partial.pending(app)
    }

    // ------------------------------------------------------------------ Kaydedilen yüzler (ana ekranın en altı)
    var savedFaces by mutableStateOf(SavedFaces.load(app))
    var pickForSaved by mutableStateOf(false)      // true: yüz seçme ekranında seçilen yüz "kaydedilen yüzler"e eklenir
    private fun persistFaces(l: List<SavedFace>) { savedFaces = l; val app = getApplication<Application>(); viewModelScope.launch(Dispatchers.IO) { SavedFaces.save(app, l) } }
    fun addSavedFace(thumb: String, embs: List<FloatArray>, name: String, force: Boolean = false) {
        if (embs.isEmpty() || !File(thumb).exists()) { toast("Bu yüz eklenemedi."); return }
        val dup = !force && savedFaces.any { s -> s.embs.any { a -> embs.any { b -> a.size == b.size && dot(a, b) > 0.70f } } }
        if (dup) { toast("Bu kişi zaten kaydedilen yüzlerde var."); return }
        try { persistFaces(savedFaces + SavedFaces.create(getApplication(), thumb, embs, name)); toast("Kaydedilen yüzlere eklendi.") }
        catch (e: Exception) { toast("Eklenemedi: ${e.message}") }
    }
    fun addSavedFromEntry(f: FaceEntry) {
        val c = f.members.firstOrNull()?.second ?: return
        addSavedFace(f.thumb, listOf(c.centroid) + c.reps.take(8), f.name)
    }
    fun renameSavedFace(f: SavedFace, name: String) { f.name = name.trim(); persistFaces(savedFaces.toList()) }
    fun removeSavedFace(f: SavedFace) { SavedFaces.deleteFile(getApplication(), f); persistFaces(savedFaces.filter { it.id != f.id }) }
    fun moveSavedFace(from: Int, to: Int) {
        if (from !in savedFaces.indices || to !in savedFaces.indices || from == to) return
        val l = savedFaces.toMutableList(); val x = l.removeAt(from); l.add(to, x); persistFaces(l)
    }
    fun addFromFound() { pickForSaved = true; photoChoices = emptyList(); screen = Screen.PickFace }
    /** Kaydedilen yüzü aranacak kişi yapar ve albüm seçimine geçer. */
    fun searchWithSaved(f: SavedFace) {
        refChoice = FaceChoice(SavedFaces.path(getApplication(), f), f.embs, f.name.ifBlank { "Yüz" }, f.name)
        personName = f.name; searchMode = false; searchPickOnly = false; personMode = true; pickForSaved = false
        loadAlbums()
    }
    var personFromGallery = false   // Galeri > Yüz ile başlatıldı: Geri, galeriye döner
    /** Galeri "Yüz" düğmesi: seçilen yüzü seçili klasörlerde arar (Sayı Seç doluysa her klasörün en yeni N fotoğrafı). */
    fun startGalleryFaceSearch(thumb: String, embs: List<FloatArray>, name: String, folderIds: List<Long>) {
        if (embs.isEmpty()) { toast("Bu yüzün verisi bulunamadı"); return }
        if (needModel() || busy()) return
        refChoice = FaceChoice(thumb, embs, name.ifBlank { "Yüz" }, name)
        personName = name; searchMode = false; searchPickOnly = false; personMode = true; pickForSaved = false
        personFromGallery = true
        error = null; screen = Screen.Person; FoundGroup.clear()
        PersonEngine.start(getApplication(), embs, thumb, name, folderIds.map { it.toString() } + (if (limitN() > 0) listOf("~N${limitN()}") else emptyList()))
    }
    var error by mutableStateOf<String?>(null)
    var loadingDirs by mutableStateOf(false)
    var rootUri by mutableStateOf<Uri?>(null)
    var subDirs by mutableStateOf<List<String>>(emptyList())
    var chosen by mutableStateOf<Set<String>>(emptySet())
    var modelReady by mutableStateOf(File(app.filesDir, "model.onnx").exists() ||
        File(app.filesDir, "arcface.onnx").let { it.exists() && it.length() > 100_000_000L } ||
        try { app.assets.open("arcface.onnx").close(); true } catch (e: Exception) { false })
    var modelMsg by mutableStateOf<String?>(null)
    var downloading by mutableStateOf(false)
    var askModel by mutableStateOf(false)      // yeniden kurulumda kayıtlı model bulunamadı: dosyadan seç mi, indir mi?
    var modelProgress by mutableStateOf(0f)
    var albums by mutableStateOf<List<Album>>(emptyList())
    var chosenAlbums by mutableStateOf<Set<String>>(emptySet())
    var autoThr by mutableStateOf(0.25f)           // 0.70 = otomatik birleştirme kapalı
    var startThr by mutableStateOf(app.getSharedPreferences("app", 0).getFloat("startThr", 0.25f))   // başlangıç benzerlik eşiği (Ayarlar)
    fun saveStartThr(v: Float) { startThr = v; getApplication<Application>().getSharedPreferences("app", 0).edit().putFloat("startThr", v).apply() }
    fun clearSaved() {
        savedSel = emptySet()
        val c = getApplication<Application>()
        File(c.filesDir, "results").deleteRecursively(); File(c.filesDir, "thumbs").deleteRecursively(); saved = emptyList(); current = null
    }
    var picks by mutableStateOf<Set<Int>>(emptySet())
    fun shown(): List<Cluster> {
        val all = current?.clusters.orEmpty().filter { it.photos.isNotEmpty() }
        val faces = all.filter { !it.obj }; val objs = all.filter { it.obj }.sortedByDescending { it.photos.size }
        return (if (autoThr >= 0.70f) faces else autoMerge(faces, autoThr)) + objs   // nesne grupları birleştirmeye girmez
    }
    fun mergePicked() {
        val s = shown(); val sel = s.filter { it.id in picks && !it.obj }
        if (sel.size < 2) return
        val ids = sel.map { it.id }.toSet()
        commit(s.filter { it.id !in ids } + sel.reduce { a, b -> mergeTwo(a, b) })
    }
    fun commit(list: List<Cluster>) {
        val r = current ?: return
        val nr = Result(r.uri, r.name, r.total, r.time, list.sortedByDescending { it.photos.size }, r.sel, r.durSec, r.label)
        current = nr; autoThr = 0.70f; picks = emptySet()
        if (nr.clusters.isNotEmpty()) { Store.save(getApplication(), nr); saved = Store.loadAll(getApplication()) }
    }
    /** Sonuç ekranındaki mevcut görünümü (benzerlik eşiğiyle birleşmiş gruplar, adlar, silinen/taşınan fotoğraflar) kalıcı kaydeder.
     *  Sonradan ana ekrandaki "Kayıtlı sonuçlar"dan açılınca yeniden analiz gerekmez. */
    fun saveNow() {
        if (current == null) return
        val list = shown()
        if (list.isEmpty()) { toast("Kaydedilecek sonuç yok"); return }
        commit(list); rev++
        toast("Kaydedildi. Ana ekranda “Kayıtlı sonuçlar”dan tekrar açabilirsin; yeniden analiz gerekmez.")
    }
    private val IMG = MediaStore.Images.Media.EXTERNAL_CONTENT_URI

    // ------------------------------------------------------------------ Foto işlemleri
    var photoList by mutableStateOf<List<String>>(emptyList())
    var photoSel by mutableStateOf<Set<String>>(emptySet())
    /** Izgaradan görüntüleyiciye geçerken kaydırma konumu (ilk görünen öğe, ofset); geri dönünce bir kez uygulanır. */
    var photosScroll: Pair<Int, Int>? = null
    var viewIndex by mutableStateOf(0)
    var cropUri by mutableStateOf<String?>(null)
    var targets by mutableStateOf<List<Target>>(emptyList())
    var rev by mutableStateOf(0)
    var viewingEdited by mutableStateOf(false)
    var enhancing by mutableStateOf(false)
    var enhanceDone by mutableStateOf(0)
    var enhanceTotal by mutableStateOf(0)
    var pendingSender by mutableStateOf<IntentSender?>(null)
    /** Taşıma ilerlemesi: ekranın köşesinde hedef klasör adı, aşama ve 0-100 yüzde gösterilir. */
    var moveInfo by mutableStateOf<MoveInfo?>(null)
    private var pendingOp: (() -> Unit)? = null
    // ---- Nesne arama (ana ekrandaki arama kutusu → albüm seç → tara)
    var searchText by mutableStateOf("")
    var searchMode by mutableStateOf(false)
    var searchPickOnly by mutableStateOf(false)   // "Albüm Seç": albümler yalnızca seçilir, arama sonra küçük "Ara" ile başlar
    var searchPicked by mutableStateOf(false)     // nesne araması için albümler seçilmiş
    var fromSearch by mutableStateOf(false)

    // ---- Kişiye göre arama (ana ekran → yüz seç → albüm seç → tara → adı düzenle → Kaydet)
    var personMode by mutableStateOf(false)
    var fromPerson by mutableStateOf(false)
    var celebBack by mutableStateOf(false)   // fotoğraflar Ünlüler ekranından açıldı (geri tuşu oraya döner)
    var fromFaces by mutableStateOf(false)   // fotoğraflar "Bulunan yüzler" ekranından açıldı: geri tuşu oraya döner
    var refChoice by mutableStateOf<FaceChoice?>(null)
    var personName by mutableStateOf("")
    var photoChoices by mutableStateOf<List<FaceChoice>>(emptyList())
    var detecting by mutableStateOf(false)

    /** Önceki analizlerde bulunan kişiler (yüz vektörü olan, fotoğrafı kalmış gruplar). */
    fun savedPeople(): List<FaceChoice> {
        val out = ArrayList<FaceChoice>()
        for (r in saved) {
            val people = r.clusters.filter { !it.obj && it.photos.isNotEmpty() && it.centroid.isNotEmpty() }
            for ((i, c) in people.withIndex()) {
                if (c.thumb.isBlank() || !File(c.thumb).exists()) continue
                val nm = c.tag.ifBlank { "" }
                out.add(FaceChoice(c.thumb, listOf(c.centroid) + c.reps, if (nm.isNotBlank()) nm else letterCode(i), nm, c, r))
            }
        }
        return out
    }

    /** Seçilen fotoğraftaki yüzleri bulur; ekranda aranacak yüz seçtirilir. */
    var galleryChoices by mutableStateOf<List<FaceChoice>>(emptyList())   // Galeri > Yüz > "Galeri" sekmesi: seçilen fotoğraftaki yüzler
    fun detectFacesIn(uri: Uri, toPickScreen: Boolean = true) {
        if (!modelReady) { error = "Yüz tanıma modeli henüz hazır değil, indirme bitene kadar bekleyin."; return }
        if (detecting) return
        detecting = true; error = null
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            var an: Analyzer? = null
            try {
                val a = Analyzer(app, 1); an = a
                val bmp = a.decode(app, uri) ?: throw Exception("Fotoğraf çözülemedi.")
                val fs = a.faces(bmp).sortedByDescending { it.area }
                if (fs.isEmpty()) throw Exception("Bu fotoğrafta yüz bulunamadı. Yüzü net görünen başka bir fotoğraf seçin.")
                val dir = File(app.filesDir, "refs").apply { deleteRecursively(); mkdirs() }
                val stamp = System.currentTimeMillis()
                val list = fs.mapIndexed { i, f ->
                    val p = File(dir, "r${stamp}_$i.jpg")
                    p.outputStream().use { Bitmap.createScaledBitmap(f.crop, 160, 160, true).compress(Bitmap.CompressFormat.JPEG, 90, it) }
                    FaceChoice(p.absolutePath, listOf(f.emb), "Yüz ${i + 1}")
                }
                withContext(Dispatchers.Main) { if (toPickScreen) { photoChoices = list; screen = Screen.PickFace } else galleryChoices = list; detecting = false }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { error = e.message ?: e.javaClass.simpleName; detecting = false }
            } finally { try { an?.close() } catch (e: Exception) { } }
        }
    }

    /** Kayıtlı kişinin ismini değiştirir (grubun etiketi olarak saklanır). */
    fun renamePerson(c: FaceChoice, newName: String) {
        val cl = c.cluster ?: return; val r = c.result ?: return
        renameMembers(listOf(r to cl), newName)
        if (refChoice?.thumb == c.thumb && newName.isNotBlank()) personName = newName.trim()
    }

    /** Aynı kişiye ait tüm grupların (farklı analizlerdeki) etiketini değiştirir ve kaydeder. */
    fun renameMembers(members: List<Pair<Result, Cluster>>, newName: String) {
        val t = newName.trim()
        val results = LinkedHashSet<Result>()
        for ((r, c) in members) {
            c.tag = t; results.add(r)
            // Açık duran sonuç aynı kayıtsa onun kopyasını da güncelle (sonradan eski etiketle üzerine yazılmasın)
            current?.takeIf { it.key == r.key }?.clusters?.firstOrNull { it.id == c.id }?.tag = t
        }
        results.forEach { Store.save(getApplication(), it) }
        saved = Store.loadAll(getApplication())
        rev++
    }

    // ---- Bulunan kişiye dokununca: kişinin fotoğrafları açılır, seçilen fotoğraftan baş (saç + boyun üstü) kırpılıp en yüksek kalitede netleştirilir ve Kaydedilen yüzler'e eklenir
    var facePickChoice by mutableStateOf<FaceChoice?>(null)
    var faceBusy by mutableStateOf(false)

    /** Kaydedilen yüzler akışında, kişinin eski küçük resmini olduğu gibi ekler. */
    fun addFacePlain() {
        val c = facePickChoice ?: return
        pickForSaved = false; facePickChoice = null
        addSavedFace(c.thumb, c.embs, c.name); screen = Screen.Main
    }

    fun addHeadFromPhoto(photo: String) {
        val c = facePickChoice ?: return
        if (faceBusy) return
        if (!modelReady) { error = "Yüz tanıma modeli henüz hazır değil, indirme bitene kadar bekleyin."; return }
        faceBusy = true
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>(); var an: Analyzer? = null
            try {
                val a = Analyzer(app, 1); an = a
                val u = Uri.parse(photo)
                val small = a.decode(app, u) ?: throw Exception("Fotoğraf çözülemedi.")
                val fs = a.faces(small)
                if (fs.isEmpty()) throw Exception("Bu fotoğrafta yüz bulunamadı.")
                fun sc(f: FaceData) = c.embs.maxOfOrNull { e -> if (e.size == f.emb.size) dot(e, f.emb) else -1f } ?: -1f
                val best = fs.maxByOrNull { sc(it) }!!
                if (sc(best) < 0.25f) throw Exception("Bu fotoğrafta bu kişi bulunamadı. Başka bir fotoğraf dene.")
                // Kaliteyi korumak için kırpma, küçültülmüş kopyadan değil orijinal çözünürlükten yapılır
                val full = android.graphics.ImageDecoder.decodeBitmap(android.graphics.ImageDecoder.createSource(app.contentResolver, u)) { dec, info, _ ->
                    dec.allocator = android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE
                    val m = maxOf(info.size.width, info.size.height)
                    if (m > 4096) dec.setTargetSampleSize(Math.ceil(m / 4096.0).toInt())
                }
                val k = full.width.toFloat() / small.width
                val b = best.box
                val fw = b.width() * k; val fh = b.height() * k
                val cx = (b.left + b.right) / 2f * k
                // Saç dahil tepe (yüzün ~0.75 katı yukarı) ile boyun (çene altı ~0.55 kat) arası; genişlik yüzün ~2 katı
                val l = (cx - fw).toInt().coerceAtLeast(0); val r = (cx + fw).toInt().coerceAtMost(full.width)
                val t = (b.top * k - 0.75f * fh).toInt().coerceAtLeast(0); val bt = (b.bottom * k + 0.55f * fh).toInt().coerceAtMost(full.height)
                if (r - l < 32 || bt - t < 32) throw Exception("Yüz çok küçük.")
                val head = Bitmap.createBitmap(full, l, t, r - l, bt - t)
                val out = Enhancer.enhanceCrop(head)
                val tmp = File(app.cacheDir, "head_${System.currentTimeMillis()}.jpg")
                tmp.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 97, it) }
                val embs = listOf(best.emb) + c.embs.take(8)
                withContext(Dispatchers.Main) {
                    addSavedFace(tmp.absolutePath, embs, c.name, force = true)
                    tmp.delete(); faceBusy = false; pickForSaved = false; facePickChoice = null; screen = Screen.Main
                }
            } catch (e: Throwable) {
                withContext(Dispatchers.Main) { faceBusy = false; toast(e.message ?: e.javaClass.simpleName) }
            } finally { try { an?.close() } catch (e: Exception) { } }
        }
    }

    fun chooseRef(c: FaceChoice) {
        if (pickForSaved && c.cluster != null && c.cluster.photos.isNotEmpty()) { facePickChoice = c; screen = Screen.PickFacePhoto; return }
        if (pickForSaved) {
            pickForSaved = false
            addSavedFace(c.thumb, c.embs, c.name); screen = Screen.Main; return
        }
        refChoice = c
        if (c.name.isNotBlank()) personName = c.name
        screen = Screen.Main
    }

    fun startPersonSearch() {
        personFromGallery = false
        val ref = refChoice ?: return
        if (needModel() || busy()) return
        if (chosenAlbums.isEmpty()) return
        error = null; screen = Screen.Person; FoundGroup.clear()
        PersonEngine.start(getApplication(), ref.embs, ref.thumb, personName, chosenAlbums.toList() + (if (limitN() > 0) listOf("~N${limitN()}") else emptyList()))
    }

    fun openPersonResults(index: Int = -1, list: List<String>? = null) {
        fromFaces = false; selected = null; viewingEdited = false; fromSearch = false; fromPerson = true; saveMode = false
        photoList = list ?: PersonEngine.hits(); photoSel = emptySet()
        if (index >= 0 && index < photoList.size) { viewIndex = index; screen = Screen.Viewer } else screen = Screen.Photos
    }

    /** Kaydet: galeride kişinin adıyla albüm (Pictures/<ad>/) oluşturur ve bulunan tüm fotoğrafları oraya taşır. */
    fun savePersonAlbum(name: String) {
        val n = name.replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
        if (n.isEmpty()) { toast("Albüm adı yazın."); return }
        val list = PersonEngine.hits()
        if (list.isEmpty()) { toast("Taşınacak fotoğraf yok."); return }
        movePhotos(list, "Pictures/$n/")
    }
    // ---- Kaydet akışı: bulunanlar hepsi seçili gelir → istemediğini çıkar → Devam → albüm seç / yeni albüm
    var saveMode by mutableStateOf(false)
    fun beginSave(person: Boolean) {
        val list = if (person) PersonEngine.hits() else SearchEngine.hits.toList()
        if (list.isEmpty()) { toast("Kaydedilecek fotoğraf yok."); return }
        fromFaces = false; selected = null; viewingEdited = false; fromPerson = person; fromSearch = !person
        photoList = list; photoSel = list.toSet(); saveMode = true; screen = Screen.Photos
    }
    fun saveSuggestion(): String = (if (fromPerson) personName.ifBlank { PersonEngine.name } else SearchEngine.query).replace(Regex("[\\\\/:*?\"<>|]"), "").trim()

    fun startSearch() {
        if (SearchEngine.running) { error = "Zaten bir arama sürüyor."; screen = Screen.Search; return }
        if (PersonEngine.running) { error = "Bir kişi araması sürüyor; bitince arama yapabilirsiniz."; screen = Screen.Person; return }
        if (Engine.running) { error = "Bir analiz sürüyor; bitince arama yapabilirsiniz."; screen = Screen.Scanning; return }
        if (searchText.isBlank() || chosenAlbums.isEmpty()) return
        error = null; screen = Screen.Search; FoundGroup.clear()
        SearchEngine.start(getApplication(), searchText, chosenAlbums.toList() + (if (limitN() > 0) listOf("~N${limitN()}") else emptyList()))
    }
    fun openSearchResults(index: Int = -1, list: List<String>? = null) {
        fromFaces = false; selected = null; viewingEdited = false; fromSearch = true; fromPerson = false; saveMode = false
        photoList = list ?: SearchEngine.hits.toList(); photoSel = emptySet()
        if (index >= 0 && index < photoList.size) { viewIndex = index; screen = Screen.Viewer } else screen = Screen.Photos
    }
    fun openCluster(c: Cluster) { fromFaces = false; saveMode = false; fromSearch = false; fromPerson = false; selected = c; viewingEdited = false; photoList = c.photos.toList(); photoSel = emptySet(); screen = Screen.Photos }
    fun openEdited(c: Cluster) { fromFaces = false; saveMode = false; fromSearch = false; fromPerson = false; selected = c; viewingEdited = true; photoList = c.edited.toList(); photoSel = emptySet(); screen = Screen.Photos }
    fun setTag(t: String) {
        val tag = t.trim().uppercase(java.util.Locale("tr"))
        selected?.let { sel ->
            sel.tag = tag
            current?.clusters?.forEach { b -> if (b.photos.isNotEmpty() && b.photos.all { it in sel.photos }) b.tag = tag }
        }
        persist(); rev++
    }
    fun togglePhoto(u: String) { photoSel = if (u in photoSel) photoSel - u else photoSel + u }
    /** "Bulunan yüzler"de yüze dokununca: o kişinin gerçek fotoğrafını tam ekran açar; kaydırınca kişinin diğer fotoğrafları gelir. */
    fun openFace(f: FaceEntry) {
        val rep = f.members.first().second
        val all = LinkedHashSet<String>(); all.addAll(rep.photos); f.members.forEach { all.addAll(it.second.photos) }
        if (all.isEmpty()) { toast("Bu kişinin fotoğrafı bulunamadı"); return }
        // Yüze dokununca o kişinin TÜM fotoğrafları (tüm analizlerden) ızgara olarak açılır; geri tuşu bulunan yüzlere döner
        saveMode = false; fromSearch = false; fromPerson = false; viewingEdited = false; fromFaces = true; celebBack = false
        selected = rep; photoList = all.toList(); photoSel = emptySet(); viewIndex = 0; screen = Screen.Photos
    }
    /** Kişiyi Bulunan yüzler panosundan Ünlüler bölümüne taşır. */
    fun moveToCelebs(f: FaceEntry, name: String) {
        val rep = f.members.firstOrNull()?.second ?: return
        val photos = LinkedHashSet<String>(); f.members.forEach { photos.addAll(it.second.photos) }
        val nm = name.trim().ifBlank { f.name }
        val added = Celebs.add(getApplication(), nm, f.thumb, rep.centroid, photos)
        toast(if (added) "Ünlüler bölümüne taşındı" else "Bu kişi zaten Ünlüler'de; fotoğrafları ona eklendi")
        rev++
    }
    /** Ünlüye dokununca: kaydedilen + sonradan eşleşen tüm fotoğrafları ızgara olarak açar. */
    fun openCeleb(c: Celeb) {
        val all = Celebs.photosOf(c, saved)
        if (all.isEmpty()) { toast("Bu ünlünün fotoğrafı bulunamadı"); return }
        saveMode = false; fromSearch = false; fromPerson = false; viewingEdited = false; fromFaces = true; celebBack = true
        selected = null; photoList = all; photoSel = emptySet(); viewIndex = 0; screen = Screen.Photos
    }
    fun openViewer(i: Int) { viewIndex = i; screen = Screen.Viewer }
    fun toast(m: String) { Toast.makeText(getApplication(), m, Toast.LENGTH_LONG).show() }
    fun senderResult(ok: Boolean) {
        val op = pendingOp; pendingOp = null
        if (ok) op?.invoke() else { moveInfo = null; toast("İşlem iptal edildi.") }
    }
    private fun setMove(f: (MoveInfo) -> MoveInfo) { moveInfo = moveInfo?.let(f) }

    private fun sortKey(n: String) = n.trimStart { !it.isLetterOrDigit() }.ifEmpty { n }
    private val col: java.text.Collator = java.text.Collator.getInstance(java.util.Locale("tr", "TR")).apply { strength = java.text.Collator.PRIMARY }
    fun loadTargets() {
        viewModelScope.launch(Dispatchers.IO) {
            val m = LinkedHashMap<String, Int>(); val cov = HashMap<String, Long>()
            try {
                getApplication<Application>().contentResolver.query(IMG,
                    arrayOf(MediaStore.MediaColumns.RELATIVE_PATH, MediaStore.Images.Media._ID), null, null,
                    "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
                    while (c.moveToNext()) { val p = c.getString(0) ?: continue; m[p] = (m[p] ?: 0) + 1; cov.getOrPut(p) { c.getLong(1) } }
                }
            } catch (e: Exception) { }
            // Android, görselleri sadece DCIM/ ve Pictures/ altına taşımaya izin verir
            val list = m.filterKeys { it.startsWith("DCIM/") || it.startsWith("Pictures/") }
                .map { (p, n) -> Target(p.trimEnd('/').substringAfterLast('/'), p, n, ContentUris.withAppendedId(IMG, cov[p] ?: 0L)) }
                .sortedWith(java.util.Comparator { x, y -> col.compare(sortKey(x.name), sortKey(y.name)) })   // A'dan Z'ye (Türkçe sıralama; baştaki emoji / simgeler yok sayılır)
            withContext(Dispatchers.Main) { targets = list }
        }
    }

    /** Her dosyada op çalıştırır; izin gerekiyorsa (Android 10) sistem penceresini açıp kaldığı yerden devam eder. */
    private fun forEachWithAccess(list: List<Uri>, op: (Uri) -> Unit, done: (Int, Int) -> Unit, ok0: Int = 0, bad0: Int = 0, progress: ((Int) -> Unit)? = null, batched: Boolean = false) {
        viewModelScope.launch(Dispatchers.IO) {
            var ok = ok0; var bad = bad0
            for ((i, u) in list.withIndex()) {
                try { op(u); ok++; progress?.invoke(ok + bad) }
                catch (e: RecoverableSecurityException) {
                    val rest = list.drop(i); val okNow = ok; val badNow = bad
                    if (Build.VERSION.SDK_INT >= 30) {
                        // Android 11+: dosya başına izin sorulmaz. Kalan TÜM dosyalar için tek bir izin penceresi açılır (en fazla bir kez);
                        // o da yetmezse kalanlar "taşınamadı" sayılır, tekrar tekrar sorulmaz.
                        if (!batched) {
                            val sender = try { MediaStore.createWriteRequest(getApplication<Application>().contentResolver, rest).intentSender } catch (x: Exception) { null }
                            if (sender != null) {
                                withContext(Dispatchers.Main) {
                                    pendingOp = { forEachWithAccess(rest, op, done, okNow, badNow, progress, batched = true) }
                                    pendingSender = sender
                                }
                                return@launch
                            }
                        }
                        bad++; progress?.invoke(ok + bad); continue
                    }
                    // Android 10: sistem yalnızca dosya başına izin verdirebilir
                    withContext(Dispatchers.Main) {
                        pendingOp = { forEachWithAccess(rest, op, done, okNow, badNow, progress, batched) }
                        pendingSender = e.userAction.actionIntent.intentSender
                    }
                    return@launch
                } catch (e: Exception) { bad++; progress?.invoke(ok + bad) }
            }
            withContext(Dispatchers.Main) { done(ok, bad) }
        }
    }

    fun movePhotos(uris: List<String>, rel: String, fromGallery: Boolean = false, onMoved: ((Set<String>) -> Unit)? = null) {
        if (uris.isEmpty()) return
        val cr = getApplication<Application>().contentResolver; val list = uris.map { Uri.parse(it) }
        val dest = if (rel.endsWith("/")) rel else "$rel/"
        // Kişi/yüz grubunun içinden (Kişiler ekranı ya da "Bulunan yüzler") taşınan fotoğraflar kayıtlı sonuçlardan da çıkar.
        // Arama / kişiye göre arama sonuçları ve Ünlüler ekranı kendi listesini yönetir, bunlara dokunulmaz.
        val fromBoard = !fromGallery && !fromSearch && !fromPerson && !celebBack
        val moved = java.util.Collections.synchronizedSet(HashSet<String>())
        val total = list.size
        val folder = dest.trimEnd('/').substringAfterLast('/')
        moveInfo = MoveInfo(folder, dest, total, 0, 0, MoveStage.WAITING, uris.first())   // izin penceresi açıkken de köşede görünür
        val run = {
            setMove { it.copy(stage = MoveStage.MOVING) }
            forEachWithAccess(list, { u ->
                val v = ContentValues().apply { put(MediaStore.MediaColumns.RELATIVE_PATH, dest) }
                if (cr.update(u, v, null, null) == 0) throw IllegalStateException("update=0")
                moved.add(u.toString())
            }, { ok, bad ->
                setMove { it.copy(done = ok + bad, bad = bad, stage = MoveStage.DONE) }
                viewModelScope.launch { delay(3000); if (moveInfo?.stage == MoveStage.DONE) moveInfo = null }
                toast(if (bad == 0) "$ok fotoğraf taşındı" else "$ok taşındı, $bad taşınamadı")
                photoSel = emptySet()
                if (moved.isNotEmpty()) onMoved?.invoke(moved.toSet())
                if (fromBoard && moved.isNotEmpty()) {
                    removeMoved(moved.toSet())
                    // Grubun hiç fotoğrafı kalmadı: geldiği ekrana dön (Bulunan yüzler panosu ya da Kişiler ekranı); grup listeden kalkar
                    if (photoList.isEmpty()) screen = if (fromFaces) Screen.Faces else Screen.Clusters
                }
                if (saveMode) { saveMode = false; screen = if (fromPerson) Screen.Person else Screen.Search }
            }, progress = { n -> setMove { it.copy(done = n) } })
        }
        // Medya yönetimi izni varsa sistem penceresi hiç çıkmaz; yoksa (Android 11 ya da izin verilmemiş) eski yol
        if (Build.VERSION.SDK_INT >= 30) { pendingOp = run; pendingSender = MediaStore.createWriteRequest(cr, list).intentSender }
        else run()
    }

    /** Galeri: klasörü yeniden adlandırır = klasördeki tüm fotoğrafları aynı üst dizinde yeni adlı klasöre taşır.
     *  Android yalnızca DCIM/ ve Pictures/ altındaki klasörlere izin verir. İzin penceresi (Android 11+) bir kez çıkar. */
    fun renameGalleryFolder(f: GalleryFolder, newName: String) {
        val name = newName.trim()
        if (name.isEmpty() || name.any { it in "/\\:*?\"<>|" } || name == "." || name == "..") { toast("Geçersiz klasör adı"); return }
        if (name == f.name) return
        val rel = f.path.trimEnd('/')
        if (!(rel.startsWith("DCIM/") || rel.startsWith("Pictures/"))) {
            toast("Bu klasör yeniden adlandırılamaz: Android yalnızca DCIM ve Pictures altındaki klasörlere izin verir."); return
        }
        val destTrim = rel.substringBeforeLast('/') + "/" + name
        if (GalleryState.folders.any { it.path.trimEnd('/').equals(destTrim, ignoreCase = true) }) { toast("Bu adda bir klasör zaten var"); return }
        val dest = "$destTrim/"
        val cr = getApplication<Application>().contentResolver
        viewModelScope.launch(Dispatchers.IO) {
            val list = ArrayList<Uri>()
            try {
                cr.query(IMG, arrayOf(MediaStore.Images.Media._ID), "${MediaStore.Images.Media.BUCKET_ID} = ?", arrayOf(f.id.toString()), null)?.use { c ->
                    while (c.moveToNext()) list.add(ContentUris.withAppendedId(IMG, c.getLong(0)))
                }
            } catch (e: Exception) { }
            if (list.isEmpty()) { withContext(Dispatchers.Main) { toast("Klasörde fotoğraf bulunamadı") }; return@launch }
            withContext(Dispatchers.Main) {
                val run = {
                    forEachWithAccess(list, { u ->
                        val v = ContentValues().apply { put(MediaStore.MediaColumns.RELATIVE_PATH, dest) }
                        if (cr.update(u, v, null, null) == 0) throw IllegalStateException("update=0")
                    }, { ok, bad ->
                        if (bad == 0) RecentOps.add(getApplication(), "Ad değiştirildi: ${f.name} → $name")
                        toast(if (bad == 0) "Klasör \"$name\" olarak yeniden adlandırıldı" else "$ok fotoğraf taşındı, $bad taşınamadı")
                        viewModelScope.launch { GalleryState.loadFolders(getApplication()) }
                    })
                }
                if (Build.VERSION.SDK_INT >= 30) {
                    try { pendingOp = run; pendingSender = MediaStore.createWriteRequest(cr, list).intentSender }
                    catch (e: Exception) { pendingOp = null; toast("İzin penceresi açılamadı") }
                } else run()
            }
        }
    }

    /** Taşınan fotoğrafları tüm kayıtlı sonuçlardaki gruplardan çıkarır. Fotoğrafı kalmayan grup (yüz önizlemesi) Kişiler ekranından
     *  ve "Bulunan yüzler"den kalkar; bir kayıtta hiç grup kalmadıysa o kayıt "Kayıtlı sonuçlar"dan da silinir. En az bir grup kaldıysa kayıt kalan gruplarla durur. */
    private fun removeMoved(uris: Set<String>) {
        photoList = photoList.filter { it !in uris }
        current?.clusters?.forEach { it.photos.removeAll(uris); it.edited.removeAll(uris) }
        val app = getApplication<Application>(); val snap = saved
        viewModelScope.launch(Dispatchers.IO) {
            val dead = HashSet<String>()
            for (r in snap) {
                var changed = false
                for (c in r.clusters) { if (c.photos.removeAll(uris)) changed = true; if (c.edited.removeAll(uris)) changed = true }
                if (!changed) continue
                try {
                    if (r.clusters.none { it.photos.isNotEmpty() }) { Store.delete(app, r); dead.add(r.key) }   // içi boşaldı: kayıt silinir
                    else Store.save(app, r)
                } catch (e: Exception) { }
            }
            val all = Store.loadAll(app)
            withContext(Dispatchers.Main) {
                saved = all
                if (dead.isNotEmpty()) {
                    Engine.setFound(app, Engine.found - dead)
                    savedSel = savedSel - dead
                }
                // Açık sonuç (henüz kaydedilmemiş olsa bile) tamamen boşaldıysa Kişiler ekranında boş sayfa bırakma
                if (current?.let { it.key in dead || it.clusters.none { c -> c.photos.isNotEmpty() } } == true) {
                    current = null; if (screen == Screen.Clusters) screen = Screen.Main
                }
                rev++
            }
        }
    }

    fun deletePhotos(uris: List<String>) {
        if (uris.isEmpty()) return
        val cr = getApplication<Application>().contentResolver; val list = uris.map { Uri.parse(it) }
        if (Build.VERSION.SDK_INT >= 30) {
            pendingOp = { purge(uris.toSet()); toast("${uris.size} fotoğraf silindi") }
            pendingSender = MediaStore.createDeleteRequest(cr, list).intentSender
        } else {
            val gone = HashSet<String>()
            forEachWithAccess(list, { u -> if (cr.delete(u, null, null) > 0) gone.add(u.toString()) },
                { _, _ -> purge(gone); toast("${gone.size} fotoğraf silindi") })
        }
    }

    /** Galeri: seçili klasörlerin TÜM fotoğraf ve videolarını + tek tek seçilen öğeleri geri dönüşüm kutusuna atar (Android 11+, tek sistem onay penceresi; Android 10'da kalıcı siler). */
    fun deleteGallerySelection(folderIds: Set<Long>, photoUris: Set<String>) {
        if (folderIds.isEmpty() && photoUris.isEmpty()) return
        val app = getApplication<Application>(); val cr = app.contentResolver
        val opNames = GalleryState.selectedFolderIds().mapNotNull { id -> GalleryState.folders.firstOrNull { it.id == id }?.name }   // Son İşlemler için
        viewModelScope.launch(Dispatchers.IO) {
            val all = LinkedHashSet<String>(photoUris)
            if (folderIds.isNotEmpty()) {
                val ids = folderIds.joinToString(",")
                val vidBase = MediaStore.Video.Media.EXTERNAL_CONTENT_URI
                for (base in listOf(IMG, vidBase)) {
                    try {
                        cr.query(base, arrayOf(MediaStore.MediaColumns._ID), "${MediaStore.MediaColumns.BUCKET_ID} IN ($ids)", null, null)?.use { c ->
                            while (c.moveToNext()) all.add(ContentUris.withAppendedId(base, c.getLong(0)).toString())
                        }
                    } catch (e: Exception) { }
                }
            }
            if (all.isEmpty()) { withContext(Dispatchers.Main) { toast("Silinecek öğe bulunamadı") }; return@launch }
            val list = all.map { Uri.parse(it) }
            withContext(Dispatchers.Main) {
                val finish = { n: Int ->
                    GalleryState.clearAllSelection()
                    val ad = RecentOps.names(opNames)
                    RecentOps.add(app, (if (Build.VERSION.SDK_INT >= 30) "Geri dönüşüme atıldı: " else "Silindi: ") + (if (ad.isNotEmpty()) "$ad • " else "") + "$n öğe")
                    toast(if (Build.VERSION.SDK_INT >= 30) "$n öğe geri dönüşüm kutusuna atıldı" else "$n öğe silindi")
                    viewModelScope.launch { GalleryState.loadFolders(app) }
                }
                if (Build.VERSION.SDK_INT >= 30) {
                    try {
                        pendingOp = { purge(all); finish(all.size) }
                        pendingSender = MediaStore.createTrashRequest(cr, list, true).intentSender   // silmez: geri dönüşüm kutusuna atar
                    } catch (e: Exception) { pendingOp = null; toast("İzin penceresi açılamadı") }
                } else {
                    val gone = HashSet<String>()
                    forEachWithAccess(list, { u -> if (cr.delete(u, null, null) > 0) gone.add(u.toString()) },
                        { _, _ -> purge(gone); finish(gone.size) })
                }
            }
        }
    }

    private fun persist() {
        val r = current ?: return
        if (r.clusters.isNotEmpty()) { Store.save(getApplication(), r); saved = Store.loadAll(getApplication()) }
    }

    private fun purge(uris: Set<String>) {
        try { EditedStore.remove(getApplication(), uris); editedStandalone = EditedStore.load(getApplication()) } catch (e: Exception) { }
        current?.clusters?.forEach { it.photos.removeAll(uris); it.edited.removeAll(uris) }
        selected?.let { it.photos.removeAll(uris); it.edited.removeAll(uris) }
        photoList = photoList.filter { it !in uris }; photoSel = photoSel - uris
        SearchEngine.hits.removeAll { it in uris }
        GalleryState.removeUris(uris)
        if (GalleryState.loaded) viewModelScope.launch { GalleryState.loadFolders(getApplication()) }
        uris.forEach { PersonEngine.scores.remove(it) }
        persist(); rev++
        scrubEverywhere(uris)
        // "Bulunan yüzler"den açılan kişinin hiç fotoğrafı kalmadıysa panoya dön; kişi panodan kalkar
        if (fromFaces && photoList.isEmpty() && screen != Screen.Faces && screen != Screen.Celebs) screen = if (celebBack) Screen.Celebs else Screen.Faces
    }

    /** Telefondan silinen fotoğrafları TÜM kayıtlı analiz sonuçlarından ve Ünlüler listesinden de çıkarır (yüz sayıları düşer, fotoğraf bir daha görünmez). */
    private fun scrubEverywhere(uris: Set<String>) {
        if (uris.isEmpty()) return
        val app = getApplication<Application>()
        try { Celebs.dropPhotos(app, uris) } catch (e: Exception) { }
        val snap = saved
        viewModelScope.launch(Dispatchers.IO) {
            for (r in snap) {
                var changed = false
                for (c in r.clusters) { if (c.photos.removeAll(uris)) changed = true; if (c.edited.removeAll(uris)) changed = true }
                if (changed) try { Store.save(app, r) } catch (e: Exception) { }
            }
            val all = Store.loadAll(app)
            withContext(Dispatchers.Main) { saved = all; rev++ }
        }
    }

    /** Düzenlenmiş kopyayı (kırpılmış / netleştirilmiş) ilgili yüzün "Düzenlenenler" bölümüne ekler. */
    private fun addEdited(orig: String, nu: String) {
        // Düzenlenen fotoğraf bulunduğu yerden (yüzün fotoğraflarından) çıkar, Düzenlenenler'e taşınır; telefondaki orijinal dosyaya dokunulmaz.
        fun add(c: Cluster) { if (orig in c.photos) { c.photos.remove(orig); c.edited.add(nu) } else if (orig in c.edited) c.edited.add(nu) }
        current?.clusters?.forEach { add(it) }
        selected?.let { add(it) }
        if (!viewingEdited && selected != null && orig in photoList) { photoList = photoList.filter { it != orig }; photoSel = photoSel - orig }
        if (viewingEdited && orig in photoList && nu !in photoList)
            photoList = photoList.flatMap { if (it == orig) listOf(it, nu) else listOf(it) }
    }

    // ---- Dış düzenleyici (Google Fotoğraflar vb.): düzenlenen YENİ kopya yalnızca Düzenlenenler'e kaydedilir, orijinal olduğu yerde aynen kalır
    private var extEditOrig: String? = null
    private var extEditStart = 0L
    fun beginExternalEdit(orig: String) { extEditOrig = orig; extEditStart = System.currentTimeMillis() / 1000 - 2 }

    /** Düzenleyiciden dönülünce çağrılır: düzenleme sırasında telefona eklenen yeni resimler bulunup Düzenlenenler'e eklenir. */
    fun collectExternalEdit() {
        val orig = extEditOrig ?: return
        val since = extEditStart
        extEditOrig = null
        val app = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val found = ArrayList<String>()
            try {
                app.contentResolver.query(IMG, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.IS_PENDING),
                    "${MediaStore.MediaColumns.DATE_ADDED} >= ?", arrayOf(since.toString()), "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                    while (c.moveToNext()) {
                        if (c.getInt(1) == 1) continue
                        val u = ContentUris.withAppendedId(IMG, c.getLong(0)).toString()
                        if (u != orig) found.add(u)
                    }
                }
            } catch (e: Exception) { }
            if (found.isEmpty()) return@launch
            withContext(Dispatchers.Main) {
                addEditedKeepOriginal(orig, found)
                toast("Düzenlenen kopya Düzenlenenler'e kaydedildi, orijinal korundu")
            }
        }
    }

    /** Orijinal fotoğraf kişinin fotoğraflarında kalır; yeni hâli yalnızca Düzenlenenler'e eklenir. Hiçbir kişi grubunda yoksa tek başına Düzenlenenler'e girer. */
    private fun addEditedKeepOriginal(orig: String, nus: List<String>) {
        var placed = false
        fun add(c: Cluster) { if (orig in c.photos || orig in c.edited) { c.edited.addAll(nus); placed = true } }
        current?.clusters?.forEach { add(it) }
        selected?.let { add(it) }
        if (placed) { persist(); rev++ }
        else { val app = getApplication<Application>(); EditedStore.add(app, nus); editedStandalone = EditedStore.load(app) }
        if (viewingEdited && selected != null && photoList.isNotEmpty()) photoList = (photoList + nus).distinct()
    }

    /** Görüntüleyicide dokunulan yüzü "Kaydedilen yüzler"e ekler: baş bölgesi orijinal çözünürlükten kırpılıp netleştirilir; olmazsa yüz kırpıntısı kullanılır. */
    fun saveViewFace(photo: String, vf: ViewFaces?, f: ViewFace, m: FaceMatch?, name: String? = null) {
        val app = getApplication<Application>()
        val embs = listOf(f.emb) + (m?.let { listOf(it.cluster.centroid) + it.cluster.reps.take(7) }.orEmpty()).filter { it.size == f.emb.size }
        viewModelScope.launch(Dispatchers.IO) {
            val tmp = File(app.cacheDir, "vface_${System.currentTimeMillis()}.jpg")
            var ok = false
            try {
                if (vf != null && vf.w > 0) {
                    val full = android.graphics.ImageDecoder.decodeBitmap(android.graphics.ImageDecoder.createSource(app.contentResolver, Uri.parse(photo))) { dec, info, _ ->
                        dec.allocator = android.graphics.ImageDecoder.ALLOCATOR_SOFTWARE
                        val mx = maxOf(info.size.width, info.size.height)
                        if (mx > 4096) dec.setTargetSampleSize(Math.ceil(mx / 4096.0).toInt())
                    }
                    val k = full.width.toFloat() / vf.w; val b = f.box
                    val fw = b.width() * k; val fh = b.height() * k; val cx = (b.left + b.right) / 2f * k
                    val l = (cx - fw).toInt().coerceAtLeast(0); val r = (cx + fw).toInt().coerceAtMost(full.width)
                    val t = (b.top * k - 0.75f * fh).toInt().coerceAtLeast(0); val bt = (b.bottom * k + 0.55f * fh).toInt().coerceAtMost(full.height)
                    if (r - l >= 32 && bt - t >= 32) {
                        val out = Enhancer.enhanceCrop(Bitmap.createBitmap(full, l, t, r - l, bt - t))
                        tmp.outputStream().use { out.compress(Bitmap.CompressFormat.JPEG, 97, it) }; ok = true
                    }
                }
            } catch (e: Throwable) { ok = false }
            if (!ok) tmp.outputStream().use { f.crop.compress(Bitmap.CompressFormat.JPEG, 95, it) }
            withContext(Dispatchers.Main) { addSavedFace(tmp.absolutePath, embs, name ?: m?.cluster?.tag.orEmpty()); tmp.delete() }
        }
    }

    /** Görüntüleyicide dokunulan yüzü (adı sorularak) Ünlüler bölümüne ekler; eşleşen kişi varsa onun fotoğrafları da gelir. */
    fun addViewFaceToCelebs(photo: String, f: ViewFace, m: FaceMatch?, name: String) {
        val app = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            val tmp = File(app.cacheDir, "vceleb_${System.currentTimeMillis()}.jpg")
            try { tmp.outputStream().use { f.crop.compress(Bitmap.CompressFormat.JPEG, 95, it) } } catch (e: Exception) { }
            withContext(Dispatchers.Main) {
                if (!tmp.exists()) { toast("Bu yüz eklenemedi."); return@withContext }
                val centroid = m?.cluster?.centroid?.takeIf { it.isNotEmpty() } ?: f.emb
                val photos = LinkedHashSet<String>().also { it.add(photo); m?.cluster?.photos?.let { p -> it.addAll(p) } }
                val added = Celebs.add(app, name.trim(), tmp.absolutePath, centroid, photos)
                tmp.delete()
                toast(if (added) "Ünlüler bölümüne eklendi" else "Bu kişi zaten Ünlüler'de; fotoğrafları ona eklendi")
                rev++
            }
        }
    }

    /** Tüm kişilerin düzenlenmiş (kırpılmış / netleştirilmiş) fotoğraflarını tek ızgarada açar. */
    fun openEditedAll(cl: List<Cluster>) {
        fromFaces = false; saveMode = false; fromSearch = false; fromPerson = false; selected = null; viewingEdited = true; editedFromMain = false
        photoList = cl.flatMap { it.edited }.distinct(); photoSel = emptySet(); screen = Screen.Photos
    }

    private val EDITED_REL = "Pictures/Düzenlenenler/"

    private fun saveCopy(orig: String, bmp: Bitmap, suffix: String, quality: Int): String {
        val cr = getApplication<Application>().contentResolver
        var rel = "Pictures/"; var name = "foto"
        cr.query(Uri.parse(orig), arrayOf(MediaStore.MediaColumns.RELATIVE_PATH, MediaStore.MediaColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) { rel = it.getString(0) ?: rel; name = (it.getString(1) ?: name).substringBeforeLast('.') }
        }
        // Düzenlenmiş kopyalar galeride gerçek bir albüme gider: Pictures/Düzenlenenler (uygulamadaki Düzenlenenler bölümüyle eşitlenir)
        rel = EDITED_REL
        fun values(r: String) = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, "${name}_${suffix}_${System.currentTimeMillis()}.jpg")
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            put(MediaStore.MediaColumns.RELATIVE_PATH, r)
            put(MediaStore.MediaColumns.IS_PENDING, 1)
        }
        val nu = (try { cr.insert(IMG, values(rel)) } catch (e: Exception) { null })
            ?: cr.insert(IMG, values("Pictures/Fotoliz/")) ?: throw IllegalStateException("kayıt oluşturulamadı")
        cr.openOutputStream(nu)!!.use { bmp.compress(Bitmap.CompressFormat.JPEG, quality, it) }
        cr.update(nu, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
        return nu.toString()
    }

    fun saveCropped(orig: String, bmp: Bitmap) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val s = saveCopy(orig, bmp, "kirpilmis", 95)
                withContext(Dispatchers.Main) {
                    addEdited(orig, s); persist(); rev++
                    toast("Kırpılmış kopya kaydedildi (Düzenlenenler bölümünde)"); screen = Screen.Viewer
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { toast("Kaydedilemedi: ${e.message}") }
            }
        }
    }

    // ---- Galeri: çoklu netleştirme -> hepsi ekranda gösterilir -> "Bitti" deyince seçilen orijinaller silinir
    /** Galeride netleştirilenler: (orijinal, yeni düzenlenmiş) çiftleri. Doluyken sonuç ekranı açılır. */
    var enhReview by mutableStateOf<List<Pair<String, String>>?>(null)

    fun enhanceGallery(uris: List<String>) {
        if (uris.isEmpty() || enhancing) return
        enhancing = true; enhanceDone = 0; enhanceTotal = uris.size
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val made = ArrayList<Pair<String, String>>(); var firstErr: String? = null
            for (u in uris) {
                try { val b = Enhancer.enhance(app, Uri.parse(u)); made.add(u to saveCopy(u, b, "net", 98)); b.recycle() }
                catch (e: Throwable) { if (firstErr == null) firstErr = e.message ?: e.javaClass.simpleName }
                withContext(Dispatchers.Main) { enhanceDone++ }
            }
            if (made.isNotEmpty()) EditedStore.add(app, made.map { it.second })
            withContext(Dispatchers.Main) {
                enhancing = false
                if (made.isEmpty()) toast("Netleştirme yapılamadı: ${firstErr ?: "bilinmeyen hata"}")
                else {
                    editedStandalone = EditedStore.load(app)
                    GalleryState.selPhotos.clear()
                    enhReview = made
                    if (GalleryState.loaded) viewModelScope.launch { GalleryState.loadFolders(app) }
                    rev++
                }
            }
        }
    }

    /** Sonuç ekranından çıkış. deleteOriginals = true ("Bitti"): netleştirilen fotoğrafların eski orijinalleri kaynağından silinir; yeni hâlleri Düzenlenenler'de kalır. */
    fun finishReview(deleteOriginals: Boolean) {
        val r = enhReview ?: return
        enhReview = null
        if (deleteOriginals) deletePhotos(r.map { it.first })
    }

    /** Düzenlenenler bölümü ile galerideki "Düzenlenenler" albümünü eşitler: albümde olup listede olmayanlar eklenir, albümden silinmiş olanlar listeden çıkar. */
    fun syncEditedFolder() {
        val app = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val cr = app.contentResolver
                val inFolder = LinkedHashSet<String>()
                cr.query(IMG, arrayOf(MediaStore.MediaColumns._ID), "${MediaStore.MediaColumns.RELATIVE_PATH} LIKE ?", arrayOf("$EDITED_REL%"),
                    "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
                    while (c.moveToNext()) inFolder.add(ContentUris.withAppendedId(IMG, c.getLong(0)).toString())
                }
                val cur = EditedStore.load(app)
                val missing = inFolder.filter { it !in cur }
                // listedeki kayıtlardan dosyası artık olmayanları (galeriden silinmiş) ayıkla
                val gone = cur.filter { u -> u !in inFolder && try { cr.query(Uri.parse(u), arrayOf(MediaStore.MediaColumns._ID), null, null, null)?.use { it.count == 0 } ?: false } catch (e: Exception) { false } }.toSet()
                if (missing.isNotEmpty()) EditedStore.add(app, missing)
                if (gone.isNotEmpty()) EditedStore.remove(app, gone)
                if (missing.isNotEmpty() || gone.isNotEmpty()) withContext(Dispatchers.Main) { editedStandalone = EditedStore.load(app); rev++ }
            } catch (e: Exception) { }
        }
    }

    /** Seçili fotoğrafların hepsini sırayla netleştirir; sonuçlar kopya olarak kaydedilir, orijinaller korunur.
     *  Düzenlenenler içindeyken: "gündüz çekimi" modu (tam kare, yazı/simge silme, en yüksek kalite) uygulanır ve işlenen düzenlenen,
     *  yeni düzenlenmiş hâliyle DEĞİŞTİRİLİR (eski düzenlenen listeden kalkar; telefondaki dosyasına dokunulmaz). */
    fun enhancePhotos(uris: List<String>, forceNormal: Boolean = false) {
        if (uris.isEmpty() || enhancing) return
        val inEdited = viewingEdited && !forceNormal
        enhancing = true; enhanceDone = 0; enhanceTotal = uris.size
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val made = ArrayList<Pair<String, String>>()
            var firstErr: String? = null
            for (u in uris) {
                try {
                    val b = if (inEdited) Enhancer.enhanceDaylight(app, Uri.parse(u)) else Enhancer.enhance(app, Uri.parse(u))
                    made.add(u to saveCopy(u, b, if (inEdited) "gunduz" else "net", if (inEdited) 100 else 98)); b.recycle()
                } catch (e: Throwable) { if (firstErr == null) firstErr = e.message ?: e.javaClass.simpleName }
                withContext(Dispatchers.Main) { enhanceDone++ }
            }
            withContext(Dispatchers.Main) {
                if (inEdited) for ((o, n) in made) replaceEdited(o, n) else for ((o, n) in made) addEdited(o, n)
                enhancing = false; photoSel = emptySet(); persist(); rev++
                toast(if (made.isEmpty()) "Netleştirme yapılamadı: ${firstErr ?: "bilinmeyen hata"}"
                    else if (inEdited) "${made.size} fotoğraf gündüz çekimi olarak netleştirildi; eski düzenlenen yenisiyle değiştirildi"
                    else "${made.size} fotoğraf netleştirildi (Düzenlenenler bölümünde)")
            }
        }
    }

    /** Düzenlenen fotoğrafı yeni düzenlenmiş hâliyle değiştirir: eski düzenlenen tüm kayıtlardan kalkar, yenisi aynı yere (aynı kişi grubuna ya da albümden netleştirilenlere) kaydedilir. */
    private fun replaceEdited(old: String, nu: String) {
        val app = getApplication<Application>()
        var placed = false
        fun swap(c: Cluster): Boolean {
            if (old !in c.edited) return false
            val l = c.edited.toMutableList(); val i = l.indexOf(old); l[i] = nu
            c.edited.clear(); c.edited.addAll(l.distinct()); return true
        }
        current?.clusters?.forEach { if (swap(it)) placed = true }
        selected?.let { if (swap(it)) placed = true }
        val changed = ArrayList<Result>()
        for (r in saved) { var ch = false; for (c in r.clusters) if (swap(c)) { ch = true; placed = true }; if (ch) changed.add(r) }
        val inStore = old in editedStandalone
        if (inStore || !placed) {
            val l = editedStandalone.toMutableList(); val i = l.indexOf(old)
            if (i >= 0) l[i] = nu else l.add(0, nu)
            editedStandalone = l.distinct(); EditedStore.save(app, editedStandalone)
        }
        if (changed.isNotEmpty()) viewModelScope.launch(Dispatchers.IO) { changed.forEach { try { Store.save(app, it) } catch (e: Exception) { } } }
        photoList = photoList.map { if (it == old) nu else it }.distinct()
    }

    // ---- Düzenlenenler (ana ekran bölümü) + "Albümden seç" ile netleştirme
    /** Albümden seçilip netleştirilen, bir kişi grubuna bağlı olmayan fotoğraflar (kalıcı). */
    var editedStandalone by mutableStateOf(EditedStore.load(getApplication()))
    var editedFromMain by mutableStateOf(false)
    var editAlbums by mutableStateOf<List<Album>>(emptyList())
    var editLoading by mutableStateOf(false)
    var editAlbum by mutableStateOf<Album?>(null)
    var editAlbumPhotos by mutableStateOf<List<String>>(emptyList())
    var editPicked by mutableStateOf<List<String>>(emptyList())

    /** Tüm düzenlenenler: önce albümden netleştirilenler (en yeni önce), sonra kişi gruplarındaki düzenlenenler. */
    var editedOrder by mutableStateOf(EditedStore.loadOrder(getApplication()))
    fun allEdited(): List<String> {
        val base = (editedStandalone + saved.flatMap { r -> r.clusters.flatMap { it.edited } }).distinct()
        if (editedOrder.isEmpty()) return base
        // Sürükleyerek verilen sıra korunur; sırada olmayan yeniler (en yeni önce) başa gelir
        val inBase = base.toHashSet(); val ordered = editedOrder.filter { it in inBase }; val os = ordered.toHashSet()
        return base.filter { it !in os } + ordered
    }
    /** Düzenlenenler sayfasında basılı tutup sürükleyerek yer değiştirme: sıra kalıcı kaydedilir. */
    fun moveEdited(from: Int, to: Int) {
        if (from !in photoList.indices || to !in photoList.indices || from == to) return
        val l = photoList.toMutableList(); val x = l.removeAt(from); l.add(to, x)
        photoList = l; editedOrder = l; EditedStore.saveOrder(getApplication(), l)
    }

    fun openEditedHub() {
        syncEditedFolder()
        fromFaces = false; saveMode = false; fromSearch = false; fromPerson = false; selected = null; viewingEdited = true; editedFromMain = true
        photoList = allEdited(); photoSel = emptySet(); screen = Screen.Photos
    }

    fun openEditPicker() {
        editAlbum = null; editAlbumPhotos = emptyList(); editPicked = emptyList(); screen = Screen.PickEdit
        editLoading = true
        viewModelScope.launch(Dispatchers.IO) {
            val names = LinkedHashMap<String, String>(); val cnt = HashMap<String, Int>(); val cover = HashMap<String, Long>()
            try {
                getApplication<Application>().contentResolver.query(IMG,
                    arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.BUCKET_ID, MediaStore.Images.Media.BUCKET_DISPLAY_NAME),
                    null, null, "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0); val b = c.getString(1) ?: continue
                        names.getOrPut(b) { c.getString(2) ?: "Diğer" }; cnt[b] = (cnt[b] ?: 0) + 1; cover.getOrPut(b) { id }
                    }
                }
            } catch (e: Exception) { }
            val list = names.map { (b, n) -> Album(b, n, cnt[b] ?: 0, ContentUris.withAppendedId(IMG, cover[b]!!)) }.sortedByDescending { it.count }
            withContext(Dispatchers.Main) { editAlbums = list; editLoading = false }
        }
    }

    fun openEditAlbum(a: Album) {
        editAlbum = a; editAlbumPhotos = emptyList()
        viewModelScope.launch(Dispatchers.IO) {
            val out = ArrayList<String>()
            try {
                getApplication<Application>().contentResolver.query(IMG, arrayOf(MediaStore.Images.Media._ID),
                    "${MediaStore.Images.Media.BUCKET_ID}=?", arrayOf(a.id), "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
                    while (c.moveToNext()) out.add(ContentUris.withAppendedId(IMG, c.getLong(0)).toString())
                }
            } catch (e: Exception) { }
            withContext(Dispatchers.Main) { if (editAlbum?.id == a.id) editAlbumPhotos = out }
        }
    }

    fun toggleEditPick(u: String) { editPicked = if (u in editPicked) editPicked - u else editPicked + u }

    /** Seçilenleri (tüm albümlerden) sırayla netleştirir; bitince sonuçlar Düzenlenenler'e kaydedilir. Orijinallere dokunulmaz. */
    fun enhancePicked() {
        val uris = editPicked
        if (uris.isEmpty() || enhancing) return
        enhancing = true; enhanceDone = 0; enhanceTotal = uris.size
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            val made = ArrayList<String>(); var firstErr: String? = null
            for (u in uris) {
                try { val b = Enhancer.enhance(app, Uri.parse(u)); made.add(saveCopy(u, b, "net", 98)); b.recycle() }
                catch (e: Throwable) { if (firstErr == null) firstErr = e.message ?: e.javaClass.simpleName }
                withContext(Dispatchers.Main) { enhanceDone++ }
            }
            if (made.isNotEmpty()) EditedStore.add(app, made)
            withContext(Dispatchers.Main) {
                enhancing = false
                if (made.isEmpty()) toast("Netleştirme yapılamadı: ${firstErr ?: "bilinmeyen hata"}")
                else {
                    editedStandalone = EditedStore.load(app); editPicked = emptyList()
                    toast("${made.size} fotoğraf netleştirildi (Düzenlenenler bölümüne kaydedildi)")
                    openEditedHub()
                }
            }
        }
    }

    fun loadAlbums() {
        error = null; loadingDirs = true
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val names = LinkedHashMap<String, String>(); val cnt = HashMap<String, Int>(); val cover = HashMap<String, Long>()
                getApplication<Application>().contentResolver.query(IMG,
                    arrayOf(MediaStore.Images.Media._ID, MediaStore.Images.Media.BUCKET_ID, MediaStore.Images.Media.BUCKET_DISPLAY_NAME),
                    null, null, "${MediaStore.Images.Media.DATE_ADDED} DESC")?.use { c ->
                    while (c.moveToNext()) {
                        val id = c.getLong(0); val b = c.getString(1) ?: continue
                        names.getOrPut(b) { c.getString(2) ?: "Diğer" }
                        cnt[b] = (cnt[b] ?: 0) + 1
                        cover.getOrPut(b) { id }
                    }
                }
                val list = names.map { (b, n) -> Album(b, n, cnt[b] ?: 0, ContentUris.withAppendedId(IMG, cover[b]!!)) }
                    .sortedByDescending { it.count }
                withContext(Dispatchers.Main) {
                    albums = list
                    chosenAlbums = if (searchPickOnly) chosenAlbums.intersect(list.map { it.id }.toSet()) else emptySet()
                    if (!searchPickOnly) searchPicked = false
                    loadingDirs = false; screen = Screen.Albums
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { error = e.message ?: "Albümler okunamadı"; loadingDirs = false }
            }
        }
    }
    /** Albüm ekranı: seçili albümlerdeki tüm fotoğrafları geri dönüşüm kutusuna atar (Android 11+; 10'da kalıcı siler). Onay penceresi arayüzde sorulur. */
    fun trashAlbums(ids: Set<String>) {
        if (ids.isEmpty()) return
        val app = getApplication<Application>(); val cr = app.contentResolver
        val opNames = albums.filter { it.id in ids }.map { it.name }
        viewModelScope.launch(Dispatchers.IO) {
            val idList = ids.mapNotNull { it.toLongOrNull() }.joinToString(",")
            val uris = ArrayList<Uri>()
            if (idList.isNotEmpty()) try {
                cr.query(IMG, arrayOf(MediaStore.Images.Media._ID), "${MediaStore.Images.Media.BUCKET_ID} IN ($idList)", null, null)?.use { c ->
                    while (c.moveToNext()) uris.add(ContentUris.withAppendedId(IMG, c.getLong(0)))
                }
            } catch (e: Exception) { }
            if (uris.isEmpty()) { withContext(Dispatchers.Main) { toast("Silinecek fotoğraf bulunamadı") }; return@launch }
            withContext(Dispatchers.Main) {
                val strs = uris.map { it.toString() }.toSet()
                val finish = { n: Int ->
                    purge(strs)
                    val ad = RecentOps.names(opNames)
                    RecentOps.add(app, (if (Build.VERSION.SDK_INT >= 30) "Geri dönüşüme atıldı: " else "Silindi: ") + (if (ad.isNotEmpty()) "$ad • " else "") + "$n fotoğraf")
                    toast(if (Build.VERSION.SDK_INT >= 30) "$n fotoğraf geri dönüşüm kutusuna atıldı" else "$n fotoğraf silindi")
                    chosenAlbums = emptySet(); loadAlbums()
                    viewModelScope.launch { GalleryState.loadFolders(app) }
                }
                if (Build.VERSION.SDK_INT >= 30) {
                    try {
                        pendingOp = { finish(uris.size) }
                        pendingSender = MediaStore.createTrashRequest(cr, uris, true).intentSender
                    } catch (e: Exception) { pendingOp = null; toast("İzin penceresi açılamadı") }
                } else {
                    val gone = HashSet<String>()
                    forEachWithAccess(uris, { u -> if (cr.delete(u, null, null) > 0) gone.add(u.toString()) }, { _, _ -> finish(gone.size) })
                }
            }
        }
    }
    fun toggleAlbum(id: String) { chosenAlbums = if (id in chosenAlbums) chosenAlbums - id else chosenAlbums + id }
    private fun needModel(): Boolean {
        if (modelReady) return false
        error = "Yüz tanıma modeli henüz hazır değil, indirme bitene kadar bekleyin."; screen = Screen.Main; return true
    }
    // Albüm analiz filtresi: "M" erkek, "F" kadın, "ALL" erkek & kadın (hepsi), "OBJ" nesne adıyla arama
    var analysisFilter by mutableStateOf("")
    var albumObjText by mutableStateOf("")
    // Albüm ekranı "Sayı Seç" kutusu: dolu ise her seçili albümden yalnızca bu kadar ilk fotoğraf analiz edilir (boş = hepsi)
    var photoLimit by mutableStateOf("")
    fun limitN(): Int = photoLimit.toIntOrNull()?.takeIf { it > 0 } ?: 0
    fun startAlbumAnalysis() {
        if (analysisFilter == "OBJ") {
            if (albumObjText.isBlank()) { error = "Nesne adı yazın."; return }
            searchText = albumObjText; startSearch()
        } else startAlbums()
    }
    fun startAlbums() {
        if (needModel() || busy()) return
        val sel = (chosenAlbums + (if (analysisFilter == "M" || analysisFilter == "F") setOf("~$analysisFilter") else emptySet()) + (if (limitN() > 0) setOf("~N${limitN()}") else emptySet())).toList().sorted()
        val pk = Store.keyOf("media", sel)
        val pd = Partial.pending(getApplication()).firstOrNull { it.key == pk }
        if (pd != null) { askResume = pd; return }          // daha önce yarıda kesilmiş: devam edilsin mi?
        val ex = saved.firstOrNull { it.uri == "media" && it.sel.sorted() == sel && it.clusters.isNotEmpty() }
        if (ex != null) askFor = ex else scanAlbums(sel)
    }
    private fun busy(): Boolean {
        if (Engine.running) { error = "Zaten bir analiz sürüyor."; screen = Screen.Scanning; return true }
        if (SearchEngine.running) { error = "Bir nesne araması sürüyor; bitmesini bekleyin ya da Durdur'a basın."; screen = Screen.Search; return true }
        if (PersonEngine.running) { error = "Bir kişi araması sürüyor; bitmesini bekleyin ya da Durdur'a basın."; screen = Screen.Person; return true }
        return false
    }
    private fun scanAlbums(sel: List<String>) {
        if (busy()) return
        error = null; screen = Screen.Scanning
        Engine.start(getApplication(), "media", sel, Engine.albumSource(sel))
    }

    fun importModel(uri: Uri) {
        modelMsg = "Model kopyalanıyor…"
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            try {
                val tmp = File(ctx.filesDir, "model.tmp")
                ctx.contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o) } }
                val dst = File(ctx.filesDir, "model.onnx")
                dst.delete(); tmp.renameTo(dst)
                Analyzer(ctx).close()
                ModelStore.saveCopy(ctx, dst)      // seçilen model de kalıcı kopya olarak Download/FotoLiz'e yazılır
                withContext(Dispatchers.Main) { modelReady = true; modelMsg = "Model yüklendi ✓ (${dst.length() / 1048576} MB)" }
            } catch (e: Exception) {
                File(ctx.filesDir, "model.onnx").delete()
                withContext(Dispatchers.Main) { modelReady = false; modelMsg = e.message ?: "Model yüklenemedi" }
            }
        }
    }

    /** Ana klasör seçildi: alt klasörleri listele, seçim ekranını aç. */
    fun picked(uri: Uri) {
        error = null; loadingDirs = true; rootUri = uri
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val d = DocumentFile.fromTreeUri(getApplication(), uri) ?: throw Exception("Klasör açılamadı.")
                val names = d.listFiles().filter { it.isDirectory }.mapNotNull { it.name }.sorted()
                withContext(Dispatchers.Main) {
                    subDirs = listOf(ROOT) + names; chosen = subDirs.toSet(); loadingDirs = false; screen = Screen.Select
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { error = e.message; loadingDirs = false }
            }
        }
    }
    fun toggle(n: String) { chosen = if (n in chosen) chosen - n else chosen + n }

    fun startSelected() {
        if (needModel() || busy()) return
        val uri = rootUri ?: return
        val sel = chosen.toList().sorted()
        val pk = Store.keyOf(uri.toString(), sel)
        val pd = Partial.pending(getApplication()).firstOrNull { it.key == pk }
        if (pd != null) { askResume = pd; return }
        val ex = saved.firstOrNull { it.uri == uri.toString() && it.sel.sorted() == sel && it.clusters.isNotEmpty() }
        if (ex != null) askFor = ex else scan(uri, sel)
    }
    fun openSaved(r: Result) { askFor = r }
    fun useSaved(r: Result) { askFor = null; Engine.addFound(getApplication(), r.key); current = r; autoThr = startThr; picks = emptySet(); screen = Screen.Clusters }
    fun reanalyze() { val r = askFor ?: return; askFor = null; if (r.uri == "media") scanAlbums(r.sel) else scan(Uri.parse(r.uri), r.sel) }

    // ------------------------------------------------------------------ Rapor: kayıtların albüm yazısını düzenle, kaydedince geçerli olsun
    /** labels: Result.key -> yeni albüm yazısı. Boş yazı = otomatik başlığa dön. Yalnızca değişenler yazılır. */
    fun applyReport(labels: Map<String, String>) {
        val app = getApplication<Application>()
        val changed = saved.filter { r -> labels[r.key]?.trim()?.let { it != savedAlbumInfo(r).second && it != r.label } == true }
        if (changed.isEmpty()) return
        viewModelScope.launch(Dispatchers.IO) {
            for (r in changed) {
                val t = labels[r.key]!!.trim()
                val auto = savedAlbumInfo(Result(r.uri, r.name, r.total, r.time, r.clusters, r.sel, r.durSec)).second
                Store.save(app, Result(r.uri, r.name, r.total, r.time, r.clusters, r.sel, r.durSec, if (t == auto) "" else t))
            }
            val all = Store.loadAll(app)
            withContext(Dispatchers.Main) {
                current?.let { c -> all.firstOrNull { it.key == c.key }?.let { n -> current = Result(c.uri, c.name, c.total, c.time, c.clusters, c.sel, c.durSec, n.label) } }
                saved = all; rev++
                toast("Rapor kaydedildi (${changed.size} kayıt güncellendi)")
            }
        }
    }

    // ------------------------------------------------------------------ Kayıtlı sonuçlarda çoklu seçim + silme
    var savedSel by mutableStateOf<Set<String>>(emptySet())      // seçili kayıtların anahtarları (Result.key)
    var askDeleteSaved by mutableStateOf(false)
    fun toggleSaved(r: Result) { savedSel = if (r.key in savedSel) savedSel - r.key else savedSel + r.key }
    fun selectAllSaved() { savedSel = if (savedSel.size == saved.size) emptySet() else saved.map { it.key }.toSet() }
    fun deleteSelectedSaved() {
        val app = getApplication<Application>()
        val gone = savedSel
        val list = saved.filter { it.key in gone }
        viewModelScope.launch(Dispatchers.IO) {
            list.forEach { Store.delete(app, it) }
            val rest = Store.loadAll(app)
            withContext(Dispatchers.Main) {
                if (current?.let { it.key in gone } == true) current = null
                saved = rest; savedSel = emptySet(); askDeleteSaved = false
                toast("${list.size} kayıt silindi")
            }
        }
    }

    // ------------------------------------------------------------------ Tek fotoğraf ekranında yüze dokunma: ayrıntı + kapak resmi
    class ViewFace(val box: android.graphics.Rect, val crop: Bitmap, val emb: FloatArray, val q: Float)
    class ViewFaces(val w: Int, val h: Int, val faces: List<ViewFace>)
    class FaceMatch(val result: Result, val cluster: Cluster, val sim: Float, val label: String)

    var viewFaces by mutableStateOf<Map<String, ViewFaces>>(emptyMap())
    var viewPending by mutableStateOf<Set<String>>(emptySet())
    private var viewAnalyzer: Analyzer? = null
    private val viewMutex = kotlinx.coroutines.sync.Mutex()

    /** Görüntülenen fotoğraftaki yüzleri (konum + parmak izi) bulur. Analiz/arama sürerken çalışmaz (bellek). */
    fun loadViewFaces(uri: String) {
        if (!modelReady || uri in viewFaces || uri in viewPending) return
        if (Engine.running || SearchEngine.running || PersonEngine.running) return
        viewPending = viewPending + uri
        viewModelScope.launch(Dispatchers.IO) {
            val app = getApplication<Application>()
            var res: ViewFaces? = null
            try {
                viewMutex.withLock {
                    val a = viewAnalyzer ?: Analyzer(app, 1).also { viewAnalyzer = it }
                    val bmp = a.decode(app, Uri.parse(uri))
                    if (bmp != null) {
                        val fs = a.faces(bmp)
                        res = ViewFaces(bmp.width, bmp.height, fs.map { ViewFace(it.box, it.crop, it.emb, it.q) })
                    }
                }
            } catch (e: Throwable) { }
            withContext(Dispatchers.Main) {
                viewPending = viewPending - uri
                viewFaces = viewFaces + (uri to (res ?: ViewFaces(0, 0, emptyList())))
            }
        }
    }

    /** Tam ekran görüntüleyiciden çıkınca model belleği ve yüz kırpıntıları boşaltılır. */
    fun releaseViewAnalyzer() {
        viewFaces = emptyMap(); viewPending = emptySet()
        viewModelScope.launch(Dispatchers.IO) {
            viewMutex.withLock { try { viewAnalyzer?.close() } catch (e: Exception) { }; viewAnalyzer = null }
        }
    }

    override fun onCleared() {
        try { viewAnalyzer?.close() } catch (e: Exception) { }
        super.onCleared()
    }

    /** Dokunulan yüzü kayıtlı kişilerle eşleştirir (merkez + örnek yüzlerin en yakını). Eşleşme yoksa null. */
    fun matchFace(emb: FloatArray): FaceMatch? {
        var best: FaceMatch? = null
        for (r in saved) {
            val people = r.clusters.filter { !it.obj && it.photos.isNotEmpty() && it.centroid.isNotEmpty() }
            for ((i, c) in people.withIndex()) {
                if (c.centroid.size != emb.size) continue
                var sim = dot(c.centroid, emb)
                for (x in c.reps) if (x.size == emb.size) sim = maxOf(sim, dot(x, emb))
                val b = best
                if (b == null || sim > b.sim) best = FaceMatch(r, c, sim, clusterLabel(c, i))
            }
        }
        return best?.takeIf { it.sim >= 0.35f }
    }

    /** Dokunulan yüzü kişinin kapak resmi yapar (kişi listesinde ve Bulunan yüzler panosunda bu yüz görünür). */
    fun setCover(m: FaceMatch, f: ViewFace) {
        val app = getApplication<Application>()
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val tf = File(Store.thumbDir(app), "${m.result.key}_c${System.currentTimeMillis()}.jpg")
                tf.outputStream().use { Bitmap.createScaledBitmap(f.crop, 160, 160, true).compress(Bitmap.CompressFormat.JPEG, 90, it) }
                val cover = 1_000_000_000   // "alan" büyük verilir: birleştirmede ve yüz panosunda bu kare temsilci kalır
                m.cluster.thumb = tf.absolutePath; m.cluster.area = cover
                current?.takeIf { it.key == m.result.key }?.clusters?.firstOrNull { it.id == m.cluster.id }
                    ?.let { it.thumb = tf.absolutePath; it.area = cover }
                Store.save(app, m.result)
                val all = Store.loadAll(app)
                withContext(Dispatchers.Main) { saved = all; rev++; toast("Kapak resmi güncellendi") }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) { toast("Kapak resmi ayarlanamadı: ${e.message}") }
            }
        }
    }

    // ---- Kaydırma ile gezinme: sola kaydır = geri, sağa kaydır = ileri ----
    private val fwdStack = ArrayList<Pair<Screen, GalleryFolder?>>()
    private var gestureScreen: Screen? = null
    private val noForward = setOf(Screen.Crop, Screen.PickFacePhoto, Screen.PickEdit, Screen.Scanning, Screen.Select, Screen.Albums)

    fun swipeBack() {
        if (screen == Screen.Main) { screen = Screen.Gallery; gestureScreen = screen; return }   // ana ekranda kaydırma: Galeri
        val b = screen; val bf = GalleryState.open
        back()
        if (screen != b) { fwdStack.add(b to bf); gestureScreen = screen }
        else if (b == Screen.Gallery && bf != null && GalleryState.open == null) { fwdStack.add(b to bf); gestureScreen = screen }
    }

    fun swipeForward() {
        while (fwdStack.isNotEmpty()) {
            val (s, f) = fwdStack.removeAt(fwdStack.size - 1)
            if (s in noForward) continue
            if (s == Screen.Photos && photoList.isEmpty()) continue
            if (s == Screen.Viewer && (viewIndex < 0 || viewIndex >= photoList.size)) continue
            if (s == Screen.Clusters && current == null) continue
            screen = s
            if (s == Screen.Gallery && f != null) GalleryState.openFolder(f)
            gestureScreen = screen
            return
        }
        if (screen == Screen.Main) { screen = Screen.Gallery; gestureScreen = screen }
    }

    /** Kaydırma dışında (düğme, dokunuş) başka bir ekrana gidilirse ileri geçmişi silinir. */
    fun noteScreenChanged() { if (screen != gestureScreen) { fwdStack.clear(); gestureScreen = null } }

    fun back() {
        when (screen) {
            Screen.Photos -> if (saveMode) { saveMode = false; photoSel = emptySet(); screen = if (fromPerson) Screen.Person else Screen.Search } else if (photoSel.isNotEmpty()) photoSel = emptySet() else if (fromPerson) screen = Screen.Person else if (fromSearch) screen = Screen.Search else if (fromFaces) { fromFaces = false; screen = if (celebBack) Screen.Celebs else Screen.Faces; celebBack = false } else if (viewingEdited && selected == null && editedFromMain) { editedFromMain = false; viewingEdited = false; screen = Screen.Main } else { screen = Screen.Clusters; rev++ }
            Screen.Search -> if (!FoundGroup.back("search")) { pickForSaved = false; screen = Screen.Main }   // önce açık grup / gruplama kapanır; arama arka planda sürer
            Screen.Person -> if (!FoundGroup.back("person")) { pickForSaved = false; screen = if (personFromGallery) { personFromGallery = false; Screen.Gallery } else Screen.Main }
            Screen.PickFace, Screen.Faces, Screen.Celebs -> { pickForSaved = false; screen = Screen.Main }
            Screen.Viewer -> screen = Screen.Photos
            Screen.PickFacePhoto -> if (!faceBusy) { facePickChoice = null; screen = Screen.PickFace }
            Screen.PickEdit -> if (enhancing) { } else if (editAlbum != null) editAlbum = null else { editPicked = emptyList(); screen = Screen.Photos }
            Screen.Crop -> screen = Screen.Viewer
            Screen.Clusters -> { if (autoThr >= 0.70f) persist(); screen = Screen.Main }
            Screen.Gallery -> if (!GalleryState.back()) screen = Screen.Main
            Screen.Select, Screen.Albums, Screen.Settings -> screen = Screen.Main
            Screen.Scanning -> screen = Screen.Main   // analiz arka planda devam eder
            else -> {}
        }
    }

    private fun scan(uri: Uri, sel: List<String>) {
        if (busy()) return
        error = null; screen = Screen.Scanning
        Engine.start(getApplication(), uri.toString(), sel, Engine.folderSource(uri, sel))
    }

    /** Yüz tanıma modelini (ArcFace, ~174 MB) ilk açılışta kendisi indirir; kullanıcı bir şey seçmez. */
    fun downloadModel() {
        if (downloading || modelReady) return
        downloading = true; modelProgress = 0f
        modelMsg = "Yüz tanıma modeli indiriliyor (~174 MB, sadece ilk açılışta)…"
        viewModelScope.launch(Dispatchers.IO) {
            val ctx = getApplication<Application>()
            val dst = File(ctx.filesDir, "arcface.onnx"); val tmp = File(ctx.filesDir, "arcface.tmp")
            var ok = false; var last = ""
            for (u in MODEL_URLS) {
                try {
                    val conn = URL(u).openConnection() as HttpURLConnection
                    conn.connectTimeout = 20000; conn.readTimeout = 30000; conn.instanceFollowRedirects = true
                    if (conn.responseCode != 200) { last = "HTTP ${conn.responseCode}"; conn.disconnect(); continue }
                    val total = conn.contentLengthLong
                    conn.inputStream.use { i ->
                        tmp.outputStream().use { o ->
                            val buf = ByteArray(256 * 1024); var n = 0; var got = 0L; var lastP = 0f
                            while (i.read(buf).also { n = it } > 0) {
                                o.write(buf, 0, n); got += n
                                if (total > 0) {
                                    val p = got.toFloat() / total
                                    if (p - lastP >= 0.01f) { lastP = p; withContext(Dispatchers.Main) { modelProgress = p } }
                                }
                            }
                        }
                    }
                    conn.disconnect()
                    if (tmp.length() > 100_000_000L) { dst.delete(); tmp.renameTo(dst); ok = true; break } else last = "dosya eksik indi"
                } catch (e: Exception) { last = e.message ?: e.javaClass.simpleName }
            }
            withContext(Dispatchers.Main) {
                downloading = false
                if (ok) { modelReady = true; modelMsg = null; viewModelScope.launch(Dispatchers.IO) { ModelStore.saveCopy(ctx, dst); ctx.getSharedPreferences("app", 0).edit().putBoolean("model_copy_done", true).apply() } }
                else { tmp.delete(); modelMsg = "Model indirilemedi ($last). İnternet bağlantınızı kontrol edip tekrar deneyin." }
            }
        }
    }

    /** Açılışta: model yoksa önce telefondaki kalıcı kopyadan (Download/FotoLiz) geri yükler, bulamazsa indirir; model varsa kopyasını güvenceye alır. */
    init {
        val app = getApplication<Application>()
        Celebs.load(app)
        if (modelReady) viewModelScope.launch(Dispatchers.IO) {
            val prefs = app.getSharedPreferences("app", 0)
            // Bayrağa değil gerçek dosyaya bakılır (bayrak Drive yedeğiyle başka telefona taşınmış olabilir)
            if (!ModelStore.hasCopy(app)) {
                val f = listOf(File(app.filesDir, "model.onnx"), File(app.filesDir, "arcface.onnx")).firstOrNull { it.exists() && it.length() > 100_000_000L }
                if (f != null) { ModelStore.saveCopy(app, f); prefs.edit().putBoolean("model_copy_done", true).apply() }
            }
        } else {
            downloading = true; modelProgress = 0f; modelMsg = "Telefonda kayıtlı model aranıyor…"
            viewModelScope.launch(Dispatchers.IO) {
                val ok = ModelStore.restore(app, File(app.filesDir, "arcface.onnx"))
                withContext(Dispatchers.Main) {
                    downloading = false
                    // Bulunamadıysa sessizce 174 MB indirmek yerine önce sorulur: daha önce indirdiysen dosyayı seçersin
                    if (ok) { modelReady = true; modelMsg = null } else { modelMsg = null; askModel = true }
                }
            }
        }
    }
}

enum class MoveStage(val label: String) { WAITING("İzin bekleniyor"), MOVING("Taşınıyor"), DONE("Tamamlandı") }
/** Devam eden taşıma işleminin ekran bilgisi. [done] işlenen dosya sayısı (başarılı + başarısız). */
data class MoveInfo(val folder: String, val rel: String, val total: Int, val done: Int, val bad: Int, val stage: MoveStage, val thumb: String?) {
    val percent: Int get() = if (stage == MoveStage.DONE) 100 else if (total <= 0) 0 else (done * 100 / total).coerceIn(0, 100)
}
