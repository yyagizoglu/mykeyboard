package com.fotoliz.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.graphics.Rect
import android.net.Uri
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger

/**
 * Galeri filtresi için fotoğraf başına yüz özellikleri (cihazda, internetsiz). Her fotoğraf bir kez taranır, sonuç telefonda saklanır.
 * Kayıt: "|F|M|T|W|X|@konumlar" -> F: kadın yüz, M: erkek yüz, T: başörtüsü / türban / bandana benzeri etiket, W: aynı yüzde örtü + erkek işareti yok (türbanlı kadın), X: güncel yöntemle tarandı. "|" = yüz yok / çözülemedi.
 */
object GalleryAttrs {
    private val map = ConcurrentHashMap<String, String>()
    @Volatile private var loaded = false
    private const val SIDE = 1024
    private fun file(ctx: Context) = File(ctx.filesDir, "galleryattrs2.json")
    private val TURBAN_KEYS = setOf("headscarf", "hijab", "veil", "turban", "scarf", "kerchief", "bandana", "bandanna", "head covering")

    @Synchronized fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try { val f = file(ctx); if (f.exists()) { val o = JSONObject(f.readText()); for (k in o.keys()) map[k] = o.getString(k) } } catch (e: Exception) { }
    }

    /** flag: "F", "M" veya "T". Henüz taranmamış fotoğraf için false. */
    fun has(uri: String, flag: String): Boolean = map[uri]?.contains("|$flag|") == true

    /** Eski sürümde (W / X işareti yokken) türban etiketi alan kayıtlar: kadın-türban kararı için yeniden taranır. */
    private fun stale(u: String): Boolean = map[u]?.let { it.contains("|T|") && !it.contains("|X|") } == true

    /** Yüz başına özellikler ("MBY", "F", "FW"...): ilk harf cinsiyet (F/M/U), sonrası W örtülü kadın, B sakal, Y bıyık, G gözlük. */
    fun faces(uri: String): List<String> {
        val v = map[uri] ?: return emptyList()
        val i = v.indexOf('#'); if (i < 0) return emptyList()
        val e = v.indexOf('@', i).let { if (it < 0) v.length else it }
        return v.substring(i + 1, e).split(';').filter { it.isNotBlank() }
    }
    private fun hasFaceData(u: String): Boolean = map[u]?.contains("|Z|") == true

    /** Fotoğraf güncel yöntemle taranmış mı? */
    fun isDone(uri: String): Boolean = map.containsKey(uri) && !stale(uri)

    /** "W" (türbanlı / eşarplı / bandanalı kadın) yüzlerinin fotoğraf içindeki konumu: [sol, üst, sağ, alt], 0..1 oranında. */
    fun wBoxes(uri: String): List<FloatArray> {
        val v = map[uri] ?: return emptyList()
        val i = v.indexOf('@'); if (i < 0) return emptyList()
        return v.substring(i + 1).split(';').mapNotNull { s ->
            val p = s.split(',')
            if (p.size != 4) null else try { floatArrayOf(p[0].toFloat(), p[1].toFloat(), p[2].toFloat(), p[3].toFloat()) } catch (e: Exception) { null }
        }
    }

    @Synchronized private fun persist(ctx: Context) {
        try {
            val o = JSONObject(); for ((k, v) in map) o.put(k, v)
            val tmp = File(ctx.filesDir, "galleryattrs.tmp"); tmp.writeText(o.toString())
            if (!tmp.renameTo(file(ctx))) { file(ctx).delete(); tmp.renameTo(file(ctx)) }
        } catch (e: Exception) { }
    }

    private fun decode(ctx: Context, uri: Uri): Bitmap? = try {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val m = maxOf(info.size.width, info.size.height)
            if (m > SIDE) { val sc = SIDE.toFloat() / m; dec.setTargetSize((info.size.width * sc).toInt().coerceAtLeast(1), (info.size.height * sc).toInt().coerceAtLeast(1)) }
        }.let { if (it.config == Bitmap.Config.ARGB_8888) it else it.copy(Bitmap.Config.ARGB_8888, false) }
    } catch (e: CancellationException) { throw e } catch (e: Throwable) { null }

    /** Yüzün başını (saç / örtü dahil) kapsayacak şekilde genişletilmiş kutu. */
    private fun headBox(b: Rect, w: Int, h: Int): Rect {
        val px = (b.width() * 0.35f).toInt(); val pt = (b.height() * 0.50f).toInt(); val pb = (b.height() * 0.25f).toInt()
        return Rect((b.left - px).coerceAtLeast(0), (b.top - pt).coerceAtLeast(0), (b.right + px).coerceAtMost(w), (b.bottom + pb).coerceAtMost(h))
    }

    /** Henüz taranmamış fotoğrafları 2 paralel tarar; iptal edilse de o ana kadarki sonuçlar saklanır. */
    /** Ağır iş (dosya okuma / yazma, model yükleme, tarama) HER ZAMAN arka plan iş parçacığında yürür; ana iş parçacığı (yazı yazma, kaydırma) donmaz. */
    suspend fun ensure(ctx: Context, uris: List<String>, needFace: Boolean = false, onProgress: (Int, Int) -> Unit) = kotlinx.coroutines.withContext(Dispatchers.Default) { ensureImpl(ctx, uris, needFace, onProgress) }

    private suspend fun ensureImpl(ctx: Context, uris: List<String>, needFace: Boolean, onProgress: (Int, Int) -> Unit) {
        load(ctx)
        val todo = uris.filter { !map.containsKey(it) || stale(it) || (needFace && !hasFaceData(it)) }
        if (todo.isEmpty()) return
        val queue = ConcurrentLinkedQueue(todo)
        val count = AtomicInteger(0)
        val workers = (Runtime.getRuntime().availableProcessors() / 2).coerceIn(2, 4)
        val detectors = List(workers) { FaceDetection.getClient(FaceDetectorOptions.Builder().setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST).setMinFaceSize(0.05f).build()) }
        val labelers = List(workers) { ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.3f).build()) }
        try {
            coroutineScope {
                for (w in 0 until workers) launch(Dispatchers.Default) {
                    while (true) {
                        val u = queue.poll() ?: break
                        ensureActive()
                        map[u] = scanOne(ctx, detectors[w], labelers[w], u)
                        val d = count.incrementAndGet()
                        if (d % 200 == 0) persist(ctx)   // uzun taramada uygulama kapanırsa ilerleme kaybolmasın
                        if (d % 5 == 0 || d == todo.size) onProgress(d, todo.size)
                    }
                }
            }
        } finally {
            detectors.forEach { try { it.close() } catch (e: Exception) { } }
            labelers.forEach { try { it.close() } catch (e: Exception) { } }
            persist(ctx)
        }
    }

    private fun scanOne(ctx: Context, det: com.google.mlkit.vision.face.FaceDetector, lab: com.google.mlkit.vision.label.ImageLabeler, u: String): String {
        val bmp = decode(ctx, Uri.parse(u)) ?: return "|"
        val flags = LinkedHashSet<String>()
        val boxes = ArrayList<String>(); val faceTok = ArrayList<String>()
        try {
            val faces = Tasks.await(det.process(InputImage.fromBitmap(bmp, 0)))
            for (f in faces) {
                if (f.boundingBox.width() < 40) continue
                val r = headBox(f.boundingBox, bmp.width, bmp.height)
                if (r.width() < 20 || r.height() < 20) continue
                val crop = Bitmap.createBitmap(bmp, r.left, r.top, r.width(), r.height())
                try {
                    val labels = Tasks.await(lab.process(InputImage.fromBitmap(crop, 0)))
                    val g = FaceAttrs.genderOf(labels)
                    when (g) { "F" -> flags.add("F"); "M" -> flags.add("M") }
                    val tok = StringBuilder(when (g) { "F" -> "F"; "M" -> "M"; else -> "U" })
                    val hasT = labels.any { l -> l.text.lowercase() in TURBAN_KEYS && l.confidence >= 0.60f }
                    if (hasT) flags.add("T")
                    // W: AYNI yüzde örtü etiketi var ve erkek işareti (sakal / bıyık) yok → türbanlı / eşarplı / bandanalı kadın
                    fun lab(keys: Set<String>) = labels.any { l -> l.text.lowercase() in keys && l.confidence >= 0.50f }
                    if (lab(setOf("beard", "facial hair"))) tok.append('B')
                    if (lab(setOf("moustache", "mustache"))) tok.append('Y')
                    if (lab(setOf("glasses", "sunglasses", "goggles"))) tok.append('G')
                    if (hasT && g != "M") tok.append('W')
                    faceTok.add(tok.toString())
                    if (hasT && g != "M") {
                        flags.add("W")
                        val b = f.boundingBox
                        boxes.add(String.format(java.util.Locale.US, "%.4f,%.4f,%.4f,%.4f",
                            b.left / bmp.width.toFloat(), b.top / bmp.height.toFloat(), b.right / bmp.width.toFloat(), b.bottom / bmp.height.toFloat()))
                    }
                } finally { crop.recycle() }
            }
        } catch (e: CancellationException) { throw e } catch (e: Throwable) { }
        finally { bmp.recycle() }
        flags.add("X"); flags.add("Z")   // X: güncel yöntemle tarandı; Z: yüz başına özellikler (sakal / bıyık / gözlük) kaydedildi
        return "|" + flags.joinToString("|") + "|" + (if (faceTok.isEmpty()) "" else "#" + faceTok.joinToString(";")) + (if (boxes.isEmpty()) "" else "@" + boxes.joinToString(";"))
    }
}
