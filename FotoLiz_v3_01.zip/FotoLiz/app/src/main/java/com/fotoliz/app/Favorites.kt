package com.fotoliz.app

import android.content.Context
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage

/** Favori fotoğraf / videolar (uri listesi, en yeni başta). Tüm tam ekran görüntüleyicilerdeki kalp düğmesiyle eklenir / çıkarılır. */
object Favorites {
    private var app: Context? = null
    private var loaded = false
    var list by mutableStateOf<List<String>>(emptyList())

    fun load(ctx: Context) {
        if (loaded) return
        loaded = true; app = ctx.applicationContext
        list = prefs(ctx).getString("fav_list", "").orEmpty().split("\n").filter { it.isNotBlank() }
    }
    private fun prefs(ctx: Context) = ctx.applicationContext.getSharedPreferences("app", 0)
    private fun persist() { app?.let { prefs(it).edit().putString("fav_list", list.joinToString("\n")).apply() } }

    fun has(u: String) = u in list
    /** Eklendiyse true, çıkarıldıysa false döner. */
    fun toggle(ctx: Context, u: String): Boolean {
        load(ctx)
        val add = u !in list
        list = if (add) listOf(u) + list else list - u
        persist(); return add
    }
    /** Silinen / taşınan fotoğraflar favorilerden de düşer. */
    fun removeAll(gone: Set<String>) { if (gone.isEmpty() || list.none { it in gone }) return; list = list.filter { it !in gone }; persist() }
    fun items(): List<GalleryItem> = list.map { GalleryItem(Uri.parse(it), it.contains("/video/")) }
}

/** Tam ekran görüntüleyicilerdeki kalp: boşsa favorilere ekler, doluysa çıkarır. */
@Composable
fun FavButton(uri: String, tint: Color = Color.White, modifier: Modifier = Modifier) {
    val ctx = LocalContext.current
    Favorites.load(ctx)
    val on = Favorites.has(uri)
    Box(modifier.size(48.dp).clip(CircleShape).clickable {
        val added = Favorites.toggle(ctx, uri)
        Toast.makeText(ctx, if (added) "Favorilere eklendi" else "Favorilerden çıkarıldı", Toast.LENGTH_SHORT).show()
    }, contentAlignment = Alignment.Center) {
        Icon(if (on) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, if (on) "Favorilerden çıkar" else "Favorilere ekle",
            tint = if (on) Color(0xFFFF4D6D) else tint, modifier = Modifier.size(28.dp))
    }
}

/** Galeri > Favoriler filtresi: favori fotoğraf ve videolar tek ızgarada; dokununca tam ekran açılır (kalple çıkarılabilir). */
@Composable
fun FavoritesScreen() {
    val ctx = LocalContext.current
    Favorites.load(ctx)
    val items = Favorites.items()
    Column(Modifier.fillMaxSize()) {
        Text("Favoriler • ${items.size}", Modifier.padding(horizontal = 12.dp, vertical = 8.dp), style = MaterialTheme.typography.titleMedium)
        if (items.isEmpty()) Text("Henüz favori yok. Tam ekran görüntülerken ♡ simgesine dokunarak ekleyebilirsin.", Modifier.padding(16.dp),
            style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        else LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), contentPadding = PaddingValues(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            itemsIndexed(items, key = { _, it -> it.uri.toString() }) { i, it ->
                AsyncImage(it.uri, null, Modifier.aspectRatio(1f).clickable { GalleryState.favView = items; GalleryState.viewing = i }, contentScale = ContentScale.Crop)
            }
        }
    }
}
