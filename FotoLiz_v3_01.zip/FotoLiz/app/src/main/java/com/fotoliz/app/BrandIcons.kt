package com.fotoliz.app

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** Instagram: mor-pembe-turuncu degrade kare, beyaz kamera cizgisi. */
@Composable
fun InstagramIcon(box: Dp = 28.dp) {
    Canvas(Modifier.size(box)) {
        val s = size.minDimension
        drawRoundRect(
            brush = Brush.linearGradient(
                listOf(Color(0xFFFEDA75), Color(0xFFFA7E1E), Color(0xFFD62976), Color(0xFF962FBF), Color(0xFF4F5BD5)),
                start = Offset(0f, s), end = Offset(s, 0f)),
            cornerRadius = CornerRadius(s * 0.28f))
        val w = s * 0.09f
        drawRoundRect(Color.White, topLeft = Offset(s * 0.2f, s * 0.2f), size = Size(s * 0.6f, s * 0.6f),
            cornerRadius = CornerRadius(s * 0.18f), style = Stroke(w))
        drawCircle(Color.White, radius = s * 0.15f, center = Offset(s * 0.5f, s * 0.5f), style = Stroke(w))
        drawCircle(Color.White, radius = s * 0.045f, center = Offset(s * 0.7f, s * 0.3f))
    }
}

/** Facebook: mavi daire, beyaz "f". */
@Composable
fun FacebookIcon(box: Dp = 28.dp) {
    Canvas(Modifier.size(box)) {
        val s = size.minDimension
        drawCircle(Color(0xFF1877F2), radius = s / 2f, center = Offset(s / 2f, s / 2f))
        val w = s * 0.12f
        // gövde
        drawRect(Color.White, topLeft = Offset(s * 0.46f, s * 0.38f), size = Size(w, s * 0.50f))
        // çapraz çizgi
        drawRect(Color.White, topLeft = Offset(s * 0.36f, s * 0.46f), size = Size(s * 0.36f, s * 0.10f))
        // üst kıvrım
        drawArc(Color.White, startAngle = 180f, sweepAngle = 90f, useCenter = false,
            topLeft = Offset(s * 0.52f - s * 0.14f, s * 0.38f - s * 0.14f), size = Size(s * 0.28f, s * 0.28f), style = Stroke(w))
        drawLine(Color.White, Offset(s * 0.52f, s * 0.24f), Offset(s * 0.76f, s * 0.24f), strokeWidth = w * 0.9f, cap = StrokeCap.Butt)
    }
}

/** WhatsApp: yeşil daire, beyaz konuşma balonu ve telefon. */
@Composable
fun WhatsAppIcon(box: Dp = 28.dp) {
    Box(Modifier.size(box).clip(CircleShape).background(Color(0xFF25D366)), contentAlignment = Alignment.Center) {
        Canvas(Modifier.size(box)) {
            val s = size.minDimension
            drawCircle(Color.White, radius = s * 0.30f, center = Offset(s * 0.5f, s * 0.48f), style = Stroke(s * 0.075f))
            val tail = Path()
            tail.moveTo(s * 0.17f, s * 0.86f); tail.lineTo(s * 0.21f, s * 0.60f); tail.lineTo(s * 0.40f, s * 0.76f); tail.close()
            drawPath(tail, Color.White)
        }
        Icon(Icons.Filled.Call, null, Modifier.size(box * 0.42f), tint = Color.White)
    }
}

/** İletişim: tema renginde daire, beyaz telefon. */
@Composable
fun ContactIcon(box: Dp = 28.dp) {
    Box(Modifier.size(box).clip(CircleShape).background(MaterialTheme.colorScheme.primary), contentAlignment = Alignment.Center) {
        Icon(Icons.Filled.Call, null, Modifier.size(box * 0.58f), tint = MaterialTheme.colorScheme.onPrimary)
    }
}

/** Saat simgesi: daire + akrep/yelkovan. Kilit isteme süresi bölümünde kullanılır. */
@Composable
fun ClockIcon(tint: Color, box: Dp = 24.dp) {
    Canvas(Modifier.size(box)) {
        val s = size.minDimension; val c = Offset(s / 2, s / 2); val w = s * 0.085f
        drawCircle(tint, radius = s * 0.42f, center = c, style = androidx.compose.ui.graphics.drawscope.Stroke(w))
        drawLine(tint, c, Offset(c.x, c.y - s * 0.26f), strokeWidth = w, cap = StrokeCap.Round)             // yelkovan
        drawLine(tint, c, Offset(c.x + s * 0.19f, c.y + s * 0.07f), strokeWidth = w, cap = StrokeCap.Round)  // akrep
        drawCircle(tint, radius = w * 0.7f, center = c)
    }
}

/** Yuvarlak köşeli, tema renkli zemin üzerinde saat simgesi. */
@Composable
fun ClockBadge(box: Dp = 38.dp) {
    Box(Modifier.size(box).clip(androidx.compose.foundation.shape.RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
        ClockIcon(MaterialTheme.colorScheme.onPrimaryContainer, box * 0.64f)
    }
}

/** Desen simgesi: 3x3 nokta ve aralarında çizgi. */
@Composable
fun PatternIcon(tint: Color, box: Dp = 24.dp) {
    Canvas(Modifier.size(box)) {
        val s = size.minDimension
        fun pt(i: Int, j: Int) = Offset(s * (0.18f + 0.32f * i), s * (0.18f + 0.32f * j))
        val w = s * 0.07f
        drawLine(tint, pt(0, 0), pt(1, 0), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(tint, pt(1, 0), pt(1, 1), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(tint, pt(1, 1), pt(1, 2), strokeWidth = w, cap = StrokeCap.Round)
        drawLine(tint, pt(1, 2), pt(2, 2), strokeWidth = w, cap = StrokeCap.Round)
        for (i in 0..2) for (j in 0..2) drawCircle(tint, radius = s * 0.075f, center = pt(i, j))
    }
}

/** Parmak izi simgesi: iç içe yaylar. */
@Composable
fun FingerprintIcon(tint: Color, box: Dp = 24.dp) {
    Canvas(Modifier.size(box)) {
        val s = size.minDimension
        val c = Offset(s * 0.5f, s * 0.5f)
        val w = s * 0.07f
        for (k in 1..4) {
            val r = s * (0.10f * k + 0.02f)
            drawArc(tint, startAngle = 160f, sweepAngle = 220f, useCenter = false,
                topLeft = Offset(c.x - r, c.y - r), size = Size(2 * r, 2 * r), style = Stroke(w, cap = StrokeCap.Round))
        }
        drawLine(tint, c, Offset(c.x, s * 0.88f), strokeWidth = w, cap = StrokeCap.Round)
    }
}
