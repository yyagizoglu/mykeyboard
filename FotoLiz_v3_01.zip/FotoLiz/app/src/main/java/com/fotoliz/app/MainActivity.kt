package com.fotoliz.app

import androidx.compose.ui.text.withStyle
import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.fragment.app.FragmentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.border
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.foundation.clickable
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.animation.core.animateIntAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.luminance
import kotlinx.coroutines.delay
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.input.pointer.positionChange
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import java.io.File
import java.text.DateFormat
import java.util.Date

class MainActivity : FragmentActivity() {   // parmak izi penceresi (BiometricPrompt) için FragmentActivity gerekir
    override fun onStart() { super.onStart(); AppLock.onReturn(this) }
    // Uygulamadan çıkarken kayıtlar Download/FotoLiz klasörüne yedeklenir; Drive yedeği açıksa hemen bir tur yedek alınır
    override fun onStop() {
        super.onStop(); AppLock.onLeave(this)
        val c = applicationContext; Thread { Backup.auto(c); DriveBackup.runSoon(c) }.start()
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AppLock.init(this)                                   // şifre / desen tanımlıysa program kilitli açılır
        DriveBackup.ensureScheduled(applicationContext)      // 10 dakikalık Drive yedek zinciri kopmuşsa yeniden kurar
        setContent {
            val prefs = remember { getSharedPreferences("app", 0) }
            val sysDark = isSystemInDarkTheme()
            // 0 = otomatik (telefon), 1 = açık, 2 = koyu. Eski "dark" ayarı varsa ondan taşınır.
            var mode by remember { mutableStateOf(prefs.getInt("theme_mode", if (prefs.contains("dark")) (if (prefs.getBoolean("dark", false)) 2 else 1) else 0)) }
            // 0 otomatik, 1 açık, 2 koyu, 3 spor, 4 eğlenceli, 5 iş (renkler UiKit.kt → appColorScheme)
            MaterialTheme(colorScheme = appColorScheme(mode, sysDark)) {
                if (AppLock.locked) LockScreen()
                else App(themeMode = mode, sysDark = sysDark, onTheme = { mode = it; prefs.edit().putInt("theme_mode", it).apply() })
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class, ExperimentalFoundationApi::class)
@Composable
fun App(vm: VM = viewModel(), themeMode: Int = 0, sysDark: Boolean = false, onTheme: (Int) -> Unit = {}) {
    val ctx = LocalContext.current
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { uri ->
        if (uri != null) {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            vm.picked(uri)
        }
    }
    val facePhotoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) vm.detectFacesIn(uri) }
    var settingsOk by remember { mutableStateOf(false) }       // Ayarlar'a girerken kilit doğrulandı mı
    var unlockDelete by remember { mutableStateOf(false) }     // kayıtlı sonuçları silmeden önce kilit doğrulaması
    LaunchedEffect(vm.screen) { if (vm.screen != Screen.Settings) settingsOk = false }
    val modelPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri -> if (uri != null) vm.importModel(uri) }
    val perm = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) vm.loadAlbums() else vm.error = "Albümleri görmek için fotoğraf izni gerekli."
    }
    val notif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    val sender = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { r ->
        vm.senderResult(r.resultCode == android.app.Activity.RESULT_OK)
    }
    LaunchedEffect(vm.pendingSender) { vm.pendingSender?.let { sender.launch(IntentSenderRequest.Builder(it).build()); vm.pendingSender = null } }
    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= 33 && ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            notif.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
    // Analiz (arka planda bile) bitince sonuç otomatik açılır
    val fin = Engine.finished; val running = Engine.running
    LaunchedEffect(fin, running) {
        vm.refreshPending()
        if (fin != null) {
            vm.saved = Store.loadAll(ctx)
            val inFront = (ctx as? androidx.lifecycle.LifecycleOwner)?.lifecycle?.currentState?.isAtLeast(androidx.lifecycle.Lifecycle.State.RESUMED) ?: true
            if (inFront) { vm.current = fin; vm.autoThr = vm.startThr; vm.picks = emptySet(); vm.screen = Screen.Clusters; Engine.setUnseen(ctx, null) }
            else { if (fin.clusters.isNotEmpty()) Engine.setUnseen(ctx, fin.key); if (vm.screen == Screen.Scanning) vm.screen = Screen.Main }   // arka planda bitti: yeşil uyarı kartı
            Engine.finished = null
        }
        else if (!running && vm.screen == Screen.Scanning) vm.screen = Screen.Main
    }
    LaunchedEffect(Unit) { Engine.loadUnseen(ctx) }
    LaunchedEffect(vm.screen, vm.current) { if (vm.screen == Screen.Clusters && vm.current?.key != null && vm.current?.key == Engine.unseenKey) Engine.setUnseen(ctx, null) }
    LaunchedEffect(vm.screen) { vm.noteScreenChanged() }
    BackHandler(vm.screen != Screen.Main) { vm.back() }
    BackHandler(vm.screen == Screen.Main) { vm.screen = Screen.Gallery }   // ana ekranda geri / kaydırma uygulamayı kapatmaz: Galeri açılır (Galeri'de geri → ana ekran)
    BackHandler(vm.screen == Screen.Main && vm.savedSel.isNotEmpty()) { vm.savedSel = emptySet() }
    val title = when (vm.screen) {
        Screen.Main -> "FotoLiz"
        Screen.Search -> "“${SearchEngine.query}” araması"
        Screen.PickFace -> "Kişi seç"
        Screen.Person -> "“${PersonEngine.name.ifBlank { "Kişi" }}” araması"
        Screen.Faces -> "Bulunan yüzler"
        Screen.Celebs -> "Ünlüler"
        Screen.Select -> "Alt klasörleri seç"
        Screen.Albums -> "Albümleri seç"
        Screen.Scanning -> "Analiz ediliyor"
        Screen.Clusters -> vm.current?.let { r -> savedAlbumInfo(r).let { "${it.first} albüm: ${it.second}" } } ?: "Kişiler"
        Screen.Photos -> if (vm.photoSel.isEmpty() && vm.viewingEdited && vm.selected == null) "Düzenlenenler (${vm.photoList.size})" else if (vm.photoSel.isNotEmpty()) "${vm.photoSel.size} seçili" else "${vm.photoList.size} fotoğraf"
        Screen.Viewer -> "${vm.viewIndex + 1} / ${vm.photoList.size}"
        Screen.Crop -> "Kırp"
        Screen.Settings -> "Ayarlar"
        Screen.PickEdit -> vm.editAlbum?.name ?: "Albümden seç"
        Screen.PickFacePhoto -> "Fotoğraf seç"
        Screen.Gallery -> GalleryState.open?.name ?: "Galeri"
    }
    val selecting = vm.screen == Screen.Main && vm.savedSel.isNotEmpty()
    Scaffold(topBar = {
        if (selecting) TopAppBar(title = { Text("${vm.savedSel.size} seçili") }, navigationIcon = {
            IconButton(onClick = { vm.savedSel = emptySet() }) { Icon(Icons.Filled.Close, "Seçimi bırak") }
        }, actions = {
            // Seçim modu: Tümünü seç + yanında çöp kutusu
            TextButton(onClick = { vm.selectAllSaved() }) { Text(if (vm.savedSel.size == vm.saved.size) "Seçimi kaldır" else "Tümünü seç") }
            IconButton(onClick = { vm.askDeleteSaved = true }) { Icon(Icons.Filled.Delete, "Seçilenleri sil", tint = Color(0xFFE53935)) }
        }) else
        Column {
        TopAppBar(title = {
            // Başlık tüm genişliği kullanır; tarih / saat / ilçe / hava tek satırlık şerit olarak çubuğun hemen altında
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (vm.screen == Screen.Main) { AppLogo(30.dp); Spacer(Modifier.width(8.dp)) }
                FitTitle(title)
            }
        }, navigationIcon = {
            if (vm.screen != Screen.Main && !(vm.screen == Screen.Gallery && GalleryState.atRoot)) IconButton(onClick = { vm.back() }) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Geri") }
        }, actions = {
            // Çark: programın tüm ayarları, bilgilendirme formu ve yasal metinler
            if (vm.screen == Screen.Clusters && vm.current != null) {
                FilledTonalButton(onClick = { vm.saveNow() }, contentPadding = PaddingValues(horizontal = 12.dp)) {
                    Icon(Icons.Filled.Check, null, Modifier.size(18.dp)); Spacer(Modifier.width(4.dp)); Text("Kaydet")
                }
            }
            // Düzenlenenler ekranı: sağ üstte "Albümden seç"
            if (vm.screen == Screen.Photos && vm.viewingEdited && vm.selected == null && vm.photoSel.isEmpty()) {
                FilledTonalButton(onClick = { vm.openEditPicker() }, contentPadding = PaddingValues(horizontal = 12.dp)) { Text("Albümden seç") }
            }
            // Galeri: klasör listesindeyken filtre / Yüz / sayı listenin üstündeki araç satırında; klasör açıkken burada
            if (vm.screen == Screen.Gallery && GalleryState.viewing < 0 && !GalleryState.showsFolderList && GalleryState.open == null) {
                GalleryFilterMenu()
                TextButton(onClick = { GalleryState.askFace = true }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Yüz", fontWeight = FontWeight.Bold) }
            }
            if (vm.screen in listOf(Screen.Main, Screen.Select, Screen.Albums, Screen.Scanning, Screen.Clusters) || (vm.screen == Screen.Gallery && GalleryState.viewing < 0)) {
                ThemeMenu(themeMode, onTheme)
                ThemeGallery(themeMode, sysDark, onTheme)
                IconButton(onClick = { vm.screen = Screen.Settings }, modifier = Modifier.size(38.dp)) { Icon(Icons.Filled.Settings, "Ayarlar") }
            }
        })
        // Sayfa durumuna göre: tam ekran görüntüleyici / kırpma / fotoğraf görüntüleyicide şerit gizlenir, diğer her sayfada görünür
        if (!(vm.screen == Screen.Gallery && GalleryState.viewing >= 0) && vm.screen != Screen.Viewer && vm.screen != Screen.Crop)
            MiniInfoPanel(Modifier.padding(horizontal = 12.dp, vertical = 2.dp))
        }
    }, bottomBar = {
        // 2 sayfa: FotoLiz (ana sayfa) ve Galeri. Alt çubuk yalnızca bu iki sayfada görünür.
        if ((vm.screen == Screen.Main && !selecting) || (vm.screen == Screen.Gallery && GalleryState.viewing < 0)) NavigationBar {
            NavigationBarItem(selected = vm.screen == Screen.Main, onClick = { if (vm.screen != Screen.Main) { GalleryState.reset(); vm.screen = Screen.Main } },
                icon = { AppLogo(26.dp) }, label = { Text("FotoLiz") })
            NavigationBarItem(selected = vm.screen == Screen.Gallery, onClick = { if (vm.screen != Screen.Gallery) vm.screen = Screen.Gallery else GalleryState.reset() },
                icon = { Icon(Icons.Filled.Menu, null) }, label = { Text("Galeri") })
        }
    }) { pad ->
        Column(Modifier.padding(pad).fillMaxSize()) {
        // Tüm ekranlarda sabit: tema / ayarlar düğmelerinin hemen altında tek satır (tarih, saat, ilçe, hava)
        val gCount = if (vm.screen == Screen.Gallery && GalleryState.showsFolderList) GalleryState.selFolders.size + GalleryState.selPhotos.size else 0
        // Galeri: seçili klasör sayısı (yalnızca seçim varken satır görünür; tarih / hava panosu artık üst çubukta)
        if (gCount > 0 && GalleryState.selFolders.isEmpty()) Text("$gCount seçili", Modifier.padding(horizontal = 12.dp, vertical = 2.dp), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary, maxLines = 1, softWrap = false)
        PendingBanner(vm)   // yarım kalan analiz varsa EN ÜSTTE: kırmızı yanıp sönen ışık + "Devam et"
        Box(Modifier.weight(1f).fillMaxWidth().swipeNav(vm.screen != Screen.Crop, { vm.swipeBack() }, { vm.swipeForward() })) {
            when (vm.screen) {
                Screen.Main -> MainScreen(vm, { picker.launch(null) }, { modelPicker.launch(arrayOf("*/*")) }, { vm.pickForSaved = false; facePhotoPicker.launch("image/*") },
                    { perm.launch(if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE) },
                    { vm.pickForSaved = true; facePhotoPicker.launch("image/*") })
                Screen.Gallery -> GalleryScreen(vm)
                Screen.Search -> SearchScreen(vm)
                Screen.PickFace -> PickFaceScreen(vm)
                Screen.Person -> PersonScreen(vm)
                Screen.Faces -> FacesScreen(vm)
                Screen.Celebs -> CelebsScreen(vm)
                Screen.Select -> SelectScreen(vm)
                Screen.Albums -> AlbumScreen(vm)
                Screen.Scanning -> ScanScreen()
                Screen.Clusters -> {
                    val shown = remember(vm.current, vm.autoThr, vm.rev) { vm.shown() }
                    if (shown.isEmpty()) Column(Modifier.padding(24.dp)) {
                        Text("Hiç yüz ya da nesne bulunamadı.")
                        if (Engine.summary.isNotEmpty()) Text(Engine.summary, style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
                    } else Column(Modifier.fillMaxSize()) {
                        Column(Modifier.padding(horizontal = 16.dp, vertical = 4.dp)) {
                            var showThr by remember { mutableStateOf(false) }
                            val people = shown.filter { !it.obj }
                            val animCount by animateIntAsState(people.size, tween(700), label = "people")
                            val facesTotal = people.sumOf { it.count }
                            val objGroups = shown.size - people.size
                            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                                // Canlı sayaç kartı: kişi sayısı sayılarak yükselir
                                Row(Modifier.weight(1f).clip(RoundedCornerShape(18.dp))
                                    .background(Brush.horizontalGradient(listOf(Color(0xFF7E57C2), Color(0xFF5E35B1), Color(0xFF3949AB))))
                                    .padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Filled.Face, null, tint = Color.White, modifier = Modifier.size(34.dp))
                                    Spacer(Modifier.width(10.dp))
                                    Text("$animCount", color = Color.White, fontSize = 38.sp, fontWeight = FontWeight.ExtraBold)
                                    Spacer(Modifier.width(8.dp))
                                    Column {
                                        Text("kişi bulundu", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                        Text("$facesTotal yüz" + (if (objGroups > 0) " • $objGroups nesne grubu" else "") + " • ${vm.current?.total ?: 0} fotoğraf", color = Color(0xCCFFFFFF), fontSize = 12.sp)
                                    }
                                }
                                // Benzerlik eşiği: simge + başlık, dokununca ayar penceresi
                                OutlinedButton(onClick = { showThr = true }, shape = RoundedCornerShape(16.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 10.dp)) {
                                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                        Icon(Icons.Filled.Settings, null, modifier = Modifier.size(22.dp))
                                        Text("Benzerlik", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                                        Text(if (vm.autoThr >= 0.70f) "kapalı" else "%.2f".format(vm.autoThr), fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                            if (showThr) AlertDialog(onDismissRequest = { showThr = false },
                                icon = { Icon(Icons.Filled.Settings, null) },
                                title = { Text("Benzerlik eşiği") },
                                text = {
                                    Column {
                                        Text(if (vm.autoThr >= 0.70f) "Otomatik birleştirme kapalı • ${people.size} kişi"
                                            else "${"%.2f".format(vm.autoThr)} → ${people.size} kişi", fontWeight = FontWeight.Bold)
                                        Slider(value = vm.autoThr, onValueChange = { vm.autoThr = it; vm.picks = emptySet() }, valueRange = 0.15f..0.70f)
                                        Text("Düşük = aynı kişiyi daha çok birleştirir, yüksek = daha ayrı tutar.", style = MaterialTheme.typography.bodySmall)
                                    }
                                },
                                confirmButton = { TextButton(onClick = { showThr = false }) { Text("Tamam") } },
                                dismissButton = { TextButton(onClick = { vm.autoThr = 0.25f; vm.picks = emptySet() }) { Text("0,25'e sıfırla") } })
                            val editedN = shown.sumOf { it.edited.size }
                            if (editedN > 0) Button(onClick = { vm.openEditedAll(shown) }, Modifier.fillMaxWidth(), shape = RoundedCornerShape(14.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32), contentColor = Color.White)) {
                                Text("Düzenlenenler ($editedN fotoğraf) • netleştirilen / kırpılan", fontWeight = FontWeight.SemiBold)
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                if (vm.autoThr < 0.70f) Button(onClick = { vm.commit(shown) }) { Text("Bu hâliyle kaydet") }
                                if (vm.picks.isNotEmpty()) {
                                    Button(onClick = { vm.mergePicked() }, enabled = vm.picks.size >= 2) { Text("Birleştir (${vm.picks.size})") }
                                    OutlinedButton(onClick = { vm.picks = emptySet() }) { Text("Seçimi bırak") }
                                }
                            }
                            if (vm.picks.isEmpty() && vm.autoThr >= 0.70f)
                                Text("Aynı kişinin gruplarını elle birleştirmek için uzun basıp seçin.", style = MaterialTheme.typography.bodySmall)
                        }
                        LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), contentPadding = PaddingValues(12.dp),
                            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            itemsIndexed(shown) { idx, c ->
                                val on = c.id in vm.picks
                                Column(Modifier.combinedClickable(
                                    onClick = {
                                        if (vm.picks.isNotEmpty()) vm.picks = if (on) vm.picks - c.id else vm.picks + c.id
                                        else vm.openCluster(c)
                                    },
                                    onLongClick = { vm.picks = if (on) vm.picks - c.id else vm.picks + c.id }),
                                    horizontalAlignment = Alignment.CenterHorizontally) {
                                    AsyncImage(File(c.thumb), null,
                                        Modifier.size(96.dp).clip(CircleShape).then(if (on) Modifier.border(4.dp, MaterialTheme.colorScheme.primary, CircleShape) else Modifier),
                                        contentScale = ContentScale.Crop)
                                    Text(clusterLabel(c, idx), style = MaterialTheme.typography.titleSmall)
                                    Text("${c.photos.size} fotoğraf", style = MaterialTheme.typography.bodySmall)
                                }
                            }
                            val edited = shown.withIndex().filter { it.value.edited.isNotEmpty() }
                            if (edited.isNotEmpty()) {
                                item(span = { GridItemSpan(maxLineSpan) }) {
                                    Text("Düzenlenenler", style = MaterialTheme.typography.titleMedium, modifier = Modifier.padding(top = 8.dp))
                                }
                                items(edited) { iv ->
                                    val c = iv.value
                                    Column(Modifier.clickable { vm.openEdited(c) }, horizontalAlignment = Alignment.CenterHorizontally) {
                                        AsyncImage(File(c.thumb), null, Modifier.size(96.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                                        Text(clusterLabel(c, iv.index) + " (2)", style = MaterialTheme.typography.titleSmall)
                                        Text("${c.edited.size} fotoğraf", style = MaterialTheme.typography.bodySmall)
                                    }
                                }
                            }
                        }
                    }
                }
                Screen.Photos -> PhotosScreen(vm)
                Screen.PickEdit -> EditPickScreen(vm)
                Screen.PickFacePhoto -> PickFacePhotoScreen(vm)
                Screen.Viewer -> ViewerScreen(vm)
                Screen.Crop -> CropScreen(vm)
                Screen.Settings -> if (settingsOk || !Vault.isSet(ctx)) SettingsScreen(vm) { modelPicker.launch(arrayOf("*/*")) }
                    else UnlockDialog("Ayarları açmak için doğrulayın", onSuccess = { settingsOk = true }, onCancel = { vm.screen = Screen.Main })
            }
            // Taşıma bilgisi: sağ üst köşede küçük kart (hedef klasör, aşama, dolan önizleme + yüzde)
            vm.moveInfo?.let { MoveBadge(it, Modifier.align(Alignment.TopEnd).padding(10.dp)) }
        }
        }
    }
    if (vm.enhancing) AlertDialog(onDismissRequest = {}, title = { Text("Netleştiriliyor…") },
        text = {
            Column {
                GreenProgress(vm.enhanceDone.toFloat() / vm.enhanceTotal.coerceAtLeast(1))
                Text("${vm.enhanceDone} / ${vm.enhanceTotal}", modifier = Modifier.padding(top = 8.dp))
            }
        }, confirmButton = {})
    if (vm.askDeleteSaved) AlertDialog(onDismissRequest = { vm.askDeleteSaved = false },
        title = { Text("Emin misiniz?") },
        text = { Text("Seçili ${vm.savedSel.size} kayıtlı sonuç silinecek. Fotoğraflarına dokunulmaz; yalnızca programın kendi kayıtları ve küçük yüz resimleri silinir.") },
        confirmButton = {
            Button(onClick = { if (Vault.isSet(ctx)) unlockDelete = true else vm.deleteSelectedSaved() },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE53935), contentColor = Color.White)) { Text("Evet") }
        },
        dismissButton = {
            Button(onClick = { vm.askDeleteSaved = false },
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF43A047), contentColor = Color.White)) { Text("Hayır") }
        })
    if (unlockDelete) UnlockDialog("Kayıtları silmek için doğrulayın", onSuccess = { unlockDelete = false; vm.deleteSelectedSaved() }, onCancel = { unlockDelete = false })
    RestoreAskDialog(vm)
    if (vm.askModel && !vm.modelReady) AlertDialog(onDismissRequest = { vm.askModel = false },
        title = { Text("Yüz tanıma modeli gerekli") },
        text = { Text("Telefonda kayıtlı model otomatik bulunamadı.\n\nDaha önce indirdiysen Download/FotoLiz klasöründeki FotoLiz_arcface_model.onnx dosyasını seç; yeniden indirmen gerekmez ve bir daha sorulmaz.\n\nİlk kez kullanıyorsan indir (~174 MB, tek seferlik).") },
        confirmButton = { Button(onClick = { vm.askModel = false; modelPicker.launch(arrayOf("*/*")) }) { Text("Dosyayı seç") } },
        dismissButton = { TextButton(onClick = { vm.askModel = false; vm.downloadModel() }) { Text("İndir") } })
    // Daha önce yarıda kesilmiş analiz: devam edilsin mi?
    vm.askResume?.let { p ->
        AlertDialog(onDismissRequest = { vm.askResume = null },
            title = { Text("Yarım kalan analiz") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("“${p.name}” analizi daha önce yarıda kesildi, tamamlanmadı (${p.done} / ${p.total} fotoğraf işlendi). Kaldığı yerden devam edilsin mi?")
                    OutlinedButton(onClick = { vm.restartPending(p) }, Modifier.fillMaxWidth()) { Text("Baştan başla") }
                    OutlinedButton(onClick = { vm.discardPending(p) }, Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Yarım kaydı sil") }
                }
            },
            confirmButton = { Button(onClick = { vm.resumePending(p) }) { Text("Devam et") } },
            dismissButton = { TextButton(onClick = { vm.askResume = null }) { Text("Vazgeç") } })
    }
    vm.askFor?.let { r ->
        AlertDialog(onDismissRequest = { vm.askFor = null },
            title = { Text("Bu klasör daha önce analiz edilmiş") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(savedAlbumInfo(r).let { "${it.first} albüm: ${it.second}" } + " • ${r.clusters.count { !it.obj }} kişi • ${r.total} fotoğraf • ${DateFormat.getDateTimeInstance().format(Date(r.time))}")
                    // Kayıtlı sonuçtan görsel önizleme: ilk yüzler
                    val thumbs = r.clusters.filter { !it.obj && it.thumb.isNotBlank() && File(it.thumb).exists() }.take(5)
                    if (thumbs.isNotEmpty()) Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        thumbs.forEach { AsyncImage(File(it.thumb), null, Modifier.size(48.dp).clip(CircleShape), contentScale = ContentScale.Crop) }
                    }
                    Text("Kayıtlı sonucu açarsan yeniden analiz gerekmez; yaptığın işlemler korunur. (Yeniden analiz uzun sürebilir.)", style = MaterialTheme.typography.bodySmall)
                }
            },
            confirmButton = { Button(onClick = { vm.useSaved(r) }) { Text("Kayıtlıyı aç") } },
            dismissButton = { TextButton(onClick = { vm.reanalyze() }) { Text("Yeniden analiz et") } })
    }
}

/**
 * Analiz sürerken ana ekranın en üstündeki bilgi kartı.
 *  - Her 6 saniyede bir, temanın karşıt rengine (inverseSurface) bir kez yanıp söner: dikkat çeker.
 *  - Kartın en altında temaya uygun (primary) ilerleme çubuğu analizin seviyesini gösterir.
 */
@Composable
fun AnalysisCard(modifier: Modifier = Modifier) {
    val cs = MaterialTheme.colorScheme
    val flash = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(6000)
            flash.animateTo(1f, tween(350))
            flash.animateTo(0f, tween(550))
        }
    }
    val f = flash.value
    val bg = androidx.compose.ui.graphics.lerp(cs.surfaceVariant, cs.inverseSurface, f)
    val fg = androidx.compose.ui.graphics.lerp(cs.onSurfaceVariant, cs.inverseOnSurface, f)
    val frac = (Engine.done.toFloat() / Engine.total.coerceAtLeast(1)).coerceIn(0f, 1f)
    val anim by androidx.compose.animation.core.animateFloatAsState(frac, tween(400), label = "mainProgress")
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = bg, contentColor = fg)) {
        Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 16.dp, bottom = 12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Analiz sürüyor…", style = MaterialTheme.typography.titleSmall, color = fg, modifier = Modifier.weight(1f))
                Text("%${(anim * 100).toInt()}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = fg)
            }
            Text(Engine.status, style = MaterialTheme.typography.bodySmall, color = fg)
            // Geçen / kalan süre: her saniye kendini yeniler
            var nowMs by remember { mutableStateOf(System.currentTimeMillis()) }
            LaunchedEffect(Unit) { while (true) { nowMs = System.currentTimeMillis(); kotlinx.coroutines.delay(1000) } }
            val elapsed = if (Engine.startMs > 0) ((nowMs - Engine.startMs) / 1000).coerceAtLeast(0) else 0L
            Text("Geçen süre: ${Engine.fmt(elapsed)} • Kalan süre: ${if (Engine.etaSec >= 0) Engine.fmt(Engine.etaSec) else "hesaplanıyor…"}",
                style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = fg)
            Spacer(Modifier.height(10.dp))
            // En altta tema renginde ilerleme çubuğu; yanıp sönerken çubuk da karşıt renge uyar
            LinearProgressIndicator(progress = { anim }, modifier = Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = androidx.compose.ui.graphics.lerp(cs.primary, cs.inversePrimary, f),
                trackColor = fg.copy(alpha = 0.22f), strokeCap = androidx.compose.ui.graphics.StrokeCap.Round)
        }
    }
}

/** Analiz bitti, sonuca henüz bakılmadı: yeşil kart, 3 saniyede bir yanıp sönerek uyarır. Dokununca sonuç açılır. */
@Composable
fun ResultReadyCard(modifier: Modifier = Modifier, onOpen: () -> Unit) {
    val flash = remember { androidx.compose.animation.core.Animatable(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            kotlinx.coroutines.delay(3000)
            flash.animateTo(1f, tween(250))
            flash.animateTo(0f, tween(450))
        }
    }
    val f = flash.value
    val bg = androidx.compose.ui.graphics.lerp(Color(0xFF2E7D32), Color(0xFF81C784), f)
    val fg = androidx.compose.ui.graphics.lerp(Color.White, Color(0xFF0B3D0B), f)
    Card(modifier.fillMaxWidth().clickable { onOpen() }, shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = bg, contentColor = fg)) {
        Column(Modifier.padding(16.dp)) {
            Text("Analiz bitti ✓", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = fg)
            Text(Engine.doneText.ifBlank { "Sonucu görmek için dokun." }, style = MaterialTheme.typography.bodySmall, color = fg)
            Text("Sonucu görmek için dokun", style = MaterialTheme.typography.labelSmall, color = fg)
        }
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun MainScreen(vm: VM, pick: () -> Unit, pickModel: () -> Unit, pickPhoto: () -> Unit, pickAlbums: () -> Unit, pickPhotoForSaved: () -> Unit) {
    val ctx = LocalContext.current
    val ver = remember { try { ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName } catch (e: Exception) { "?" } }
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(start = 16.dp, end = 16.dp, top = 0.dp, bottom = 16.dp)) {
        if (Engine.running) AnalysisCard(Modifier.padding(bottom = 12.dp).clickable { vm.screen = Screen.Scanning })
        else Engine.unseenKey?.let { uk ->
            ResultReadyCard(Modifier.padding(bottom = 12.dp)) {
                val r = vm.saved.firstOrNull { it.key == uk }
                if (r != null) vm.useSaved(r) else Engine.setUnseen(ctx, null)
            }
        }
        SearchBox(vm, pickAlbums)
        // "Albümlerden seç": nesne aramanın hemen altında
        PrimaryAction("Albümlerden seç • kişi ve nesne gruplama", { vm.searchMode = false; vm.searchPickOnly = false; vm.personMode = false; pickAlbums() }, enabled = vm.modelReady, icon = Icons.Filled.Face,
            modifier = Modifier.padding(bottom = 14.dp))
        PersonBox(vm, pickPhoto, pickAlbums)
        if (!vm.modelReady) {
            Text(vm.modelMsg ?: "Yüz tanıma modeli hazırlanıyor…", color = if (vm.downloading) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.error)
            if (vm.downloading) {
                if (vm.modelProgress > 0f) LinearProgressIndicator(progress = { vm.modelProgress }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
                else LinearProgressIndicator(modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp))
            } else {
                OutlinedButton(onClick = { vm.downloadModel() }, Modifier.fillMaxWidth().padding(vertical = 8.dp)) { Text("Tekrar dene") }
                TextButton(onClick = pickModel, Modifier.fillMaxWidth()) { Text("Daha önce kaydedilen modeli dosyadan seç (Download/FotoLiz)") }
            }
        }
        FaceOrder.ensure(LocalContext.current)
        val faces = remember(vm.saved, Celebs.items, Engine.found, FaceOrder.version) { collectFaces(vm.saved.filter { it.key in Engine.found }) }
        if (faces.isNotEmpty()) Column(Modifier.padding(top = 14.dp)) { FacesPreviewCard(faces) { vm.screen = Screen.Faces } }
        if (vm.loadingDirs) Text("Klasörler okunuyor…", modifier = Modifier.padding(top = 8.dp))
        (vm.error ?: Engine.error)?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 12.dp)) }
        // Düzenlenenler önizlemesi (ilk 6 fotoğraf); herhangi bir yerine dokununca hepsi açılır
        EditedPreview(vm)
        // Kaydedilen yüzler (sürükleyerek sırala, dokununca ad gir)
        Column(Modifier.padding(top = 24.dp)) { SavedFacesCard(vm, pickPhotoForSaved, onCelebs = { vm.screen = Screen.Celebs }) }
        if (vm.saved.isNotEmpty() || vm.pending.isNotEmpty()) {
            // Başlığın yanında mercek: yazdıkça albüm ismine göre süzer
            var savedQuery by remember { mutableStateOf("") }
            var showReport by remember { mutableStateOf(false) }
            Row(Modifier.fillMaxWidth().padding(top = 24.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Kayıtlı sonuçlar", style = MaterialTheme.typography.titleMedium)
                FieldBox(savedQuery, { savedQuery = it }, "Albüm ara", Icons.Filled.Search, Modifier.weight(1f))
                TonalAction("Rapor", { showReport = true }, h = 40.dp)
            }
            if (showReport) ReportDialog(vm) { showReport = false }
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Yarıda kesilmiş (tamamlanmamış) analizler: dokununca "devam edilsin mi?" sorulur
                vm.pending.forEach { p ->
                    // Yarıda kesilmiş analiz: kırmızı kart, 0.5 sn'de bir yanıp sönen kırmızı ışık
                    var lit by remember { mutableStateOf(true) }
                    LaunchedEffect(Unit) { while (true) { delay(500); lit = !lit } }
                    Card(Modifier.fillMaxWidth().clickable { vm.askResume = p }, shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF7A1F2B), contentColor = Color.White)) {
                        Column(Modifier.padding(16.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(Modifier.size(14.dp).clip(CircleShape).background(if (lit) Color(0xFFFF1744) else Color(0xFF3A0A10)))
                                Spacer(Modifier.width(10.dp))
                                Text(p.name, style = MaterialTheme.typography.titleSmall, modifier = Modifier.weight(1f), maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                            }
                            Text("Yarım kaldı • ${p.done} / ${p.total} fotoğraf • ${DateFormat.getDateTimeInstance().format(Date(p.time))}", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 4.dp))
                            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.Bottom) {
                                Text("Dokununca devam edilebilir", style = MaterialTheme.typography.labelSmall, modifier = Modifier.weight(1f))
                                Text("YARIDA KESİLDİ", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.ExtraBold, color = Color(0xFFFF8A80))
                            }
                        }
                    }
                }
                // Pencere: aynı anda en çok 10 kayıt görünür; fazlası yukarı / aşağı kaydırılır
                val q = savedQuery.trim()
                val shown = vm.saved.withIndex().filter { (_, r) ->
                    q.isEmpty() || savedAlbumInfo(r).second.contains(q, ignoreCase = true)
                }
                if (shown.isEmpty() && q.isNotEmpty()) Text("“$q” ile eşleşen albüm yok.", style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
                val rowH = 64.dp; val gap = 6.dp
                Column(Modifier.fillMaxWidth().heightIn(max = rowH * 10 + gap * 9).verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(gap)) {
                    shown.forEach { (idx, r) ->
                        val on = r.key in vm.savedSel
                        val selMode = vm.savedSel.isNotEmpty()
                        // Basılı tut = seçim modunu başlat; seçim modunda dokunmak seç/bırak yapar
                        Card(Modifier.fillMaxWidth().height(rowH).combinedClickable(
                                onClick = { if (selMode) vm.toggleSaved(r) else vm.openSaved(r) },
                                onLongClick = { vm.toggleSaved(r) }),
                            shape = RoundedCornerShape(12.dp),
                            colors = if (on) CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
                                     else CardDefaults.cardColors(containerColor = Color(0xFFA5CF92), contentColor = Color(0xFF14210E))) {   // koyu çağla yeşili: tamamlananlar
                            Row(Modifier.fillMaxSize().padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
                                if (selMode) { Checkbox(checked = on, onCheckedChange = { vm.toggleSaved(r) }, modifier = Modifier.size(32.dp)); Spacer(Modifier.width(6.dp)) }
                                Column(Modifier.weight(1f), verticalArrangement = Arrangement.Center) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(Modifier.weight(1f)) { SavedResultTitle(idx + 1, r) }
                                        // En üstteki (en yeni) kaydın sağ üst köşesi
                                        if (idx == 0) Text("SON ANALİZ", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, maxLines = 1,
                                            modifier = Modifier.padding(start = 6.dp).clip(RoundedCornerShape(6.dp)).background(Color(0xFFC62828)).padding(horizontal = 6.dp, vertical = 2.dp))
                                    }
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text("${r.clusters.size} kişi • ${r.total} fotoğraf • ${java.text.SimpleDateFormat("dd.MM.yy HH:mm", java.util.Locale.getDefault()).format(Date(r.time))}",
                                            style = MaterialTheme.typography.bodySmall, fontSize = 11.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
                                            modifier = Modifier.weight(1f))
                                        Text("TAMAMLANDI", fontSize = 10.sp, fontWeight = FontWeight.ExtraBold, color = Color(0xFF1F5214), maxLines = 1, softWrap = false,
                                            modifier = Modifier.padding(start = 6.dp))
                                    }
                                    // Alt satır, sağ son: analiz süresi
                                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                                        Text("Analiz Süre: ${if (r.durSec > 0) Engine.fmt(r.durSec) else "—"}", fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
                                            maxLines = 1, softWrap = false)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        // En altta: sürüm bilgisi
        Text("Sürüm $ver", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 16.dp))
    }
}

@Composable
fun SelectScreen(vm: VM) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = { vm.chosen = vm.subDirs.toSet() }) { Text("Hepsini seç") }
            OutlinedButton(onClick = { vm.chosen = emptySet() }) { Text("Hiçbiri") }
        }
        if (vm.subDirs.size <= 1) Text("Bu klasörde alt klasör bulunamadı. Galerideki albümler için ana ekrandan “Albümlerden seç”i kullanın.",
            modifier = Modifier.padding(16.dp))
        LazyColumn(Modifier.weight(1f)) {
            items(vm.subDirs) { n ->
                Row(Modifier.fillMaxWidth().clickable { vm.toggle(n) }.padding(horizontal = 16.dp, vertical = 2.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = n in vm.chosen, onCheckedChange = { vm.toggle(n) })
                    Text(if (n == ROOT) "Bu klasörün kendisindeki fotoğraflar" else n)
                }
            }
        }
        Button(onClick = { vm.startSelected() }, enabled = vm.chosen.isNotEmpty(),
            modifier = Modifier.fillMaxWidth().padding(16.dp)) { Text("Analiz başlat (${vm.chosen.size} seçili)") }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AlbumScreen(vm: VM) {
    LaunchedEffect(Unit) { vm.analysisFilter = "" }   // her açılışta seçim boş gelir
    var askDelAlbums by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize()) {
        // Düğmelerin üstünde: kaç albüm / klasör seçili
        Text("${vm.chosenAlbums.size} albüm / klasör seçili", Modifier.padding(start = 16.dp, end = 16.dp, top = 8.dp),
            style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 0.dp), horizontalArrangement = Arrangement.spacedBy(0.dp), verticalAlignment = Alignment.CenterVertically) {
            val tint = MaterialTheme.colorScheme.primary
            ActIcon(Ic.SelectAll, "Hepsini seç", tint, { vm.chosenAlbums = vm.albums.map { it.id }.toSet() })
            ActIcon(Ic.SelectNone, "Hiçbiri", tint, { vm.chosenAlbums = emptySet() })
            ActIcon(Ic.Delete, "Seçili albümleri sil", if (vm.chosenAlbums.isEmpty()) tint.copy(alpha = 0.3f) else MaterialTheme.colorScheme.error,
                { if (vm.chosenAlbums.isNotEmpty()) askDelAlbums = true })
            Spacer(Modifier.weight(1f))
            // Sağ üst: Sayı Girin. Rakam girilirse her seçili albümden yalnızca o kadar ilk fotoğraf analiz edilir; boşsa hepsi.
            CountField(vm.photoLimit, { vm.photoLimit = it }, Modifier.width(130.dp).padding(end = 8.dp))
        }
        if (askDelAlbums) {
            val n = vm.albums.filter { it.id in vm.chosenAlbums }.sumOf { it.count }
            AlertDialog(onDismissRequest = { askDelAlbums = false },
                title = { Text("Albümler silinsin mi?") },
                text = { Text("Seçili ${vm.chosenAlbums.size} albümdeki $n fotoğraf " +
                    (if (Build.VERSION.SDK_INT >= 30) "geri dönüşüm kutusuna atılacak (30 gün içinde geri alınabilir)." else "telefondan silinecek (Android 10'da geri dönüşüm yok).")) },
                confirmButton = { TextButton(onClick = { askDelAlbums = false; vm.trashAlbums(vm.chosenAlbums) }) { Text("Geri dönüşüme at", color = MaterialTheme.colorScheme.error) } },
                dismissButton = { TextButton(onClick = { askDelAlbums = false }) { Text("Vazgeç") } })
        }
        if (vm.albums.isEmpty()) Text("Hiç fotoğraf albümü bulunamadı. İznin “tüm fotoğraflar” olduğundan emin olun.", Modifier.padding(16.dp))
        LazyVerticalGrid(GridCells.Fixed(2), Modifier.weight(1f), contentPadding = PaddingValues(12.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            items(vm.albums) { a ->
                Column(Modifier.clickable { vm.toggleAlbum(a.id) }) {
                    Box {
                        AsyncImage(a.cover, null, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                        Checkbox(checked = a.id in vm.chosenAlbums, onCheckedChange = { vm.toggleAlbum(a.id) }, modifier = Modifier.align(Alignment.TopEnd))
                    }
                    Text(a.name, style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                    Text("${a.count} fotoğraf", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        if (vm.personMode) {
            (vm.error)?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp)) }
            Button(onClick = { vm.startPersonSearch() }, enabled = vm.chosenAlbums.isNotEmpty() && vm.refChoice != null,
                modifier = Modifier.fillMaxWidth().padding(16.dp)) { Text("Kişiyi ara (${vm.chosenAlbums.size} albüm)") }
        } else if (vm.searchMode && vm.searchPickOnly) {
            Button(onClick = { vm.searchPicked = true; vm.searchPickOnly = false; vm.screen = Screen.Main }, enabled = vm.chosenAlbums.isNotEmpty(),
                modifier = Modifier.fillMaxWidth().padding(16.dp)) { Text("Tamam (${vm.chosenAlbums.size} albüm)") }
        } else if (vm.searchMode) {
            (vm.error)?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(horizontal = 16.dp)) }
            Button(onClick = { vm.startSearch() }, enabled = vm.chosenAlbums.isNotEmpty() && vm.searchText.isNotBlank(),
                modifier = Modifier.fillMaxWidth().padding(16.dp)) { Text("“${vm.searchText.trim()}” ara (${vm.chosenAlbums.size} albüm)") }
        } else {
            Column(Modifier.padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("Analiz filtresi", style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    for ((k, label) in listOf("M" to "Erkek", "F" to "Kadın", "ALL" to "Erkek & Kadın", "OBJ" to "Nesne ismi"))
                        FilterChip(vm.analysisFilter == k, { vm.analysisFilter = if (vm.analysisFilter == k) "" else k },
                            { Text(label, maxLines = 1, fontSize = 11.sp, softWrap = false, modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center) },
                            Modifier.weight(1f))
                }
                if (vm.analysisFilter == "OBJ") {
                    FieldBox(vm.albumObjText, { vm.albumObjText = it }, "Nesne adı (örn. araba kedi)", Icons.Filled.Search, search = true, onSearch = { vm.startAlbumAnalysis() })
                    (vm.error)?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
                }
                Text(when (vm.analysisFilter) {
                    "M" -> "Yalnızca erkek yüzleri gruplanır. Cinsiyet cihazda tahmin edilir; belirsiz yüzler alınmaz."
                    "F" -> "Yalnızca kadın yüzleri gruplanır. Cinsiyet cihazda tahmin edilir; belirsiz yüzler alınmaz."
                    "OBJ" -> "Seçili albümlerde yazdığın nesnenin göründüğü fotoğrafları bulur (kelimeleri boşlukla ayır)."
                    "" -> "Filtre seçmezsen tüm yüzler (erkek ve kadın) taranır; yüzü olmayan fotoğraflar nesne adına göre gruplanır."
                    else -> "Tüm yüzler gruplanır (erkek ve kadın); yüzü olmayan fotoğraflar nesne adına göre gruplanır."
                }, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            Button(onClick = { vm.startAlbumAnalysis() }, enabled = vm.chosenAlbums.isNotEmpty() && (vm.analysisFilter != "OBJ" || vm.albumObjText.isNotBlank()),
                modifier = Modifier.fillMaxWidth().padding(16.dp)) { Text(if (vm.analysisFilter == "OBJ") "“${vm.albumObjText.trim()}” ara (${vm.chosenAlbums.size} albüm)" else "Analiz başlat (${vm.chosenAlbums.size} albüm)") }
        }
    }
}


/** Ana ekran: Düzenlenenler bölümü. 6 fotoğraf önizlenir; kartın herhangi bir yerine dokununca tüm düzenlenenler açılır. */
@Composable
fun EditedPreview(vm: VM) {
    val rv = vm.rev   // kişi gruplarındaki düzenlenenler değişince yenilensin
    val all = remember(vm.saved, vm.editedStandalone, vm.editedOrder, rv) { vm.allEdited() }
    Card(Modifier.fillMaxWidth().padding(top = 24.dp).clickable { vm.openEditedHub() }, shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Düzenlenenler" + if (all.isNotEmpty()) " (${all.size})" else "", style = MaterialTheme.typography.titleMedium)
            if (all.isEmpty()) Text("Henüz düzenlenen yok. Dokun, sağ üstten “Albümden seç” ile fotoğraf seçip netleştir.", style = MaterialTheme.typography.bodySmall)
            else for (row in all.take(6).chunked(3)) Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                for (u in row) AsyncImage(Uri.parse(u), null, Modifier.weight(1f).aspectRatio(1f).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}


/** Albüm taramasında kayıtlı ad "3 albüm • Erkek • A, B, C" biçimindedir; baştaki sayı / cinsiyet ekini atıp yalnızca klasör adlarını döndürür. */
private fun albumNamesOf(name: String): String {
    val m = Regex("^\\d+ albüm( • (Erkek|Kadın))? • ").find(name)
    return if (m != null) name.substring(m.range.last + 1) else name
}

/** Kayıtlı sonucun albüm sayısı ve klasör adları: ("3", "Kamera, WhatsApp, Download"). Başka hiçbir ek (cinsiyet, tarih, sayı tekrarı) yok. */
fun savedAlbumInfo(r: Result): Pair<Int, String> {
    val media = r.uri == "media"
    if (r.label.isNotBlank()) return Pair(r.sel.filter { !it.startsWith("~") }.size.coerceAtLeast(1), r.label)
    val folders = r.sel.filter { !it.startsWith("~") }
    return if (media) Pair(folders.size.coerceAtLeast(1), albumNamesOf(r.name))
    else {
        val root = r.name.substringBefore(" • ")
        Pair(folders.size.coerceAtLeast(1), if (folders.isEmpty()) root else folders.joinToString(", ") { if (it == ROOT) root else it })
    }
}

/** Kayıtlı sonuç başlığı: tek satır, her zaman "N albüm: Klasör1, Klasör2, ...". */
@Composable
fun SavedResultTitle(no: Int, r: Result) {
    val (count, names) = savedAlbumInfo(r)
    Text(androidx.compose.ui.text.buildAnnotatedString {
        withStyle(androidx.compose.ui.text.SpanStyle(fontWeight = FontWeight.ExtraBold)) { append("$no.  ") }
        withStyle(androidx.compose.ui.text.SpanStyle(fontWeight = FontWeight.ExtraBold, color = Color(0xFF0D47A1))) { append("$count albüm: ") }
        withStyle(androidx.compose.ui.text.SpanStyle(fontWeight = FontWeight.ExtraBold, color = Color(0xFFB34700))) { append(names) }
    }, style = MaterialTheme.typography.titleSmall, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
}


/** Başlık tek satıra sığar: sığmazsa yazı tipi küçülür (en fazla 12 sp'ye kadar), yine sığmazsa sonu "…" ile kesilir. */
@Composable
fun FitTitle(text: String, modifier: Modifier = Modifier) {
    var size by remember(text) { mutableStateOf(22f) }
    Text(text, modifier, fontSize = size.sp, maxLines = 1, softWrap = false, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
        onTextLayout = { if (it.hasVisualOverflow && size > 12f) size = (size - 1f).coerceAtLeast(12f) })
}


/** Tüm ekranlarda: parmağı SOLA kaydır = geri, SAĞA kaydır = ileri. İçerik (galeri sayfaları, yakınlaştırma, liste) hareketi kendisi kullanıyorsa karışmaz. */
fun Modifier.swipeNav(enabled: Boolean, onLeft: () -> Unit, onRight: () -> Unit): Modifier = pointerInput(enabled) {
    if (!enabled) return@pointerInput
    val need = 90.dp.toPx()
    awaitEachGesture {
        awaitFirstDown(requireUnconsumed = false, pass = PointerEventPass.Final)
        var dx = 0f; var dy = 0f; var bad = false
        while (true) {
            val ev = awaitPointerEvent(PointerEventPass.Final)
            if (ev.changes.size > 1) bad = true
            ev.changes.forEach { c ->
                val d = c.positionChange()
                if (d != androidx.compose.ui.geometry.Offset.Zero && c.isConsumed) bad = true
                dx += d.x; dy += d.y
            }
            if (ev.changes.none { it.pressed }) break
        }
        if (!bad && kotlin.math.abs(dx) > need && kotlin.math.abs(dx) > 2 * kotlin.math.abs(dy)) { if (dx < 0) onLeft() else onRight() }
    }
}


/** Bu oturumda "Gizle" ile kapatılan yarım kalan analiz anahtarları. */
private val hiddenPending = mutableStateListOf<String>()

/**
 * Yarım kalan (Durdur'la ya da kesintiyle yarıda kalmış) analiz varken her ekranın en üstünde görünen şerit.
 * "Devam et" kaldığı yerden sürdürür; şerit yazısına dokununca baştan başla / sil seçenekleri açılır. Ayrıca bildirim çubuğuna bildirim düşer.
 */
@Composable
private fun PendingBanner(vm: VM) {
    val ctx = LocalContext.current.applicationContext
    val p = vm.pending.firstOrNull()
    val live = p != null && !Engine.running
    LaunchedEffect(vm.pending.map { it.key + it.done }.joinToString(), Engine.running) {
        if (live && p != null) DoneSound.notifyPending(ctx, "“${p.name}” yarım kaldı • ${p.done} / ${p.total} • devam etmek için dokun") else DoneSound.cancelPending(ctx)
    }
    if (!live || p == null || p.key in hiddenPending) return
    if (vm.screen == Screen.Scanning || vm.screen == Screen.Crop || vm.screen == Screen.Viewer) return
    var lit by remember { mutableStateOf(true) }
    LaunchedEffect(Unit) { while (true) { delay(500); lit = !lit } }
    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 3.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF7A1F2B))
            .clickable { vm.askResume = p }.padding(start = 12.dp, end = 4.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(CircleShape).background(if (lit) Color(0xFFFF1744) else Color(0xFF3A0A10)))
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) {
            Text("Yarım kalan analiz" + (if (vm.pending.size > 1) " (+${vm.pending.size - 1})" else ""), color = Color(0xFFFF8A80), style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.ExtraBold)
            Text("${p.name} • ${p.done} / ${p.total}", color = Color.White, style = MaterialTheme.typography.bodySmall, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
        }
        Button(onClick = { vm.resumePending(p) }, contentPadding = PaddingValues(horizontal = 12.dp), modifier = Modifier.height(34.dp)) { Text("Devam et") }
        TextButton(onClick = { hiddenPending.add(p.key) }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Gizle", color = Color(0xFFFFCDD2)) }
    }
}
