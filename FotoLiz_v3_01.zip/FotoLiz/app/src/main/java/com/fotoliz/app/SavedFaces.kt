package com.fotoliz.app

import android.content.Context
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Star
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import kotlin.math.abs
import androidx.compose.ui.zIndex
import coil.compose.AsyncImage
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Kullanıcının "kaydedilen yüzler" bölümüne eklediği yüz: küçük resim + yüz vektörleri (aranabilsin diye) + ad. Liste sırası kullanıcının verdiği sıradır. */
class SavedFace(val id: String, var name: String, val file: String, val embs: List<FloatArray>)

object SavedFaces {
    private fun dir(ctx: Context) = File(ctx.filesDir, "savedfaces").apply { mkdirs() }
    private fun index(ctx: Context) = File(ctx.filesDir, "savedfaces.json")
    fun path(ctx: Context, f: SavedFace): String = File(dir(ctx), f.file).absolutePath

    fun load(ctx: Context): List<SavedFace> = try {
        val f = index(ctx)
        if (!f.exists()) emptyList() else parse(f.readText())
    } catch (e: Exception) { emptyList() }

    private fun parse(text: String): List<SavedFace> {
        val a = JSONObject(text).getJSONArray("faces")
        return (0 until a.length()).mapNotNull { i ->
            try {
                val o = a.getJSONObject(i)
                SavedFace(o.getString("id"), o.optString("name", ""), o.getString("file"), unpackReps(o.optString("e", ""), o.optInt("d", 512)))
            } catch (e: Exception) { null }
        }
    }

    fun save(ctx: Context, list: List<SavedFace>) {
        val a = JSONArray()
        for (f in list) a.put(JSONObject().put("id", f.id).put("name", f.name).put("file", f.file)
            .put("d", f.embs.firstOrNull()?.size ?: 512).put("e", packReps(f.embs)))
        index(ctx).writeText(JSONObject().put("faces", a).toString())
    }

    /** Küçük resmi kalıcı klasöre kopyalar (analiz kaydı silinse de yüz kalsın). */
    fun create(ctx: Context, thumbPath: String, embs: List<FloatArray>, name: String): SavedFace {
        val id = System.currentTimeMillis().toString() + "_" + (Math.random() * 1000).toInt()
        val fn = "$id.jpg"
        File(thumbPath).copyTo(File(dir(ctx), fn), overwrite = true)
        return SavedFace(id, name.trim(), fn, embs.take(9))
    }

    fun deleteFile(ctx: Context, f: SavedFace) { File(dir(ctx), f.file).delete() }

    /** Yedekten gelen listeyi birleştirir: yerelde olmayan yüzler sona eklenir. Eklenen sayıyı döndürür. */
    fun mergeFromJson(ctx: Context, json: String): Int {
        val have = load(ctx); val ids = have.map { it.id }.toSet()
        val add = parse(json).filter { it.id !in ids && File(dir(ctx), it.file).exists() }
        if (add.isNotEmpty()) save(ctx, have + add)
        return add.size
    }
}

/** Ana ekranın en altındaki "Kaydedilen yüzler" bölümü. Basılı tutup sürükleyerek sıra değişir, dokununca ad girilir. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SavedFacesCard(vm: VM, addFromPhoto: () -> Unit, onCelebs: () -> Unit = {}) {
    val ctx = LocalContext.current
    val faces = vm.savedFaces
    var edit by remember { mutableStateOf<SavedFace?>(null) }
    var preview by remember { mutableStateOf<SavedFace?>(null) }
    var askDelete by remember { mutableStateOf<SavedFace?>(null) }
    var unlock by remember { mutableStateOf<SavedFace?>(null) }
    var full by remember { mutableStateOf(false) }   // "Kaydedilen yüzler" penceresinin başlığı: tam ekran, her sırada 5 yüz
    val celebs = Celebs.items
    SectionCard(Icons.Filled.Face, "Kaydedilen yüzler", "Son eklenen 6 yüz • A'dan Z'ye • dokunursan hepsi açılır", compact = true) {
        // Ekranı ortadan böl: solda Kaydedilen yüzler, sağda Ünlüler. Her pencerede en son eklenen 6 yüz, kendi içinde A-Z sıralı.
        val savedShown = remember(faces) { latestSix(faces) { it.name } }
        val celebShown = remember(celebs) { latestSix(celebs) { it.name } }
        Row(Modifier.fillMaxWidth().height(IntrinsicSize.Min), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FaceWindow("Kaydedilen yüzler", faces.size, savedShown.map { MiniFace(it.name, File(SavedFaces.path(ctx, it))) },
                onHeader = { full = true }, onTap = { preview = savedShown[it] }, onLong = { edit = savedShown[it] },
                modifier = Modifier.weight(1f).fillMaxHeight())
            FaceWindow("Ünlüler", celebs.size, celebShown.map { MiniFace(it.name, File(Celebs.path(ctx, it))) },
                onHeader = onCelebs, onTap = { vm.openCeleb(celebShown[it]) }, onLong = { onCelebs() },
                modifier = Modifier.weight(1f).fillMaxHeight())
        }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            TonalAction("Fotoğraftan ekle", addFromPhoto, Modifier.weight(1f), enabled = vm.modelReady && !vm.detecting, icon = Icons.Filled.Face, h = 40.dp)
            TonalAction("Bulunanlardan ekle", { vm.addFromFound() }, Modifier.weight(1f), icon = Icons.Filled.Person, h = 40.dp)
        }
    }
    if (full) {
        Dialog(onDismissRequest = { full = false }, properties = DialogProperties(usePlatformDefaultWidth = false, decorFitsSystemWindows = true)) {
            Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                Column(Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding()) {
                    Row(Modifier.fillMaxWidth().padding(start = 16.dp, end = 8.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text("Kaydedilen yüzler (${faces.size})", style = MaterialTheme.typography.titleLarge, modifier = Modifier.weight(1f))
                        TextButton(onClick = { full = false }) { Text("Kapat") }
                    }
                    Text("Fotoğrafa dokununca tam ekran • isme basılı tutunca ad değişir • fotoğrafa basılı tutup sürükleyince sıra değişir", style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp))
                    Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 10.dp, vertical = 8.dp)) {
                        if (faces.isEmpty()) Text("Henüz kaydedilen yüz yok.", style = MaterialTheme.typography.bodyMedium)
                        else DraggableFaces(faces, ctx, onMove = { a, b -> vm.moveSavedFace(a, b) }, onTap = { preview = it }, onLongPress = { edit = it }, cols = 5)
                    }
                }
            }
        }
    }
    preview?.let { f ->
        Dialog(onDismissRequest = { preview = null }, properties = DialogProperties(usePlatformDefaultWidth = false)) {
            Box(Modifier.fillMaxSize().background(Color.Black).clickable { preview = null }, contentAlignment = Alignment.Center) {
                AsyncImage(File(SavedFaces.path(ctx, f)), null, Modifier.fillMaxWidth(), contentScale = ContentScale.Fit)
                if (f.name.isNotBlank()) Text(f.name, color = Color.White, style = MaterialTheme.typography.titleLarge,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(32.dp))
            }
        }
    }
    edit?.let { f ->
        var text by remember(f.id) { mutableStateOf(f.name) }
        AlertDialog(onDismissRequest = { edit = null }, title = { Text("Kaydedilen yüz") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    AsyncImage(File(SavedFaces.path(ctx, f)), null, Modifier.size(88.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                    FieldBox(text, { text = it }, "Ad (yüzün altında görünür)", Icons.Filled.Person)
                    TonalAction("Bu kişiyi albümlerde ara", { val x = f; edit = null; vm.searchWithSaved(x) }, Modifier.fillMaxWidth(), icon = Icons.Filled.Search)
                    OutlinedButton(onClick = { askDelete = f; edit = null }, Modifier.fillMaxWidth(),
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)) { Text("Listeden kaldır") }
                }
            },
            confirmButton = { TextButton(onClick = { vm.renameSavedFace(f, text); edit = null }) { Text("Kaydet") } },
            dismissButton = { TextButton(onClick = { edit = null }) { Text("Vazgeç") } })
    }
    askDelete?.let { f ->
        AlertDialog(onDismissRequest = { askDelete = null }, title = { Text("Emin misiniz?") },
            text = { Text("“${f.name.ifBlank { "Adsız" }}” kaydedilen yüzlerden kaldırılır. Fotoğraflarına ve analiz kayıtlarına dokunulmaz.") },
            confirmButton = {
                Button(onClick = { if (Vault.isSet(ctx)) { unlock = f; askDelete = null } else { vm.removeSavedFace(f); askDelete = null } },
                    colors = ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color(0xFFE53935), contentColor = androidx.compose.ui.graphics.Color.White)) { Text("Evet") }
            },
            dismissButton = {
                Button(onClick = { askDelete = null },
                    colors = ButtonDefaults.buttonColors(containerColor = androidx.compose.ui.graphics.Color(0xFF43A047), contentColor = androidx.compose.ui.graphics.Color.White)) { Text("Hayır") }
            })
    }
    unlock?.let { f -> UnlockDialog("Yüzü kaldırmak için doğrulayın", onSuccess = { vm.removeSavedFace(f); unlock = null }, onCancel = { unlock = null }) }
}

private class MiniFace(val name: String, val file: File)

private val trCollator: java.text.Collator = java.text.Collator.getInstance(java.util.Locale("tr", "TR"))

/** Listenin en son eklenen 6 öğesi; kendi içinde A'dan Z'ye (adsızlar sona). Listeye yeni öğeler sona eklendiği için son 6 = en yeni 6. */
private fun <T> latestSix(list: List<T>, name: (T) -> String): List<T> =
    list.takeLast(6).sortedWith(Comparator { a, b ->
        val x = name(a).trim(); val y = name(b).trim()
        when { x.isEmpty() && y.isEmpty() -> 0; x.isEmpty() -> 1; y.isEmpty() -> -1; else -> trCollator.compare(x, y) }
    })

/** Ana ekrandaki yarım genişlikli pencere: herhangi bir yerine dokununca tümü açılır + 3x2 = 6 yüz önizlemesi. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FaceWindow(title: String, count: Int, faces: List<MiniFace>, onHeader: () -> Unit, onTap: (Int) -> Unit, onLong: (Int) -> Unit, modifier: Modifier = Modifier) {
    // Pencerenin herhangi bir yerine (başlık, boşluk, yüzler) dokununca tüm yüzlerin olduğu sayfa açılır
    Card(modifier.clip(RoundedCornerShape(12.dp)).clickable { onHeader() }, shape = RoundedCornerShape(12.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
        Column(Modifier.padding(6.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Column(Modifier.fillMaxWidth().padding(2.dp)) {
                Text(title, fontWeight = FontWeight.Bold, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text("$count", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary, maxLines = 1)
            }
            if (faces.isEmpty()) Box(Modifier.fillMaxWidth().height(96.dp), contentAlignment = Alignment.Center) {
                Text("Henüz yok", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            } else faces.chunked(3).forEachIndexed { r, row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    row.forEachIndexed { c, f ->
                        val i = r * 3 + c
                        Column(Modifier.weight(1f).combinedClickable(onClick = { onHeader() }, onLongClick = { onLong(i) }), horizontalAlignment = Alignment.CenterHorizontally) {
                            AsyncImage(f.file, null, Modifier.fillMaxWidth().aspectRatio(1f).clip(CircleShape), contentScale = ContentScale.Crop)
                            Text(f.name.ifBlank { "İsim ekle" }, fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth(),
                                color = if (f.name.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface)
                        }
                    }
                    repeat(3 - row.size) { Spacer(Modifier.weight(1f)) }
                }
            }
        }
    }
}

/** 3 sütunlu, uzun basınca sürüklenebilen yüz ızgarası. Bırakılan yer hangi hücreye denk geliyorsa oraya taşınır. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun DraggableFaces(faces: List<SavedFace>, ctx: Context, onMove: (Int, Int) -> Unit, onTap: (SavedFace) -> Unit, onLongPress: (SavedFace) -> Unit, cols: Int = 3) {
    val space = if (cols > 3) 6.dp else 10.dp
    val gap = with(LocalDensity.current) { space.toPx() }
    var dragId by remember { mutableStateOf<String?>(null) }
    var dx by remember { mutableStateOf(0f) }
    var dy by remember { mutableStateOf(0f) }
    var cw by remember { mutableStateOf(1f) }
    var chh by remember { mutableStateOf(1f) }
    val count by rememberUpdatedState(faces.size)
    val move by rememberUpdatedState(onMove)
    val longPress by rememberUpdatedState(onLongPress)
    Column(verticalArrangement = Arrangement.spacedBy(space)) {
        faces.chunked(cols).forEachIndexed { r, row ->
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(space)) {
                row.forEachIndexed { c, f ->
                    key(f.id) {
                        val idx = r * cols + c
                        val curIdx by rememberUpdatedState(idx)
                        val dragging = dragId == f.id
                        Column(Modifier.weight(1f)
                            .onSizeChanged { cw = it.width + gap; chh = it.height + gap }
                            .zIndex(if (dragging) 1f else 0f)
                            .graphicsLayer {
                                translationX = if (dragging) dx else 0f; translationY = if (dragging) dy else 0f
                                scaleX = if (dragging) 1.12f else 1f; scaleY = if (dragging) 1.12f else 1f; alpha = if (dragging) 0.85f else 1f
                            },
                            horizontalAlignment = Alignment.CenterHorizontally) {
                            AsyncImage(File(SavedFaces.path(ctx, f)), null, Modifier.fillMaxWidth().aspectRatio(1f).clip(CircleShape)
                                .clickable { onTap(f) }
                                .pointerInput(f.id) {
                                detectDragGesturesAfterLongPress(
                                    onDragStart = { dragId = f.id; dx = 0f; dy = 0f },
                                    onDrag = { change, amount -> change.consume(); dx += amount.x; dy += amount.y },
                                    onDragEnd = {
                                        val n = count; val rowsN = (n + cols - 1) / cols
                                        val from = curIdx
                                        val col = ((((from % cols) + 0.5f) * cw + dx) / cw).toInt().coerceIn(0, cols - 1)
                                        val rw = ((((from / cols) + 0.5f) * chh + dy) / chh).toInt().coerceIn(0, rowsN - 1)
                                        val to = (rw * cols + col).coerceIn(0, n - 1)
                                        val still = abs(dx) < 24f && abs(dy) < 24f   // sürüklenmeden bırakıldı: ad düzenleme
                                        dragId = null; dx = 0f; dy = 0f
                                        if (still) longPress(f) else if (to != from) move(from, to)
                                    },
                                    onDragCancel = { dragId = null; dx = 0f; dy = 0f })
                                }, contentScale = ContentScale.Crop)
                            Text(f.name.ifBlank { "İsim ekle" }, style = if (cols > 3) MaterialTheme.typography.labelSmall else MaterialTheme.typography.labelLarge, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth().padding(top = 4.dp).combinedClickable(onClick = { onTap(f) }, onLongClick = { longPress(f) }),
                                color = if (f.name.isBlank()) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
                repeat(cols - row.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}
