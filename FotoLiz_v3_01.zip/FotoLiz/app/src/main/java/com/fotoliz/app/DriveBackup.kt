package com.fotoliz.app

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.work.*
import com.google.android.gms.auth.api.identity.AuthorizationRequest
import com.google.android.gms.auth.api.identity.AuthorizationResult
import com.google.android.gms.auth.api.identity.Identity
import com.google.android.gms.common.api.Scope
import com.google.android.gms.tasks.Tasks
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

/**
 * Google Drive yedeği.
 *  - Yedek: ayarlar + analiz kayıtları + bulunan yüzlerin küçük resimleri + kaydedilen yüzler tek zip dosyasında.
 *  - Ad: FOTOLIZYEDEK.zip (tek dosya). Klasörde yedek varsa içeriği ÜZERİNE YAZILIR; yeni dosya oluşturulmaz (eski tarihli adlar da bu ada çevrilir).
 *  - Otomatik: WorkManager zinciri, her 10 dakikada bir (uygulama kapalı olsa da). Veri değişmemişse yükleme atlanır.
 *  - Kapsam drive (tam): Drive'daki istenen klasör seçilebilsin diye klasör listesi okunur; uygulama yalnızca seçilen klasördeki FOTOLIZYEDEK dosyalarına dokunur.
 */
object DriveBackup {
    const val SCOPE = "https://www.googleapis.com/auth/drive"
    const val INTERVAL_MIN = 10L
    const val DEFAULT_FOLDER = "FotoLizYedek"
    private const val WORK_CHAIN = "fotoliz_drive_chain"
    private const val WORK_NOW = "fotoliz_drive_now"
    private val lock = Any()

    var running by mutableStateOf(false)

    private fun p(ctx: Context) = ctx.getSharedPreferences("drive", 0)

    class Info(val connected: Boolean, val enabled: Boolean, val account: String, val folder: String, val wifiOnly: Boolean,
               val lastOk: Long, val lastName: String, val lastSize: Long, val lastCount: Int, val lastError: String, val lastCheck: Long, val folderId: String,
               val restoreChecked: Boolean)

    fun info(ctx: Context): Info {
        val s = p(ctx)
        return Info(s.getBoolean("connected", false), s.getBoolean("enabled", false), s.getString("account", "") ?: "",
            s.getString("folder", "") ?: "", s.getBoolean("wifi", false),
            s.getLong("last_ok", 0L), s.getString("last_name", "") ?: "", s.getLong("last_size", 0L), s.getInt("last_count", 0),
            s.getString("last_error", "") ?: "", s.getLong("last_check", 0L), s.getString("folder_id", "") ?: "", restoreChecked(s))
    }

    /** Klasördeki eski yedek soruldu mu? Eski sürümden gelip zaten yedek almış olanlar için "soruldu" sayılır. */
    private fun restoreChecked(s: android.content.SharedPreferences) = s.getBoolean("restore_checked", s.getLong("last_ok", 0L) > 0L)
    fun markRestoreChecked(ctx: Context) { p(ctx).edit().putBoolean("restore_checked", true).apply() }

    /** Drive'daki en son yedeğin bilgisi (yükleme sorusunda gösterilir). */
    class Meta(val name: String, val time: Long, val size: Long)

    /** Seçili klasörde yedek varsa bilgisini, yoksa null döndürür. Arka plan iş parçacığında çağrılmalı. */
    fun latestMeta(ctx: Context): Meta? {
        val s = p(ctx); val folder = s.getString("folder_id", "") ?: ""
        if (folder.isBlank()) return null
        val tk = token(ctx)
        val query = "'$folder' in parents and trashed=false and name contains 'FOTOLIZYEDEK'"
        val files = JSONObject(call("GET", "https://www.googleapis.com/drive/v3/files?q=${q(query)}&orderBy=modifiedTime%20desc&pageSize=1&fields=files(id,name,modifiedTime,size)&spaces=drive", tk)).getJSONArray("files")
        if (files.length() == 0) return null
        val o = files.getJSONObject(0)
        val t = try { SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss", Locale.ROOT).apply { timeZone = java.util.TimeZone.getTimeZone("UTC") }.parse(o.getString("modifiedTime").take(19))?.time ?: 0L } catch (e: Exception) { 0L }
        return Meta(o.getString("name"), t, o.optString("size", "0").toLongOrNull() ?: 0L)
    }

    fun enabled(ctx: Context) = p(ctx).getBoolean("connected", false) && p(ctx).getBoolean("enabled", false)
    /** Seçilen Drive klasörü (kimlik + görünen ad). Değişince bir sonraki yedek yeni klasöre tam yüklenir. */
    fun setFolderChosen(ctx: Context, id: String, name: String) {
        p(ctx).edit().putString("folder_id", id).putString("folder", name).putString("last_sig", "").putString("last_error", "").putBoolean("restore_checked", false).apply()
    }
    fun setWifiOnly(ctx: Context, on: Boolean) { p(ctx).edit().putBoolean("wifi", on).apply(); if (enabled(ctx)) schedule(ctx, INTERVAL_MIN, ExistingWorkPolicy.REPLACE) }
    fun setEnabled(ctx: Context, on: Boolean) {
        p(ctx).edit().putBoolean("enabled", on).apply()
        if (on) schedule(ctx, INTERVAL_MIN, ExistingWorkPolicy.REPLACE) else WorkManager.getInstance(ctx).cancelUniqueWork(WORK_CHAIN)
    }
    fun disconnect(ctx: Context) {
        // Bağlantı kalkınca her şey sıfırlanır: hesap, klasör, son yedek bilgisi, Wi-Fi seçeneği. Baştan tanımlanır.
        p(ctx).edit().clear().apply()
        WorkManager.getInstance(ctx).cancelUniqueWork(WORK_CHAIN)
        WorkManager.getInstance(ctx).cancelUniqueWork(WORK_NOW)
    }

    // ------------------------------------------------------------ zamanlama
    private fun constraints(ctx: Context) = Constraints.Builder()
        .setRequiredNetworkType(if (p(ctx).getBoolean("wifi", false)) NetworkType.UNMETERED else NetworkType.CONNECTED).build()

    /** Sonraki otomatik yedeği delayMin dakika sonrasına kurar (her çalışma bitince kendini yeniden kurar = zincir). */
    fun schedule(ctx: Context, delayMin: Long, policy: ExistingWorkPolicy) {
        try {
            val req = OneTimeWorkRequestBuilder<BackupWorker>().setInitialDelay(delayMin, TimeUnit.MINUTES)
                .setConstraints(constraints(ctx)).setInputData(workDataOf("chain" to true)).build()
            WorkManager.getInstance(ctx).enqueueUniqueWork(WORK_CHAIN, policy, req)
        } catch (e: Exception) { }
    }

    /** Uygulama açılırken: zincir kopmuşsa yeniden kurar, sağlamsa dokunmaz. */
    fun ensureScheduled(ctx: Context) { if (enabled(ctx)) schedule(ctx, INTERVAL_MIN, ExistingWorkPolicy.KEEP) }

    /** Uygulamadan çıkılırken: hemen bir yedek (değişiklik varsa) alınır. */
    fun runSoon(ctx: Context) {
        if (!enabled(ctx)) return
        try {
            val req = OneTimeWorkRequestBuilder<BackupWorker>().setConstraints(constraints(ctx)).setInputData(workDataOf("chain" to false)).build()
            WorkManager.getInstance(ctx).enqueueUniqueWork(WORK_NOW, ExistingWorkPolicy.KEEP, req)
        } catch (e: Exception) { }
    }

    /** Kurulu uygulamanın gerçek imza SHA-1'i: Google Cloud'daki Android OAuth istemcisindekiyle birebir aynı olmalı. */
    fun signingSha1(ctx: Context): String {
        return try {
            val pi = ctx.packageManager.getPackageInfo(ctx.packageName, android.content.pm.PackageManager.GET_SIGNING_CERTIFICATES)
            val sig = pi.signingInfo?.apkContentsSigners?.firstOrNull() ?: return "bilinmiyor"
            java.security.MessageDigest.getInstance("SHA-1").digest(sig.toByteArray()).joinToString(":") { "%02X".format(it) }
        } catch (e: Exception) { "bilinmiyor" }
    }

    // ------------------------------------------------------------ yetkilendirme
    /** Drive izni yenilenmeli / ilk kez verilmeli: kullanıcıya Google izin ekranı gösterilmesi gerekir. */
    class NeedConsent(m: String) : Exception(m)

    /** account verilirse o Google hesabı için; verilmezse bağlı hesap için yetki alınır. */
    fun authorize(ctx: Context, account: android.accounts.Account? = null): AuthorizationResult {
        val acc = account ?: (p(ctx).getString("account", "") ?: "").takeIf { it.contains("@") }?.let { android.accounts.Account(it, "com.google") }
        val b = AuthorizationRequest.builder().setRequestedScopes(listOf(Scope(SCOPE)))
        if (acc != null) b.setAccount(acc)
        return Tasks.await(Identity.getAuthorizationClient(ctx).authorize(b.build()), 30, TimeUnit.SECONDS)
    }

    private fun token(ctx: Context): String {
        val r = authorize(ctx)
        if (r.hasResolution()) throw NeedConsent("Google Drive izni yenilenmeli: Ayarlar > Google Drive yedeği > hesabı yeniden bağla.")
        return r.accessToken ?: throw Exception("Google erişim anahtarı alınamadı.")
    }

    /** Hata iletisini kullanıcıya anlaşılır hâle getirir. */
    fun explain(e: Throwable): String {
        val m = (e.cause?.message ?: e.message ?: e.javaClass.simpleName)
        return when {
            m.contains("UNREGISTERED", true) || m.startsWith("8:") ->
                "Google bu uygulamayı tanımıyor (OAuth istemcisi yok ya da SHA-1/paket adı uyuşmuyor). Google Cloud'da Android OAuth istemcisi oluştur: paket com.fotoliz.app, SHA-1 F2:7D:FD:98:62:64:0D:35:BC:84:5A:49:92:62:2B:17:03:59:D5:BC. Ayrıca Drive API açık ve e-postan Test kullanıcılarında olmalı."
            m.contains("10:") || m.contains("DEVELOPER_ERROR", true) ->
                "Google OAuth istemcisi tanımlı değil ya da SHA-1 uyuşmuyor (README'deki Google Cloud adımlarına bak). Ayrıntı: $m"
            m.contains("Drive hatası 404") -> "Seçili Drive klasörü bulunamadı (silinmiş olabilir). Ayarlar'da klasörü yeniden seç."
            m.contains("insufficient", true) || m.contains("Drive hatası 403") ->
                "Google Drive izni yetersiz. Drive bağlantısını kaldırıp yeniden bağla ve izin ekranında Drive erişimine izin ver. (Ayrıntı: ${m.take(120)})"
            m.contains("Unable to resolve host", true) || m.contains("timeout", true) -> "İnternet bağlantısı yok ya da zaman aşımı."
            else -> m
        }
    }

    fun onConnected(ctx: Context, accessToken: String?, hint: String? = null) {
        var email = ""
        try { if (accessToken != null) email = JSONObject(call("GET", "https://www.googleapis.com/drive/v3/about?fields=user(emailAddress)", accessToken))
            .getJSONObject("user").optString("emailAddress", "") } catch (e: Exception) { }
        if (email.isBlank()) email = hint ?: ""
        val sameAccount = email.isNotBlank() && email == (p(ctx).getString("account", "") ?: "")
        val e = p(ctx).edit().putBoolean("connected", true).putBoolean("enabled", true).putString("account", email).putString("last_error", "").putString("last_sig", "")
        if (!sameAccount) e.putString("folder_id", "").putString("folder", "")      // başka hesap: klasör yeniden seçilecek
        e.apply()
        schedule(ctx, INTERVAL_MIN, ExistingWorkPolicy.REPLACE)
    }

    // ------------------------------------------------------------ HTTP / Drive
    private fun call(method: String, url: String, token: String, json: String? = null): String {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 30000; c.readTimeout = 60000; c.requestMethod = method
            c.setRequestProperty("Authorization", "Bearer $token")
            if (json != null) {
                c.doOutput = true; c.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                c.outputStream.use { it.write(json.toByteArray(Charsets.UTF_8)) }
            }
            val code = c.responseCode
            val body = (if (code in 200..299) c.inputStream else c.errorStream)?.use { String(it.readBytes(), Charsets.UTF_8) } ?: ""
            if (code !in 200..299) throw Exception("Drive hatası $code: ${body.take(200)}")
            return body
        } finally { c.disconnect() }
    }

    private fun q(s: String) = URLEncoder.encode(s, "UTF-8")
    private fun esc(s: String) = s.replace("\\", "\\\\").replace("'", "\\'")

    /** Verilen klasörün ("root" = Drive ana dizini) alt klasörleri: (kimlik, ad) çiftleri. Arka plan iş parçacığında çağrılmalı. */
    fun listFolders(ctx: Context, parent: String): List<Pair<String, String>> {
        val tk = token(ctx)
        // "shared" = Benimle paylaşılanlar (başkasının paylaştığı klasörler)
        val query = (if (parent == "shared") "sharedWithMe=true" else "'${esc(parent)}' in parents") +
            " and mimeType='application/vnd.google-apps.folder' and trashed=false"
        val files = JSONObject(call("GET", "https://www.googleapis.com/drive/v3/files?q=${q(query)}&orderBy=name&pageSize=1000&fields=files(id,name)&spaces=drive&supportsAllDrives=true&includeItemsFromAllDrives=true", tk)).getJSONArray("files")
        val out = ArrayList<Pair<String, String>>()
        for (k in 0 until files.length()) { val o = files.getJSONObject(k); out.add(Pair(o.getString("id"), o.getString("name"))) }
        return out
    }

    /** Verilen klasörün içinde yeni klasör oluşturur; (kimlik, ad) döndürür. */
    fun createFolder(ctx: Context, parent: String, name: String): Pair<String, String> {
        val tk = token(ctx)
        val n = name.trim()
        val body = JSONObject().put("name", n).put("mimeType", "application/vnd.google-apps.folder").put("parents", JSONArray().put(parent)).toString()
        val id = JSONObject(call("POST", "https://www.googleapis.com/drive/v3/files?fields=id", tk, body)).getString("id")
        return Pair(id, n)
    }

    /** Klasördeki yedek dosyaları (en yeni önce). */
    private fun findBackups(token: String, folder: String): List<String> {
        val query = "'$folder' in parents and trashed=false and name contains 'FOTOLIZYEDEK'"
        val files = JSONObject(call("GET", "https://www.googleapis.com/drive/v3/files?q=${q(query)}&orderBy=modifiedTime%20desc&fields=files(id,name)&spaces=drive", token)).getJSONArray("files")
        return (0 until files.length()).map { files.getJSONObject(it).getString("id") }
    }

    /** Yeni dosya (fileId == null) yükler ya da var olan dosyanın içeriğini ve adını günceller. */
    private fun upload(token: String, fileId: String?, name: String, parent: String, zip: File) {
        val boundary = "fotoliz" + System.nanoTime()
        val meta = JSONObject().put("name", name)
        if (fileId == null) meta.put("parents", JSONArray().put(parent))
        val head = ("--$boundary\r\nContent-Type: application/json; charset=UTF-8\r\n\r\n$meta\r\n--$boundary\r\nContent-Type: application/zip\r\n\r\n").toByteArray(Charsets.UTF_8)
        val tail = "\r\n--$boundary--".toByteArray(Charsets.UTF_8)
        val url = if (fileId == null) "https://www.googleapis.com/upload/drive/v3/files?uploadType=multipart&fields=id"
            else "https://www.googleapis.com/upload/drive/v3/files/$fileId?uploadType=multipart&fields=id"
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 30000; c.readTimeout = 180000; c.requestMethod = "POST"
            if (fileId != null) c.setRequestProperty("X-HTTP-Method-Override", "PATCH")
            c.setRequestProperty("Authorization", "Bearer $token")
            c.setRequestProperty("Content-Type", "multipart/related; boundary=$boundary")
            c.doOutput = true
            c.setFixedLengthStreamingMode(head.size.toLong() + zip.length() + tail.size.toLong())
            c.outputStream.use { o -> o.write(head); zip.inputStream().use { it.copyTo(o) }; o.write(tail) }
            val code = c.responseCode
            if (code !in 200..299) throw Exception("Drive hatası $code: ${(c.errorStream?.use { String(it.readBytes()) } ?: "").take(200)}")
        } finally { c.disconnect() }
    }

    private fun download(token: String, id: String, dest: File) {
        val c = URL("https://www.googleapis.com/drive/v3/files/$id?alt=media").openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 30000; c.readTimeout = 180000; c.setRequestProperty("Authorization", "Bearer $token")
            if (c.responseCode !in 200..299) throw Exception("Drive hatası ${c.responseCode}")
            c.inputStream.use { i -> FileOutputStream(dest).use { o -> i.copyTo(o) } }
        } finally { c.disconnect() }
    }

    // ------------------------------------------------------------ yedek al / geri yükle
    /** Değişiklik imzası: kayıtlar, küçük resimler, kaydedilen yüzler ve ayarlar değişmediyse yükleme atlanır. */
    private fun signature(ctx: Context): String {
        val sb = StringBuilder()
        fun add(d: File) { d.listFiles()?.sortedBy { it.name }?.forEach { sb.append(it.name).append(it.length()).append(it.lastModified()).append(';') } }
        add(File(ctx.filesDir, "results")); add(File(ctx.filesDir, "thumbs")); add(File(ctx.filesDir, "savedfaces")); add(File(ctx.filesDir, "celebs"))
        File(ctx.filesDir, "celebs.json").takeIf { it.exists() }?.let { sb.append(it.length()).append(it.lastModified()) }
        File(ctx.filesDir, "savedfaces.json").takeIf { it.exists() }?.let { sb.append(it.length()).append(it.lastModified()) }
        sb.append(Backup.settingsJson(ctx).toString())
        return sb.toString().hashCode().toString() + "_" + sb.length
    }

    /** Bir yedek turu. force = true: değişiklik olmasa da yükler (elle "Şimdi yedekle"). Kullanıcıya gösterilecek iletiyi döndürür. */
    fun runOnce(ctx: Context, force: Boolean = false): String = synchronized(lock) { runLocked(ctx, force) }

    private fun runLocked(ctx: Context, force: Boolean): String {
        val s = p(ctx)
        if (!s.getBoolean("connected", false)) return "Önce Google Drive hesabını bağla."
        if (!force && !s.getBoolean("enabled", false)) return "Otomatik yedek kapalı."
        val folder = s.getString("folder_id", "") ?: ""
        if (folder.isBlank()) return "Önce Drive klasörünü seç."
        if (!restoreChecked(s)) return "Önce Drive'daki eski yedek için karar ver (yüklensin mi?); sonra yedekleme başlar."
        running = true
        try {
            s.edit().putLong("last_check", System.currentTimeMillis()).apply()
            val sig = signature(ctx)
            if (!force && sig == s.getString("last_sig", "") && (s.getString("last_error", "") ?: "").isEmpty()) return "Değişiklik yok; yedek güncel."
            val tk = token(ctx)
            val zip = File(ctx.cacheDir, "fotoliz_drive.zip")
            val count = FileOutputStream(zip).use { Backup.writeZip(ctx, it) }
            val name = "FOTOLIZYEDEK.zip"      // tek sabit dosya: her turda aynı dosyanın içeriği değişir, yenisi oluşturulmaz
            val old = findBackups(tk, folder)
            upload(tk, old.firstOrNull(), name, folder, zip)      // varsa üzerine yazar, yoksa yeni dosya
            for (extra in old.drop(1)) try { call("DELETE", "https://www.googleapis.com/drive/v3/files/$extra", tk) } catch (e: Exception) { }
            val size = zip.length(); zip.delete()
            s.edit().putLong("last_ok", System.currentTimeMillis()).putString("last_name", name).putLong("last_size", size)
                .putInt("last_count", count).putString("last_error", "").putString("last_sig", sig).apply()
            return "Drive'a yedeklendi."
        } catch (e: Throwable) {
            val m = explain(e)
            s.edit().putString("last_error", m).apply()
            return "Yedekleme başarısız: $m"
        } finally { running = false }
    }

    /** Drive'daki en son yedeği indirip geri yükler. Yüklenen kayıt sayısını ya da hata iletisini döndürür. */
    fun restoreLatest(ctx: Context): String = synchronized(lock) { restoreLocked(ctx) }

    private fun restoreLocked(ctx: Context): String {
        running = true
        try {
            val s = p(ctx)
            if (!s.getBoolean("connected", false)) return "Önce Google Drive hesabını bağla."
            val tk = token(ctx)
            val folder = s.getString("folder_id", "") ?: ""
            if (folder.isBlank()) return "Önce Drive klasörünü seç."
            val id = findBackups(tk, folder).firstOrNull() ?: return "Klasörde yedek bulunamadı."
            val f = File(ctx.cacheDir, "fotoliz_restore.zip")
            download(tk, id, f)
            val n = f.inputStream().use { Backup.importStream(ctx, it) }
            f.delete()
            s.edit().putBoolean("restore_checked", true).putString("last_sig", "").apply()
            return "Drive yedeğinden $n kayıt geri yüklendi."
        } catch (e: Throwable) {
            return "Geri yükleme başarısız: ${explain(e)}"
        } finally { running = false }
    }
}

/** Arka plan yedek işi: yedeği alır, sonra (zincirdeyse) 10 dakika sonrasına kendini yeniden kurar. */
class BackupWorker(ctx: Context, params: WorkerParameters) : Worker(ctx, params) {
    override fun doWork(): ListenableWorker.Result {
        val c = applicationContext
        try { if (DriveBackup.enabled(c)) DriveBackup.runOnce(c) } catch (e: Throwable) { }
        if (inputData.getBoolean("chain", true) && DriveBackup.enabled(c))
            DriveBackup.schedule(c, DriveBackup.INTERVAL_MIN, ExistingWorkPolicy.APPEND_OR_REPLACE)
        return ListenableWorker.Result.success()
    }
}
