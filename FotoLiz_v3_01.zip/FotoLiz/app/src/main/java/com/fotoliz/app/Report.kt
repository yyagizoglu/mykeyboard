package com.fotoliz.app

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

// Fiş (adisyon) renkleri: tema ne olursa olsun termal kâğıt görünümü
private val NAVY = Color(0xFF1F3A5F)
private val INK = Color(0xFF1B1B1B)
private val MUTED = Color(0xFF6B6B6B)
private val DASH = Color(0xFF8A8A8A)
private val PAPER = Color(0xFFFFFEF7)
private val EDITED = Color(0xFFFFF0B3)
private val MONO = FontFamily.Monospace

/**
 * Kayıtlı sonuçların raporu: fiş / adisyon görünümü.
 * Normalde ekranın SAĞ YARISINDA açılır (sol yarıya dokununca kapanır); sığmayan kısım baştan sona kaydırılır.
 * Üstteki tam ekran düğmesi fişi tüm ekranda gösterir. Albüm adına dokunup düzenlenebilir; çıkarken "Kaydedilsin mi?" sorulur.
 */
@Composable
fun ReportDialog(vm: VM, onClose: () -> Unit) {
    val original = remember { vm.saved.associate { it.key to savedAlbumInfo(it).second } }
    val draft = remember { mutableStateMapOf<String, String>().also { it.putAll(original) } }
    val dirty = draft.any { (k, v) -> v.trim() != original[k] }
    var askSave by remember { mutableStateOf(false) }
    var full by remember { mutableStateOf(false) }

    fun tryClose() { if (dirty) askSave = true else onClose() }
    fun save() { vm.applyReport(draft.toMap()); onClose() }

    Dialog(onDismissRequest = { if (full) full = false else tryClose() }, properties = DialogProperties(usePlatformDefaultWidth = false, dismissOnClickOutside = false)) {
        BackHandler { if (full) full = false else tryClose() }
        val none = remember { MutableInteractionSource() }
        Box(Modifier.fillMaxSize().background(Color(if (full) 0xE6000000 else 0x66000000))
            .clickable(interactionSource = none, indication = null) { if (!full) tryClose() }) {
            if (full) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.TopCenter) {
                    ReceiptPanel(vm, draft, original, true, dirty, { full = false }, { tryClose() }, { save() },
                        Modifier.widthIn(max = 440.dp).fillMaxWidth().padding(horizontal = 10.dp))
                }
            } else {
                Row(Modifier.fillMaxSize()) {
                    Spacer(Modifier.weight(1f))          // sol yarı: dokununca kapanır
                    ReceiptPanel(vm, draft, original, false, dirty, { full = true }, { tryClose() }, { save() },
                        Modifier.weight(1f).padding(end = 6.dp))
                }
            }
        }
        if (askSave) AlertDialog(onDismissRequest = { askSave = false }, title = { Text("Kaydedilsin mi?") },
            text = { Text("Raporda yaptığın değişiklikler kayıtlı sonuçlara işlensin mi?") },
            confirmButton = { TextButton(onClick = { askSave = false; save() }) { Text("Kaydet") } },
            dismissButton = { Row { TextButton(onClick = { askSave = false }) { Text("Düzenlemeye dön") }; TextButton(onClick = { askSave = false; onClose() }) { Text("Kaydetme") } } })
    }
}

@Composable
private fun ReceiptPanel(vm: VM, draft: MutableMap<String, String>, original: Map<String, String>, full: Boolean, dirty: Boolean,
                         onToggleFull: () -> Unit, onClose: () -> Unit, onSave: () -> Unit, modifier: Modifier) {
    val fs = if (full) 1.2f else 1f
    fun t(x: Float) = (x * fs).sp
    val fmt = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr", "TR")) }
    val now = remember { Date() }
    val people = vm.saved.sumOf { r -> r.clusters.count { !it.obj } }
    val photos = vm.saved.sumOf { it.total }
    val totalSec = vm.saved.sumOf { it.durSec.toLong() }
    val receiptNo = remember { (now.time / 1000L % 1000000L).toString().padStart(6, '0') }
    val none = remember { MutableInteractionSource() }

    // Panel dokunuşları yutar: kâğıda dokununca arkadaki "kapat" tetiklenmesin
    Column(modifier.statusBarsPadding().navigationBarsPadding().imePadding().padding(vertical = 8.dp)
        .clickable(interactionSource = none, indication = null) { }) {
        // Araç çubuğu: başlık + (Kaydet) + tam ekran + kapat
        Row(Modifier.fillMaxWidth().background(NAVY, RoundedCornerShape(10.dp)).padding(start = 10.dp, end = 2.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Text("Rapor", Modifier.weight(1f), color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.Bold)
            if (dirty) TextButton(onClick = onSave, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Kaydet", color = Color(0xFFFFC247), fontSize = 12.sp, fontWeight = FontWeight.Bold) }
            IconButton(onClick = onToggleFull, Modifier.size(40.dp)) { FullIcon(full, Color.White) }
            IconButton(onClick = onClose, Modifier.size(40.dp)) { Icon(Icons.Filled.Close, "Kapat", tint = Color.White) }
        }
        Spacer(Modifier.height(6.dp))

        LazyColumn(Modifier.fillMaxWidth()) {
            item { Zigzag(true) }
            // Başlık: logo + ad + fiş türü
            item {
                Column(Modifier.fillMaxWidth().background(PAPER).padding(horizontal = 12.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    FotoLizLogo(if (full) 64.dp else 48.dp)
                    Spacer(Modifier.height(4.dp))
                    Text("FOTOLİZ", color = INK, fontFamily = MONO, fontSize = t(16f), fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
                    Text("ANALİZ RAPOR FİŞİ", color = MUTED, fontFamily = MONO, fontSize = t(9f), textAlign = TextAlign.Center)
                    Spacer(Modifier.height(6.dp))
                    Dashed()
                    Spacer(Modifier.height(6.dp))
                    // Yapımcı + iletişim (simgeli)
                    Text("YAPIMCI", color = MUTED, fontFamily = MONO, fontSize = t(8f), letterSpacing = 2.sp)
                    Text(Dev.NAME, color = INK, fontFamily = MONO, fontSize = t(12f), fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(4.dp))
                    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        ContactLine(fs, { Icon(Icons.Filled.Phone, null, Modifier.size(14.dp * fs), tint = INK); Spacer(Modifier.width(3.dp)); WhatsAppIcon(14.dp * fs) }, Dev.PHONE_SHOW)
                        ContactLine(fs, { Icon(Icons.Filled.Email, null, Modifier.size(14.dp * fs), tint = INK) }, Dev.CONTACT_EMAIL)
                        ContactLine(fs, { InstagramIcon(14.dp * fs) }, "@" + Dev.INSTAGRAM.trimEnd('/').substringAfterLast('/'))
                        ContactLine(fs, { FacebookIcon(14.dp * fs) }, Dev.FACEBOOK.trimEnd('/').substringAfterLast('/'))
                        ContactLine(fs, { Icon(Icons.Filled.LocationOn, null, Modifier.size(14.dp * fs), tint = INK) }, Dev.ADDRESS)
                    }
                    Spacer(Modifier.height(6.dp))
                    Dashed()
                    Spacer(Modifier.height(4.dp))
                    KV("TARİH", fmt.format(now), fs)
                    KV("FİŞ NO", receiptNo, fs)
                    KV("KAYIT", "${vm.saved.size}", fs)
                    Spacer(Modifier.height(4.dp))
                    Dashed()
                    Spacer(Modifier.height(2.dp))
                    Text("KAYITLAR", color = INK, fontFamily = MONO, fontSize = t(10f), fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Albüm adına dokunarak düzenle • sağda: kişi•foto", color = MUTED, fontFamily = MONO, fontSize = t(8f), textAlign = TextAlign.Center)
                }
            }
            if (vm.saved.isEmpty()) item {
                Text("Kayıt yok", Modifier.fillMaxWidth().background(PAPER).padding(12.dp), color = MUTED, fontFamily = MONO, fontSize = t(11f), textAlign = TextAlign.Center)
            }
            itemsIndexed(vm.saved, key = { _, r -> r.key }) { i, r ->
                val text = draft[r.key] ?: ""
                val edited = text.trim() != original[r.key]
                val persons = r.clusters.count { !it.obj }
                // Bir kayıt = tek satır: sıra no • albüm adı (dokununca düzenlenir) • kişi sayısı • foto sayısı. Satır arası boşluk / çizgi yok.
                Row(Modifier.fillMaxWidth().background(if (edited) EDITED else PAPER).padding(horizontal = 12.dp, vertical = 0.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text((i + 1).toString().padStart(2, '0') + " ", color = MUTED, fontFamily = MONO, fontSize = t(9f))
                    BasicTextField(value = text, onValueChange = { draft[r.key] = it.replace("\n", " ") }, modifier = Modifier.weight(1f),
                        singleLine = true,
                        textStyle = TextStyle(color = INK, fontFamily = MONO, fontSize = t(9f), fontWeight = FontWeight.Bold, lineHeight = t(11f)),
                        cursorBrush = SolidColor(NAVY))
                    Text(" $persons•${r.total}", color = INK, fontFamily = MONO, fontSize = t(9f), fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                }
            }
            // Toplamlar + barkod + alt yazı
            item {
                Column(Modifier.fillMaxWidth().background(PAPER).padding(horizontal = 12.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Dashed()
                    Spacer(Modifier.height(4.dp))
                    KV("TOPLAM KİŞİ GRUBU", "$people", fs)
                    KV("TOPLAM SÜRE", if (totalSec > 0) Engine.fmt(totalSec) else "—", fs)
                    Spacer(Modifier.height(2.dp))
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text("TOPLAM FOTO", Modifier.weight(1f), color = INK, fontFamily = MONO, fontSize = t(12f), fontWeight = FontWeight.Bold)
                        Text("$photos", color = INK, fontFamily = MONO, fontSize = t(14f), fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.height(6.dp))
                    Dashed()
                    Spacer(Modifier.height(8.dp))
                    Barcode(receiptNo, fs)
                    Text(receiptNo, color = MUTED, fontFamily = MONO, fontSize = t(8f), letterSpacing = 3.sp)
                    Spacer(Modifier.height(6.dp))
                    Text("TEŞEKKÜRLER", color = INK, fontFamily = MONO, fontSize = t(10f), fontWeight = FontWeight.Bold, letterSpacing = 2.sp)
                    Text("Bu fiş FotoLiz tarafından cihaz üzerinde oluşturuldu; hiçbir veri dışarı gönderilmez.",
                        color = MUTED, fontFamily = MONO, fontSize = t(8f), textAlign = TextAlign.Center)
                    Spacer(Modifier.height(4.dp))
                }
            }
            item { Zigzag(false) }
        }
    }
}

@Composable
private fun ContactLine(fs: Float, icon: @Composable RowScope.() -> Unit, text: String) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        icon()
        Spacer(Modifier.width(5.dp))
        Text(text, color = INK, fontFamily = MONO, fontSize = (9f * fs).sp, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun KV(k: String, v: String, fs: Float) {
    Row(Modifier.fillMaxWidth().padding(vertical = 1.dp)) {
        Text(k, Modifier.weight(1f), color = MUTED, fontFamily = MONO, fontSize = (9f * fs).sp)
        Text(v, color = INK, fontFamily = MONO, fontSize = (9f * fs).sp, fontWeight = FontWeight.Bold)
    }
}

/** Fişlerdeki kesik çizgi. */
@Composable
private fun Dashed(light: Boolean = false) {
    Canvas(Modifier.fillMaxWidth().height(2.dp)) {
        drawLine(if (light) Color(0xFFCFCFCF) else DASH, Offset(0f, size.height / 2), Offset(size.width, size.height / 2),
            strokeWidth = 1.2.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(7.dp.toPx(), 4.dp.toPx())))
    }
}

/** Fişin üst / alt kenarındaki testere dişi. */
@Composable
private fun Zigzag(top: Boolean) {
    Canvas(Modifier.fillMaxWidth().height(7.dp)) {
        val tooth = 9.dp.toPx()
        val n = (size.width / tooth).toInt().coerceAtLeast(1)
        val w = size.width / n
        val p = Path()
        if (top) {
            p.moveTo(0f, size.height)
            for (i in 0 until n) { p.lineTo(w * i + w / 2, 0f); p.lineTo(w * (i + 1), size.height) }
        } else {
            p.moveTo(0f, 0f)
            for (i in 0 until n) { p.lineTo(w * i + w / 2, size.height); p.lineTo(w * (i + 1), 0f) }
        }
        p.close()
        drawPath(p, PAPER)
    }
}

/** Fiş numarasından üretilen süs barkodu. */
@Composable
private fun Barcode(seed: String, fs: Float) {
    Canvas(Modifier.fillMaxWidth().height(34.dp * fs)) {
        var x = 0f
        var i = 0
        val digits = seed.map { it - '0' }.ifEmpty { listOf(1) }
        while (x < size.width) {
            val d = digits[i % digits.size]
            val bw = (1 + (d + i) % 3) * 1.2.dp.toPx()
            if (i % 2 == 0) drawRect(INK, Offset(x, 0f), androidx.compose.ui.geometry.Size(minOf(bw, size.width - x), size.height))
            x += bw + 1.dp.toPx()
            i++
        }
    }
}

/** Tam ekran / küçült simgesi (köşe okları). */
@Composable
private fun FullIcon(full: Boolean, tint: Color) {
    Canvas(Modifier.size(20.dp)) {
        val s = size.minDimension
        val w = s * 0.11f
        val a = s * 0.16f; val b = s * 0.84f; val m = s * 0.38f; val n = s * 0.62f
        fun corner(x0: Float, y0: Float, dx: Float, dy: Float, l: Float) {
            val p = Path(); p.moveTo(x0 + dx * l, y0); p.lineTo(x0, y0); p.lineTo(x0, y0 + dy * l)
            drawPath(p, tint, style = Stroke(w, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        if (!full) {   // dışa doğru köşeler
            corner(a, a, 1f, 1f, s * 0.26f); corner(b, a, -1f, 1f, s * 0.26f)
            corner(a, b, 1f, -1f, s * 0.26f); corner(b, b, -1f, -1f, s * 0.26f)
        } else {       // içe doğru köşeler
            corner(m, m, -1f, -1f, s * 0.22f); corner(n, m, 1f, -1f, s * 0.22f)
            corner(m, n, -1f, 1f, s * 0.22f); corner(n, n, 1f, 1f, s * 0.22f)
        }
    }
}

/** FotoLiz logosu: uygulama simgesi (lacivert kare, sarı odak köşeleri, üç kişi). */
@Composable
fun FotoLizLogo(box: Dp = 48.dp) {
    Canvas(Modifier.size(box)) {
        val k = size.minDimension / 108f
        drawRoundRect(androidx.compose.ui.graphics.Brush.linearGradient(listOf(Color(0xFF0A2A5E), Color(0xFF0F5C8C), Color(0xFF12A39A)),
            start = Offset.Zero, end = Offset(size.width, size.height)), cornerRadius = CornerRadius(24f * k))
        // odak köşeleri
        val yellow = Color(0xFFFFC247)
        val st = Stroke(4f * k, cap = StrokeCap.Round, join = StrokeJoin.Round)
        fun br(x0: Float, y0: Float, dx: Float, dy: Float) {
            val p = Path(); p.moveTo((x0 + dx * 13f) * k, y0 * k); p.lineTo(x0 * k, y0 * k); p.lineTo(x0 * k, (y0 + dy * 13f) * k)
            drawPath(p, yellow, style = st)
        }
        br(28f, 28f, 1f, 1f); br(80f, 28f, -1f, 1f); br(28f, 80f, 1f, -1f); br(80f, 80f, -1f, -1f)
        // arkadaki iki kişi
        val soft = Color(0xB3FFFFFF)
        fun person(cx: Float, cy: Float, r: Float, x0: Float, x1: Float, yb: Float, yt: Float, col: Color) {
            drawCircle(col, r * k, Offset(cx * k, cy * k))
            val p = Path(); val mid = (x0 + x1) / 2f
            p.moveTo(x0 * k, yb * k)
            p.cubicTo(x0 * k, (yt + 3.5f) * k, (x0 + 3f) * k, yt * k, mid * k, yt * k)
            p.cubicTo((x1 - 3f) * k, yt * k, x1 * k, (yt + 3.5f) * k, x1 * k, yb * k)
            p.close(); drawPath(p, col)
        }
        person(40f, 50f, 4.8f, 32f, 48f, 70f, 59f, soft)
        person(68f, 50f, 4.8f, 60f, 76f, 70f, 59f, soft)
        person(54f, 46f, 7.5f, 40f, 68f, 72f, 57f, Color.White)
    }
}
