package com.fotoliz.app

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.border
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import java.io.File

private class FaceOpt(val thumb: String, val name: String, val embs: List<FloatArray>)

private enum class FaceSrc(val label: String) { SAVED("Kayıtlı"), CELEB("Ünlü"), FOUND("Bulunan"), GALLERY("Galeri") }

/**
 * Galeri üst çubuğundaki "Yüz" düğmesi: Kayıtlı yüzler / Ünlüler / Bulunanlar arasından bir yüz seçilir,
 * seçili klasörlerde (ya da açık klasörde) bu yüz aranır. "İlk taranacak sayı" doluysa her klasörün en yeni N fotoğrafı taranır.
 */
@Composable
fun GalleryFaceDialog(vm: VM) {
    val ctx = LocalContext.current
    var src by remember { mutableStateOf(FaceSrc.SAVED) }
    var pick by remember { mutableStateOf<FaceOpt?>(null) }
    FaceOrder.ensure(ctx)
    val saved = vm.savedFaces
    val celebs = Celebs.items
    val found = remember(vm.saved, Engine.found, FaceOrder.version) { collectFaces(vm.saved.filter { it.key in Engine.found }) }
    val opts: List<FaceOpt> = when (src) {
        FaceSrc.SAVED -> saved.map { FaceOpt(SavedFaces.path(ctx, it), it.name, it.embs) }
        FaceSrc.CELEB -> celebs.map { FaceOpt(Celebs.path(ctx, it), it.name, listOf(it.centroid)) }
        FaceSrc.GALLERY -> vm.galleryChoices.map { FaceOpt(it.thumb, it.label, it.embs) }
        FaceSrc.FOUND -> found.map { e ->
            val c = e.members.firstOrNull()?.second
            FaceOpt(e.thumb, e.name, if (c == null) emptyList() else listOf(c.centroid) + c.reps.take(8))
        }
    }
    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri -> if (uri != null) { pick = null; vm.detectFacesIn(uri, toPickScreen = false) } }
    // Taranacak klasörler: seçili klasörler; hiçbiri seçili değilse açık klasör
    val folderIds: List<Long> = GalleryState.selFolders.keys.toList().ifEmpty { listOfNotNull(GalleryState.open?.id) }
    fun close() { GalleryState.askFace = false }
    AlertDialog(onDismissRequest = { close() }, title = { Text("Yüze göre ara") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                // Belirgin kaynak seçimi: seçili olan dolu düğme, diğerleri çerçeveli
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    FaceSrc.values().forEach { s ->
                        val m = Modifier.weight(1f).height(44.dp)
                        if (src == s) Button({ }, m, contentPadding = PaddingValues(horizontal = 2.dp)) { Text(s.label, maxLines = 1, softWrap = false, fontWeight = FontWeight.Bold, fontSize = 13.sp) }
                        else OutlinedButton({ src = s; pick = null }, m, contentPadding = PaddingValues(horizontal = 2.dp)) { Text(s.label, maxLines = 1, softWrap = false, fontSize = 13.sp) }
                    }
                }
                if (src == FaceSrc.GALLERY) {
                    FilledTonalButton({ photoPicker.launch("image/*") }, Modifier.fillMaxWidth(), enabled = !vm.detecting) {
                        Text(if (vm.detecting) "Yüzler aranıyor…" else "Galeriden fotoğraf seç")
                    }
                    vm.error?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error) }
                }
                if (opts.isEmpty()) Box(Modifier.fillMaxWidth().height(120.dp), contentAlignment = Alignment.Center) {
                    Text(if (src == FaceSrc.GALLERY) "Galeriden bir fotoğraf seç; içindeki yüzler burada çıkar." else "Bu bölümde henüz yüz yok.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                } else LazyVerticalGrid(GridCells.Fixed(4), Modifier.fillMaxWidth().heightIn(max = 260.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    itemsIndexed(opts) { _, o ->
                        val on = pick?.thumb == o.thumb
                        Column(Modifier.clickable { pick = o }, horizontalAlignment = Alignment.CenterHorizontally) {
                            AsyncImage(File(o.thumb), null, Modifier.fillMaxWidth().aspectRatio(1f).clip(CircleShape)
                                .border(if (on) 3.dp else 0.dp, if (on) MaterialTheme.colorScheme.primary else androidx.compose.ui.graphics.Color.Transparent, CircleShape),
                                contentScale = ContentScale.Crop)
                            Text(o.name.ifBlank { "Adsız" }, style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth(),
                                color = if (on) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                        }
                    }
                }
                Text("Her klasörde ilk taranacak fotoğraf sayısı (boş = hepsi)", style = MaterialTheme.typography.labelMedium)
                CountField(vm.photoLimit, { vm.photoLimit = it }, Modifier.fillMaxWidth())
                Text(if (folderIds.isEmpty()) "Önce galeriden klasör seç (klasöre basılı tut) ya da bir klasörü aç."
                     else "${folderIds.size} klasörde aranacak" + (if (vm.limitN() > 0) " • her birinde en yeni ${vm.limitN()} fotoğraf" else ""),
                    style = MaterialTheme.typography.bodySmall,
                    color = if (folderIds.isEmpty()) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
            }
        },
        confirmButton = {
            TextButton(enabled = pick != null && folderIds.isNotEmpty(), onClick = {
                val p = pick ?: return@TextButton
                close(); vm.startGalleryFaceSearch(p.thumb, p.embs, p.name, folderIds)
            }) { Text("Tara") }
        },
        dismissButton = { TextButton({ close() }) { Text("Vazgeç") } })
}
