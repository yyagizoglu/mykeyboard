package com.fotoliz.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import android.os.Looper
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.coroutines.resume

/**
 * Ana ekranda, sağ üstte (ayarlar çarkının altında) küçük pano:
 *   tarih
 *   anlık saat
 *   konum simgesi + ilçe adı
 *   hava durumu simgesi + derece
 * Konum izni bir kez istenir. Hava: Open-Meteo (anahtarsız, ücretsiz). İlçe adı: Android Geocoder, olmazsa BigDataCloud.
 * Veri 15 dakikada bir yenilenir; ekranlar arası geçişte son değer saklanır.
 */
object MiniInfo {
    var district by mutableStateOf<String?>(null)
    var temp by mutableStateOf<Int?>(null)
    var code by mutableStateOf(-1)
    var lastFetch = 0L
    var asked = false      // izin penceresi bu oturumda bir kez gösterilir
}

private fun hasLoc(ctx: Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED

@SuppressLint("MissingPermission")
private fun lastKnown(ctx: Context): Location? {
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    return try {
        lm.getProviders(true).mapNotNull { try { lm.getLastKnownLocation(it) } catch (e: Exception) { null } }.maxByOrNull { it.time }
    } catch (e: Exception) { null }
}

@SuppressLint("MissingPermission")
@Suppress("DEPRECATION")
private suspend fun currentLoc(ctx: Context): Location? {
    lastKnown(ctx)?.let { if (System.currentTimeMillis() - it.time < 30 * 60_000L) return it }
    val lm = ctx.getSystemService(Context.LOCATION_SERVICE) as LocationManager
    val prov = try {
        when {
            lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER) -> LocationManager.NETWORK_PROVIDER
            lm.isProviderEnabled(LocationManager.GPS_PROVIDER) -> LocationManager.GPS_PROVIDER
            else -> return lastKnown(ctx)
        }
    } catch (e: Exception) { return lastKnown(ctx) }
    return withTimeoutOrNull(15_000) {
        suspendCancellableCoroutine<Location?> { cont ->
            val l = object : LocationListener {
                override fun onLocationChanged(loc: Location) { if (cont.isActive) cont.resume(loc) }
                override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
                override fun onProviderEnabled(provider: String) {}
                override fun onProviderDisabled(provider: String) {}
            }
            try { lm.requestSingleUpdate(prov, l, Looper.getMainLooper()) } catch (e: Exception) { if (cont.isActive) cont.resume(null) }
            cont.invokeOnCancellation { try { lm.removeUpdates(l) } catch (_: Exception) {} }
        }
    } ?: lastKnown(ctx)
}

private fun httpGet(u: String): String {
    val c = URL(u).openConnection() as HttpURLConnection
    c.connectTimeout = 10_000; c.readTimeout = 10_000
    try { return c.inputStream.bufferedReader().use { it.readText() } } finally { c.disconnect() }
}

/** Türkiye'de ilçe: Geocoder'da subAdminArea (yoksa locality). Geocoder yoksa BigDataCloud. */
@Suppress("DEPRECATION")
private suspend fun districtName(ctx: Context, lat: Double, lon: Double): String? = withContext(Dispatchers.IO) {
    try {
        if (Geocoder.isPresent()) {
            val a = Geocoder(ctx, Locale("tr", "TR")).getFromLocation(lat, lon, 1)?.firstOrNull()
            val n = a?.subAdminArea?.takeIf { it.isNotBlank() } ?: a?.locality?.takeIf { it.isNotBlank() }
            if (n != null) return@withContext n
        }
    } catch (_: Exception) {}
    try {
        val j = JSONObject(httpGet("https://api.bigdatacloud.net/data/reverse-geocode-client?latitude=$lat&longitude=$lon&localityLanguage=tr"))
        j.optString("city").ifBlank { j.optString("locality") }.ifBlank { null }
    } catch (_: Exception) { null }
}

/** Open-Meteo: anlık sıcaklık + WMO hava kodu. */
private suspend fun fetchWeather(lat: Double, lon: Double): Pair<Int, Int>? = withContext(Dispatchers.IO) {
    try {
        val j = JSONObject(httpGet("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current=temperature_2m,weather_code&timezone=auto"))
        val cur = j.getJSONObject("current")
        Math.round(cur.getDouble("temperature_2m")).toInt() to cur.getInt("weather_code")
    } catch (_: Exception) { null }
}

private fun weatherEmoji(code: Int) = when (code) {
    0 -> "☀️"
    1 -> "🌤️"
    2 -> "⛅"
    3 -> "☁️"
    45, 48 -> "🌫️"
    in 51..57 -> "🌦️"
    in 61..67 -> "🌧️"
    in 71..77 -> "🌨️"
    in 80..82 -> "🌦️"
    85, 86 -> "❄️"
    in 95..99 -> "⛈️"
    else -> "🌡️"
}

@Composable
fun MiniInfoPanel(modifier: Modifier = Modifier, compact: Boolean = false) {
    val ctx = LocalContext.current
    val trLocale = remember { Locale("tr", "TR") }
    val dateFmt = remember { SimpleDateFormat(if (compact) "d MMM EEE" else "d MMMM EEE", trLocale) }
    val timeFmt = remember { SimpleDateFormat("HH:mm:ss", trLocale) }
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) { while (true) { now = System.currentTimeMillis(); delay(1000) } }

    var granted by remember { mutableStateOf(hasLoc(ctx)) }
    var noLoc by remember { mutableStateOf(false) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { granted = hasLoc(ctx) }
    LaunchedEffect(Unit) {
        if (!granted && !MiniInfo.asked) { MiniInfo.asked = true; launcher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)) }
    }
    LaunchedEffect(granted) {
        if (!granted) return@LaunchedEffect
        while (true) {
            if (MiniInfo.temp == null || System.currentTimeMillis() - MiniInfo.lastFetch > 15 * 60_000L) {
                val loc = currentLoc(ctx)
                if (loc == null) noLoc = true
                else {
                    noLoc = false
                    districtName(ctx, loc.latitude, loc.longitude)?.let { MiniInfo.district = it }
                    fetchWeather(loc.latitude, loc.longitude)?.let { (t, c) -> MiniInfo.temp = t; MiniInfo.code = c; MiniInfo.lastFetch = System.currentTimeMillis() }
                }
            }
            delay(60_000)
        }
    }

    val sub = MaterialTheme.colorScheme.onSurfaceVariant
    if (compact) {
        // Üst çubuk için dar pano: başlık ile tema düğmeleri arasına sığar (saat / tarih / ilçe + hava alt alta)
        Card(modifier, shape = RoundedCornerShape(10.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Column(Modifier.padding(horizontal = 7.dp, vertical = 2.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(timeFmt.format(Date(now)), fontSize = 13.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false, lineHeight = 15.sp)
                Text(dateFmt.format(Date(now)), fontSize = 9.sp, color = sub, maxLines = 1, softWrap = false, lineHeight = 11.sp)
                if (!granted) {
                    Text("Konum izni ver", fontSize = 9.sp, color = MaterialTheme.colorScheme.primary, maxLines = 1, softWrap = false, lineHeight = 11.sp,
                        modifier = Modifier.clickable { launcher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)) })
                } else {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                        Icon(Icons.Filled.LocationOn, null, Modifier.size(9.dp), tint = sub)
                        Text(MiniInfo.district ?: if (noLoc) "Konum kapalı" else "…", fontSize = 9.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, lineHeight = 11.sp, modifier = Modifier.widthIn(max = 70.dp))
                        MiniInfo.temp?.let { t -> Text(weatherEmoji(MiniInfo.code) + "$t°", fontSize = 9.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false, lineHeight = 11.sp) }
                    }
                }
            }
        }
        return
    }
    // Tek satır şerit (üst çubuğun hemen altı, tüm sayfalarda): saat • tarih • 📍ilçe • hava
    // Genişliğe uyar: dar ekranda yazılar küçülür, ilçe adı kısalır; sığmazsa ilçe gizlenir.
    BoxWithConstraints(modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
        val narrow = maxWidth < 340.dp
        val big = if (narrow) 12.sp else 14.sp
        val small = if (narrow) 10.sp else 11.sp
        val dot = @Composable { Text("•", fontSize = small, color = sub.copy(alpha = 0.6f)) }
        Card(Modifier.widthIn(max = maxWidth), shape = RoundedCornerShape(14.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
            Row(Modifier.padding(horizontal = 12.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(if (narrow) 6.dp else 8.dp, Alignment.CenterHorizontally)) {
                Text(timeFmt.format(Date(now)), fontSize = big, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                dot()
                Text(dateFmt.format(Date(now)), fontSize = small, color = sub, maxLines = 1, softWrap = false)
                if (!granted) {
                    dot()
                    Text("Konum izni ver", fontSize = small, color = MaterialTheme.colorScheme.primary, maxLines = 1, softWrap = false,
                        modifier = Modifier.clickable { launcher.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION)) })
                } else {
                    dot()
                    Row(Modifier.weight(1f, fill = false), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Filled.LocationOn, null, Modifier.size(12.dp), tint = sub)
                        Text(MiniInfo.district ?: if (noLoc) "Konum kapalı" else "…", fontSize = small, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    MiniInfo.temp?.let { t ->
                        Text(weatherEmoji(MiniInfo.code) + "$t°", fontSize = big, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                    }
                }
            }
        }
    }
}
