package com.fotoliz.app

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.IBinder
import android.os.PowerManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

/** Ön plan servisi: analiz sürerken uygulamayı canlı tutar (ekran kapansa, başka uygulamaya geçilse bile). */
class ScanService : Service() {
    companion object {
        const val CH = "scan"; const val CH_DONE = "scan_done2"; const val ID = 1; const val DONE_ID = 2
        fun start(ctx: Context) { ContextCompat.startForegroundService(ctx, Intent(ctx, ScanService::class.java)) }
    }
    private var wl: PowerManager.WakeLock? = null
    private var loop: Job? = null
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "Analiz ilerlemesi", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Analiz sonucu", NotificationManager.IMPORTANCE_DEFAULT).apply { setSound(null, null); enableVibration(false) })   // ses uygulama içinden çalınır (Ayarlar > Sesler)
        startForeground(ID, build("Analiz başlıyor…", 0, 0, true, CH), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
        if (wl == null) wl = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "fotoliz:scan")
            .apply { setReferenceCounted(false); acquire(6 * 60 * 60 * 1000L) }
        if (loop?.isActive == true) return START_NOT_STICKY
        loop = scope.launch {
            while (Engine.running || SearchEngine.running || PersonEngine.running) {
                if (PersonEngine.running) nm.notify(ID, build(PersonEngine.status, PersonEngine.done, PersonEngine.total, true, CH))
                else if (SearchEngine.running) nm.notify(ID, build(SearchEngine.status, SearchEngine.done, SearchEngine.total, true, CH))
                else nm.notify(ID, build(Engine.status, Engine.done, Engine.total, true, CH))
                delay(1500)
            }
            val applicationCtx = applicationContext
            if (PersonEngine.notifyDone) {
                PersonEngine.notifyDone = false; DoneSound.play(applicationCtx); nm.notify(DONE_ID, build(PersonEngine.doneText, 0, 0, false, CH_DONE))
            } else if (SearchEngine.notifyDone) {
                SearchEngine.notifyDone = false; DoneSound.play(applicationCtx); nm.notify(DONE_ID, build(SearchEngine.doneText, 0, 0, false, CH_DONE))
            } else if (!Engine.cancelled && Engine.doneText.isNotEmpty()) {
                DoneSound.play(applicationCtx); nm.notify(DONE_ID, build(Engine.doneText, 0, 0, false, CH_DONE)) }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun build(text: String, done: Int, total: Int, ongoing: Boolean, channel: String): Notification {
        val pi = PendingIntent.getActivity(this, 0,
            Intent(this, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP or Intent.FLAG_ACTIVITY_NEW_TASK),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val b = NotificationCompat.Builder(this, channel)
            .setSmallIcon(android.R.drawable.stat_notify_sync)
            .setContentTitle("FotoLiz").setContentText(text)
            .setContentIntent(pi).setOnlyAlertOnce(true).setOngoing(ongoing).setAutoCancel(!ongoing)
        if (ongoing) { if (total > 0) b.setProgress(total, done, false) else b.setProgress(0, 0, true) }
        return b.build()
    }

    override fun onDestroy() {
        scope.cancel()
        try { wl?.let { if (it.isHeld) it.release() } } catch (e: Exception) {}
        super.onDestroy()
    }
}
