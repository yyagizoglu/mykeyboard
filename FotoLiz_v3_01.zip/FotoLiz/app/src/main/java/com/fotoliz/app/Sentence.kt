package com.fotoliz.app

import java.util.Locale

/**
 * Nesne kutusuna PARANTEZ içinde yazılan cümle: "(sakallı ve bıyıklı erkekler)", "(başında türban olan kadınlar)", "(gözlüklü sakalsız erkek)".
 * Katı kural: fotoğraftaki BÜTÜN yüzler cümleye uymalıdır; tek bir uymayan yüz varsa fotoğraf gelmez.
 * Yüz başına özellikler GalleryAttrs'ta saklanır: cinsiyet (F/M/U), W örtülü kadın, B sakal, Y bıyık, G gözlük.
 */
class SentenceQuery(val gender: Char?, val needW: Boolean, val must: Set<Char>, val mustNot: Set<Char>, val labelKeys: List<Set<String>>) {
    private fun faceOk(t: String): Boolean {
        val g = t.firstOrNull() ?: return false
        val fl = t.drop(1)
        val genderOk = when {
            needW -> g != 'M' && gender != 'M'              // örtülü: erkek işareti olmayan yüz (W zaten bunu garanti eder)
            gender == null -> true
            else -> g == gender
        }
        if (!genderOk) return false
        if (needW && 'W' !in fl) return false
        for (c in must) if (c !in fl) return false
        for (c in mustNot) if (c in fl) return false
        return true
    }
    /** Yüz bilgisi var ve bütün yüzler uyuyor mu? (etiket koşulları ayrıca photoOk'ta) */
    fun facesOk(u: String): Boolean { val fs = GalleryAttrs.faces(u); return fs.isNotEmpty() && fs.all { faceOk(it) } }
    fun photoOk(u: String): Boolean = facesOk(u) && labelKeys.all { PhotoLabels.has(u, it) }

    companion object {
        private val tr = Locale("tr", "TR")
        private val stop = setOf("olan", "olanlar", "ve", "veya", "ile", "ya", "da", "de", "bir", "başında", "basinda", "kafasında", "kafasinda", "başı", "basi",
            "bulunan", "giyen", "takan", "kişi", "kisi", "hem", "sadece", "yalnızca", "yalnizca")
        /** Parantezli cümle değilse ya da hiçbir özellik tanınmadıysa null (normal nesne araması sürer). */
        fun parse(q: String): SentenceQuery? {
            val s = q.trim()
            if (!(s.startsWith("(") && s.endsWith(")")) || s.length < 3) return null
            var gender: Char? = null; var needW = false
            val must = LinkedHashSet<Char>(); val not = LinkedHashSet<Char>(); val keys = ArrayList<Set<String>>()
            for (t in s.substring(1, s.length - 1).lowercase(tr).split(Regex("[^\\p{L}]+")).filter { it.isNotEmpty() }) {
                if (t in stop) continue
                when {
                    t.startsWith("kadın") || t.startsWith("kadin") || t.startsWith("bayan") || t.startsWith("hanım") || t.startsWith("hanim") || t.startsWith("kız") || t.startsWith("kiz") -> gender = 'F'
                    t.startsWith("erkek") || t.startsWith("adam") || t.startsWith("delikanlı") -> gender = 'M'
                    TrObjects.isHeadscarf(t) -> needW = true
                    t.startsWith("sakal") -> if (t.contains("sız") || t.contains("siz")) not.add('B') else must.add('B')
                    t.startsWith("bıyık") || t.startsWith("biyik") -> if (t.contains("sız") || t.contains("siz")) not.add('Y') else must.add('Y')
                    t.startsWith("gözlük") || t.startsWith("gozluk") -> if (t.contains("süz") || t.contains("suz")) not.add('G') else must.add('G')
                    else -> { val k = TrObjects.resolve(t); if (k.isNotEmpty()) keys.add(k) }
                }
            }
            if (gender == null && !needW && must.isEmpty() && not.isEmpty() && keys.isEmpty()) return null
            return SentenceQuery(gender, needW, must, not, keys)
        }
    }
}
