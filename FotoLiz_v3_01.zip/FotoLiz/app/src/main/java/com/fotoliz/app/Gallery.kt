package com.fotoliz.app

import androidx.compose.animation.core.animateFloat
import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.grid.rememberLazyGridState
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.TextFieldValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.withContext

/** Galeri üst çubuğundaki (sağ üst) filtre seçenekleri. */
enum class GalleryFilter(val label: String) {
    PHOTO("Foto"), VIDEO("Video"), FEMALE("Kadın"), MALE("Erkek"), OBJECT("Nesne"), FAV("Favoriler"), ALL("Hepsi");
    /** Kadın / Erkek / Nesne / Türban: fotoğraflar cihazda taranıp süzülür (klasör açılınca). */
    val needsScan: Boolean get() = this == FEMALE || this == MALE || this == OBJECT
}

/** Galeri sayfasındaki bir klasör / albüm (telefondaki her MediaStore klasörü). */
class GalleryFolder(val id: Long, val name: String, val path: String, val count: Int, val cover: Uri, val coverVideo: Boolean = false, val ids: List<Long> = emptyList())

/** Klasördeki bir öğe: fotoğraf ya da video. */
class GalleryItem(val uri: Uri, val video: Boolean)

/**
 * 2. sayfa "Galeri": telefondaki TÜM fotoğraf / video klasörlerini listeler. Klasöre dokununca öğeleri açılır; dokununca tam ekran, kaydırmalı görüntülenir.
 * Sağ üstteki filtre: Foto, Video, Kadın, Erkek, Nesne, Hepsi. Nesne: eşarp / başörtüsü yazılırsa yalnızca örtülü kadın yüzü doğrulanan fotoğraflar gelir.
 * Kendi durumunu burada tutar; analiz / kişi / arama ekranlarının akışına karışmaz.
 */
object GalleryState {
    private val IMGU = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
    private val VIDU = MediaStore.Video.Media.EXTERNAL_CONTENT_URI

    var folders by mutableStateOf<List<GalleryFolder>>(emptyList())
    var total by mutableStateOf(0)
    var loading by mutableStateOf(false)
    var loaded by mutableStateOf(false)
    var open by mutableStateOf<GalleryFolder?>(null)          // açık klasör (null = klasör listesi)
    var items by mutableStateOf<List<GalleryItem>>(emptyList())   // açık klasörün tüm öğeleri (yeniden eskiye)
    var shown by mutableStateOf<List<GalleryItem>>(emptyList())   // filtreden geçenler (ızgarada görünen)
    var viewing by mutableStateOf(-1)                          // >= 0: tam ekran görüntüleyici açık, `shown` içindeki sıra

    var filter by mutableStateOf(GalleryFilter.ALL)
    var scanMsg by mutableStateOf<String?>(null)                // Tarama başlamadıysa nedeni (örn. model indirilemedi)
    var objectQuery by mutableStateOf("")                      // Nesne filtresi için yazılan ad
    var askObject by mutableStateOf(false)
    var pendingFilter by mutableStateOf<GalleryFilter?>(null)   // klasör içinde taramalı filtre seçilince "kaç fotoğraf taransın?" sorusu
    var capN by mutableStateOf(0)                                // >0: yalnızca klasörün ilk (en yeni) N fotoğrafı taranır ve gösterilir
    var scan by mutableStateOf<Pair<Int, Int>?>(null)          // süzme taraması ilerlemesi (biten, toplam)
    var videoGranted by mutableStateOf(false)
    var askedVideo = false

    // --- Çoklu seçim: geri dönülünce / klasör değişince korunur (reset() seçimi silmez) ---
    val selFolders = mutableStateMapOf<Long, Boolean>()        // seçili klasör / albüm kimlikleri
    val selPhotos = mutableStateMapOf<String, Boolean>()       // seçili fotoğraf / video uri'leri (tüm klasörler birlikte)
    var folderScrollIdx = 0; var folderScrollOff = 0           // klasör listesinin kaydırma yeri
    val photoScroll = HashMap<Long, Pair<Int, Int>>()          // klasör kimliği -> ızgaranın kaydırma yeri

    val selOrder = mutableStateListOf<Long>()                  // klasörlerin seçilme sırası (üstteki liste bu sırayla alt alta yazar)
    fun toggleFolder(id: Long) {
        if (selFolders.remove(id) == null) { selFolders[id] = true; selOrder.remove(id); selOrder.add(id) } else selOrder.remove(id)
    }
    fun selectedFolderIds(): List<Long> = selOrder.filter { selFolders.containsKey(it) } + selFolders.keys.filter { it !in selOrder }
    fun togglePhoto(u: Uri) { val k = u.toString(); if (selPhotos.remove(k) == null) selPhotos[k] = true }
    fun selectAllFolders() { folders.forEach { if (!selFolders.containsKey(it.id)) { selFolders[it.id] = true; selOrder.add(it.id) } } }
    fun selectAllShown() { shown.forEach { selPhotos[it.uri.toString()] = true } }
    fun clearAllSelection() { selFolders.clear(); selOrder.clear(); selPhotos.clear() }
    var askDelete by mutableStateOf(false)                     // üst çubuktaki Sil düğmesi: onay penceresini açar
    var askTrash by mutableStateOf(false)                      // 2. adım: "Evet" denince geri dönüşüm uyarısı
    // --- Klasör taramasını durdur / devam et + süre ---
    var scanPaused by mutableStateOf(false)
    var unfinishedUntil by mutableStateOf(0L)                   // yarım kalan işlem uyarısı (yanıp sönen şerit) bu ana kadar görünür
    var scanLast by mutableStateOf<Pair<Int, Int>?>(null)      // son bilinen ilerleme (duraklatılınca da görünsün)
    var scanBase by mutableStateOf(0L)                         // önceki bölümlerde geçen süre (ms)
    var scanSegStart by mutableStateOf(0L)                     // çalışan bölümün başlangıcı (0 = çalışmıyor)
    fun resetScanClock() { scanPaused = false; scanLast = null; scanBase = 0L; scanSegStart = 0L }
    var askFace by mutableStateOf(false)                       // üst çubuktaki Yüz düğmesi: yüz seçme penceresi
    var askRename by mutableStateOf(false)                     // üst çubuktaki Adı değiştir düğmesi: ad penceresini açar

    /** Silinen / taşınan fotoğrafları ızgaradan, gruplardan, Türban sonuçlarından ve seçimden çıkarır. */
    fun removeUris(gone: Set<String>) {
        if (gone.isEmpty()) return
        fun keep(l: List<GalleryItem>) = l.filter { it.uri.toString() !in gone }
        fun regroup(g: List<FaceGroup>?): List<FaceGroup>? = g?.map { FaceGroup(it.id, keep(it.items), it.cover, it.ungrouped) }?.filter { it.items.isNotEmpty() }
        items = keep(items); shown = keep(shown)
        groups = regroup(groups)
        openGroup = openGroup?.let { og -> groups?.firstOrNull { it.id == og.id } }
        TurbanState.items = keep(TurbanState.items)
        TurbanState.groups = regroup(TurbanState.groups)
        TurbanState.openGroup = TurbanState.openGroup?.let { og -> TurbanState.groups?.firstOrNull { it.id == og.id } }
        gone.forEach { selPhotos.remove(it) }
        Favorites.removeAll(gone)
        if (viewing >= 0 && viewList.isEmpty()) viewing = -1
        else if (viewing >= viewList.size) viewing = (viewList.size - 1).coerceAtLeast(0)
    }

    // --- Açık klasördeki (süzülmüş) sonuçları yüzlere göre gruplama ---
    var groups by mutableStateOf<List<FaceGroup>?>(null)       // null = gruplanmamış (düz ızgara)
    var openGroup by mutableStateOf<FaceGroup?>(null)
    var grouping by mutableStateOf<Pair<Int, Int>?>(null)      // gruplama ilerlemesi (biten, toplam)
    var groupError by mutableStateOf<String?>(null)
    var groupPaused by mutableStateOf(false)                   // gruplama durduruldu mu
    var groupBase by mutableStateOf(0L)                        // önceki bölümlerde geçen süre (ms)
    var groupSegStart by mutableStateOf(0L)                    // çalışan bölümün başlangıcı (0 = çalışmıyor)
    fun resetGroupClock() { groupPaused = false; groupBase = 0L; groupSegStart = 0L }
    fun toggleGroupPause() {
        val now = System.currentTimeMillis()
        if (!groupPaused) { if (groupSegStart > 0L) groupBase += now - groupSegStart; groupSegStart = 0L; groupPaused = true }
        else { groupSegStart = now; groupPaused = false }
    }
    fun clearGroups() { groups = null; openGroup = null; grouping = null; groupError = null; resetGroupClock() }

    /** `shown` listesindeki fotoğrafları yüzlere göre gruplar. */
    suspend fun groupShown(ctx: Context) {
        val list = shown
        if (list.isEmpty() || grouping != null) return
        groupError = null; grouping = 0 to list.size
        groupPaused = false; groupBase = 0L; groupSegStart = System.currentTimeMillis()
        try {
            val g = TurbanState.groupList(ctx, list, false, { groupPaused }) { d, t -> grouping = d to t }
            groups = g; openGroup = null
            DoneSound.play(ctx)
        } catch (e: kotlinx.coroutines.CancellationException) { throw e
        } catch (e: Throwable) { groupError = e.message ?: e.javaClass.simpleName
        } finally { grouping = null; groupSegStart = 0L; groupPaused = false }
    }

    var favView: List<GalleryItem> = emptyList()               // Favoriler tam ekran açılırken donmuş liste (kalple çıkarılınca sayfa kaymasın)
    /** Klasör listesi görünüyor mu (Türban ekranı kendi albüm seçimine sahiptir). */
    val showsFolderList: Boolean get() = atRoot && filter != GalleryFilter.FAV
    val atRoot: Boolean get() = open == null && viewing < 0

    /** Tam ekran görüntüleyicinin gezdiği liste (Türban filtresinde bulunan / gruptaki fotoğraflar). */
    val viewList: List<GalleryItem> get() = if (filter == GalleryFilter.FAV) favView else (openGroup?.items ?: shown)

    /** Menüden bir filtre seçilince. */
    fun choose(f: GalleryFilter) {
        resetScanClock()
        viewing = -1
        clearGroups()
        filter = f
        if (f == GalleryFilter.OBJECT) objectQuery = ""   // nesne adı filtre seçilince değil, yeşil Ara'ya basınca sorulur
        if (f == GalleryFilter.OBJECT && open != null) askObject = true   // klasör içindeyken Ara'ya basılmaz: adı hemen sor
    }

    /** Geri tuşu: önce görüntüleyiciyi, sonra klasörü kapatır. Bir şey kapandıysa true döner. */
    fun back(): Boolean {
        if (viewing >= 0) { viewing = -1; return true }
        if (openGroup != null) { openGroup = null; return true }
        if (groups != null) { groups = null; return true }
        if (open != null) { open = null; items = emptyList(); shown = emptyList(); scan = null; resetScanClock(); return true }
        return false
    }

    fun reset() { clearGroups(); open = null; items = emptyList(); shown = emptyList(); viewing = -1; scan = null; TurbanState.clearGroups() }

    suspend fun loadFolders(ctx: Context) {
        loading = true
        val flt = GalleryFilter.ALL; val vg = videoGranted   // klasör listesi süzgeçten etkilenmez: süzgeç Ara'ya basınca açılan albümde uygulanır
        val list = withContext(Dispatchers.IO) {
            val names = LinkedHashMap<Long, String>(); val paths = HashMap<Long, String>()
            val cnt = HashMap<Long, Int>(); val cover = HashMap<Long, Long>()
            val coverDate = HashMap<Long, Long>(); val coverVid = HashMap<Long, Boolean>()
            fun scanSource(base: Uri, video: Boolean) {
                val proj = arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.BUCKET_ID, MediaStore.MediaColumns.BUCKET_DISPLAY_NAME,
                    MediaStore.MediaColumns.RELATIVE_PATH, MediaStore.MediaColumns.DATE_ADDED)
                try {
                    ctx.contentResolver.query(base, proj, null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                        while (c.moveToNext()) {
                            val id = c.getLong(0); val b = c.getLong(1); val d = c.getLong(4)
                            names.getOrPut(b) { c.getString(2) ?: "Diğer" }
                            paths.getOrPut(b) { c.getString(3) ?: "" }
                            cnt[b] = (cnt[b] ?: 0) + 1
                            if (d > (coverDate[b] ?: -1L)) { coverDate[b] = d; cover[b] = id; coverVid[b] = video }   // en yeni öğe = kapak
                        }
                    }
                } catch (e: Exception) { }
            }
            if (flt != GalleryFilter.VIDEO) scanSource(IMGU, false)
            if ((flt == GalleryFilter.ALL || flt == GalleryFilter.VIDEO) && vg) scanSource(VIDU, true)
            names.map { (b, n) ->
                val v = coverVid[b] == true
                GalleryFolder(b, n, paths[b].orEmpty(), cnt[b] ?: 0, ContentUris.withAppendedId(if (v) VIDU else IMGU, cover[b]!!), v)
            }.sortedByDescending { it.count }
        }
        folders = list; total = list.sumOf { it.count }; loaded = true; loading = false
    }

    /** Yeşil "Ara": seçili albümleri (birden çoksa birleşik görünümde) açar; seçili filtreye göre tarama başlar. Seçim yoksa false. */
    fun openSelected(): Boolean {
        val ids = selectedFolderIds().filter { id -> folders.any { it.id == id } }
        if (ids.isEmpty()) return false
        val fs = ids.mapNotNull { id -> folders.firstOrNull { it.id == id } }
        if (fs.size == 1) openFolder(fs[0])
        else openFolder(GalleryFolder(-1L, "${fs.size} albüm", "", fs.sumOf { it.count }, fs[0].cover, fs[0].coverVideo, fs.map { it.id }))
        return true
    }

    fun openFolder(f: GalleryFolder) { resetScanClock(); clearGroups(); items = emptyList(); shown = emptyList(); viewing = -1; open = f
        if (filter == GalleryFilter.OBJECT && objectQuery.isBlank()) askObject = true }

    suspend fun loadPhotos(ctx: Context, f: GalleryFolder, perFolder: Int = 0) {
        val flt = filter; val vg = videoGranted
        val out = withContext(Dispatchers.IO) {
            GalleryAttrs.load(ctx); PhotoLabels.load(ctx)
            val res = ArrayList<Triple<Long, Uri, Boolean>>()
            fun readSource(base: Uri, video: Boolean) {
                try {
                    for (bid in (if (f.ids.isNotEmpty()) f.ids else listOf(f.id)))
                    ctx.contentResolver.query(base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.DATE_ADDED),
                        "${MediaStore.MediaColumns.BUCKET_ID} = ?", arrayOf(bid.toString()), "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                        var n = 0
                        while (c.moveToNext() && (perFolder <= 0 || n < perFolder)) { res.add(Triple(c.getLong(1), ContentUris.withAppendedId(base, c.getLong(0)), video)); n++ }
                    }
                } catch (e: Exception) { }
            }
            if (flt != GalleryFilter.VIDEO) readSource(IMGU, false)
            if ((flt == GalleryFilter.ALL || flt == GalleryFilter.VIDEO) && vg) readSource(VIDU, true)
            res.sortByDescending { it.first }
            res.map { GalleryItem(it.second, it.third) }
        }
        if (open?.id == f.id) { items = out; recompute() }
    }

    private val mainHandler = Handler(Looper.getMainLooper())
    /** Arka plan iş parçacıklarından güvenle çağrılır: asıl hesap her zaman ana iş parçacığında yapılır. */
    @Volatile private var lastRecompute = 0L
    /** Tarama ilerledikçe liste her 5 fotoğrafta değil, en çok ~0,6 sn'de bir yenilenir (akıcılık). */
    fun recomputeThrottled(d: Int, t: Int) { val now = System.currentTimeMillis(); if (d >= t || now - lastRecompute > 600) { lastRecompute = now; recomputeSafe() } }
    fun recomputeSafe() { if (Looper.myLooper() == Looper.getMainLooper()) recompute() else mainHandler.post { recompute() } }

    /** `items` içinden seçili filtreye uyanları `shown`a yazar (tarama ilerledikçe tekrar çağrılır). */
    fun recompute() {
      try {
        val f = filter
        val all = items
        val sq = if (f == GalleryFilter.OBJECT) SentenceQuery.parse(objectQuery) else null
        val items = if (capN > 0 && f.needsScan) all.filter { !it.video }.take(capN) else all   // "ilk N": yalnızca ilk N fotoğraf
        shown = when (f) {
            GalleryFilter.FEMALE -> items.filter { !it.video && GalleryAttrs.has(it.uri.toString(), "F") }
            GalleryFilter.MALE -> items.filter { !it.video && GalleryAttrs.has(it.uri.toString(), "M") }
            GalleryFilter.OBJECT -> if (sq != null) {
                items.filter { !it.video && sq.photoOk(it.uri.toString()) }   // (cümle): bütün yüzler cümleye uymalı
            } else if (TrObjects.isHeadscarf(objectQuery)) {
                // Eşarp / başörtüsü / türban / bandana: yalnızca örtülü KADIN yüzü doğrulanan fotoğraflar (başı açık olanlar asla gelmez)
                items.filter { !it.video && GalleryAttrs.has(it.uri.toString(), "W") }
            } else {
                val nq = if (objectQuery.isBlank()) null else TrObjects.nude(objectQuery)
                if (nq != null) {
                    // Açıkta görünen vücut bölümü: yalnızca dedektörün eşik üstü bulduğu fotoğraflar. Çocuk / bebek etiketi taşıyanlar hiçbir zaman gelmez.
                    // Etiketi henüz okunmamış fotoğraf (çocuk kontrolü yapılamadı) gösterilmez.
                    items.filter { val u = it.uri.toString()
                        !it.video && NudeDetector.matches(u, nq.classes) && PhotoLabels.scanned(u) && !PhotoLabels.has(u, CHILD_KEYS) &&
                            (nq.rest.isEmpty() || PhotoLabels.has(u, nq.rest)) }
                } else {
                    val keys = if (objectQuery.isBlank()) emptySet() else TrObjects.resolve(objectQuery)
                    if (keys.isEmpty()) emptyList() else items.filter { !it.video && PhotoLabels.has(it.uri.toString(), keys) }
                }
            }
            else -> items
        }
      } catch (e: Throwable) { shown = emptyList() }   // yazılan nesne adı ne olursa olsun program kapanmasın
    }

    /** Kadın / Erkek / Nesne / Türban filtresinde açık klasördeki fotoğrafları (daha önce taranmamışları) tarar. */
    suspend fun scanFolder(ctx: Context, limit: Int = 0) {
        val f = filter
        if (!f.needsScan) { scan = null; return }
        if (f == GalleryFilter.OBJECT && (askObject || objectQuery.isBlank())) { scan = null; return }   // yazı penceresi açıkken tarama başlamaz
        val imgsAll = items.filter { !it.video }.map { it.uri.toString() }
        val imgs = if (limit > 0) imgsAll.take(limit) else imgsAll   // "ilk N": klasörün en yeni N fotoğrafı
        if (imgs.isEmpty()) { scan = null; return }
        val myStart = System.currentTimeMillis(); scanSegStart = myStart
        var completed = false
        try {
            scanMsg = null
            val sq = if (f == GalleryFilter.OBJECT) SentenceQuery.parse(objectQuery) else null
            val nq = if (f == GalleryFilter.OBJECT && sq == null) TrObjects.nude(objectQuery) else null
            if (sq != null) {
                // (cümle) modu: önce yüz başına özellikler (cinsiyet / örtü / sakal / bıyık / gözlük), sonra varsa ek nesne kelimeleri yalnızca uyan adaylarda etiketlenir
                GalleryAttrs.ensure(ctx, imgs, true) { d, t -> scan = d to t; scanLast = d to t; recomputeThrottled(d, t) }
                if (sq.labelKeys.isNotEmpty()) PhotoLabels.ensure(ctx, imgs.filter { sq.facesOk(it) }) { d, t -> scan = d to t; scanLast = d to t; recomputeThrottled(d, t) }
            }
            else if (nq != null) {
                // 1) tüm fotoğraflar vücut bölümü dedektöründen geçer, 2) yalnızca aday çıkanlar etiketlenir (çocuk kontrolü + varsa ek kelime)
                NudeDetector.ensure(ctx, imgs) { d, t -> scan = d to t; scanLast = d to t; recomputeThrottled(d, t) }
                val cand = imgs.filter { NudeDetector.matches(it, nq.classes) }
                PhotoLabels.ensure(ctx, cand) { d, t -> scan = d to t; scanLast = d to t; recomputeThrottled(d, t) }
            }
            else if (f == GalleryFilter.OBJECT && TrObjects.isHeadscarf(objectQuery)) GalleryAttrs.ensure(ctx, imgs) { d, t -> scan = d to t; scanLast = d to t; recomputeThrottled(d, t) }
            else if (f == GalleryFilter.OBJECT) PhotoLabels.ensure(ctx, imgs) { d, t -> scan = d to t; scanLast = d to t; recomputeThrottled(d, t) }
            else GalleryAttrs.ensure(ctx, imgs) { d, t -> scan = d to t; scanLast = d to t; recomputeThrottled(d, t) }
            completed = scanLast != null && !scanPaused   // gerçekten tarama yapıldıysa (önbellekten gelen anlık sonuçta ses çalmaz)
        } catch (e: kotlinx.coroutines.CancellationException) { throw e
        } catch (e: Throwable) { scanMsg = e.message   /* tarama hatası programı kapatmasın */
        } finally {
            scanBase += System.currentTimeMillis() - myStart
            if (scanSegStart == myStart) scanSegStart = 0L
            if (!scanPaused) scanLast = null
            scan = null; recomputeSafe()
            if (completed) DoneSound.play(ctx)
        }
    }
}

private fun hasPhotoPermission(ctx: Context): Boolean {
    val p = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
    return ctx.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED
}

private val videoPermission: String
    get() = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_VIDEO else Manifest.permission.READ_EXTERNAL_STORAGE

private fun hasVideoPermission(ctx: Context): Boolean = ctx.checkSelfPermission(videoPermission) == PackageManager.PERMISSION_GRANTED

/** Simgeli, küçük düğme (klasör içi araç satırı). */
@Composable
fun GalBtn(icon: ImageVector, label: String, onClick: () -> Unit) {
    FilledTonalButton(onClick, contentPadding = PaddingValues(horizontal = 6.dp), modifier = Modifier.height(34.dp)) {
        Icon(icon, null, Modifier.size(14.dp)); Spacer(Modifier.width(3.dp))
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
    }
}

/** Üst çubuğun sağ üstündeki filtre düğmesi + açılır menü. */
@Composable
fun GalleryFilterMenu(compact: Boolean = false, asButton: Boolean = false) {
    var open by remember { mutableStateOf(false) }
    Box {
        if (asButton) GalBtn(Icons.Filled.Menu, "${GalleryState.filter.label} ▾") { open = true }
        else TextButton(onClick = { open = true }, contentPadding = if (compact) PaddingValues(horizontal = 6.dp) else ButtonDefaults.TextButtonContentPadding) { Text("${GalleryState.filter.label} ▾", fontWeight = FontWeight.Bold) }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            (listOf(GalleryFilter.ALL) + GalleryFilter.values().filter { it != GalleryFilter.ALL }).forEach { f ->
                DropdownMenuItem(
                    text = { Text(f.label, fontWeight = if (f == GalleryState.filter) FontWeight.Bold else FontWeight.Normal) },
                    onClick = { open = false; if (GalleryState.open != null && f.needsScan) GalleryState.pendingFilter = f else { GalleryState.capN = 0; GalleryState.choose(f) } })
            }
        }
    }
}

/** Video küçük resmi (Coil video çözmediği için sistemin küçük resmi kullanılır). */
@Composable
private fun VideoThumb(uri: Uri, modifier: Modifier, big: Boolean = false) {
    val ctx = LocalContext.current
    val bmp by produceState<android.graphics.Bitmap?>(null, uri) {
        value = withContext(Dispatchers.IO) {
            try { ctx.contentResolver.loadThumbnail(uri, android.util.Size(360, 360), null) } catch (e: Exception) { null }
        }
    }
    Box(modifier.background(Color(0xFF222222))) {
        bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = if (big) ContentScale.Fit else ContentScale.Crop) }
        Text("▶", color = Color.White, style = if (big) MaterialTheme.typography.displayMedium else MaterialTheme.typography.titleLarge,
            modifier = Modifier.align(Alignment.Center).clip(RoundedCornerShape(50)).background(Color(0x77000000)).padding(horizontal = 10.dp, vertical = 2.dp))
    }
}

/** Seçim işareti: boş halka (seçili değil) / dolu yuvarlak içinde ✓ (seçili). */
@Composable
private fun SelDot(on: Boolean) {
    Box(Modifier.size(24.dp).clip(CircleShape)
        .background(if (on) MaterialTheme.colorScheme.primary else Color(0x66000000))
        .border(1.5.dp, Color.White, CircleShape), contentAlignment = Alignment.Center) {
        if (on) Text("✓", color = MaterialTheme.colorScheme.onPrimary, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun GalleryScreen(vm: VM) {
    val ctx = LocalContext.current
    var granted by remember { mutableStateOf(hasPhotoPermission(ctx)) }
    val permLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    val videoLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { GalleryState.videoGranted = it }
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
    val flt = GalleryState.filter

    // Video izni: sayfa ilk açılışında bir kez, ayrıca "Video" seçilince sorulur
    LaunchedEffect(granted) {
        if (!granted) return@LaunchedEffect
        GalleryState.videoGranted = hasVideoPermission(ctx)
        if (!GalleryState.videoGranted && !GalleryState.askedVideo) { GalleryState.askedVideo = true; videoLauncher.launch(videoPermission) }
    }
    LaunchedEffect(flt) {
        if (granted && flt == GalleryFilter.VIDEO && !GalleryState.videoGranted) videoLauncher.launch(videoPermission)
    }

    // Sayfaya her girişte (ve filtre değişince) liste tazelenir
    LaunchedEffect(granted, GalleryState.videoGranted) { if (granted) GalleryState.loadFolders(ctx) }
    LaunchedEffect(granted) { if (granted) vm.syncEditedFolder() }
    LaunchedEffect(Unit) { if (GalleryState.scanPaused || GalleryState.groupPaused) DoneSound.warnUnfinished(ctx.applicationContext, "Galeride yarım kalan bir işlem var") }
    // Açık klasör varken geri tuşu bir üst basamağa döner (App içindeki genel BackHandler de bunu çağırır)
    val folder = GalleryState.open
    LaunchedEffect(folder?.id, granted, flt, GalleryState.objectQuery, GalleryState.videoGranted, GalleryState.askObject, GalleryState.scanPaused, GalleryState.capN) {
        if (granted && folder != null) {
            try { val multi = folder.ids.isNotEmpty()   // birleşik (çok albüm) görünümde sayı her albümün en yeni N öğesidir
                GalleryState.loadPhotos(ctx, folder, if (multi) vm.limitN() else 0); if (!GalleryState.scanPaused) GalleryState.scanFolder(ctx, if (multi) 0 else vm.limitN()) }
            catch (e: kotlinx.coroutines.CancellationException) { throw e }
            catch (e: Throwable) { }
        }
    }

    if (!granted) {
        Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
            Text("Galerini göstermek için fotoğraf izni gerekli.", style = MaterialTheme.typography.bodyLarge)
            Spacer(Modifier.height(16.dp))
            PrimaryAction("İzin ver", { permLauncher.launch(perm) })
        }
        return
    }

    if (GalleryState.askFace) GalleryFaceDialog(vm)
    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            RunningAlert()   // devam eden analiz varken üstte 5 sn'de bir yanıp sönen yeşil ışık + bilgi
            Box(Modifier.weight(1f).fillMaxWidth()) {
                if (flt == GalleryFilter.FAV) FavoritesScreen()
                else if (folder == null) FolderGrid(vm) else PhotoGrid(vm, folder)
            }
        }
        if (GalleryState.viewing < 0 && GalleryState.selPhotos.isNotEmpty()  && false)
            SelectionBar(vm, Modifier.align(Alignment.BottomCenter))
        if (GalleryState.viewing >= 0 && GalleryState.viewList.isNotEmpty()) FullViewer(vm)
        vm.enhReview?.let { EnhanceReview(vm, it) }
    }

    GalleryState.pendingFilter?.let { pf ->
        var n by remember(pf) { mutableStateOf(vm.photoLimit) }
        val cancel = { GalleryState.pendingFilter = null }
        val go = { v: String ->
            val d = v.filter { it.isDigit() }.take(6)
            vm.photoLimit = d
            val multi = GalleryState.open?.ids?.isNotEmpty() == true   // birleşik görünümde sınır zaten her albümün ilk N'i
            GalleryState.capN = if (multi) 0 else (d.toIntOrNull()?.takeIf { it > 0 } ?: 0)
            GalleryState.pendingFilter = null
            GalleryState.choose(pf)
        }
        var nm by remember(pf) { mutableStateOf(GalleryState.objectQuery) }
        if (pf == GalleryFilter.OBJECT) {
            // Nesne ismi + kaç fotoğraf taransın: tek pencerede (isim üstte, sayı altında)
            val goObj: () -> Unit = {
                val q = nm.trim()
                if (q.isNotEmpty()) {
                    val d = n.filter { it.isDigit() }.take(6)
                    vm.photoLimit = d
                    val multi = GalleryState.open?.ids?.isNotEmpty() == true
                    GalleryState.capN = if (multi) 0 else (d.toIntOrNull()?.takeIf { it > 0 } ?: 0)
                    GalleryState.pendingFilter = null
                    GalleryState.choose(pf)
                    GalleryState.objectQuery = q
                    GalleryState.askObject = false
                }
            }
            AlertDialog(onDismissRequest = cancel, shape = RoundedCornerShape(28.dp),
                title = { Text("Nesne ismi", fontWeight = FontWeight.Bold) },
                text = {
                    Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            OutlinedTextField(nm, { v -> nm = v.take(120) }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                                shape = RoundedCornerShape(14.dp),
                                leadingIcon = { Icon(Icons.Filled.Search, null) },
                                placeholder = { Text("araba, kedi, deniz…", maxLines = 1) },
                                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Next))
                            Text("Birden çok nesne için virgül kullan; koşul için parantez: (sakallı ve bıyıklı erkekler)",
                                style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        HorizontalDivider()
                        ScanCountField(n, { n = it }, { goObj() })
                    }
                },
                confirmButton = {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(cancel, Modifier.weight(1f).height(46.dp), shape = RoundedCornerShape(14.dp)) { Text("Vazgeç", fontWeight = FontWeight.SemiBold) }
                        ColorAction("Ara", OkGreen, { goObj() }, Modifier.weight(1f), enabled = nm.isNotBlank())
                    }
                })
        } else {
            AlertDialog(onDismissRequest = cancel, shape = RoundedCornerShape(28.dp),
                title = { Text("${pf.label} taraması", fontWeight = FontWeight.Bold) },
                text = { ScanCountField(n, { n = it }, { go(n) }) },
                confirmButton = {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        OutlinedButton(cancel, Modifier.weight(1f).height(46.dp), shape = RoundedCornerShape(14.dp)) { Text("Vazgeç", fontWeight = FontWeight.SemiBold) }
                        ColorAction("Ara", OkGreen, { go(n) }, Modifier.weight(1f))
                    }
                })
        }
    }
    if (GalleryState.askObject) {
        var t by remember { mutableStateOf(GalleryState.objectQuery) }
        val cancel = { GalleryState.askObject = false; if (GalleryState.objectQuery.isBlank()) GalleryState.filter = GalleryFilter.ALL }
        val confirm = { val q = t.trim(); GalleryState.objectQuery = q; GalleryState.askObject = false; if (q.isBlank()) GalleryState.filter = GalleryFilter.ALL }
        AlertDialog(onDismissRequest = cancel,
            title = { Text("Nesne ismi") },
            text = {
                OutlinedTextField(t, { v -> t = v.take(120) },
                    singleLine = true, label = { Text("örn: araba, kedi  veya  (sakallı ve bıyıklı erkekler)") },
                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Done),
                    keyboardActions = KeyboardActions(onDone = { confirm() }))
            },
            confirmButton = {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedButton(cancel, Modifier.weight(1f).height(46.dp), shape = RoundedCornerShape(14.dp)) { Text("Vazgeç", fontWeight = FontWeight.SemiBold) }
                    ColorAction("Ara", OkGreen, { confirm() }, Modifier.weight(1f))
                }
            })
    }
}

private val OkGreen = Color(0xFF2E7D32)

/** "Kaç fotoğraf taransın?" bölümü: soru + açıklama + sayı alanı + hızlı seçim çipleri (Hepsi = boş = tamamı). */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun ScanCountField(n: String, onChange: (String) -> Unit, onDone: () -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("Kaç fotoğraf taransın?", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
        Text("Klasörün en yeni kaç fotoğrafına bakılsın? Boş bırakırsan veya \"Hepsi\"ni seçersen tamamı taranır.",
            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        OutlinedTextField(n, { v -> onChange(v.filter { it.isDigit() }.take(6)) }, modifier = Modifier.fillMaxWidth(), singleLine = true,
            shape = RoundedCornerShape(14.dp), placeholder = { Text("Sayı (örn: 500)") },
            keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number, imeAction = ImeAction.Done),
            keyboardActions = KeyboardActions(onDone = { onDone() }))
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            for (c in listOf("100", "500", "1000", "")) {
                FilterChip(selected = n == c, onClick = { onChange(c) }, label = { Text(if (c.isEmpty()) "Hepsi" else c) })
            }
        }
    }
}

/** Vücut bölümü aramalarında bu etiketlerden birini taşıyan fotoğraflar sonuçtan çıkarılır. */
private val CHILD_KEYS = setOf("baby", "toddler", "infant", "child")

private fun unitOf(f: GalleryFilter) = when (f) { GalleryFilter.VIDEO -> "video"; GalleryFilter.ALL -> "öğe"; else -> "fotoğraf" }

/** Yeşil "Ara" düğmesi tarzında dolu, yuvarlak köşeli araç düğmesi. */
@Composable
private fun ToolBtn(kind: Ic, desc: String, enabled: Boolean, color: Color, onClick: () -> Unit) {
    val bg = if (enabled) color else color.copy(alpha = 0.28f)
    Box(Modifier.height(34.dp).width(34.dp).clip(RoundedCornerShape(10.dp)).background(bg)
        .clickable(enabled = enabled, onClick = onClick), contentAlignment = Alignment.Center) {
        ActIcon(kind, desc, Color.White, { if (enabled) onClick() }, Modifier.size(28.dp))
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FolderGrid(vm: VM) {
    var renaming by remember { mutableStateOf<GalleryFolder?>(null) }
    var newName by remember { mutableStateOf("") }
    val list = GalleryState.folders
    val flt = GalleryState.filter
    val gridState = rememberLazyGridState(GalleryState.folderScrollIdx, GalleryState.folderScrollOff)
    DisposableEffect(Unit) { onDispose { GalleryState.folderScrollIdx = gridState.firstVisibleItemIndex; GalleryState.folderScrollOff = gridState.firstVisibleItemScrollOffset } }
    if (list.isEmpty()) {
        Text(if (GalleryState.loading) "Galeri okunuyor…"
             else if (flt == GalleryFilter.VIDEO && !GalleryState.videoGranted) "Videoları göstermek için video izni gerekli."
             else if (flt == GalleryFilter.VIDEO) "Telefonda video bulunamadı." else "Telefonda fotoğraf bulunamadı.", Modifier.padding(16.dp))
        return
    }
    val anySel = GalleryState.selFolders.isNotEmpty() || GalleryState.selPhotos.isNotEmpty()
    Column(Modifier.fillMaxSize()) {
    // Üst bölüm (sayaç, seçili liste, araç satırı) SABİT: albümler kayarken yerinde kalır
    Column(Modifier.fillMaxWidth().padding(start = 8.dp, end = 8.dp, top = 8.dp, bottom = 4.dp)) {
                Text("${list.size} klasör / albüm • ${GalleryState.total} öğe", style = MaterialTheme.typography.titleMedium)
                // Seçili albümlerin adları seçildikçe alt alta; baştaki çöp ikonu albümü seçimden çıkarır (fotoğrafları silmez)
                if (GalleryState.selFolders.isNotEmpty()) {
                    val byId = list.associateBy { it.id }
                    val ids = GalleryState.selectedFolderIds().filter { byId.containsKey(it) }
                    val total = GalleryState.selFolders.size + GalleryState.selPhotos.size
                    // Yan yana, satırda 4 hücre: ilk hücre "N seçili" sayacı (ilk seçimin başında), sonra albümler; dolunca alt satıra geçer
                    val cells: List<Long?> = listOf<Long?>(null) + ids
                    Column(Modifier.fillMaxWidth().padding(top = 2.dp).heightIn(max = 132.dp).verticalScroll(rememberScrollState())) {
                        cells.chunked(4).forEach { rowCells ->
                            Row(Modifier.fillMaxWidth().height(30.dp), verticalAlignment = Alignment.CenterVertically) {
                                rowCells.forEach { id ->
                                    if (id == null) Text("$total seçili", Modifier.weight(1f), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary,
                                        fontWeight = FontWeight.Bold, maxLines = 1, softWrap = false)
                                    else Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically) {
                                        ActIcon(Ic.Delete, "Seçimden kaldır", MaterialTheme.colorScheme.error, { GalleryState.toggleFolder(id) }, Modifier.size(24.dp))
                                        Text(byId[id]?.name ?: "", Modifier.weight(1f), style = MaterialTheme.typography.labelSmall, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                                repeat(4 - rowCells.size) { Spacer(Modifier.weight(1f)) }
                            }
                        }
                    }
                }
                // Araç satırı: solda simgeler (Tümünü seç, Temizle, Adı değiştir, Sil); sağda filtre, Yüz ve "ilk N" sayısı
                val nf = GalleryState.selFolders.size; val np = GalleryState.selPhotos.size; val has = nf > 0 || np > 0
                val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
                val ic = Modifier.size(32.dp)
                Row(Modifier.fillMaxWidth().padding(top = 2.dp), verticalAlignment = Alignment.CenterVertically) {
                    ToolBtn(Ic.SelectAll, "Tümünü seç", list.isNotEmpty(), Color(0xFF7C5CE0)) { GalleryState.selectAllFolders() }
                    Spacer(Modifier.width(3.dp))
                    ToolBtn(Ic.Close, "Temizle", has, Color(0xFF6B7280)) { GalleryState.clearAllSelection() }
                    Spacer(Modifier.width(3.dp))
                    ToolBtn(Ic.Edit, "Adı değiştir", nf == 1, Color(0xFF3B82F6)) { GalleryState.askRename = true }
                    Spacer(Modifier.width(3.dp))
                    ToolBtn(Ic.Delete, "Sil", has, Color(0xFFE5484D)) { GalleryState.askDelete = true }
                    Spacer(Modifier.weight(1f))
                    GalleryFilterMenu(compact = true)
                    TextButton({ GalleryState.askFace = true }, contentPadding = PaddingValues(horizontal = 3.dp)) { Text("Yüz", fontWeight = FontWeight.Bold) }
                    LimitPill(vm.photoLimit) { vm.photoLimit = it }
                    Spacer(Modifier.width(6.dp))
                    Button({ if (!GalleryState.openSelected()) vm.toast("Önce aranacak albümleri seç") },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E9E5B), contentColor = Color.White),
                        contentPadding = PaddingValues(horizontal = 10.dp), modifier = Modifier.height(34.dp)) { Text("Ara", fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1, softWrap = false) }
                }
                if (flt == GalleryFilter.VIDEO || flt == GalleryFilter.PHOTO) Text("Filtre: ${flt.label} — albümleri seçip yeşil Ara'ya bas; süzgeç açılan albümde uygulanır.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (flt.needsScan) Text("Filtre: ${flt.label}${if (flt == GalleryFilter.OBJECT && GalleryState.objectQuery.isNotBlank()) " (${GalleryState.objectQuery})" else ""} — albümleri seçip yeşil Ara'ya bas (ya da klasörü aç); fotoğraflar cihazda taranıp süzülür.",
                    style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
    LazyVerticalGrid(GridCells.Fixed(4), Modifier.fillMaxWidth().weight(1f), state = gridState,
        contentPadding = PaddingValues(start = 8.dp, top = 4.dp, end = 8.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        items(list, key = { it.id }) { f ->
            val sel = GalleryState.selFolders.containsKey(f.id)
            // basılı tut: klasörü seç; bir klasör seçiliyken dokunmak seçimi değiştirir, değilse klasörü açar
            Column(Modifier.combinedClickable(
                onClick = { if (GalleryState.selFolders.isNotEmpty()) GalleryState.toggleFolder(f.id) else GalleryState.openFolder(f) },
                onLongClick = { GalleryState.toggleFolder(f.id) })) {
                Box {
                    val cm = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(10.dp))
                    if (f.coverVideo) VideoThumb(f.cover, cm) else AsyncImage(f.cover, null, cm, contentScale = ContentScale.Crop)
                    if (sel) Box(Modifier.matchParentSize().border(3.dp, MaterialTheme.colorScheme.primary, RoundedCornerShape(10.dp)))
                    Box(Modifier.align(Alignment.TopEnd).size(36.dp).clickable { GalleryState.toggleFolder(f.id) }, contentAlignment = Alignment.Center) { SelDot(sel) }
                }
                Text(f.name, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 3.dp))
                Text("${f.count}",
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        // Sayfanın altı: Son İşlemler
        item(span = { GridItemSpan(maxLineSpan) }) { RecentOpsSection() }
    }
    }
    if (GalleryState.askRename) LaunchedEffect(Unit) {
        GalleryState.askRename = false
        list.firstOrNull { GalleryState.selFolders.containsKey(it.id) }?.let { newName = it.name; renaming = it }
    }
    if (GalleryState.askDelete) {
        val nf = GalleryState.selFolders.size; val np = GalleryState.selPhotos.size
        val what = listOfNotNull(if (nf == 1) "seçili albüm" else if (nf > 1) "seçili $nf albüm" else null, if (np > 0) "seçili $np öğe" else null).joinToString(" ve ")
        // 1. adım: emin misiniz? Evet / Hayır
        AlertDialog(onDismissRequest = { GalleryState.askDelete = false },
            title = { Text("Emin misiniz?") },
            text = { Text("${what.replaceFirstChar { it.uppercase() }} silinecektir. Emin misiniz?") },
            confirmButton = { TextButton({ GalleryState.askDelete = false; GalleryState.askTrash = true }) { Text("Evet", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton({ GalleryState.askDelete = false }) { Text("Hayır") } })
    }
    if (GalleryState.askTrash) {
        val nf = GalleryState.selFolders.size; val np = GalleryState.selPhotos.size
        val what = listOfNotNull(if (nf == 1) "Seçili albüm" else if (nf > 1) "Seçili $nf albüm" else null, if (np > 0) "${if (nf > 0) "seçili" else "Seçili"} $np öğe" else null).joinToString(" ve ")
        val canTrash = android.os.Build.VERSION.SDK_INT >= 30
        // 2. adım: geri dönüşüm uyarısı
        AlertDialog(onDismissRequest = { GalleryState.askTrash = false },
            title = { Text(if (canTrash) "Geri dönüşüme atılacak" else "Kalıcı silinecek") },
            text = { Text(if (canTrash) "$what silinmeyecek, geri dönüşüm kutusuna atılacak. İstersen geri dönüşüm kutusundan (30 gün içinde) geri alabilirsiniz."
                          else "$what telefondan kalıcı olarak silinecek. Bu Android sürümünde geri dönüşüm kutusu yok, geri alınamaz.") },
            confirmButton = { TextButton({
                GalleryState.askTrash = false
                vm.deleteGallerySelection(GalleryState.selFolders.keys.toSet(), GalleryState.selPhotos.keys.toSet())
            }) { Text(if (canTrash) "Geri dönüşüme at" else "Sil", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton({ GalleryState.askTrash = false }) { Text("Vazgeç") } })
    }
    renaming?.let { f ->
        AlertDialog(onDismissRequest = { renaming = null },
            title = { Text("Klasör adını değiştir") },
            text = {
                Column {
                    OutlinedTextField(newName, { newName = it }, singleLine = true, label = { Text("Yeni ad") })
                    if (!(f.path.startsWith("DCIM/") || f.path.startsWith("Pictures/")))
                        Text("Bu klasör ${f.path.trimEnd('/')} altında; Android yalnızca DCIM ve Pictures altındaki klasörlerin adının değişmesine izin verir.",
                            style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(top = 8.dp))
                }
            },
            confirmButton = { TextButton({ val n = newName; renaming = null; vm.renameGalleryFolder(f, n) }) { Text("Değiştir") } },
            dismissButton = { TextButton({ renaming = null }) { Text("Vazgeç") } })
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun PhotoGrid(vm: VM, f: GalleryFolder) {
    val ctx = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    var groupJob by remember { mutableStateOf<kotlinx.coroutines.Job?>(null) }
    val groups = GalleryState.groups
    val openG = GalleryState.openGroup
    val gp = GalleryState.grouping
    val list = openG?.items ?: GalleryState.shown
    val flt = GalleryState.filter
    val sc = GalleryState.scan
    val saved = GalleryState.photoScroll[f.id]
    val gridState = rememberLazyGridState(saved?.first ?: 0, saved?.second ?: 0)
    DisposableEffect(f.id) { onDispose { GalleryState.photoScroll[f.id] = gridState.firstVisibleItemIndex to gridState.firstVisibleItemScrollOffset } }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(start = 12.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (flt.needsScan) "${f.name} • ${list.size} ${unitOf(flt)} (${flt.label}${if (flt == GalleryFilter.OBJECT) ": ${GalleryState.objectQuery}" else ""})"
                 else "${f.name} • ${if (GalleryState.items.isEmpty()) f.count else list.size} ${unitOf(flt)}",
                Modifier.weight(1f).padding(vertical = 6.dp), style = MaterialTheme.typography.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
        }
        val np = GalleryState.selPhotos.size
        Row(Modifier.padding(horizontal = 12.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(if (np > 0) "$np öğe seçili" else "Tam ekran için dokun • seçmek için yuvarlağa dokun veya basılı tut", Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis,
                style = MaterialTheme.typography.labelSmall, color = if (np > 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
        }
        // Simgeli düğmeler: Tümü, Yüz Grupla, filtre (Hepsi ▾), Yüz; en sağda Netleştir / Taşı / Sil
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Row(Modifier.weight(1f), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                if (list.isNotEmpty() && (groups == null || openG != null)) GalBtn(Icons.Filled.Check, "Tümü") { if (openG != null) openG.items.forEach { GalleryState.selPhotos[it.uri.toString()] = true } else GalleryState.selectAllShown() }
                if (groups == null && gp == null && GalleryState.shown.any { !it.video } && sc == null)
                    GalBtn(Icons.Filled.Person, "Yüz Grupla") { groupJob = scope.launch { GalleryState.groupShown(ctx) } }
                if (groups != null && openG == null) GalBtn(Icons.Filled.Person, "Grubu kapat") { GalleryState.groups = null }
                GalleryFilterMenu(asButton = true)
                GalBtn(Icons.Filled.Face, "Yüz") { GalleryState.askFace = true }
            }
            SelActionButtons(vm)   // Netleştir / Taşı / Sil: Tümü-Foto-Yüz satırının sağında
        }
        UnfinishedAlert()
        ScanBar()
        if (gp != null) GroupBar { groupJob?.cancel(); GalleryState.clearGroups() }
        GalleryState.groupError?.let { Text(it, Modifier.padding(horizontal = 12.dp), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
        if (groups != null && openG == null) {
            Text("${groups.count { !it.ungrouped }} kişi • ${GalleryState.shown.size} ${unitOf(flt)}", Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.labelMedium)
            Box(Modifier.weight(1f)) { GroupTiles(groups) { GalleryState.openGroup = it } }
        }
        else if (GalleryState.items.isEmpty()) Text("Fotoğraflar okunuyor…", Modifier.padding(16.dp))
        else if (list.isEmpty()) Text(if (sc != null) "Eşleşen fotoğraf aranıyor…" else if (flt == GalleryFilter.OBJECT && GalleryState.objectQuery.isBlank()) "Filtre için bir nesne ismi yazın." else if (GalleryState.scanMsg != null) GalleryState.scanMsg!! else "Bu klasörde '${flt.label}' filtresine uyan öğe yok.", Modifier.padding(16.dp))
        else LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), state = gridState, contentPadding = PaddingValues(start = 4.dp, top = 4.dp, end = 4.dp, bottom = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            itemsIndexed(list, key = { _, item -> item.uri.toString() }) { i, item ->
                val sel = GalleryState.selPhotos.containsKey(item.uri.toString())
                // tek dokunuş: tam ekran (altında Düzenle / Netleştir / Taşı / Sil); yuvarlağa dokunma veya uzun basış: seç / seçimi kaldır
                Box(Modifier.aspectRatio(1f).background(if (sel) MaterialTheme.colorScheme.primaryContainer else Color.Transparent)
                    .combinedClickable(onClick = { GalleryState.viewing = i }, onLongClick = { GalleryState.togglePhoto(item.uri) })) {
                    val m = Modifier.fillMaxSize().padding(if (sel) 8.dp else 0.dp).clip(RoundedCornerShape(if (sel) 6.dp else 0.dp))
                    if (item.video) VideoThumb(item.uri, m) else AsyncImage(item.uri, null, m, contentScale = ContentScale.Crop)
                    Box(Modifier.align(Alignment.TopEnd).size(44.dp).clickable { GalleryState.togglePhoto(item.uri) }, contentAlignment = Alignment.Center) { SelDot(sel) }
                }
            }
        }
    }
}

/** Seçili öğeler için simgeli işlem düğmeleri: Netleştir (seçilenlerin hepsine), Taşı, Sil. Seçim yokken soluk görünür. */
@Composable
private fun SelActionButtons(vm: VM) {
    var showMove by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val n = GalleryState.selPhotos.size
    val on = n > 0
    val dim = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.38f)
    val photos = GalleryState.selPhotos.keys.filter { k -> GalleryState.items.none { it.uri.toString() == k && it.video } }
    ActIcon(Ic.Enhance, "Netleştir", if (on && photos.isNotEmpty()) MaterialTheme.colorScheme.primary else dim, { if (photos.isNotEmpty()) vm.enhanceGallery(photos) }, Modifier.size(34.dp))
    ActIcon(Ic.Move, "Taşı", if (on) MaterialTheme.colorScheme.onSurface else dim, { if (on) showMove = true }, Modifier.size(34.dp))
    ActIcon(Ic.Delete, "Sil", if (on) MaterialTheme.colorScheme.error else dim, { if (on) confirmDelete = true }, Modifier.size(34.dp))
    if (showMove) MoveDialog(vm, { showMove = false }) { rel ->
        showMove = false
        vm.movePhotos(GalleryState.selPhotos.keys.toList(), rel, fromGallery = true) { moved ->
            GalleryState.removeUris(moved)
            vm.viewModelScope.launch { GalleryState.loadFolders(vm.getApplication<android.app.Application>()) }
        }
    }
    if (confirmDelete) AlertDialog(onDismissRequest = { confirmDelete = false },
        title = { Text("Silinsin mi?") },
        text = { Text("Seçili $n öğe telefondan silinecek. Bu işlem geri alınamaz.") },
        confirmButton = { TextButton({ confirmDelete = false; vm.deletePhotos(GalleryState.selPhotos.keys.toList()) }) { Text("Sil", color = MaterialTheme.colorScheme.error) } },
        dismissButton = { TextButton({ confirmDelete = false }) { Text("Vazgeç") } })
}

/** Alt çubuk (yalnızca Türban ekranı): seçili sayısı + Netleştir / Taşı / Sil simgeleri. */
@Composable
private fun SelectionBar(vm: VM, modifier: Modifier = Modifier) {
    val n = GalleryState.selPhotos.size
    Surface(modifier.fillMaxWidth().padding(8.dp), shape = RoundedCornerShape(16.dp), tonalElevation = 6.dp, shadowElevation = 6.dp) {
        Row(Modifier.padding(horizontal = 12.dp, vertical = 2.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("$n öğe seçili", Modifier.weight(1f), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary)
            SelActionButtons(vm)
        }
    }
}

/** Galeride çoklu netleştirme sonucu: yeni hâllerin hepsi ekranda. "Bitti" → seçilen orijinaller kaynağından silinir; yeni hâller Düzenlenenler albümünde kalır. */
@Composable
private fun EnhanceReview(vm: VM, pairs: List<Pair<String, String>>) {
    androidx.activity.compose.BackHandler(true) { vm.finishReview(false) }
    Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        Column(Modifier.fillMaxSize()) {
            Text("${pairs.size} fotoğraf netleştirildi", Modifier.padding(12.dp, 10.dp, 12.dp, 2.dp), style = MaterialTheme.typography.titleMedium)
            Text("Yeni hâlleri Düzenlenenler albümüne kaydedildi. \"Bitti\" dersen seçtiğin eski orijinaller kaynağından silinir.",
                Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f).padding(top = 8.dp), contentPadding = PaddingValues(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                items(pairs, key = { it.second }) { (_, nu) ->
                    AsyncImage(Uri.parse(nu), null, Modifier.aspectRatio(1f), contentScale = ContentScale.Crop)
                }
            }
            Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton({ vm.finishReview(false) }, Modifier.weight(1f)) { Text("Orijinalleri koru", maxLines = 1) }
                Button({ vm.finishReview(true) }, Modifier.weight(1f)) { Text("Bitti", maxLines = 1) }
            }
        }
    }
}

/** Tam ekran, sağa-sola kaydırmalı görüntüleyici. Videoda büyük ▶ düğmesi telefonun video oynatıcısını açar. Geri tuşu ızgaraya döner. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun FullViewer(vm: VM) {
    val ctx = LocalContext.current
    val list = GalleryState.viewList
    if (list.isEmpty()) { LaunchedEffect(Unit) { GalleryState.viewing = -1 }; return }
    val pager = rememberPagerState(initialPage = GalleryState.viewing.coerceIn(0, list.size - 1)) { list.size }
    Box(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(pager, Modifier.fillMaxSize()) { page ->
            val it = list[page]
            if (it.video) VideoThumb(it.uri, Modifier.fillMaxSize().clickable {
                try {
                    ctx.startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(it.uri, "video/*").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION))
                } catch (e: Exception) { }
            }, big = true)
            else AsyncImage(it.uri, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
        }
        val cur = list[pager.currentPage.coerceIn(0, list.size - 1)]
        val curSel = GalleryState.selPhotos.containsKey(cur.uri.toString())
        Box(Modifier.align(Alignment.TopEnd).padding(8.dp).size(48.dp).clickable { GalleryState.togglePhoto(cur.uri) }, contentAlignment = Alignment.Center) { SelDot(curSel) }
        var showMove by remember { mutableStateOf(false) }
        var confirmDelete by remember { mutableStateOf(false) }
        Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().background(Color(0x99000000)).navigationBarsPadding().padding(vertical = 6.dp),
            horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
            FavButton(cur.uri.toString())
            if (!cur.video) ActIcon(Ic.Edit, "Düzenle", Color.White, {
                vm.beginExternalEdit(cur.uri.toString())
                if (!openSystemEditor(ctx, cur.uri)) vm.toast("Düzenleyici uygulama bulunamadı.")
            })
            if (!cur.video) ActIcon(Ic.Enhance, "Netleştir", Color.White, { vm.enhancePhotos(listOf(cur.uri.toString()), forceNormal = true) })
            ActIcon(Ic.Move, "Taşı", Color.White, { showMove = true })
            ActIcon(Ic.Delete, "Sil", Color.White, { confirmDelete = true })
        }
        if (showMove) MoveDialog(vm, { showMove = false }) { rel ->
            showMove = false
            vm.movePhotos(listOf(cur.uri.toString()), rel, fromGallery = true) { moved ->
                GalleryState.removeUris(moved)
                vm.viewModelScope.launch { GalleryState.loadFolders(vm.getApplication<android.app.Application>()) }
            }
        }
        if (confirmDelete) AlertDialog(onDismissRequest = { confirmDelete = false },
            title = { Text("Silinsin mi?") },
            text = { Text("Bu ${if (cur.video) "video" else "fotoğraf"} telefondan silinecek. Bu işlem geri alınamaz.") },
            confirmButton = { TextButton({ confirmDelete = false; vm.deletePhotos(listOf(cur.uri.toString())) }) { Text("Sil", color = MaterialTheme.colorScheme.error) } },
            dismissButton = { TextButton({ confirmDelete = false }) { Text("Vazgeç") } })
        Text("${pager.currentPage + 1} / ${list.size}", color = Color.White, style = MaterialTheme.typography.labelLarge,
            modifier = Modifier.align(Alignment.TopCenter).padding(12.dp).clip(RoundedCornerShape(12.dp)).background(Color(0x66000000)).padding(horizontal = 10.dp, vertical = 4.dp))
    }
}


/** Klasör taraması çubuğu: yeşil ilerleme, geçen / kalan süre, Durdur – Devam et. */
/** Devam eden analiz (galeri taraması, yüz gruplama, albüm analizi, nesne / kişi araması) varken üstte yeşil bildirim ışığı: 5 sn'de bir yanıp söner ve ne sürdüğünü yazar. */
@Composable
private fun RunningAlert() {
    val sc = GalleryState.scan; val gp = GalleryState.grouping
    val text: String? = when {
        sc != null && !GalleryState.scanPaused -> "Galeri taraması sürüyor • ${sc.first} / ${sc.second}" + (if (sc.second > 0) " • %${sc.first * 100 / sc.second}" else "")
        gp != null && !GalleryState.groupPaused -> "Yüz gruplama sürüyor • ${gp.first} / ${gp.second}" + (if (gp.second > 0) " • %${gp.first * 100 / gp.second}" else "")
        Engine.running -> "Albüm analizi sürüyor • ${Engine.done} / ${Engine.total}"
        SearchEngine.running -> "Nesne araması sürüyor"
        PersonEngine.running -> "Kişi araması sürüyor"
        else -> null
    }
    val running = text != null
    var on by remember { mutableStateOf(false) }
    val ctxR = LocalContext.current.applicationContext
    LaunchedEffect(running) {
        if (!running) { on = false; kotlinx.coroutines.delay(3000); DoneSound.runPlayed = false; return@LaunchedEffect }   // 3 sn boyunca yeniden başlamazsa yeni çalışma sayılır
        if (!DoneSound.runPlayed) { DoneSound.runPlayed = true; DoneSound.play(ctxR, run = true) }   // devam eden analiz sesi: çalışma başına BİR KERE
        while (true) { on = true; kotlinx.coroutines.delay(800); on = false; kotlinx.coroutines.delay(4200) }   // 5 sn'lik döngü: 0,8 sn yanar
    }
    if (text == null) return
    val a by androidx.compose.animation.core.animateFloatAsState(if (on) 1f else 0.12f, androidx.compose.animation.core.tween(250), label = "runLight")
    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp).clip(RoundedCornerShape(12.dp))
            .background(Color(0xFF16301F).copy(alpha = 0.6f + 0.4f * a)).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(CircleShape).background(Color(0xFF4CAF50).copy(alpha = a)))
        Spacer(Modifier.width(10.dp))
        Text(text, color = Color(0xFFB9F6CA), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Yarım kalan (durdurulmuş) işlem varken 5 sn yanıp sönen turuncu "bildirim ışığı" şeridi. */
@Composable
private fun UnfinishedAlert() {
    val until = GalleryState.unfinishedUntil
    var on by remember(until) { mutableStateOf(until > System.currentTimeMillis()) }
    LaunchedEffect(until) { val r = until - System.currentTimeMillis(); if (r > 0) { on = true; kotlinx.coroutines.delay(r) }; on = false }
    if (!on || !(GalleryState.scanPaused || GalleryState.groupPaused)) return
    val a by androidx.compose.animation.core.rememberInfiniteTransition(label = "unf").animateFloat(0.2f, 1f,
        androidx.compose.animation.core.infiniteRepeatable(androidx.compose.animation.core.tween(450), androidx.compose.animation.core.RepeatMode.Reverse), label = "a")
    Row(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 2.dp).clip(RoundedCornerShape(12.dp)).background(Color(0xFF3A2A00)).padding(horizontal = 12.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(14.dp).clip(androidx.compose.foundation.shape.CircleShape).background(Color(0xFFFFA000).copy(alpha = a)))
        Spacer(Modifier.width(10.dp))
        Text("Yarım kalan işlem var — Devam et'e basarak sürdürebilirsin.", color = Color(0xFFFFCC80), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ScanBar() {
    val ctx = LocalContext.current.applicationContext
    val sc = GalleryState.scan
    val paused = GalleryState.scanPaused
    if (sc == null && !paused) return
    val last = sc ?: GalleryState.scanLast
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(GalleryState.scanSegStart, paused) {
        while (GalleryState.scanSegStart > 0L) { now = System.currentTimeMillis(); kotlinx.coroutines.delay(1000) }
    }
    val d = last?.first ?: 0; val t = last?.second ?: 0
    val seg = if (GalleryState.scanSegStart > 0L) (now - GalleryState.scanSegStart).coerceAtLeast(0L) else 0L
    val elapsedSec = (GalleryState.scanBase + seg) / 1000
    val remainSec = if (!paused && d > 0 && t > d) ((t - d).toLong() * seg / d) / 1000 else -1L
    val frac = if (t == 0) 0f else (d.toFloat() / t).coerceIn(0f, 1f)
    val green = Color(0xFF4CAF50); val soft = Color(0xFFB9F6CA)
    Surface(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp), shape = RoundedCornerShape(14.dp), color = Color(0xFF16301F)) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (paused) "Duraklatıldı" else "Taranıyor", style = MaterialTheme.typography.labelMedium, color = soft, fontWeight = FontWeight.Bold)
                    Text("$d / $t  •  %${(frac * 100).toInt()}", style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
                }
                Button({ if (!paused) DoneSound.warnUnfinished(ctx, "Yarım kalan tarama: $d / $t"); GalleryState.scanPaused = !paused }, Modifier.height(38.dp), contentPadding = PaddingValues(horizontal = 16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = green, contentColor = Color.White)) {
                    Text(if (paused) "Devam et" else "Durdur", fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(6.dp))
                // Sil: taramayı bırakır, süzgeci "Hepsi"ne döndürür (taranan fotoğraf bilgileri saklı kalır)
                Button({ GalleryState.scanPaused = false; GalleryState.choose(GalleryFilter.ALL) }, Modifier.height(38.dp), contentPadding = PaddingValues(horizontal = 14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828), contentColor = Color.White)) {
                    Text("Sil", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { frac }, Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = Color(0xFF69F0AE), trackColor = Color(0xFF2E5339))
            Spacer(Modifier.height(6.dp))
            Row {
                Text("Geçen ${Engine.fmt(elapsedSec)}", style = MaterialTheme.typography.labelMedium, color = soft, modifier = Modifier.weight(1f))
                Text(if (paused) "Kalan —" else if (remainSec >= 0) "Kalan ~${Engine.fmt(remainSec)}" else "Kalan hesaplanıyor…", style = MaterialTheme.typography.labelMedium, color = soft)
            }
        }
    }
}


/** Yüz gruplama çubuğu: yeşil ilerleme, geçen / kalan süre, Durdur – Devam et ve Sil (gruplamayı bırakır). */
@Composable
private fun GroupBar(onDelete: () -> Unit) {
    val ctx = LocalContext.current.applicationContext
    val gp = GalleryState.grouping ?: return
    val paused = GalleryState.groupPaused
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(GalleryState.groupSegStart, paused) {
        while (GalleryState.groupSegStart > 0L) { now = System.currentTimeMillis(); kotlinx.coroutines.delay(1000) }
    }
    val d = gp.first; val t = gp.second
    val seg = if (GalleryState.groupSegStart > 0L) (now - GalleryState.groupSegStart).coerceAtLeast(0L) else 0L
    val activeMs = GalleryState.groupBase + seg
    val elapsedSec = activeMs / 1000
    val remainSec = if (!paused && d > 0 && t > d) ((t - d).toLong() * activeMs / d) / 1000 else -1L
    val frac = if (t == 0) 0f else (d.toFloat() / t).coerceIn(0f, 1f)
    val green = Color(0xFF4CAF50); val soft = Color(0xFFB9F6CA)
    Surface(Modifier.fillMaxWidth().padding(horizontal = 10.dp, vertical = 4.dp), shape = RoundedCornerShape(14.dp), color = Color(0xFF16301F)) {
        Column(Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(if (paused) "Duraklatıldı" else if (d >= t && t > 0) "Gruplar kuruluyor…" else "Yüzler gruplanıyor", style = MaterialTheme.typography.labelMedium, color = soft, fontWeight = FontWeight.Bold)
                    Text("$d / $t  •  %${(frac * 100).toInt()}", style = MaterialTheme.typography.titleMedium, color = Color.White, fontWeight = FontWeight.Bold)
                }
                Button({ if (!paused) DoneSound.warnUnfinished(ctx, "Yarım kalan yüz gruplama: $d / $t"); GalleryState.toggleGroupPause() }, Modifier.height(38.dp), contentPadding = PaddingValues(horizontal = 16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = green, contentColor = Color.White)) {
                    Text(if (paused) "Devam et" else "Durdur", fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(6.dp))
                Button(onDelete, Modifier.height(38.dp), contentPadding = PaddingValues(horizontal = 14.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFC62828), contentColor = Color.White)) {
                    Text("Sil", fontWeight = FontWeight.Bold)
                }
            }
            Spacer(Modifier.height(8.dp))
            LinearProgressIndicator(progress = { frac }, Modifier.fillMaxWidth().height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = Color(0xFF69F0AE), trackColor = Color(0xFF2E5339))
            Spacer(Modifier.height(6.dp))
            Row {
                Text("Geçen ${Engine.fmt(elapsedSec)}", style = MaterialTheme.typography.labelMedium, color = soft, modifier = Modifier.weight(1f))
                Text(if (paused) "Kalan —" else if (remainSec >= 0) "Kalan ~${Engine.fmt(remainSec)}" else if (d >= t && t > 0) "Kalan ~00:00" else "Kalan hesaplanıyor…", style = MaterialTheme.typography.labelMedium, color = soft)
            }
        }
    }
}

/** Küçük, hap biçimli sayı kutusu: boş = hepsi; rakam girilirse taramalarda her klasörün en yeni o kadar fotoğrafı alınır. */
@Composable
private fun LimitPill(value: String, onChange: (String) -> Unit) {
    val cs = MaterialTheme.colorScheme
    androidx.compose.foundation.text.BasicTextField(value, { v -> onChange(v.filter { it.isDigit() }.take(6)) }, singleLine = true,
        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 14.sp, fontWeight = FontWeight.Bold, color = cs.onSurface, textAlign = androidx.compose.ui.text.style.TextAlign.Center),
        cursorBrush = androidx.compose.ui.graphics.SolidColor(cs.primary),
        keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number),
        modifier = Modifier.width(64.dp).height(34.dp),
        decorationBox = { inner ->
            Box(Modifier.fillMaxSize().clip(RoundedCornerShape(17.dp)).background(cs.surfaceVariant.copy(alpha = 0.45f))
                .border(1.dp, if (value.isBlank()) cs.outline.copy(alpha = 0.6f) else cs.primary, RoundedCornerShape(17.dp)), contentAlignment = Alignment.Center) {
                if (value.isBlank()) Text("Sayı", fontSize = 13.sp, color = cs.onSurfaceVariant.copy(alpha = 0.7f), maxLines = 1, softWrap = false)
                inner()
            }
        })
}
