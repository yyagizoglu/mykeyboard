package com.fotoliz.app

import android.content.ContentUris
import android.content.Context
import android.graphics.Bitmap
import android.net.Uri
import android.provider.MediaStore
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.atomic.AtomicInteger
import kotlin.math.sqrt

/** Aynı kişiye ait fotoğraflar. cover: yüz küçük resmi (yoksa ilk fotoğraf gösterilir). */
class FaceGroup(val id: Int, val items: List<GalleryItem>, val cover: Bitmap?, val ungrouped: Boolean = false)

private class TFace(val emb: FloatArray, val photo: String, val q: Float, val area: Int, val crop: Bitmap)

private class TurbanCore {
    val photos = LinkedHashSet<String>(); val embs = ArrayList<FloatArray>()
    var sum = FloatArray(0); var cent = FloatArray(0); var score = 0
    fun add(r: TFace) {
        if (sum.isEmpty()) sum = FloatArray(r.emb.size)
        for (i in sum.indices) sum[i] += r.emb[i]
        cent = normalize(sum)
        photos.add(r.photo); embs.add(r.emb)
        score = maxOf(score, (r.area * r.q).toInt())
    }
}

/**
 * Galeri > Türban filtresi: telefondaki TÜM klasörler taranır, yalnızca türbanlı / eşarplı / bandanalı KADIN fotoğrafları ekrana gelir.
 * Tarama bitince "Yüze göre grupla": bulunan yüzler ArcFace ile ayrıştırılıp aynı kişiye ait fotoğraflar gruplanır.
 */
object TurbanState {
    var items by mutableStateOf<List<GalleryItem>>(emptyList())      // bulunanlar (yeniden eskiye)
    var scan by mutableStateOf<Pair<Int, Int>?>(null)                // tarama ilerlemesi (biten, toplam); null = tarama yok
    var scanned by mutableStateOf(false)                             // tüm klasörler bitti
    var grouping by mutableStateOf<Pair<Int, Int>?>(null)            // gruplama ilerlemesi (biten, bulunan foto)
    var groups by mutableStateOf<List<FaceGroup>?>(null)             // null = gruplanmamış (düz liste)
    var openGroup by mutableStateOf<FaceGroup?>(null)
    var error by mutableStateOf<String?>(null)
    var stopped by mutableStateOf(false)                             // kullanıcı taramayı durdurdu: ekrana tekrar girilince kendiliğinden başlamaz
    var started by mutableStateOf(false)                             // "Başla"ya basıldı: false iken albüm seçme ekranı görünür, tarama başlamaz
    val pickIds = mutableStateMapOf<Long, Boolean>()                 // taranacak albümler
    var limitText by mutableStateOf("")                              // her albümde ilk kaç fotoğraf (boş = hepsi)

    /** Filtre yeniden seçilince: sonuçlar silinir, albüm seçme ekranına dönülür (albüm seçimi ve sayı korunur). */
    fun reset() { started = false; stopped = false; scanned = false; scan = null; grouping = null; items = emptyList(); groups = null; openGroup = null; error = null }

    /** Tam ekran görüntüleyicinin gezdiği liste. */
    val shown: List<GalleryItem> get() = openGroup?.items ?: items

    /** Geri tuşu: önce açık grubu, sonra grup listesini kapatır. */
    fun back(): Boolean {
        if (openGroup != null) { openGroup = null; return true }
        if (groups != null) { groups = null; return true }
        return false
    }

    fun clearGroups() { groups = null; openGroup = null }

    private fun allImages(ctx: Context, ids: Set<Long>, limit: Int): List<Uri> {
        val out = ArrayList<Uri>()
        val base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val cnt = HashMap<Long, Int>()
        try {
            ctx.contentResolver.query(base, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.BUCKET_ID), null, null, "${MediaStore.MediaColumns.DATE_ADDED} DESC")?.use { c ->
                while (c.moveToNext()) {
                    val b = c.getLong(1)
                    if (b !in ids) continue
                    if (limit > 0) { val n = (cnt[b] ?: 0) + 1; cnt[b] = n; if (n > limit) continue }   // albüm başına en yeni N
                    out.add(ContentUris.withAppendedId(base, c.getLong(0)))
                }
            }
        } catch (e: Exception) { }
        return out
    }

    /** Tüm klasörlerdeki fotoğrafları tarar (önceden taranmışlar atlanır); bulunanlar ilerledikçe `items`a eklenir. */
    suspend fun scanAll(ctx: Context) {
        error = null
        val all = withContext(Dispatchers.IO) { GalleryAttrs.load(ctx); allImages(ctx, pickIds.keys.toSet(), limitText.toIntOrNull()?.takeIf { it > 0 } ?: 0) }
        val gi = all.map { GalleryItem(it, false) }
        val keys = all.map { it.toString() }
        fun refresh(force: Boolean) {
            if (force || GalleryState.viewing < 0) items = gi.filter { GalleryAttrs.has(it.uri.toString(), "W") }   // görüntüleyici açıkken liste kaymasın
        }
        refresh(true)
        scanned = false
        if (gi.isEmpty()) { scanned = true; return }
        scan = keys.count { GalleryAttrs.isDone(it) } to gi.size
        try {
            GalleryAttrs.ensure(ctx, keys) { d, t -> scan = (gi.size - t + d) to gi.size; refresh(false) }
            scanned = true
        } finally { scan = null; refresh(true) }
    }

    private fun extract(ctx: Context, a: Analyzer, uri: String, out: MutableCollection<TFace>, useBoxes: Boolean) {
        try {
            val bmp = a.decode(ctx, Uri.parse(uri)) ?: return
            try {
                val boxes = if (useBoxes) GalleryAttrs.wBoxes(uri) else emptyList()
                for (f in a.faces(bmp)) {
                    if (boxes.isNotEmpty()) {
                        // yalnızca tarama sırasında "türbanlı kadın" bulunan yüzler (aynı fotoğraftaki diğer kişiler gruplanmaz)
                        val cx = f.box.exactCenterX() / bmp.width; val cy = f.box.exactCenterY() / bmp.height
                        if (boxes.none { cx >= it[0] - 0.03f && cx <= it[2] + 0.03f && cy >= it[1] - 0.03f && cy <= it[3] + 0.03f }) continue
                    }
                    out.add(TFace(f.emb, uri, f.q, f.area, Bitmap.createScaledBitmap(f.crop, 80, 80, true)))
                }
            } finally { bmp.recycle() }
        } catch (e: CancellationException) { throw e } catch (e: Throwable) { }
    }

    /** Bulunan fotoğraflardaki yüzleri çıkarıp aynı kişiye göre gruplar (Türban ekranı). */
    suspend fun group(ctx: Context) {
        val list = items
        if (list.isEmpty() || grouping != null) return
        error = null
        grouping = 0 to list.size
        try {
            groups = groupList(ctx, list, true) { d, t -> grouping = d to t }
            openGroup = null
        } catch (e: CancellationException) { throw e
        } catch (e: Throwable) { error = e.message ?: e.javaClass.simpleName
        } finally { grouping = null }
    }

    /** Herhangi bir fotoğraf listesini yüzlere göre gruplar. useBoxes: yalnızca Türban taramasında bulunan yüzler alınır. */
    suspend fun groupList(ctx: Context, list: List<GalleryItem>, useBoxes: Boolean, paused: () -> Boolean = { false }, progress: (Int, Int) -> Unit): List<FaceGroup> {
        var an: Analyzer? = null
        try {
            val a = withContext(Dispatchers.Default) { Analyzer(ctx, 2).also { it.selfTest() } }
            an = a
            val recs = ConcurrentLinkedQueue<TFace>()
            val queue = ConcurrentLinkedQueue(list)
            val cnt = AtomicInteger(0)
            coroutineScope {
                repeat(2) {
                    launch(Dispatchers.Default) {
                        while (true) {
                            while (paused()) { kotlinx.coroutines.delay(250); ensureActive() }   // Durdur: kaldığı yerden devam eder
                            val item = queue.poll() ?: break
                            ensureActive()
                            if (!item.video) extract(ctx, a, item.uri.toString(), recs, useBoxes)
                            val d = cnt.incrementAndGet()
                            if (d % 3 == 0 || d == list.size) progress(d, list.size)
                        }
                    }
                }
            }
            return withContext(Dispatchers.Default) { cluster(recs.toList(), list) }
        } finally { try { an?.close() } catch (e: Exception) { } }
    }

    private fun cluster(recs: List<TFace>, list: List<GalleryItem>): List<FaceGroup> {
        var good = recs.filter { it.q >= Q_GOOD }.sortedByDescending { it.q * sqrt(it.area.toFloat()) }
        var weak = recs.filter { it.q < Q_GOOD }
        if (good.isEmpty()) { good = weak.sortedByDescending { it.q * sqrt(it.area.toFloat()) }; weak = emptyList() }

        // 1) saf çekirdek gruplar (aynı fotoğraftaki iki yüz aynı gruba girmez)
        val cores = ArrayList<TurbanCore>()
        for (r in good) {
            var best: TurbanCore? = null; var bs = CORE_THR
            for (w in cores) {
                if (r.photo in w.photos) continue
                val s = dot(w.cent, r.emb)
                if (s >= bs) { bs = s; best = w }
            }
            if (best == null) { best = TurbanCore(); cores.add(best) }
            best.add(r)
        }
        val init = cores.mapIndexed { i, w -> Cluster(i, w.cent, w.embs.size, LinkedHashSet(w.photos), "", w.score, pickReps(w.embs, MAX_REPS)) }
        // 2) gruplar arası derin birleştirme (örtü / gözlük / ışık farkını örnek köprüleriyle aşar)
        val merged = agglomerate(init, MERGE_THR)
        // 3) düşük kaliteli yüzler yeterince benziyorsa mevcut gruba eklenir
        for (r in weak) {
            var best: Cluster? = null; var bs = WEAK_THR
            for (c in merged) {
                if (r.photo in c.photos) continue
                var s = dot(c.centroid, r.emb)
                for (x in c.reps) { val t = dot(x, r.emb) - LINK_PENALTY / 2; if (t > s) s = t }
                if (s >= bs) { bs = s; best = c }
            }
            if (best != null) { best.photos.add(r.photo); best.count++ }
        }

        val byUri = list.associateBy { it.uri.toString() }
        val used = HashSet<String>()
        val out = ArrayList<FaceGroup>()
        for (c in merged.sortedByDescending { it.photos.size }) {
            val its = c.photos.mapNotNull { byUri[it] }
            if (its.isEmpty()) continue
            used.addAll(c.photos)
            val cover = recs.filter { it.photo in c.photos }.maxByOrNull { dot(it.emb, c.centroid) + 0.2f * it.q }?.crop
            out.add(FaceGroup(out.size, its, cover))
        }
        val rest = list.filter { it.uri.toString() !in used }
        if (rest.isNotEmpty()) out.add(FaceGroup(out.size, rest, null, ungrouped = true))
        return out
    }
}

private val GREEN = Color(0xFF2E7D32)

/** Sağ üst köşe: aşama adı, yüzde ve içi yeşil dolan çubuk. */
@Composable
internal fun ProgressBadge(label: String, done: Int, total: Int, modifier: Modifier, stopLabel: String? = null, onStop: (() -> Unit)? = null) {
    val f = if (total <= 0) 0f else (done.toFloat() / total).coerceIn(0f, 1f)
    Surface(modifier, shape = RoundedCornerShape(12.dp), tonalElevation = 6.dp, shadowElevation = 4.dp) {
        Column(Modifier.padding(horizontal = 12.dp, vertical = 8.dp).width(150.dp)) {
            Text("$label %${(f * 100).toInt()}", color = GREEN, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleSmall)
            Text("$done / $total", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            LinearProgressIndicator(progress = { f }, Modifier.fillMaxWidth().padding(top = 4.dp).height(8.dp).clip(RoundedCornerShape(4.dp)),
                color = GREEN, trackColor = Color(0x33888888))
            if (onStop != null && stopLabel != null)
                TextButton(onStop, Modifier.align(Alignment.End), contentPadding = PaddingValues(horizontal = 8.dp, vertical = 0.dp)) {
                    Text(stopLabel, color = MaterialTheme.colorScheme.error, fontWeight = FontWeight.Bold)
                }
        }
    }
}

@Composable
internal fun PhotoTiles(list: List<GalleryItem>) {
    LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxSize(), contentPadding = PaddingValues(4.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
        itemsIndexed(list, key = { _, it -> it.uri.toString() }) { i, it ->
            AsyncImage(it.uri, null, Modifier.aspectRatio(1f).clickable { GalleryState.viewing = i }, contentScale = ContentScale.Crop)
        }
    }
}

@Composable
internal fun GroupTiles(groups: List<FaceGroup>, onOpen: (FaceGroup) -> Unit = { TurbanState.openGroup = it }) {
    LazyVerticalGrid(GridCells.Fixed(3), Modifier.fillMaxSize(), contentPadding = PaddingValues(6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        itemsIndexed(groups, key = { _, g -> g.id }) { _, g ->
            Column(Modifier.clickable { onOpen(g) }, horizontalAlignment = Alignment.CenterHorizontally) {
                val m = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(50))
                val cv = g.cover
                if (cv != null) Image(cv.asImageBitmap(), null, m, contentScale = ContentScale.Crop)
                else AsyncImage(g.items.first().uri, null, m, contentScale = ContentScale.Crop)
                Text(if (g.ungrouped) "Yüzü alınamayan (${g.items.size})" else "${g.items.size} fotoğraf",
                    style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 3.dp))
            }
        }
    }
}

/** Galeri sayfasında Türban filtresi seçilince görünen ekran. */
@Composable
fun TurbanScreen() {
    val ctx = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    // Tarama: ekran açılınca başlar; "Durdur" ile iptal edilir (anahtar değişince eski tarama iptal olur), "Taramayı sürdür" kaldığı yerden devam ettirir
    var runKey by remember { mutableStateOf(0) }
    LaunchedEffect(runKey, TurbanState.started) { if (TurbanState.started && !TurbanState.stopped) TurbanState.scanAll(ctx) }
    if (!TurbanState.started) { TurbanSetup { TurbanState.stopped = false; TurbanState.started = true; runKey++ }; return }
    var groupJob by remember { mutableStateOf<Job?>(null) }

    val sc = TurbanState.scan
    val gp = TurbanState.grouping
    val groups = TurbanState.groups
    val open = TurbanState.openGroup
    val items = TurbanState.items

    Box(Modifier.fillMaxSize()) {
        Column(Modifier.fillMaxSize()) {
            val title = when {
                open != null -> if (open.ungrouped) "Yüzü alınamayanlar • ${open.items.size} fotoğraf" else "Aynı kişi • ${open.items.size} fotoğraf"
                groups != null -> "${groups.count { !it.ungrouped }} kişi • ${items.size} fotoğraf"
                else -> "Türbanlı / eşarplı / bandanalı kadın • ${items.size} fotoğraf"
            }
            Text(title, Modifier.padding(start = 12.dp, end = 170.dp, top = 8.dp, bottom = 4.dp), style = MaterialTheme.typography.bodyMedium)
            if (TurbanState.stopped && sc == null && gp == null && !TurbanState.scanned) {
                Row(Modifier.padding(horizontal = 12.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Tarama durduruldu", style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.error)
                    FilledTonalButton({ TurbanState.stopped = false; runKey++ }) { Text("Taramayı sürdür") }
                }
            }
            if (groups == null && gp == null && (TurbanState.scanned || TurbanState.stopped) && sc == null && items.isNotEmpty()) {
                FilledTonalButton({ groupJob = scope.launch { TurbanState.group(ctx) } }, Modifier.padding(horizontal = 12.dp, vertical = 4.dp)) { Text("Yüze göre grupla") }
            }
            TurbanState.error?.let { Text(it, Modifier.padding(12.dp), color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
            Box(Modifier.weight(1f)) {
                when {
                    groups != null && open == null -> GroupTiles(groups)
                    groups != null && open != null -> PhotoTiles(open.items)
                    items.isNotEmpty() -> PhotoTiles(items)
                    else -> Text(if (sc != null) "Türbanlı kadın fotoğrafları aranıyor…" else if (TurbanState.stopped) "Tarama durduruldu." else if (TurbanState.scanned) "Telefonda türbanlı / eşarplı / bandanalı kadın fotoğrafı bulunamadı." else "Fotoğraflar okunuyor…",
                        Modifier.padding(16.dp))
                }
            }
        }
        // Sağ üst: tarama (ya da gruplama) aşaması + yüzde + yeşil dolan çubuk
        if (gp != null) ProgressBadge("Gruplanıyor", gp.first, gp.second, Modifier.align(Alignment.TopEnd).padding(8.dp), "İptal") { groupJob?.cancel() }
        else if (sc != null) ProgressBadge("Taranıyor", sc.first, sc.second, Modifier.align(Alignment.TopEnd).padding(8.dp), "Durdur") { TurbanState.stopped = true; runKey++ }
    }
}


/** Türban filtresi seçilince ilk görünen ekran: taranacak albümleri seç, istersen "ilk N" sayısı gir, Başla. */
@Composable
private fun TurbanSetup(onStart: () -> Unit) {
    val folders = GalleryState.folders
    val n = TurbanState.pickIds.size
    Column(Modifier.fillMaxSize()) {
        Text("Türbanlı / eşarplı kadın taraması", Modifier.padding(start = 12.dp, end = 12.dp, top = 10.dp), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
        Text("Taranacak albümleri seç. Sayı girersen her albümde yalnızca en yeni o kadar fotoğraf taranır; boş bırakırsan hepsi taranır.",
            Modifier.padding(horizontal = 12.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton({ folders.forEach { TurbanState.pickIds[it.id] = true } }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Tümünü seç") }
            TextButton({ TurbanState.pickIds.clear() }, contentPadding = PaddingValues(horizontal = 8.dp)) { Text("Temizle") }
            Spacer(Modifier.weight(1f))
            CountField(TurbanState.limitText, { TurbanState.limitText = it }, Modifier.width(120.dp).padding(end = 8.dp), placeholder = "Hepsi")
        }
        Text("$n albüm seçili", Modifier.padding(horizontal = 12.dp), style = MaterialTheme.typography.labelLarge, color = GREEN, fontWeight = FontWeight.Bold)
        if (folders.isEmpty()) Text(if (GalleryState.loading) "Galeri okunuyor…" else "Telefonda fotoğraf bulunamadı.", Modifier.padding(16.dp))
        LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), contentPadding = PaddingValues(8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(folders, key = { it.id }) { f ->
                val on = TurbanState.pickIds.containsKey(f.id)
                Column(Modifier.clickable { if (on) TurbanState.pickIds.remove(f.id) else TurbanState.pickIds[f.id] = true }) {
                    Box {
                        AsyncImage(f.cover, null, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(10.dp)), contentScale = ContentScale.Crop)
                        if (on) Box(Modifier.matchParentSize().border(3.dp, GREEN, RoundedCornerShape(10.dp)))
                        Checkbox(checked = on, onCheckedChange = { if (on) TurbanState.pickIds.remove(f.id) else TurbanState.pickIds[f.id] = true }, modifier = Modifier.align(Alignment.TopEnd))
                    }
                    Text(f.name, style = MaterialTheme.typography.labelMedium, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                    Text("${f.count}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        Button(onClick = onStart, enabled = n > 0, modifier = Modifier.fillMaxWidth().padding(12.dp).height(50.dp),
            colors = ButtonDefaults.buttonColors(containerColor = GREEN, contentColor = Color.White)) {
            Text("Başla ($n albüm${TurbanState.limitText.toIntOrNull()?.takeIf { it > 0 }?.let { " • her birinde ilk $it" } ?: " • hepsi"})", fontWeight = FontWeight.Bold)
        }
    }
}
