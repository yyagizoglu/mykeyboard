package com.fotoliz.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileWriter

/**
 * Yarım kalan analizin diske yazılan ilerlemesi.
 * Analiz her fotoğraftan sonra bir satır (jsonl) ekler; uygulama kapansa, öldürülse ya da Durdur'a basılsa da
 * satırlar diskte kalır. Kayıtlı sonuçlar listesinde "Yarım kaldı" olarak görünür ve kaldığı yerden sürdürülür.
 * Analiz sorunsuz bitince bu dosyalar silinir.
 */
object Partial {
    class Pending(val key: String, val uri: String, val sel: List<String>, val total: Int, val done: Int, val time: Long, val name: String)
    class Loaded(val processed: HashSet<String>, val recs: ArrayList<FaceRec>, val objPhotos: LinkedHashMap<String, LinkedHashSet<String>>,
                 val objThumbs: HashMap<String, String>, val noFace: Int, val failed: Int)

    private fun dir(ctx: Context) = File(ctx.filesDir, "partial").apply { mkdirs() }
    private fun meta(ctx: Context, key: String) = File(dir(ctx), "$key.meta")
    private fun lines(ctx: Context, key: String) = File(dir(ctx), "$key.jsonl")

    /** Yeni (sıfırdan) analiz başlarken: eski yarım kaydı siler, yenisini açar. */
    fun begin(ctx: Context, key: String, uri: String, sel: List<String>, total: Int, name: String) {
        try {
            meta(ctx, key).writeText(JSONObject().put("uri", uri).put("sel", JSONArray(sel)).put("total", total)
                .put("time", System.currentTimeMillis()).put("name", name).toString())
            lines(ctx, key).writeText("")
        } catch (e: Exception) { }
    }

    /** Bir fotoğraf işlenince sonucu (bulunan yüzler / nesne adı / hata) tek satır olarak ekler. */
    fun append(ctx: Context, key: String, photo: String, err: Boolean, faces: List<FaceRec>, obj: String?, objThumb: String?) {
        try {
            val o = JSONObject().put("u", photo)
            if (err) o.put("x", 1)
            if (faces.isNotEmpty()) {
                val a = JSONArray()
                for (f in faces) a.put(JSONObject().put("e", packReps(listOf(f.emb))).put("d", f.emb.size)
                    .put("q", f.q.toDouble()).put("a", f.area).put("t", f.thumb))
                o.put("f", a)
            }
            if (obj != null) { o.put("o", obj); if (objThumb != null) o.put("ot", objThumb) }
            FileWriter(lines(ctx, key), true).use { it.write(o.toString()); it.write("\n") }
        } catch (e: Exception) { }
    }

    fun load(ctx: Context, key: String): Loaded? {
        val f = lines(ctx, key)
        if (!f.exists()) return null
        val processed = HashSet<String>(); val recs = ArrayList<FaceRec>()
        val objPhotos = LinkedHashMap<String, LinkedHashSet<String>>(); val objThumbs = HashMap<String, String>()
        var noFace = 0; var failed = 0
        f.forEachLine { line ->
            try {   // kapanırken yarım yazılmış son satır varsa atlanır
                val o = JSONObject(line)
                val u = o.getString("u")
                processed.add(u)
                if (o.optInt("x", 0) == 1) failed++
                val fa = o.optJSONArray("f")
                if (fa != null) {
                    for (i in 0 until fa.length()) {
                        val j = fa.getJSONObject(i)
                        val emb = unpackReps(j.getString("e"), j.getInt("d")).firstOrNull() ?: continue
                        recs.add(FaceRec(emb, u, j.getDouble("q").toFloat(), j.getInt("a"), j.optString("t", "")))
                    }
                } else if (o.optInt("x", 0) != 1) noFace++
                val name = o.optString("o", "")
                if (name.isNotEmpty()) {
                    objPhotos.getOrPut(name) { LinkedHashSet() }.add(u)
                    val ot = o.optString("ot", "")
                    if (ot.isNotEmpty()) objThumbs[name] = ot
                }
            } catch (e: Exception) { }
        }
        return Loaded(processed, recs, objPhotos, objThumbs, noFace, failed)
    }

    fun clear(ctx: Context, key: String) { meta(ctx, key).delete(); lines(ctx, key).delete() }

    /** Tamamlanmamış analizler (en yeni önce). */
    fun pending(ctx: Context): List<Pending> = dir(ctx).listFiles().orEmpty().filter { it.extension == "meta" }.mapNotNull { m ->
        try {
            val key = m.nameWithoutExtension
            val o = JSONObject(m.readText())
            val sa = o.optJSONArray("sel")
            val sel = if (sa == null) emptyList() else (0 until sa.length()).map { sa.getString(it) }
            val lf = lines(ctx, key)
            val done = if (lf.exists()) lf.useLines { it.count() } else 0
            val total = o.getInt("total")
            Pending(key, o.getString("uri"), sel, total, done, o.getLong("time"), o.optString("name", "Analiz"))
        } catch (e: Exception) { null }
    }.sortedByDescending { it.time }
}
