package com.fotoliz.app

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabeler
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import org.json.JSONObject
import java.io.File

/** "Bulunan yüzler" ekranındaki filtre seçenekleri. */
enum class FaceFilter(val label: String) {
    ALL("Tümü"), MALE("Erkek"), FEMALE("Kadın"),
    F_BLOND("Kadın • Sarışın"), F_BROWN("Kadın • Esmer"), F_RED("Kadın • Kızıl"), F_HAIR_UNK("Kadın • Saç belirsiz");

    fun matches(a: FaceAttrs.A?): Boolean = when (this) {
        ALL -> true
        MALE -> a?.g == "M"
        FEMALE -> a?.g == "F"
        F_BLOND -> a?.g == "F" && a.h == "B"
        F_BROWN -> a?.g == "F" && a.h == "D"
        F_RED -> a?.g == "F" && a.h == "R"
        F_HAIR_UNK -> a?.g == "F" && a.h == "?"
    }
}

/**
 * Yüz küçük resimlerinden cinsiyet ve saç rengi tahmini (cihazda, internetsiz). Sonuç telefonda saklanır; kullanıcı elle düzeltirse (m = true)
 * düzeltme bir daha otomatik analizle ezilmez.
 * g: M erkek, F kadın, ? belirsiz • h: B sarışın, D esmer, R kızıl, ? belirsiz
 */
object FaceAttrs {
    class A(var g: String, var h: String, var m: Boolean)
    private const val VERSION = 4      // saç rengi algoritması sürümü (4: esmer filtresine sarışın karışmasın diye daha da katı)

    private val map = HashMap<String, A>()
    private var loaded = false
    private fun file(ctx: Context) = File(ctx.filesDir, "faceattrs.json")

    @Synchronized fun load(ctx: Context) {
        if (loaded) return
        loaded = true
        try {
            val f = file(ctx); if (!f.exists()) return
            val o = JSONObject(f.readText())
            val ver = o.optInt("__v", 1)
            for (k in o.keys()) {
                if (k == "__v") continue
                val e = o.getJSONObject(k); val manual = e.optInt("m", 0) == 1
                if (ver < VERSION && !manual) continue      // eski algoritmanın otomatik tahmini: yeniden hesaplanacak
                map[k] = A(e.optString("g", "?"), e.optString("h", "?"), manual)
            }
        } catch (e: Exception) { }
    }

    @Synchronized fun get(path: String): A? = map[path]
    @Synchronized fun put(path: String, a: A) { map[path] = a }
    @Synchronized fun remove(path: String) { map.remove(path) }
    /** Yeni analizde aynı adla yeniden yazılan küçük resimlerin eski cinsiyet / saç tahminleri silinir. */
    @Synchronized fun forgetPrefix(ctx: Context, prefix: String) { load(ctx); if (map.keys.removeAll { it.startsWith(prefix) }) persist(ctx) }

    @Synchronized fun persist(ctx: Context) {
        try {
            val o = JSONObject().put("__v", VERSION)
            for ((k, a) in map) o.put(k, JSONObject().put("g", a.g).put("h", a.h).put("m", if (a.m) 1 else 0))
            file(ctx).writeText(o.toString())
        } catch (e: Exception) { }
    }

    /** Henüz analiz edilmemiş yüzleri sırayla analiz eder. onProgress(biten, toplam) arada çağrılır. */
    fun analyzeMissing(ctx: Context, paths: List<String>, onProgress: (Int, Int) -> Unit) {
        load(ctx); HairStore.load(ctx)
        val todo = paths.filter { get(it) == null }
        if (todo.isEmpty()) return
        val lab = ImageLabeling.getClient(ImageLabelerOptions.Builder().setConfidenceThreshold(0.3f).build())
        try {
            todo.forEachIndexed { i, p ->
                put(p, analyze(lab, p) ?: A("?", "?", false))
                if (i % 4 == 3 || i == todo.lastIndex) onProgress(i + 1, todo.size)
            }
        } finally { lab.close(); persist(ctx) }
    }

    /** ML Kit etiketlerinden cinsiyet: M erkek, F kadın, ? belirsiz. */
    fun genderOf(labels: List<com.google.mlkit.vision.label.ImageLabel>): String {
        var male = 0f; var female = 0f
        for (l in labels) {
            when (l.text.lowercase()) {
                "beard", "facial hair", "moustache", "mustache", "goatee", "sideburns", "stubble" -> male = maxOf(male, l.confidence)
                "eyelash", "lipstick", "eye shadow", "eyeliner", "mascara", "lip gloss", "long hair", "bangs", "hair coloring", "headscarf", "hijab", "veil" ->
                    female = maxOf(female, l.confidence)
            }
        }
        return if (male >= 0.45f && male >= female) "M" else if (female >= 0.4f) "F" else "?"
    }

    private fun analyze(lab: ImageLabeler, path: String): A? {
        val bmp = decode(path) ?: return null
        var g = "?"
        try {
            val labels = Tasks.await(lab.process(InputImage.fromBitmap(bmp, 0)))
            g = genderOf(labels)
        } catch (e: Exception) { }
        val thumbH = try { HairColor.fromThumb(bmp) } catch (e: Exception) { "?" }
        var h = HairStore.get(path) ?: thumbH
        // Esmer sonucu iki yöntemde de tutmalı: küçük resim sarışın/kızıl diyorsa "esmer" denmez (esmer filtresine sarışın karışmasın)
        if (h == "D" && (thumbH == "B" || thumbH == "R")) h = "?"
        bmp.recycle()
        return A(g, h, false)
    }

    private fun decode(path: String): Bitmap? = try {
        val o = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, o)
        var s = 1
        while (o.outWidth / (s * 2) >= 200 && o.outHeight / (s * 2) >= 200) s *= 2
        BitmapFactory.decodeFile(path, BitmapFactory.Options().apply { inSampleSize = s })
    } catch (e: Exception) { null }
}
