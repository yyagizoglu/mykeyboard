package com.fotoliz.app

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import android.util.Base64
import java.io.File
import java.nio.ByteBuffer
import java.nio.ByteOrder

const val ROOT = "@root"

class Cluster(val id: Int, var centroid: FloatArray, var count: Int, val photos: LinkedHashSet<String>, var thumb: String, var area: Int,
              var reps: List<FloatArray> = emptyList(), var tag: String = "", val edited: LinkedHashSet<String> = LinkedHashSet(),
              val obj: Boolean = false)   // obj = nesne grubu (yüzü olmayan fotoğraflar; adı tag)
class Result(val uri: String, val name: String, val total: Int, val time: Long, val clusters: List<Cluster>, val sel: List<String>,
             val durSec: Long = 0L,   // durSec = analizin sürdüğü süre (sn)
             val label: String = "") {   // label = Rapor'dan elle verilen albüm yazısı (boşsa otomatik)
    val key get() = Store.keyOf(uri, sel)
}

object Store {
    fun keyOf(uri: String, sel: List<String>) = (uri + "|" + sel.sorted().joinToString("/")).hashCode().toString().replace("-", "n")
    private fun dir(ctx: Context) = File(ctx.filesDir, "results").apply { mkdirs() }
    fun thumbDir(ctx: Context) = File(ctx.filesDir, "thumbs").apply { mkdirs() }

    fun save(ctx: Context, r: Result) {
        val arr = JSONArray()
        for (c in r.clusters) arr.put(JSONObject().put("id", c.id).put("count", c.count).put("area", c.area)
            .put("thumb", c.thumb).put("cen", packReps(listOf(c.centroid))).put("cd", c.centroid.size)
            .put("photos", JSONArray(c.photos.toList())).put("reps", packReps(c.reps))
            .put("tag", c.tag).put("edited", JSONArray(c.edited.toList())).put("obj", c.obj))
        val o = JSONObject().put("uri", r.uri).put("name", r.name).put("total", r.total).put("time", r.time)
            .put("sel", JSONArray(r.sel)).put("dur", r.durSec).put("label", r.label).put("clusters", arr)
        val dst = File(dir(ctx), r.key + ".json"); val tmp = File(dir(ctx), r.key + ".tmp")
        tmp.writeText(o.toString())                      // önce geçici dosyaya yaz: yazarken uygulama kapanırsa eski kayıt bozulmaz
        if (!tmp.renameTo(dst)) { dst.delete(); tmp.renameTo(dst) }
    }

    /** Kayıtlı bir analiz sonucunu ve ona ait küçük yüz resimlerini siler (fotoğraflara dokunulmaz). */
    fun delete(ctx: Context, r: Result) {
        File(dir(ctx), r.key + ".json").delete()
        thumbDir(ctx).listFiles()?.filter { it.name.startsWith(r.key + "_") }?.forEach { it.delete() }
    }

    fun loadAll(ctx: Context): List<Result> = dir(ctx).listFiles().orEmpty().filter { it.extension == "json" }.mapNotNull { f ->
        try {
            val o = JSONObject(f.readText()); val a = o.getJSONArray("clusters")
            val cl = (0 until a.length()).map { i ->
                val c = a.getJSONObject(i); val ph = c.getJSONArray("photos")
                val cen = if (c.has("cen")) (unpackReps(c.getString("cen"), c.getInt("cd")).firstOrNull() ?: FloatArray(0))
                    else c.getJSONArray("centroid").let { ce -> FloatArray(ce.length()) { ce.getDouble(it).toFloat() } }   // eski kayıtlar
                Cluster(c.getInt("id"), cen, c.getInt("count"),
                    LinkedHashSet((0 until ph.length()).map { ph.getString(it) }), c.getString("thumb"), c.getInt("area"),
                    unpackReps(c.optString("reps", ""), cen.size), c.optString("tag", ""),
                    LinkedHashSet<String>().also { set -> c.optJSONArray("edited")?.let { ea -> for (k in 0 until ea.length()) set.add(ea.getString(k)) } },
                    c.optBoolean("obj", false))
            }
            val sa = o.optJSONArray("sel")
            val sel = if (sa == null) emptyList() else (0 until sa.length()).map { sa.getString(it) }
            Result(o.getString("uri"), o.getString("name"), o.getInt("total"), o.getLong("time"), cl, sel, o.optLong("dur", 0L), o.optString("label", ""))
        } catch (e: Exception) { null }
    }.sortedByDescending { it.time }
}

fun packReps(reps: List<FloatArray>): String {
    if (reps.isEmpty()) return ""
    val bb = ByteBuffer.allocate(reps.sumOf { it.size } * 4).order(ByteOrder.LITTLE_ENDIAN)
    for (r in reps) for (x in r) bb.putFloat(x)
    return Base64.encodeToString(bb.array(), Base64.NO_WRAP)
}

fun unpackReps(s: String, dim: Int): List<FloatArray> {
    if (s.isEmpty() || dim <= 0) return emptyList()
    return try {
        val fb = ByteBuffer.wrap(Base64.decode(s, Base64.NO_WRAP)).order(ByteOrder.LITTLE_ENDIAN).asFloatBuffer()
        List(fb.remaining() / dim) { FloatArray(dim).also { a -> fb.get(a) } }
    } catch (e: Exception) { emptyList() }
}

fun mergeTwo(a: Cluster, b: Cluster): Cluster {
    val n = a.count + b.count
    val c = normalize(FloatArray(a.centroid.size) { (a.centroid[it] * a.count + b.centroid[it] * b.count) / n })
    val big = if (a.area >= b.area) a else b
    return Cluster(a.id, c, n, LinkedHashSet(a.photos).apply { addAll(b.photos) }, big.thumb, big.area,
        pickReps(a.reps + b.reps, MAX_REPS)).also { m ->
        m.tag = a.tag.ifBlank { b.tag }; m.edited.addAll(a.edited); m.edited.addAll(b.edited)
    }
}

/** Eşiği geçen grupları birleştirir (ayrıntı: Clusterer.kt → agglomerate). */
fun autoMerge(list: List<Cluster>, thr: Float): List<Cluster> = agglomerate(list, thr)
