package com.fotoliz.app

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.ui.graphics.luminance
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.KeyboardArrowRight
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Face
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathOperation
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.cos
import kotlin.math.sin

/* Ortak, tutarlı arayüz parçaları: kart, arama alanı, düğmeler. Renkler uygulamanın mevcut tema renklerinden gelir. */

/** Hafif kenarlıklı, yuvarlak köşeli panel. */
@Composable
fun PanelCard(modifier: Modifier = Modifier, compact: Boolean = false, content: @Composable ColumnScope.() -> Unit) {
    Card(modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.55f)),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)) {
        Column(Modifier.padding(if (compact) 10.dp else 16.dp), verticalArrangement = Arrangement.spacedBy(if (compact) 7.dp else 12.dp), content = content)
    }
}

/** Simgeli başlık + alt başlıklı bölüm kartı. */
@Composable
fun SectionCard(icon: ImageVector, title: String, subtitle: String? = null, compact: Boolean = false, trailing: (@Composable () -> Unit)? = null, content: @Composable ColumnScope.() -> Unit) {
    PanelCard(Modifier.padding(bottom = if (compact) 8.dp else 14.dp), compact) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.size(if (compact) 32.dp else 40.dp).clip(RoundedCornerShape(12.dp)).background(MaterialTheme.colorScheme.primaryContainer), contentAlignment = Alignment.Center) {
                Icon(icon, null, tint = MaterialTheme.colorScheme.onPrimaryContainer, modifier = Modifier.size(if (compact) 18.dp else 22.dp))
            }
            Column(Modifier.weight(1f, fill = trailing != null)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            trailing?.invoke()   // başlık satırının en sağı
        }
        content()
    }
}

/** Yuvarlak köşeli arama / metin alanı (sol simge, sağda temizle düğmesi). */
@Composable
fun FieldBox(value: String, onValueChange: (String) -> Unit, placeholder: String, leading: ImageVector? = null,
             modifier: Modifier = Modifier, search: Boolean = false, onSearch: () -> Unit = {}) {
    OutlinedTextField(value = value, onValueChange = onValueChange, modifier = modifier.fillMaxWidth(), singleLine = true,
        shape = RoundedCornerShape(14.dp),
        placeholder = { Text(placeholder, maxLines = 1) },
        leadingIcon = if (leading != null) ({ Icon(leading, null) }) else null,
        trailingIcon = if (value.isNotEmpty()) ({
            IconButton(onClick = { onValueChange("") }) { Icon(Icons.Filled.Clear, "Temizle") }
        }) else null,
        colors = OutlinedTextFieldDefaults.colors(
            focusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedContainerColor = MaterialTheme.colorScheme.surface,
            unfocusedBorderColor = MaterialTheme.colorScheme.outlineVariant),
        keyboardOptions = KeyboardOptions(imeAction = if (search) ImeAction.Search else ImeAction.Done),
        keyboardActions = KeyboardActions(onSearch = { onSearch() }, onDone = { onSearch() }))
}

/** Ana eylem düğmesi: tam genişlik, 52 dp, yuvarlak köşe, isteğe bağlı simge. */
@Composable
fun PrimaryAction(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, icon: ImageVector? = null, h: androidx.compose.ui.unit.Dp = 52.dp) {
    Button(onClick = onClick, enabled = enabled, modifier = modifier.fillMaxWidth().height(h), shape = RoundedCornerShape(14.dp)) {
        if (icon != null) { Icon(icon, null, Modifier.size(20.dp)); Spacer(Modifier.width(8.dp)) }
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 15.sp, maxLines = 2, lineHeight = 18.sp)
    }
}

/** İkincil eylem düğmesi (dolgulu açık ton). Satırda yan yana kullanılabilir. */
@Composable
fun TonalAction(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true, icon: ImageVector? = null, h: androidx.compose.ui.unit.Dp = 48.dp) {
    val cs = MaterialTheme.colorScheme
    // Belirgin: tema rengiyle kalın çerçeve + koyu/dolgun zemin + kalın yazı
    FilledTonalButton(onClick = onClick, enabled = enabled, modifier = modifier.height(h), shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(horizontal = 12.dp),
        colors = ButtonDefaults.filledTonalButtonColors(containerColor = cs.primaryContainer, contentColor = cs.onPrimaryContainer),
        border = BorderStroke(2.dp, if (enabled) cs.primary else cs.outlineVariant)) {
        if (icon != null) { Icon(icon, null, Modifier.size(18.dp)); Spacer(Modifier.width(6.dp)) }
        Text(text, fontWeight = FontWeight.Bold, fontSize = 14.sp, maxLines = 1)
    }
}

/** Renkli eylem düğmesi (örn. kırmızı Durdur, yeşil Devam et). Pasifken soluk görünür. */
@Composable
fun ColorAction(text: String, color: Color, onClick: () -> Unit, modifier: Modifier = Modifier, enabled: Boolean = true) {
    Button(onClick = onClick, enabled = enabled, modifier = modifier.height(46.dp), shape = RoundedCornerShape(14.dp),
        contentPadding = PaddingValues(horizontal = 12.dp),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Color.White,
            disabledContainerColor = color.copy(alpha = 0.30f), disabledContentColor = Color.White.copy(alpha = 0.55f))) {
        Text(text, fontWeight = FontWeight.SemiBold, fontSize = 14.sp, maxLines = 1)
    }
}

/** "Son arama" gibi tek dokunuşluk satır. */
@Composable
fun RecentRow(text: String, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)).background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.45f))
        .clickable(onClick = onClick).padding(horizontal = 14.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(text, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium,
            color = MaterialTheme.colorScheme.onPrimaryContainer, maxLines = 2)
        Icon(Icons.AutoMirrored.Filled.KeyboardArrowRight, null, tint = MaterialTheme.colorScheme.onPrimaryContainer)
    }
}

/** Tema simgesi: 0 = otomatik (yarı dolu daire), 1 = açık (güneş), 2 = koyu (ay). */
@Composable
fun ThemeGlyph(mode: Int, tint: androidx.compose.ui.graphics.Color, size: androidx.compose.ui.unit.Dp = 24.dp) {
    Canvas(Modifier.size(size)) {
        val s = this.size.width / 24f
        val c = Offset(12f * s, 12f * s)
        when (mode) {
            1 -> {
                drawCircle(tint, radius = 4.6f * s, center = c)
                for (i in 0 until 8) {
                    val a = Math.toRadians(i * 45.0); val cs = cos(a).toFloat(); val sn = sin(a).toFloat()
                    drawLine(tint, Offset((12f + 7.4f * cs) * s, (12f + 7.4f * sn) * s), Offset((12f + 10.2f * cs) * s, (12f + 10.2f * sn) * s),
                        strokeWidth = 2f * s, cap = StrokeCap.Round)
                }
            }
            2 -> {
                val moon = Path.combine(PathOperation.Difference,
                    Path().apply { addOval(Rect(c, 8.5f * s)) },
                    Path().apply { addOval(Rect(Offset(16.5f * s, 8.5f * s), 7.5f * s)) })
                drawPath(moon, tint)
            }
            3, 4, 5 -> {
                drawCircle(tint, radius = 9.5f * s, center = c, style = Stroke(2f * s))
                for ((x, y) in listOf(8f to 9f, 13f to 7.5f, 16.5f to 12f, 9f to 15f)) drawCircle(tint, radius = 1.7f * s, center = Offset(x * s, y * s))
            }
            else -> {
                drawCircle(tint, radius = 8.5f * s, center = c, style = Stroke(2f * s))
                drawArc(tint, startAngle = 90f, sweepAngle = 180f, useCenter = true,
                    topLeft = Offset(3.5f * s, 3.5f * s), size = androidx.compose.ui.geometry.Size(17f * s, 17f * s))
            }
        }
    }
}

/** 0 = otomatik, 1 = açık, 2 = koyu, 3 = spor, 4 = eğlenceli, 5 = iş. */
val THEME_NAMES = listOf("Otomatik", "Açık", "Koyu", "Spor", "Eğlenceli", "İş")

/** Seçilen tema moduna göre renk şeması. Otomatik = telefonun açık/koyu ayarı. */
fun appColorScheme(mode: Int, sysDark: Boolean): ColorScheme = when (mode) {
    1 -> lightColorScheme()
    2 -> darkColorScheme()
    3 -> darkColorScheme(   // Spor: koyu zemin, neon yeşil + turuncu
        primary = Color(0xFF3DDC84), onPrimary = Color(0xFF06210F), primaryContainer = Color(0xFF1F3B2A), onPrimaryContainer = Color(0xFFB7F5D0),
        secondary = Color(0xFFFF8A3D), onSecondary = Color(0xFF2A1200), tertiary = Color(0xFFFF8A3D),
        background = Color(0xFF121614), onBackground = Color(0xFFF2F7F2), surface = Color(0xFF1A201C), onSurface = Color(0xFFF2F7F2),
        surfaceVariant = Color(0xFF26302A), onSurfaceVariant = Color(0xFF8FA195), outlineVariant = Color(0xFF3C4A41))
    4 -> lightColorScheme(  // Eğlenceli: pembe + sarı + mavi
        primary = Color(0xFFFF4FA3), onPrimary = Color.White, primaryContainer = Color(0xFFFFD6EA), onPrimaryContainer = Color(0xFF3A1C4D),
        secondary = Color(0xFF29B6F6), onSecondary = Color.White, tertiary = Color(0xFFFFC400),
        background = Color(0xFFFFF4FA), onBackground = Color(0xFF3A1C4D), surface = Color(0xFFFFFFFF), onSurface = Color(0xFF3A1C4D),
        surfaceVariant = Color(0xFFFFE8F3), onSurfaceVariant = Color(0xFF8A5FA0), outlineVariant = Color(0xFFFFC9E3))
    5 -> lightColorScheme(  // İş: soğuk gri zemin, lacivert vurgu
        primary = Color(0xFF1F3A5F), onPrimary = Color.White, primaryContainer = Color(0xFFD3DAE4), onPrimaryContainer = Color(0xFF1B2430),
        secondary = Color(0xFF5B6675), onSecondary = Color.White, tertiary = Color(0xFF8A6D1F),
        background = Color(0xFFE6EAF0), onBackground = Color(0xFF1B2430), surface = Color(0xFFFFFFFF), onSurface = Color(0xFF1B2430),
        surfaceVariant = Color(0xFFD9DFE8), onSurfaceVariant = Color(0xFF5B6675), outlineVariant = Color(0xFFB3BECD))
    else -> if (sysDark) darkColorScheme() else lightColorScheme()
}

/** Tema modlarını zemin parlaklığına göre KOYUDAN AÇIĞA sıralar (Otomatik, telefonun o anki açık/koyu ayarına göre yerleşir). */
fun themesDarkToLight(sysDark: Boolean, modes: List<Int> = listOf(0, 1, 2, 3, 4, 5)): List<Int> =
    modes.sortedBy { appColorScheme(it, sysDark).background.luminance() }

/** Tema simgesi (palet): üstteki tema düğmesi ve önizleme penceresi bunu kullanır. */
@Composable
fun ThemeGallery(mode: Int, sysDark: Boolean, onSelect: (Int) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val ink = MaterialTheme.colorScheme.onSurface
    IconButton(onClick = { open = true }, modifier = Modifier.size(38.dp).semantics { contentDescription = "Temalar" }) {
        Canvas(Modifier.size(24.dp)) {
            val s = this.size.width / 24f
            drawCircle(ink, radius = 9.5f * s, center = Offset(12f * s, 12f * s), style = Stroke(2f * s))
            for ((x, y) in listOf(8f to 9f, 13f to 7.5f, 16.5f to 12f, 9f to 15f)) drawCircle(ink, radius = 1.7f * s, center = Offset(x * s, y * s))
        }
    }
    if (open) {
        var pending by remember { mutableStateOf(mode) }
        AlertDialog(onDismissRequest = { open = false },
            title = { Text("Temalar") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Önce önizlemeye bak, beğendiğine dokun, sonra Uygula'ya bas.", style = MaterialTheme.typography.bodySmall)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        for (m in themesDarkToLight(sysDark)) ThemePreviewCard(m, sysDark, m == pending) { pending = m }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { open = false; onSelect(pending) }) { Text("Uygula") } },
            dismissButton = { TextButton(onClick = { open = false }) { Text("Vazgeç") } })
    }
}

/** Bir temanın küçük uygulama önizlemesi: üst çubuk, yüz daireleri, düğme ve kart şeridi o temanın renkleriyle çizilir. */
@Composable
private fun ThemePreviewCard(mode: Int, sysDark: Boolean, selected: Boolean, onClick: () -> Unit) {
    val cs = appColorScheme(mode, sysDark)
    val outer = MaterialTheme.colorScheme
    Column(Modifier.width(112.dp).clickable(onClick = onClick), horizontalAlignment = Alignment.CenterHorizontally) {
        Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp))
            .border(if (selected) 3.dp else 1.dp, if (selected) outer.primary else outer.outlineVariant, RoundedCornerShape(14.dp))
            .background(cs.background).padding(8.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(Modifier.fillMaxWidth().height(12.dp).clip(RoundedCornerShape(4.dp)).background(cs.primary))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                for (c in listOf(cs.primaryContainer, cs.secondary, cs.tertiary))
                    Box(Modifier.size(22.dp).clip(CircleShape).background(c))
            }
            Box(Modifier.fillMaxWidth().height(18.dp).clip(RoundedCornerShape(9.dp)).background(cs.primary), contentAlignment = Alignment.Center) {
                Text("Analiz", color = cs.onPrimary, fontSize = 9.sp, fontWeight = FontWeight.SemiBold)
            }
            Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(5.dp)).background(cs.surfaceVariant))
            Box(Modifier.fillMaxWidth().height(14.dp).clip(RoundedCornerShape(5.dp)).background(cs.surface))
        }
        Text((if (selected) "✓ " else "") + THEME_NAMES[mode], style = MaterialTheme.typography.labelMedium,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, modifier = Modifier.padding(top = 4.dp))
    }
}

/** Tek simge: o anki temayı gösterir. Dokununca küçük bir liste açılır; sadece seçim yapılır, seçilen tema hemen uygulanır. */
@Composable
fun ThemeMenu(mode: Int, onSelect: (Int) -> Unit, sysDark: Boolean = isSystemInDarkTheme()) {
    var open by remember { mutableStateOf(false) }
    val ink = MaterialTheme.colorScheme.onSurface
    Box {
        IconButton(onClick = { open = true }, modifier = Modifier.size(38.dp).semantics { contentDescription = "Tema: ${THEME_NAMES[mode]}" }) {
            ThemeGlyph(mode, ink)
        }
        DropdownMenu(expanded = open, onDismissRequest = { open = false }) {
            for (m in themesDarkToLight(sysDark, listOf(1, 2, 0))) {
                val on = m == mode
                DropdownMenuItem(
                    text = { Text(THEME_NAMES[m], fontWeight = if (on) FontWeight.Bold else FontWeight.Normal,
                        color = if (on) MaterialTheme.colorScheme.primary else ink) },
                    leadingIcon = { ThemeGlyph(m, if (on) MaterialTheme.colorScheme.primary else ink, 22.dp) },
                    onClick = { open = false; onSelect(m) })
            }
        }
    }
}


/** "Sayı Girin" kutusu: yazı yazılınca silinen soluk ipucu, yuvarlak köşe, ortalı rakam. Boş = hepsi. */
@androidx.compose.runtime.Composable
fun CountField(value: String, onChange: (String) -> Unit, modifier: androidx.compose.ui.Modifier = androidx.compose.ui.Modifier, placeholder: String = "Sayı Girin") {
    val cs = androidx.compose.material3.MaterialTheme.colorScheme
    androidx.compose.material3.OutlinedTextField(
        value, { v -> onChange(v.filter { it.isDigit() }.take(6)) }, modifier = modifier.height(52.dp), singleLine = true,
        shape = androidx.compose.foundation.shape.RoundedCornerShape(16.dp),
        textStyle = androidx.compose.ui.text.TextStyle(fontSize = 15.sp, fontWeight = androidx.compose.ui.text.font.FontWeight.Medium, textAlign = androidx.compose.ui.text.style.TextAlign.Center, color = cs.onSurface),
        placeholder = { androidx.compose.material3.Text(placeholder, fontSize = 14.sp, color = cs.onSurfaceVariant.copy(alpha = 0.6f), maxLines = 1, softWrap = false,
            modifier = androidx.compose.ui.Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center) },
        colors = androidx.compose.material3.OutlinedTextFieldDefaults.colors(
            unfocusedBorderColor = cs.outline.copy(alpha = 0.6f), focusedBorderColor = cs.primary,
            unfocusedContainerColor = cs.surfaceVariant.copy(alpha = 0.35f), focusedContainerColor = cs.surfaceVariant.copy(alpha = 0.5f)),
        keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number))
}


/** Uygulamanın KENDİ simgesi (telefondaki başlatıcı simgesi). "FotoLiz" yazan her yerde bunun yanında/yerinde kullanılır. */
@Composable
fun AppLogo(size: androidx.compose.ui.unit.Dp = 24.dp, modifier: Modifier = Modifier) {
    val ctx = androidx.compose.ui.platform.LocalContext.current
    val bmp = remember {
        try {
            val d = ctx.packageManager.getApplicationIcon(ctx.packageName)
            val b = android.graphics.Bitmap.createBitmap(192, 192, android.graphics.Bitmap.Config.ARGB_8888)
            d.setBounds(0, 0, 192, 192); d.draw(android.graphics.Canvas(b))
            androidx.compose.ui.graphics.asImageBitmap(b)
        } catch (e: Throwable) { null }
    }
    if (bmp != null) androidx.compose.foundation.Image(bmp, "FotoLiz", modifier.size(size).clip(RoundedCornerShape(size / 4)))
    else androidx.compose.material3.Icon(androidx.compose.material.icons.Icons.Filled.Face, "FotoLiz", modifier.size(size))
}
