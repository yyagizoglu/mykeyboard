package com.fotoliz.app

import android.content.Context
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.LazyGridScope
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

/**
 * Nesne arama ve kişi arama sonuç ekranlarında, bulunup ekrana getirilen fotoğrafları yüze göre gruplar.
 * who: "search" (nesne arama) ya da "person" (kişi arama). Bulunanlar değişirse (arama sürerken, eşik değişince)
 * eski gruplar geçersiz sayılır ve düz ızgara görünür.
 */
object FoundGroup {
    var groups by mutableStateOf<List<FaceGroup>?>(null)
    var openGroup by mutableStateOf<FaceGroup?>(null)
    var grouping by mutableStateOf<Pair<Int, Int>?>(null)
    var error by mutableStateOf<String?>(null)
    var owner by mutableStateOf("")
    private var groupedFor = 0
    var job: Job? = null

    fun clear() { groups = null; openGroup = null; grouping = null; error = null; owner = "" }
    fun cancel() { job?.cancel() }

    /** Bu ekran için geçerli gruplar; yoksa (ya da bulunanlar değiştiyse) null. */
    fun valid(who: String, hits: List<String>): List<FaceGroup>? =
        if (owner == who && groupedFor == hits.hashCode()) groups else null

    /** Geri tuşu: önce açık grubu, sonra gruplamayı kapatır. Bir şey kapandıysa true döner. */
    fun back(who: String): Boolean {
        if (owner != who) return false
        if (openGroup != null) { openGroup = null; return true }
        if (groups != null) { groups = null; return true }
        return false
    }

    suspend fun run(ctx: Context, who: String, hits: List<String>) {
        if (hits.isEmpty() || grouping != null) return
        clear(); owner = who; grouping = 0 to hits.size
        try {
            val list = hits.map { GalleryItem(Uri.parse(it), false) }
            val g = TurbanState.groupList(ctx, list, false) { d, t -> grouping = d to t }
            groups = g; groupedFor = hits.hashCode(); openGroup = null
        } catch (e: CancellationException) { throw e
        } catch (e: Throwable) { error = e.message ?: e.javaClass.simpleName
        } finally { grouping = null }
    }
}

/** "Yüze göre grupla" düğmesi, ilerleme çubuğu + İptal ve grup açıkken "Gruplara dön / Grubu kapat". */
@Composable
fun FoundGroupBar(who: String, hits: List<String>, running: Boolean) {
    val ctx = LocalContext.current.applicationContext
    val scope = rememberCoroutineScope()
    val gp = FoundGroup.grouping
    val valid = FoundGroup.valid(who, hits)
    val open = FoundGroup.openGroup
    Column(Modifier.fillMaxWidth().padding(horizontal = 12.dp)) {
        if (gp != null && FoundGroup.owner == who) {
            Text("Gruplanıyor: ${gp.first} / ${gp.second}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.primary)
            Row(verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(progress = { if (gp.second == 0) 0f else gp.first.toFloat() / gp.second }, Modifier.weight(1f).padding(vertical = 4.dp))
                TextButton({ FoundGroup.cancel() }) { Text("İptal", color = MaterialTheme.colorScheme.error) }
            }
        } else if (valid != null) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(if (open != null) (if (open.ungrouped) "Yüzü alınamayanlar • ${open.items.size} fotoğraf" else "Aynı kişi • ${open.items.size} fotoğraf")
                     else "${valid.count { !it.ungrouped }} kişi • ${hits.size} fotoğraf",
                    Modifier.weight(1f), style = MaterialTheme.typography.labelMedium)
                TextButton({ if (open != null) FoundGroup.openGroup = null else FoundGroup.clear() }) { Text(if (open != null) "Gruplara dön" else "Grubu kapat") }
            }
        } else if (!running && hits.isNotEmpty() && FoundGroup.grouping == null) {
            FilledTonalButton({ FoundGroup.job = scope.launch { FoundGroup.run(ctx, who, hits) } }) { Text("Yüze göre grupla") }
        }
        if (FoundGroup.owner == who) FoundGroup.error?.let { Text(it, color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall) }
    }
}

/**
 * Sonuç ızgarasının öğeleri: gruplama yoksa düz fotoğraflar, gruplama varsa kişi daireleri,
 * bir grup açıksa o kişinin fotoğrafları. onPhoto(sıra, liste): dokunulan fotoğrafı (o listede) açar.
 */
fun LazyGridScope.foundItems(groups: List<FaceGroup>?, open: FaceGroup?, hits: List<String>, onPhoto: (Int, List<String>) -> Unit) {
    if (groups == null) {
        itemsIndexed(hits, key = { _, u -> u }) { i, u -> FoundTile(u) { onPhoto(i, hits) } }
    } else if (open == null) {
        itemsIndexed(groups, key = { _, g -> "grp${g.id}" }) { _, g ->
            Column(Modifier.clickable { FoundGroup.openGroup = g }, horizontalAlignment = Alignment.CenterHorizontally) {
                val m = Modifier.fillMaxWidth().aspectRatio(1f).clip(CircleShape)
                val cv = g.cover
                if (cv != null) Image(cv.asImageBitmap(), null, m, contentScale = ContentScale.Crop)
                else AsyncImage(g.items.first().uri, null, m, contentScale = ContentScale.Crop)
                Text(if (g.ungrouped) "Yüzü alınamayan (${g.items.size})" else "${g.items.size} fotoğraf",
                    style = MaterialTheme.typography.labelMedium, modifier = Modifier.padding(top = 3.dp))
            }
        }
    } else {
        val l = open.items.map { it.uri.toString() }
        itemsIndexed(l, key = { _, u -> u }) { i, u -> FoundTile(u) { onPhoto(i, l) } }
    }
}

@Composable
private fun FoundTile(u: String, onClick: () -> Unit) {
    AsyncImage(Uri.parse(u), null, Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(6.dp)).clickable { onClick() }, contentScale = ContentScale.Crop)
}
