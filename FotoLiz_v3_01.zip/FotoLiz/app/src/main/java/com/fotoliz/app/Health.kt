package com.fotoliz.app

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import android.os.Build
import android.os.StatFs
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.NotificationManagerCompat
import kotlinx.coroutines.delay

/** level: 0 = yeşil (sorun yok), 1 = sarı (ayar gerekiyor), 2 = kırmızı (sorun var; detail nedeni anlatır). */
class Health(val name: String, val level: Int, val detail: String, val fixLabel: String? = null, val fix: (() -> Unit)? = null)

private val GREEN = Color(0xFF43A047)
private val AMBER = Color(0xFFFFB300)
private val RED = Color(0xFFE53935)
private fun levelColor(l: Int) = when (l) { 0 -> GREEN; 1 -> AMBER; else -> RED }

private fun hasNet(ctx: Context): Boolean = try {
    val cm = ctx.getSystemService(ConnectivityManager::class.java)
    cm.getNetworkCapabilities(cm.activeNetwork)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) == true
} catch (e: Exception) { true }

private fun appSettings(ctx: Context, action: String) {
    try { ctx.startActivity(Intent(action, Uri.parse("package:${ctx.packageName}")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { }
}

private fun checks(ctx: Context, vm: VM): List<Health> {
    val out = ArrayList<Health>()

    // Yüz tanıma modeli
    out.add(when {
        vm.modelReady -> Health("Yüz tanıma modeli", 0, "Hazır ve yüklü.")
        vm.downloading -> Health("Yüz tanıma modeli", 1, "İndiriliyor; bitene kadar yüz analizi yapılamaz.")
        else -> Health("Yüz tanıma modeli", 2,
            "Model yüklü değil" + (if (!hasNet(ctx)) " ve internet bağlantısı yok (model yalnızca ilk açılışta indirilir)" else "") +
                (vm.modelMsg?.let { ": $it" } ?: "."), "Modeli indir") { vm.downloadModel() }
    })

    // Fotoğraf erişimi
    val perm = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_IMAGES else Manifest.permission.READ_EXTERNAL_STORAGE
    out.add(if (ctx.checkSelfPermission(perm) == PackageManager.PERMISSION_GRANTED) Health("Fotoğraf erişimi", 0, "İzin verilmiş; albümler okunabiliyor.")
        else Health("Fotoğraf erişimi", 2, "Fotoğraf izni yok: albümler listelenemez, analiz ve arama çalışmaz.", "İzin ayarlarını aç") {
            appSettings(ctx, android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS) })

    // Bildirimler
    out.add(if (NotificationManagerCompat.from(ctx).areNotificationsEnabled()) Health("Bildirimler", 0, "Açık; ilerleme ve bitiş bildirimi gösterilir.")
        else Health("Bildirimler", 1, "Kapalı: arka planda sürerken ilerleme ve bitiş bildirimi görünmez.", "Bildirim ayarlarını aç") {
            try { ctx.startActivity(Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
                .putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, ctx.packageName).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) } catch (e: Exception) { } })

    // Arka planda çalışma (pil)
    val pm = ctx.getSystemService(android.os.PowerManager::class.java)
    out.add(if (pm.isIgnoringBatteryOptimizations(ctx.packageName)) Health("Arka planda çalışma", 0, "Pil kısıtlaması kaldırılmış; uzun analizler kesilmez.")
        else Health("Arka planda çalışma", 1, "Pil kısıtlaması açık: ekran kapanınca uzun analizler sistem tarafından durdurulabilir.", "Kısıtlamayı kaldır") {
            try { ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
            catch (e: Exception) { appSettings(ctx, android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS) } })

    // Analiz / arama servisleri
    val err = Engine.error ?: SearchEngine.error ?: PersonEngine.error
    val busy = Engine.running || SearchEngine.running || PersonEngine.running
    out.add(when {
        err != null -> Health("Analiz ve arama servisi", 2, "Son işlem hata verdi: $err (Yeni bir analiz ya da arama başlatınca hata temizlenir.)")
        busy -> Health("Analiz ve arama servisi", 0, "Çalışıyor; arka plan servisi aktif.")
        else -> Health("Analiz ve arama servisi", 0, "Hazır, bekliyor.")
    })

    // Benzerlik eşiği
    out.add(if (Math.abs(vm.startThr - 0.25f) < 0.005f) Health("Benzerlik eşiği", 0, "0,25: en iyi verim için önerilen değer.")
        else Health("Benzerlik eşiği", 1, "${"%.2f".format(vm.startThr)}: en iyi verim için 0,25 uygundur. Daha yüksek değer yüzleri daha belirgin ayırır ama aynı kişiyi farklı gruplara bölebilir.",
            "0,25'e ayarla") { vm.saveStartThr(0.25f) })

    // Google Drive yedeği (yalnızca bağlı ve açıksa)
    val dv = DriveBackup.info(ctx)
    if (dv.connected && dv.enabled) out.add(when {
        dv.folderId.isBlank() -> Health("Drive yedeği", 1, "Drive klasörü seçilmedi; yedek alınmıyor. Ayarlar > Google Drive yedeği'nden klasör seç.")
        dv.lastError.isNotBlank() -> Health("Drive yedeği", 2, "Son yedek başarısız: ${dv.lastError}", "Şimdi dene") { vm.driveBackupNow() }
        dv.lastOk == 0L -> Health("Drive yedeği", 1, "Henüz yedek alınmadı; ilk yedek az sonra alınır.", "Şimdi yedekle") { vm.driveBackupNow() }
        else -> Health("Drive yedeği", 0, "Otomatik yedek açık; son yedek: ${java.text.DateFormat.getDateTimeInstance().format(java.util.Date(dv.lastOk))}.")
    })

    // Depolama
    val free = try { StatFs(ctx.filesDir.path).availableBytes } catch (e: Exception) { Long.MAX_VALUE }
    val mb = free / 1048576
    val freeTxt = fmtSize(free)
    out.add(when {
        mb < 50 -> Health("Depolama", 2, "Boş yer çok az ($freeTxt): analiz sonucu ve yüz resimleri kaydedilemeyebilir. Telefonda yer aç.")
        mb < 300 -> Health("Depolama", 1, "Boş yer azalıyor ($freeTxt). Gereksiz dosyaları temizlemen önerilir.")
        else -> Health("Depolama", 0, "Yeterli boş yer var: $freeTxt boş.")
    })
    return out
}

/** Sistem sağlığı panosu: trafik ışığı + her servisin durumu. Her 1,5 sn'de ve ekrana dönüşte kendini yeniler. */
@Composable
fun HealthPanel(vm: VM) {
    val ctx = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    LaunchedEffect(Unit) { while (true) { delay(1500); tick++ } }
    val items = tick.let { checks(ctx, vm) }   // tick okunur: her 1,5 sn'de yeniden hesaplanır
    val level = items.maxOf { it.level }
    val reds = items.filter { it.level == 2 }
    val ambers = items.filter { it.level == 1 }

    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("Sistem sağlığı", style = MaterialTheme.typography.titleSmall, color = MaterialTheme.colorScheme.primary)
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(Modifier.size(18.dp).clip(CircleShape).background(levelColor(level)))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(when (level) { 0 -> "Her şey yolunda"; 1 -> "Ayar yapılması gerekiyor"; else -> "Sorun var" },
                    color = levelColor(level), fontWeight = FontWeight.ExtraBold, style = MaterialTheme.typography.titleMedium)
                Text(when (level) {
                    0 -> "Tüm sistemler sağlıklı ve aktif. Başka bir ayar gerekmiyor."
                    1 -> "En iyi çalışma için şunları ayarla: " + ambers.joinToString(", ") { it.name } + "."
                    else -> "Sorunun nedeni: " + reds.joinToString(" • ") { "${it.name} — ${it.detail}" }
                }, style = MaterialTheme.typography.bodySmall)
            }
        }
        items.forEach { h ->
            Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(12.dp)).background(levelColor(h.level).copy(alpha = 0.10f)).padding(horizontal = 12.dp, vertical = 8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(10.dp).clip(CircleShape).background(levelColor(h.level)))
                    Spacer(Modifier.width(8.dp))
                    Text(h.name, Modifier.weight(1f), fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodyMedium)
                    Text(when (h.level) { 0 -> "Aktif"; 1 -> "Ayar gerekli"; else -> "Sorun" }, color = levelColor(h.level), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                }
                Text(h.detail, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.padding(start = 18.dp, top = 2.dp))
                if (h.level > 0 && h.fix != null && h.fixLabel != null)
                    TextButton(onClick = { h.fix.invoke() }, modifier = Modifier.padding(start = 10.dp)) { Text(h.fixLabel) }
            }
        }
    }
}

/** Bayt sayısını okunur boyuta çevirir: KB / MB / GB / TB. */
fun fmtSize(b: Long): String {
    if (b == Long.MAX_VALUE) return "bilinmiyor"
    val kb = 1024.0; val mb = kb * 1024; val gb = mb * 1024; val tb = gb * 1024
    val v = b.toDouble()
    return when {
        v >= tb -> "%.2f TB".format(v / tb)
        v >= gb -> "%.2f GB".format(v / gb)
        v >= mb -> "%.0f MB".format(v / mb)
        else -> "%.0f KB".format(v / kb)
    }
}
