package com.fotoliz.app

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File

/**
 * Yüz modelinin (ArcFace, ~174 MB) kalıcı kopyası. Android, uygulama kaldırılınca program klasörünü siler; bu yüzden model
 * indirilince/yüklenince Download/FotoLiz/ klasörüne de bir kopya yazılır. Uygulama yeniden kurulup model yoksa önce bu kopya
 * aranır; bulunursa internetten tekrar indirmeye gerek kalmaz.
 */
object ModelStore {
    private const val NAME = "FotoLiz_arcface_model.onnx"
    private const val REL = "Download/FotoLiz/"
    private const val MIN = 100_000_000L

    private fun find(ctx: Context): Pair<Uri, Long>? {
        if (Build.VERSION.SDK_INT < 29) return null
        val coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        return try {
            ctx.contentResolver.query(coll, arrayOf(MediaStore.MediaColumns._ID, MediaStore.MediaColumns.SIZE),
                "${MediaStore.MediaColumns.DISPLAY_NAME}=?", arrayOf(NAME), null)?.use {
                if (it.moveToFirst()) ContentUris.withAppendedId(coll, it.getLong(0)) to it.getLong(1) else null
            }
        } catch (e: Exception) { null }
    }

    /** Download/FotoLiz içinde tam boyutlu bir model kopyası gerçekten var mı (bayrağa değil dosyaya bakar). */
    fun hasCopy(ctx: Context): Boolean = (find(ctx)?.second ?: 0L) >= MIN

    /** Model var ve telefona henüz kopyalanmadıysa kopyalar (sessiz; hata olursa yok sayılır). */
    fun saveCopy(ctx: Context, src: File) {
        try {
            if (Build.VERSION.SDK_INT < 29 || !src.exists() || src.length() < MIN) return
            val have = find(ctx)
            if (have != null && have.second == src.length()) return
            val cr = ctx.contentResolver; val coll = MediaStore.Downloads.EXTERNAL_CONTENT_URI
            have?.let { try { cr.delete(it.first, null, null) } catch (e: Exception) { } }
            val uri = cr.insert(coll, ContentValues().apply {
                put(MediaStore.MediaColumns.DISPLAY_NAME, NAME)
                put(MediaStore.MediaColumns.MIME_TYPE, "application/octet-stream")
                put(MediaStore.MediaColumns.RELATIVE_PATH, REL)
                put(MediaStore.MediaColumns.IS_PENDING, 1)
            }) ?: return
            try {
                cr.openOutputStream(uri, "wt")?.use { o -> src.inputStream().use { it.copyTo(o, 256 * 1024) } }
                cr.update(uri, ContentValues().apply { put(MediaStore.MediaColumns.IS_PENDING, 0) }, null, null)
            } catch (e: Exception) { try { cr.delete(uri, null, null) } catch (x: Exception) { } }
        } catch (e: Exception) { }
    }

    /** Telefondaki kopyayı program klasörüne geri koyar. Başarılıysa true. */
    fun restore(ctx: Context, dst: File): Boolean {
        val tmp = File(ctx.filesDir, "arcface.tmp")
        try {
            val ins = find(ctx)?.let { ctx.contentResolver.openInputStream(it.first) }
                ?: File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS), "FotoLiz/$NAME").takeIf { it.canRead() }?.inputStream()
                ?: return false
            ins.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 256 * 1024) } }
            if (tmp.length() < MIN) { tmp.delete(); return false }
            dst.delete(); return tmp.renameTo(dst)
        } catch (e: Exception) { tmp.delete(); return false }
    }
}
