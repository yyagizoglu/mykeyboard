package com.fotoliz.app

import android.content.Context
import android.content.Intent
import android.content.pm.ApplicationInfo
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.net.Uri
import androidx.compose.animation.Crossfade
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.calculateCentroid
import androidx.compose.foundation.gestures.calculatePan
import androidx.compose.foundation.gestures.calculateZoom
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.zIndex
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Face
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.positionChanged
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.roundToInt

const val TR_ALPHA = "ABCÇDEFGĞHIİJKLMNOÖPRSŞTUÜVYZ"
fun letterCode(i: Int): String {
    var n = i; val sb = StringBuilder()
    do { sb.insert(0, TR_ALPHA[n % TR_ALPHA.length]); n = n / TR_ALPHA.length - 1 } while (n >= 0)
    return sb.toString()
}
/** Yüz adı: [etiket] + alfabe kodu, örn. "A", "TÜRBAN B". */
fun clusterLabel(c: Cluster, idx: Int) = if (c.obj) c.tag.ifBlank { "Nesne" } else (if (c.tag.isNotBlank()) c.tag + " " else "") + letterCode(idx)

class Target(val name: String, val rel: String, val count: Int, val cover: Uri)

/* ---------------------------------------------------------------- Foto ızgarası + çoklu seçim */

@Composable
fun PhotosScreen(vm: VM) {
    val sel = vm.photoSel
    val selMode = sel.isNotEmpty()
    var showMove by remember { mutableStateOf(false) }
    var askDelete by remember { mutableStateOf(false) }
    var showTag by remember { mutableStateOf(false) }
    // Görüntüleyiciden dönünce ızgara başa atlamasın: kaldığı konumdan devam etsin.
    val gridState = rememberLazyGridState(vm.photosScroll?.first ?: 0, vm.photosScroll?.second ?: 0)
    LaunchedEffect(Unit) { vm.photosScroll = null }
    // Düzenlenenler sayfasında (tüm düzenlenenler): basılı tutup sürükleyerek sıra değiştirme
    val canReorder = vm.viewingEdited && vm.selected == null && !vm.saveMode
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragX by remember { mutableStateOf(0f) }
    var dragY by remember { mutableStateOf(0f) }
    var cellW by remember { mutableStateOf(1f) }
    var cellH by remember { mutableStateOf(1f) }
    val gapPx = with(LocalDensity.current) { 4.dp.toPx() }
    val openViewerKeep: (Int) -> Unit = { i ->
        vm.photosScroll = gridState.firstVisibleItemIndex to gridState.firstVisibleItemScrollOffset
        vm.openViewer(i)
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            val tg = vm.selected?.tag.orEmpty()
            Text((if (vm.fromPerson) "“${PersonEngine.name.ifBlank { "Kişi" }}” • " else if (vm.fromSearch) "“${SearchEngine.query}” • " else if (tg.isNotBlank()) "$tg • " else "") + (if (vm.viewingEdited) "düzenlenen " else "") + "${vm.photoList.size} fotoğraf", style = MaterialTheme.typography.bodyMedium)
            Spacer(Modifier.weight(1f))
            if (vm.selected != null) {
                val en = vm.selected!!.edited.size
                if (en > 0 && !vm.viewingEdited) TextButton(onClick = { vm.openEdited(vm.selected!!) }) { Text("Düzenlenenler ($en)", color = Color(0xFF2E7D32), fontWeight = FontWeight.Bold) }
                else if (vm.viewingEdited) TextButton(onClick = { vm.openCluster(vm.selected!!) }) { Text("Asıllar") }
                TextButton(onClick = { showTag = true }) { Text("Etiket") }
            }
            val all = vm.photoList.isNotEmpty() && sel.size == vm.photoList.size
            TextButton(onClick = { vm.photoSel = if (all) emptySet() else vm.photoList.toSet() }) { Text(if (all) "Seçimi kaldır" else "Tümünü seç") }
        }
        if (vm.saveMode) Text("Albüme eklemek istediğin fotoğrafları seç; istemediklerinin işaretini kaldır, sonra Devam'a bas.",
            Modifier.padding(horizontal = 12.dp, vertical = 4.dp), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        LazyVerticalGrid(GridCells.Fixed(3), Modifier.weight(1f), state = gridState, contentPadding = PaddingValues(4.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            itemsIndexed(vm.photoList, key = { _, u -> u }) { i, u ->
                val on = u in sel
                // Seçim modunda: tek dokunuş = seç/bırak, hızlı çift dokunuş = tam ekran göster (seçim korunur).
                // Normal modda: tek dokunuş = direkt aç, uzun basış = seçim modunu başlat.
                val dbl: ((Offset) -> Unit)? = if (selMode) { _ -> openViewerKeep(i) } else null
                val dragging = dragKey == u
                val curIdx by rememberUpdatedState(i)
                Box(Modifier.aspectRatio(1f)
                    .onSizeChanged { cellW = it.width + gapPx; cellH = it.height + gapPx }
                    .zIndex(if (dragging) 1f else 0f)
                    .graphicsLayer {
                        translationX = if (dragging) dragX else 0f; translationY = if (dragging) dragY else 0f
                        scaleX = if (dragging) 1.08f else 1f; scaleY = if (dragging) 1.08f else 1f; alpha = if (dragging) 0.85f else 1f
                    }
                    .pointerInput(selMode, on, u, i, canReorder) {
                        detectTapGestures(
                            onTap = { if (selMode) vm.togglePhoto(u) else openViewerKeep(i) },
                            onDoubleTap = dbl,
                            onLongPress = { if (!canReorder) vm.togglePhoto(u) })
                    }
                    .then(if (!canReorder) Modifier else Modifier.pointerInput(u) {
                        detectDragGesturesAfterLongPress(
                            onDragStart = { dragKey = u; dragX = 0f; dragY = 0f },
                            onDrag = { change, amount -> change.consume(); dragX += amount.x; dragY += amount.y },
                            onDragEnd = {
                                val n = vm.photoList.size; val cols = 3; val rowsN = (n + cols - 1) / cols
                                val from = curIdx
                                val col = ((((from % cols) + 0.5f) * cellW + dragX) / cellW).toInt().coerceIn(0, cols - 1)
                                val rw = ((((from / cols) + 0.5f) * cellH + dragY) / cellH).toInt().coerceIn(0, rowsN - 1)
                                val to = (rw * cols + col).coerceIn(0, n - 1)
                                val still = abs(dragX) < 24f && abs(dragY) < 24f   // sürüklenmeden bırakıldı: seçim modu
                                dragKey = null; dragX = 0f; dragY = 0f
                                if (still) vm.togglePhoto(u) else if (to != from) vm.moveEdited(from, to)
                            },
                            onDragCancel = { dragKey = null; dragX = 0f; dragY = 0f })
                    })
                ) {
                    AsyncImage(Uri.parse(u), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    if (on) Box(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.primary.copy(alpha = 0.30f)))
                    Box(Modifier.align(Alignment.TopStart).padding(6.dp).size(24.dp).clip(CircleShape)
                        .background(if (on) MaterialTheme.colorScheme.primary else Color(0x66000000))
                        .border(2.dp, Color.White, CircleShape)
                        .clickable { vm.togglePhoto(u) },
                        contentAlignment = Alignment.Center) {
                        if (on) Icon(Icons.Filled.Check, null, tint = Color.White, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
        if (vm.saveMode) Surface(tonalElevation = 3.dp) {
            PrimaryAction("Devam: albüm seç / oluştur (${sel.size})", { showMove = true }, Modifier.padding(12.dp), enabled = sel.isNotEmpty())
        } else if (selMode) Surface(tonalElevation = 3.dp) {
            Row(Modifier.fillMaxWidth().padding(8.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                val ink = MaterialTheme.colorScheme.onSurface
                ActIcon(Ic.Enhance, "Netleştir", ink, { vm.enhancePhotos(vm.photoList.filter { it in sel }) })
                ActIcon(Ic.Move, "Taşı", ink, { showMove = true })
                ActIcon(Ic.Delete, "Sil", MaterialTheme.colorScheme.error, { askDelete = true })
                ActIcon(Ic.Close, "Seçimi bırak", ink, { vm.photoSel = emptySet() })
            }
        }
    }
    if (showTag) TagDialog(vm.selected?.tag.orEmpty(), { showTag = false }) { t -> showTag = false; vm.setTag(t) }
    if (showMove) MoveDialog(vm, { showMove = false }, initialName = if (vm.saveMode) vm.saveSuggestion() else "") { rel -> showMove = false; vm.movePhotos(vm.photoList.filter { it in sel }, rel) }
    if (askDelete) AlertDialog(onDismissRequest = { askDelete = false },
        title = { Text("${sel.size} fotoğraf silinsin mi?") },
        text = { Text("Fotoğraflar telefondan silinir.") },
        confirmButton = { TextButton(onClick = { askDelete = false; vm.deletePhotos(vm.photoList.filter { it in sel }) }) { Text("Sil") } },
        dismissButton = { TextButton(onClick = { askDelete = false }) { Text("Vazgeç") } })
}

/* ---------------------------------------------------------------- Yüz etiketi (elle) */

@Composable
fun TagDialog(current: String, onDismiss: () -> Unit, onSave: (String) -> Unit) {
    var text by remember { mutableStateOf(current) }
    AlertDialog(onDismissRequest = onDismiss, title = { Text("Yüze etiket ekle") },
        text = {
            Column {
                Text("Etiket, yüzün alfabe kodunun başına eklenir (örn. TÜRBAN A).", style = MaterialTheme.typography.bodySmall)
                OutlinedTextField(text, { text = it }, singleLine = true, label = { Text("Etiket") }, modifier = Modifier.fillMaxWidth().padding(top = 8.dp))
                TextButton(onClick = { text = "TÜRBAN" }) { Text("TÜRBAN") }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(text) }) { Text("Kaydet") } },
        dismissButton = { TextButton(onClick = { onSave("") }) { Text("Etiketi kaldır") } })
}

/* ---------------------------------------------------------------- Albüm seçme / yeni albüm */

@Composable
fun MoveDialog(vm: VM, onDismiss: () -> Unit, initialName: String = "", onPick: (String) -> Unit) {
    var newName by remember { mutableStateOf(initialName) }
    LaunchedEffect(Unit) { vm.loadTargets() }
    AlertDialog(onDismissRequest = onDismiss, title = { Text(if (initialName.isNotBlank()) "Hangi albüme taşınsın?" else "Albüme taşı") },
        text = {
            Column {
                OutlinedTextField(newName, { newName = it }, singleLine = true, label = { Text("Yeni albüm adı") }, modifier = Modifier.fillMaxWidth())
                Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Button(onClick = {
                        val n = newName.replace(Regex("[\\\\/:*?\"<>|]"), "").trim()
                        if (n.isNotEmpty()) onPick("Pictures/$n/")
                    }, enabled = newName.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Yeni albüm oluştur ve taşı") }
                }
                // Yeni albüm adı yazıldıkça adı uyan mevcut albümler altta listelenir (yazı yoksa hepsi)
                val tr = java.util.Locale("tr")
                val q = newName.trim()
                val shown = if (q.isEmpty()) vm.targets else vm.targets.filter { it.name.contains(q, ignoreCase = true) || it.name.lowercase(tr).contains(q.lowercase(tr)) }
                Text(if (q.isEmpty()) "Mevcut albümler" else "Benzer albümler (${shown.size})", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 4.dp))
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(shown) { t ->
                        Row(Modifier.fillMaxWidth().clickable { onPick(t.rel) }.padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            AsyncImage(t.cover, null, Modifier.size(52.dp).clip(RoundedCornerShape(8.dp)), contentScale = ContentScale.Crop)
                            Spacer(Modifier.width(12.dp))
                            Column {
                                Text(t.name, maxLines = 1, style = MaterialTheme.typography.bodyLarge)
                                Text("${t.count} fotoğraf", style = MaterialTheme.typography.bodySmall)
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Vazgeç") } })
}

/* ---------------------------------------------------------------- Tam ekran görüntüleyici */

/**
 * İki parmakla yakınlaştır/uzaklaştır (pinch), yakınlaşınca tek parmakla kaydır, çift dokunuşla 2.5x yakınlaştır/geri al.
 * Yakınlaşmamışken tek parmak olayları tüketilmez; yani sayfalar arası kaydırma (pager) normal çalışır.
 */
@Composable
fun ZoomBox(modifier: Modifier = Modifier, content: @Composable BoxScope.() -> Unit) {
    var scale by remember { mutableFloatStateOf(1f) }
    var offset by remember { mutableStateOf(Offset.Zero) }
    BoxWithConstraints(modifier.fillMaxSize().clipToBounds()) {
        val w = constraints.maxWidth.toFloat(); val h = constraints.maxHeight.toFloat()
        val center = Offset(w / 2f, h / 2f)
        fun clamp(o: Offset, sc: Float): Offset {
            val mx = w * (sc - 1f) / 2f; val my = h * (sc - 1f) / 2f
            return Offset(o.x.coerceIn(-mx, mx), o.y.coerceIn(-my, my))
        }
        // c noktası sabit kalacak şekilde yeni ölçeğe geç
        fun zoomAt(c: Offset, newScale: Float, pan: Offset) {
            val ns = newScale.coerceIn(1f, 6f)
            if (ns <= 1.001f) { scale = 1f; offset = Offset.Zero; return }
            val ratio = ns / scale
            val t = (c - center) - (c - center - offset) * ratio + pan
            scale = ns; offset = clamp(t, ns)
        }
        Box(Modifier.fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures(onDoubleTap = { p -> if (scale > 1.05f) { scale = 1f; offset = Offset.Zero } else zoomAt(p, 2.5f, Offset.Zero) })
            }
            .pointerInput(Unit) {
                awaitEachGesture {
                    awaitFirstDown(requireUnconsumed = false)
                    do {
                        val ev = awaitPointerEvent()
                        val multi = ev.changes.count { it.pressed } >= 2
                        if (multi || scale > 1.001f) {
                            val z = ev.calculateZoom(); val pan = ev.calculatePan(); val c = ev.calculateCentroid()
                            if (multi) zoomAt(c, scale * z, pan) else offset = clamp(offset + pan, scale)
                            ev.changes.forEach { if (it.positionChanged()) it.consume() }
                        }
                    } while (ev.changes.any { it.pressed })
                }
            }
            .graphicsLayer { scaleX = scale; scaleY = scale; translationX = offset.x; translationY = offset.y },
            content = content)
    }
}

@Composable
fun ViewerScreen(vm: VM) {
    if (vm.photoList.isEmpty()) { LaunchedEffect(Unit) { vm.screen = Screen.Photos }; return }
    ViewerBody(vm)
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun ViewerBody(vm: VM) {
    val ctx = LocalContext.current
    val list = vm.photoList
    val pager = rememberPagerState(initialPage = vm.viewIndex.coerceIn(0, list.lastIndex)) { list.size }
    LaunchedEffect(pager.currentPage) { vm.viewIndex = pager.currentPage }
    var showMove by remember { mutableStateOf(false) }
    var askDelete by remember { mutableStateOf(false) }
    var faceSel by remember { mutableStateOf<VM.ViewFace?>(null) }
    var nameAsk by remember { mutableStateOf<Pair<Boolean, VM.ViewFace>?>(null) }   // (true = Ünlülere, false = Kaydedilen yüzlere) eklerken yüz ismi sorulur
    // Görüntüleyiciden çıkınca yüz bulucu model belleği boşaltılır
    DisposableEffect(Unit) { onDispose { vm.releaseViewAnalyzer() } }
    // Düzenleyiciden (Google Fotoğraflar vb.) dönünce yeni kopya Düzenlenenler'e eklenir
    DisposableEffect(ctx) {
        val lc = (ctx as? androidx.lifecycle.LifecycleOwner)?.lifecycle
        val ob = androidx.lifecycle.LifecycleEventObserver { _, e -> if (e == androidx.lifecycle.Lifecycle.Event.ON_RESUME) vm.collectExternalEdit() }
        lc?.addObserver(ob)
        onDispose { lc?.removeObserver(ob) }
    }
    val cur = list.getOrNull(pager.currentPage) ?: return
    // Sayfa değişince o fotoğraftaki yüzler bulunur; yüzlerin etrafında dokunulabilir çerçeve çizilir
    LaunchedEffect(cur) { vm.loadViewFaces(cur) }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        HorizontalPager(pager, Modifier.weight(1f).fillMaxWidth()) { p ->
            val u = list[p]
            ZoomBox {
                AsyncImage(Uri.parse(u), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
                val vf = vm.viewFaces[u]
                if (vf != null && vf.w > 0 && vf.h > 0) BoxWithConstraints(Modifier.fillMaxSize()) {
                    val bw = constraints.maxWidth.toFloat(); val bh = constraints.maxHeight.toFloat()
                    val sc = minOf(bw / vf.w, bh / vf.h)
                    val ox = (bw - vf.w * sc) / 2f; val oy = (bh - vf.h * sc) / 2f
                    val dn = LocalDensity.current
                    for (f in vf.faces) {
                        Box(Modifier
                            .offset { IntOffset((ox + f.box.left * sc).roundToInt(), (oy + f.box.top * sc).roundToInt()) }
                            .size(with(dn) { (f.box.width() * sc).toDp() }, with(dn) { (f.box.height() * sc).toDp() })
                            .clip(RoundedCornerShape(8.dp))
                            .border(2.dp, Color(0xCCFFFFFF), RoundedCornerShape(8.dp))
                            .clickable { faceSel = f })
                    }
                }
            }
        }
        val vfCur = vm.viewFaces[cur]
        val hint = when {
            !vm.modelReady -> null
            vfCur == null && cur in vm.viewPending -> "Yüzler aranıyor…"
            vfCur != null && vfCur.faces.isNotEmpty() -> "Yüze dokun: ayrıntı, kapak resmi ve yüzlere kaydet"
            else -> null
        }
        if (hint != null) Box(Modifier.fillMaxWidth().padding(top = 4.dp), contentAlignment = Alignment.Center) {
            Text(hint, color = Color(0xCCFFFFFF), style = MaterialTheme.typography.bodySmall)
        }
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            FavButton(cur)
            // Düzenle: telefonun kendi (sistem) düzenleyicisi seçici sormadan doğrudan açılır
            ActIcon(Ic.Edit, "Düzenle", Color.White, {
                vm.beginExternalEdit(cur)
                if (!openSystemEditor(ctx, Uri.parse(cur))) vm.toast("Düzenleyici uygulama bulunamadı.")
            })
            ActIcon(Ic.Crop, "Kırp", Color.White, { vm.cropUri = cur; vm.screen = Screen.Crop })
            ActIcon(Ic.Enhance, "Netleştir", Color.White, { vm.enhancePhotos(listOf(cur)) })
            ActIcon(Ic.Move, "Taşı", Color.White, { showMove = true })
            ActIcon(Ic.Delete, "Sil", Color(0xFFFF6B6B), { askDelete = true })
        }
    }
    faceSel?.let { f ->
        val m = remember(f, vm.saved) { vm.matchFace(f.emb) }
        val img = remember(f) { f.crop.asImageBitmap() }
        AlertDialog(onDismissRequest = { faceSel = null }, title = { Text("Yüz ayrıntısı") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically) {
                        val coverFile = m?.cluster?.thumb?.takeIf { it.isNotBlank() }?.let { java.io.File(it) }?.takeIf { it.exists() }
                        if (coverFile != null) Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            AsyncImage(coverFile, null, Modifier.size(84.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                            Text("Mevcut kapak", style = MaterialTheme.typography.labelSmall)
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Image(img, null, Modifier.size(84.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                            Text("Dokunulan yüz", style = MaterialTheme.typography.labelSmall)
                        }
                    }
                    if (m != null) {
                        Text("Kişi: ${m.label}", fontWeight = FontWeight.SemiBold)
                        Text("Bu kişinin ${m.cluster.photos.size} fotoğrafı var (analiz: ${m.result.name}).", style = MaterialTheme.typography.bodySmall)
                        Text("Benzerlik: %${(m.sim * 100).roundToInt()}", style = MaterialTheme.typography.bodySmall)
                    } else Text("Bu yüz kayıtlı kişilerle eşleşmedi. Bu fotoğrafı içeren bir analiz kaydı yoksa kapak resmi yapılamaz.", style = MaterialTheme.typography.bodySmall)
                    Text("Yüz netliği: %${(f.q * 100).roundToInt()}", style = MaterialTheme.typography.bodySmall)
                    TonalAction("Yüzlere kaydet", { nameAsk = false to f; faceSel = null }, Modifier.fillMaxWidth(), icon = Icons.Filled.Face)
                    TonalAction("Ünlülere ekle", { nameAsk = true to f; faceSel = null }, Modifier.fillMaxWidth(), icon = Icons.Filled.Star)
                }
            },
            confirmButton = { if (m != null) TextButton(onClick = { vm.setCover(m, f); faceSel = null }) { Text("Kapak resmi yap") } },
            dismissButton = { TextButton(onClick = { faceSel = null }) { Text("Kapat") } })
    }
    nameAsk?.let { (toCeleb, f) ->
        val m = remember(f, vm.saved) { vm.matchFace(f.emb) }
        var nm by remember(f) { mutableStateOf(m?.cluster?.tag.orEmpty()) }
        AlertDialog(onDismissRequest = { nameAsk = null }, title = { Text(if (toCeleb) "Ünlülere ekle" else "Yüzlere kaydet") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Image(remember(f) { f.crop.asImageBitmap() }, null, Modifier.size(84.dp).clip(CircleShape), contentScale = ContentScale.Crop)
                    FieldBox(nm, { nm = it }, "Yüz ismi", Icons.Filled.Face)
                }
            },
            confirmButton = { TextButton(onClick = {
                if (toCeleb) vm.addViewFaceToCelebs(cur, f, m, nm) else vm.saveViewFace(cur, vm.viewFaces[cur], f, m, nm)
                nameAsk = null
            }) { Text("Ekle") } },
            dismissButton = { TextButton(onClick = { nameAsk = null }) { Text("Vazgeç") } })
    }
    if (showMove) MoveDialog(vm, { showMove = false }) { rel -> showMove = false; vm.movePhotos(listOf(cur), rel) }
    if (askDelete) AlertDialog(onDismissRequest = { askDelete = false },
        title = { Text("Bu fotoğraf silinsin mi?") },
        text = { Text("Fotoğraf telefondan silinir.") },
        confirmButton = { TextButton(onClick = { askDelete = false; vm.deletePhotos(listOf(cur)) }) { Text("Sil") } },
        dismissButton = { TextButton(onClick = { askDelete = false }) { Text("Vazgeç") } })
}

/* ---------------------------------------------------------------- Kırpma */

@Composable
fun CropScreen(vm: VM) {
    val ctx = LocalContext.current
    val uriStr = vm.cropUri
    var bmp by remember(uriStr) { mutableStateOf<Bitmap?>(null) }
    LaunchedEffect(uriStr) {
        if (uriStr != null) bmp = withContext(Dispatchers.IO) {
            try {
                val src = ImageDecoder.createSource(ctx.contentResolver, Uri.parse(uriStr))
                ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                    dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                    val m = maxOf(info.size.width, info.size.height)
                    if (m > 4096) dec.setTargetSampleSize(m / 4096 + 1)
                }
            } catch (e: Exception) { null }
        }
    }
    val b = bmp
    if (b == null || uriStr == null) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { CircularProgressIndicator() }
    else CropEditor(b, uriStr, vm)
}

@Composable
private fun CropEditor(b: Bitmap, uri: String, vm: VM) {
    var l by remember { mutableFloatStateOf(0.1f) }
    var t by remember { mutableFloatStateOf(0.1f) }
    var r by remember { mutableFloatStateOf(0.9f) }
    var bt by remember { mutableFloatStateOf(0.9f) }
    val img = remember(b) { b.asImageBitmap() }
    val touch = with(LocalDensity.current) { 40.dp.toPx() }

    Column(Modifier.fillMaxSize()) {
        BoxWithConstraints(Modifier.weight(1f).fillMaxWidth().background(Color.Black)) {
            val boxW = constraints.maxWidth.toFloat(); val boxH = constraints.maxHeight.toFloat()
            val scale = minOf(boxW / b.width, boxH / b.height)
            val dw = b.width * scale; val dh = b.height * scale
            val ox = (boxW - dw) / 2f; val oy = (boxH - dh) / 2f
            Canvas(Modifier.fillMaxSize().pointerInput(b, dw, dh, ox, oy) {
                var mode = 0
                detectDragGestures(
                    onDragStart = { p ->
                        val px = (p.x - ox) / dw; val py = (p.y - oy) / dh
                        val tx = touch / dw; val ty = touch / dh
                        fun near(x: Float, y: Float) = abs(px - x) < tx && abs(py - y) < ty
                        mode = when {
                            near(l, t) -> 1; near(r, t) -> 2; near(l, bt) -> 3; near(r, bt) -> 4
                            px in l..r && py in t..bt -> 5
                            else -> 0
                        }
                    },
                    onDrag = { change, d ->
                        change.consume()
                        val dx = d.x / dw; val dy = d.y / dh; val mn = 0.08f
                        when (mode) {
                            1 -> { l = (l + dx).coerceIn(0f, r - mn); t = (t + dy).coerceIn(0f, bt - mn) }
                            2 -> { r = (r + dx).coerceIn(l + mn, 1f); t = (t + dy).coerceIn(0f, bt - mn) }
                            3 -> { l = (l + dx).coerceIn(0f, r - mn); bt = (bt + dy).coerceIn(t + mn, 1f) }
                            4 -> { r = (r + dx).coerceIn(l + mn, 1f); bt = (bt + dy).coerceIn(t + mn, 1f) }
                            5 -> {
                                val w = r - l; val h = bt - t
                                val nl = (l + dx).coerceIn(0f, 1f - w); val nt = (t + dy).coerceIn(0f, 1f - h)
                                l = nl; r = nl + w; t = nt; bt = nt + h
                            }
                        }
                    })
            }) {
                drawImage(img, dstOffset = IntOffset(ox.roundToInt(), oy.roundToInt()), dstSize = IntSize(dw.roundToInt(), dh.roundToInt()))
                val rl = ox + l * dw; val rt = oy + t * dh; val rr = ox + r * dw; val rb = oy + bt * dh
                val shade = Color(0x99000000)
                drawRect(shade, Offset(ox, oy), Size(dw, rt - oy))
                drawRect(shade, Offset(ox, rb), Size(dw, oy + dh - rb))
                drawRect(shade, Offset(ox, rt), Size(rl - ox, rb - rt))
                drawRect(shade, Offset(rr, rt), Size(ox + dw - rr, rb - rt))
                drawRect(Color.White, Offset(rl, rt), Size(rr - rl, rb - rt), style = Stroke(3f))
                for (c in listOf(Offset(rl, rt), Offset(rr, rt), Offset(rl, rb), Offset(rr, rb))) drawCircle(Color.White, 14f, c)
            }
        }
        Row(Modifier.fillMaxWidth().padding(12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = { vm.screen = Screen.Viewer }, modifier = Modifier.weight(1f)) { Text("Vazgeç") }
            Button(onClick = {
                val x = (l * b.width).roundToInt().coerceIn(0, b.width - 1)
                val y = (t * b.height).roundToInt().coerceIn(0, b.height - 1)
                val w = ((r - l) * b.width).roundToInt().coerceIn(1, b.width - x)
                val h = ((bt - t) * b.height).roundToInt().coerceIn(1, b.height - y)
                vm.saveCropped(uri, Bitmap.createBitmap(b, x, y, w, h))
            }, modifier = Modifier.weight(1f)) { Text("Kopya olarak kaydet") }
        }
    }
}

/* ---------------------------------------------------------------- Analiz (tarama) ekranı */

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun ScanScreen() {
    val ctx = LocalContext.current
    // Analiz sürerken bir yüze dokununca o yüzün (ve şu ana kadar bulunan benzer yüzlerin) fotoğrafları açılır
    var peek by remember { mutableStateOf<List<String>?>(null) }
    fun openFace(path: String) {
        val info = Engine.liveInfo[path] ?: return
        val others = Engine.liveInfo.values.toList()
            .filter { it.photo != info.photo }
            .map { it to dot(it.emb, info.emb) }.filter { it.second >= CORE_THR }
            .sortedByDescending { it.second }.map { it.first.photo }.distinct()
        peek = listOf(info.photo) + others
    }
    val batteryOk = ctx.getSystemService(android.os.PowerManager::class.java).isIgnoringBatteryOptimizations(ctx.packageName)
    val faces = Engine.liveFaces
    val recent = faces.asReversed().take(60)   // en yeni bulunan yüz başta
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        // Üst bölüm: şu an analiz edilen fotoğraf (sırayla akar)
        Box(Modifier.weight(1f).fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.Black), contentAlignment = Alignment.Center) {
            Crossfade(Engine.currentPhoto, animationSpec = tween(180), label = "scan") { u ->
                if (u != null) AsyncImage(u, null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit)
            }
        }
        Spacer(Modifier.height(12.dp))
        val frac = Engine.done.toFloat() / Engine.total.coerceAtLeast(1)
        Row(Modifier.fillMaxWidth().padding(bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Bekleyiniz…", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = Color(0xFF2E7D32))
            Spacer(Modifier.weight(1f))
            Text("Taranan %${(frac * 100).roundToInt()}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
        }
        GreenProgress(frac)
        Text(Engine.status, style = MaterialTheme.typography.bodySmall, maxLines = 1, softWrap = false, fontSize = 11.sp, modifier = Modifier.padding(top = 6.dp))
        // Alt bölüm: bulunan yüzler yuvarlak önizleme olarak
        Text("Bulunan yüzler (${Engine.people})", style = MaterialTheme.typography.titleSmall, modifier = Modifier.padding(top = 12.dp, bottom = 6.dp))
        LazyRow(Modifier.fillMaxWidth().height(68.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            items(recent, key = { it }) { path ->
                AsyncImage(java.io.File(path), null, Modifier.size(64.dp).clip(CircleShape).clickable { openFace(path) }, contentScale = ContentScale.Crop)
            }
        }
        Text("Uygulamadan çıksanız bile analiz arka planda sürer.", style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
        if (!batteryOk) TextButton(onClick = {
            try {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
            } catch (e: Exception) {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${ctx.packageName}")))
            }
        }) { Text("Arka planda durmasın: pil kısıtlamasını kaldır") }
        OutlinedButton(onClick = { Engine.cancel() }, modifier = Modifier.padding(top = 4.dp)) { Text("İptal et") }
    }
    peek?.let { list ->
        androidx.compose.ui.window.Dialog(onDismissRequest = { peek = null },
            properties = androidx.compose.ui.window.DialogProperties(usePlatformDefaultWidth = false)) {
            val pager = rememberPagerState { list.size }
            Box(Modifier.fillMaxSize().background(Color.Black)) {
                HorizontalPager(pager, Modifier.fillMaxSize()) { i ->
                    ZoomBox { AsyncImage(Uri.parse(list[i]), null, Modifier.fillMaxSize(), contentScale = ContentScale.Fit) }
                }
                Column(Modifier.fillMaxWidth().align(Alignment.TopCenter).background(Color(0x66000000))) {
                Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically) {
                    TextButton(onClick = { peek = null }) { Text("← Geri", color = Color.White) }
                    Spacer(Modifier.weight(1f))
                    FavButton(list[pager.currentPage.coerceIn(0, list.lastIndex)])
                    Text("${pager.currentPage + 1} / ${list.size} • analiz sürüyor %${(Engine.done.toFloat() / Engine.total.coerceAtLeast(1) * 100).roundToInt()}",
                        color = Color.White, style = MaterialTheme.typography.bodyMedium, modifier = Modifier.padding(end = 12.dp))
                }
                    Box(Modifier.fillMaxWidth().padding(start = 12.dp, end = 12.dp, bottom = 10.dp)) { GreenProgress(Engine.done.toFloat() / Engine.total.coerceAtLeast(1)) }
                }
            }
        }
    }
}

/** Yuvarlak köşeli, yeşil degrade, akıcı animasyonlu ilerleme çubuğu. */
@Composable
fun GreenProgress(p: Float) {
    val a by animateFloatAsState(p.coerceIn(0f, 1f), tween(400), label = "progress")
    Box(Modifier.fillMaxWidth().height(16.dp).clip(RoundedCornerShape(8.dp)).background(Color(0x264CAF50))) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(a).clip(RoundedCornerShape(8.dp))
            .background(Brush.horizontalGradient(listOf(Color(0xFF81C784), Color(0xFF43A047), Color(0xFF1B5E20)))))
    }
}

/** Telefonun kendi (sistem) düzenleyici/galeri uygulamasını seçici göstermeden doğrudan açar. */
fun openSystemEditor(ctx: Context, uri: Uri): Boolean {
    val pm = ctx.packageManager
    fun tryAction(action: String): Boolean {
        val base = Intent(action).setDataAndType(uri, "image/*")
            .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)   // yazma izni verilmez: düzenleyici orijinalin üstüne yazamaz, yeni kopya oluşturur
        val all = try { pm.queryIntentActivities(base, 0) } catch (e: Exception) { emptyList() }
        val cands = all.filter { it.activityInfo.packageName != ctx.packageName }
        val sys = cands.filter { (it.activityInfo.applicationInfo.flags and ApplicationInfo.FLAG_SYSTEM) != 0 }
        val pick = sys.firstOrNull { r -> listOf("gallery", "photo", "edit").any { r.activityInfo.packageName.contains(it) } }
            ?: sys.firstOrNull() ?: cands.firstOrNull() ?: return false
        base.setClassName(pick.activityInfo.packageName, pick.activityInfo.name)
        return try { ctx.startActivity(base); true } catch (e: Exception) { false }
    }
    return tryAction(Intent.ACTION_EDIT) || tryAction(Intent.ACTION_VIEW)
}

/** Taşıma bilgi kartı (köşe): hedef klasör adı, aşama, "x / y" ve küçük önizlemenin etrafında 0-100 dolan halka + yüzde. */
@Composable
fun MoveBadge(info: MoveInfo, modifier: Modifier = Modifier) {
    val frac by animateFloatAsState(info.percent / 100f, tween(300), label = "moveFrac")
    val accent = if (info.stage == MoveStage.DONE) Color(0xFF43A047) else Color(0xFF7E57C2)
    Row(modifier.widthIn(max = 260.dp).clip(RoundedCornerShape(16.dp)).background(Color(0xE61E1E24))
        .border(1.dp, Color(0x33FFFFFF), RoundedCornerShape(16.dp)).padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
            info.thumb?.let {
                coil.compose.AsyncImage(model = Uri.parse(it), contentDescription = null, contentScale = androidx.compose.ui.layout.ContentScale.Crop,
                    modifier = Modifier.size(40.dp).clip(CircleShape))
            }
            // Önizlemeyi çevreleyen halka: 0'dan 100'e dolar
            Canvas(Modifier.fillMaxSize()) {
                val w = 4.dp.toPx(); val inset = w / 2
                val sz = androidx.compose.ui.geometry.Size(size.width - w, size.height - w)
                val tl = androidx.compose.ui.geometry.Offset(inset, inset)
                drawArc(Color(0x44FFFFFF), 0f, 360f, false, tl, sz, style = androidx.compose.ui.graphics.drawscope.Stroke(w))
                drawArc(accent, -90f, 360f * frac, false, tl, sz, style = androidx.compose.ui.graphics.drawscope.Stroke(w, cap = androidx.compose.ui.graphics.StrokeCap.Round))
            }
        }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f, fill = false)) {
            Text("Hedef albüm", color = Color(0x99FFFFFF), fontSize = 10.sp)
            Text(info.folder.ifBlank { "Albüm" }, color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.Bold,
                fontSize = 14.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            Text(info.rel.trimEnd('/'), color = Color(0x99FFFFFF), fontSize = 10.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            Text(info.stage.label + if (info.stage != MoveStage.WAITING) " • ${info.done} / ${info.total}" else " • ${info.total} dosya",
                color = Color(0xCCFFFFFF), fontSize = 12.sp)
            if (info.stage == MoveStage.DONE && info.bad > 0) Text("${info.bad} taşınamadı", color = Color(0xFFFFB74D), fontSize = 11.sp)
        }
        Spacer(Modifier.width(8.dp))
        Text("%${info.percent}", color = Color.White, fontWeight = androidx.compose.ui.text.font.FontWeight.ExtraBold, fontSize = 16.sp)
    }
}
