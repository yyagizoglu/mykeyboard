plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.fotoliz.app"
    compileSdk = 34
    defaultConfig { applicationId = "com.fotoliz.app"; minSdk = 29; targetSdk = 34; versionCode = (System.currentTimeMillis() / 60000L).toInt(); versionName = "3.01" }   // versionCode her derlemede otomatik artar: mevcut uygulamanın üstüne güncelleme olarak kurulur
    signingConfigs {
        getByName("debug") {
            storeFile = file("debug.keystore"); storePassword = "android"
            keyAlias = "androiddebugkey"; keyPassword = "android"
        }
    }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    androidResources { noCompress += "onnx" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
// APK dosyasının adı: FotoLiz.apk
android.applicationVariants.all {
    outputs.all {
        (this as com.android.build.gradle.internal.api.BaseVariantOutputImpl).outputFileName = "FotoLiz.apk"
    }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-compose:1.9.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.8.3")
    implementation("androidx.documentfile:documentfile:1.0.1")
    implementation("androidx.exifinterface:exifinterface:1.3.7")
    implementation("io.coil-kt:coil-compose:2.6.0")
    implementation("com.google.mlkit:face-detection:16.1.6")
    implementation("com.google.mlkit:image-labeling:17.0.9")
    implementation("com.google.mlkit:text-recognition:16.0.1")          // netleştirmede fotoğraf üzerindeki yazıyı bulup siler
    implementation("com.microsoft.onnxruntime:onnxruntime-android:1.18.0")
    implementation("androidx.work:work-runtime-ktx:2.9.1")              // arka planda 10 dakikada bir Drive yedeği
    implementation("androidx.biometric:biometric:1.1.0")                // parmak izi
    implementation("androidx.fragment:fragment-ktx:1.8.1")              // BiometricPrompt için FragmentActivity
    implementation("com.google.android.gms:play-services-auth:21.2.0")  // Google Drive yetkilendirmesi
}
