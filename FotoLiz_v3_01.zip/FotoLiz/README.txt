--- v2.97: YARIM KALAN ANALIZ: EN USTTE SERIT + BILDIRIM ---
- Yarida kalan (Durdur / kesinti) analiz varken her ekranin en ustunde kirmizi yanip sonen isikli serit: "Devam et" kaldigi yerden surdurur; serit yazisina dokunca Bastan basla / Sil secenekleri. "Gizle" o oturumda saklar.
- Ayni anda bildirim cubuguna kirmizi isikli "Yarim kalan analiz" bildirimi duser; analiz surdurulunce / silinince kalkar.
- DoneSound.kt, MainActivity.kt, app/build.gradle.kts (2.97) degisti.

--- v2.96: SESLER: DEVAM EDEN ANALIZ SESI + SESSIZE AL ---
- Yeni "Devam Eden Analiz" sesi: bir analiz / tarama / arama baslayip surerken BIR KERE calar (varsayilan kisa bip). Ayarlar > Sesler'den degistirilir.
- Hem "Devam Eden Analiz" hem "Biten Analiz" (biten aramalar dahil) icin Dene dugmesinin yaninda "Sessize al / Sesi ac" dugmesi: ses secimi korunur, sadece susturulur.
- DoneSound.kt, Settings.kt, Gallery.kt, app/build.gradle.kts (2.96) degisti.

--- v2.95: GALERI: DEVAM EDEN ANALIZ ISIGI ---
- Galeri ekraninda (klasor listesi ve klasor ici) tarama / yuz gruplama / album analizi / nesne-kisi aramasi surerken ustte yesil bildirim isigi 5 sn'de bir yanip soner ve ilerlemeyi yazar.
- Gallery.kt, app/build.gradle.kts (2.95) degisti.

--- v2.94: NESNE: (CUMLE) ARAMA ---
- Nesne kutusuna parantez icinde cumle yazilabilir: (sakalli ve biyikli erkekler), (basinda turban olan kadin), (gozluklu sakalsiz erkek).
- Fotograftaki BUTUN yuzler cumleye uymali; uymayan yuz varsa fotograf gelmez. Yuz basina cinsiyet / ortu / sakal / biyik / gozluk saklanir (ilk (cumle) aramasinda fotograflar bir kez taranir).
- Sentence.kt (yeni), GalleryAttrs.kt, Gallery.kt, app/build.gradle.kts (2.94) degisti.

--- v2.93: GALERI: KAC FOTOGRAF TARANSIN SORUSU ---
- Klasor icindeyken Kadin / Erkek / Nesne filtresi secilince sayi penceresi acilir: yazdigin sayi kadar en yeni fotograf taranir ve gosterilir; bos / "Hepsi" = tumu.
- Gallery.kt, app/build.gradle.kts (2.93) degisti.

--- v2.92: GALERI: TEK DOKUNUSLA TAM EKRAN + DUZENLE ---
- Galeri izgarasinda fotografa tek dokunus artik tam ekran acar; altta Duzenle / Netlestir / Tasi / Sil dugmeleri var.
- Secmek icin saginin ustundeki yuvarlaga dokun ya da fotografa basili tut.
- Gallery.kt, app/build.gradle.kts (2.92) degisti.

--- v2.78: GALERI: YESIL ILERLEME CUBUKLARI (DURDUR / DEVAM ET / SIL + SURE) ---
- "Yuz Grupla" calisirken cubuk artik yesil: ilerleme, Gecen ve Kalan sure, Durdur / Devam et (kaldigi yerden surer) ve Sil (gruplamayi birakir, duz izgaraya doner).
- Filtre taramasi cubugu (Kadin / Erkek / Nesne ...) de Durdur / Devam et yanina Sil aldi: taramayi birakir, suzgec "Hepsi"ne doner; taranan bilgiler saklidir.
- Gallery.kt, TurbanScan.kt, app/build.gradle.kts (2.78) degisti.

--- v2.77: NESNE ARAMA KATI MOD ---
- Yazilan nesne fotografta yoksa sonuc olarak gosterilmez. Her yazilan kelime yalnizca kendi etiketleriyle eslesir (ornek: "agac" artik cimen / bahce / bitki etiketi getirmez).
- Bulanik "icerir / icerilir" grup eslesmesi kaldirildi (ornek: "ata" kelimesi At grubunu getiriyordu). Yalnizca sozluk, tam grup adi veya yazilan Ingilizce etiket gecerli.
- Etiket guveni 0.45 -> 0.60: dusuk guvenli, belirsiz etiketler nesne sayilmaz. Hem Nesne ara (ana ekran) hem Galeri > Nesne filtresi icin gecerli.
- Galeri etiket kaydi yenilendi (photolabels2.json): eski gevsek etiketler kullanilmaz, ilk Nesne filtresinde fotograflar bir kez yeniden etiketlenir.
- Birden cok nesne yazilirsa fotograf, yazilan nesnelerden en az birini KATI olarak icermelidir.
- ObjectSearch.kt, PhotoLabels.kt, app/build.gradle.kts (2.77) degisti.

--- v2.76: GALERI KLASOR ICI: SIMGELI DUGMELER ---
- Klasor acikken ustteki "Hepsi" filtresi ve "Yuz" dugmesi, "Yuz Grupla"nin yanina alindi. "Tumunu sec" artik "Tumu".
- Dort dugme de basinda simgeli: Tumu, Yuz Grupla, Hepsi (filtre menusu), Yuz.
- Netlestir / Tasi / Sil simgeleri baslik satirinin (klasor adi • oge sayisi) sagina tasindi.
- Gallery.kt, MainActivity.kt, app/build.gradle.kts (2.76) degisti.

--- v2.75: GALERI: UST BOLUM SABIT ---
- Galeri klasor listesinde "N klasor / album" sayaci, secili album listesi ve arac satiri (filtre, Yuz, Sayi, Ara) artik kaydirirken yukari cikmaz; yalnizca albumler kayar.
- Gallery.kt, app/build.gradle.kts (2.75) degisti.

--- v2.74: GALERI: HEPSI ILK SIRADA + SAYI KUTUSU + YESIL ARA ---
- Filtre menusunde "Hepsi" en uste alindi (Hepsi, Foto, Video, Kadin, Erkek, Nesne, Turban, Favoriler).
- Sayi kutusundaki "Ilk N" yazisi "Sayi" oldu; yaninda yesil "Ara" dugmesi var. Albumleri secip Ara'ya basinca secili filtreye gore tarama baslar.
  Birden cok album secilirse tek birlesik gorunumde acilir; sayi doluysa her albumun en yeni o kadar ogesi alinir, bos = hepsi. Secim yoksa uyari cikar.
- Gallery.kt, app/build.gradle.kts (2.74) degisti.

--- v2.73: GALERI: SECILI LISTESI YER DEGISTIRDI + SON ISLEMLER ---
- Secili albumlerin alt alta yazan listesi artik "N klasor / album • N oge" bilgisinin hemen altinda (cop ikonu secimden cikarir).
- Galeri sayfasinin en altinda "Son Islemler": Kayitli sonuclardaki kartlarla ayni gorunum (cagla yesili kart, en yeni kayitta kirmizi "SON ISLEM" rozeti). Album geri donusume atma ve ad degistirme kaydedilir (en fazla 30, kalici), "Temizle" ile silinir.
- Yeni dosya: RecentOps.kt. Gallery.kt, MainActivity.kt, VM.kt, app/build.gradle.kts (2.73) degisti.

--- v2.72: GALERI: SIL ICIN IKI ADIMLI UYARI + GERI DONUSUM ---
- Galeride Sil ikonuna basinca once "Secili album(ler) silinecektir. Emin misiniz?" (Evet / Hayir) sorulur.
- Evet denirse ikinci uyari: "Geri donusum kutusuna atilacak, 30 gun icinde geri alabilirsiniz" (Geri donusume at / Vazgec).
- Silme artik KALICI degil: Android 11+'da geri donusum kutusuna atilir (Android 10'da kutu olmadigi icin kalici silinir ve uyari buna gore yazar).
- Gallery.kt, VM.kt, app/build.gradle.kts (2.72) degisti.

--- v2.71: GALERI: SECILI ALBUM ADLARI ALT ALTA + SECIMDEN KALDIR ---
- Galeri ekraninda "N secili" yazisinin altinda secilen albumlerin adlari secildikce alt alta listelenir (cok olursa kaydirilir).
- Her adin basindaki cop ikonu albumu secimden cikarir; fotograflari SILMEZ (silme icin ustteki Sil ikonu).
- Gallery.kt (secilme sirasi), MainActivity.kt, app/build.gradle.kts (2.71) degisti.

--- v2.70: NESNE ARA: ALBUM SEC YANINDA SAYI KUTUSU ---
- Ana ekrandaki Nesne ara kartinda Albüm Seç dugmesi biraz sola kaydi, yanina (Ara'nin soluna) sayi kutusu geldi. Albüm ekranindaki "Sayi Girin" ile ayni degeri gosterir (orn. 10), buradan da degistirilebilir; bos = hepsi.
- SearchUi.kt, app/build.gradle.kts (2.70) degisti.

--- v2.69: RAPOR FIS (ADISYON) GORUNUMU ---
- Kayitli sonuclarda Rapor'a basinca rapor artik ekrani kaplamaz: ekranin SAG YARISINDA fis/adisyon seklinde acilir. Sol yariya dokununca veya X ile kapanir.
- Fiste FotoLiz logosu, yapimci adi ve simgeli iletisim bilgileri (telefon, WhatsApp, e-posta, Instagram, Facebook, adres), tarih, fis no, kayit dokumu (kisi / foto), toplamlar ve barkod yer alir. Fise sigmayan kisim bastan sona kaydirilir.
- Ustteki tam ekran dugmesi fisi tum ekranda gosterir; ayni dugme (veya geri) kucultur. Albüm adi duzenleme ve "Kaydedilsin mi?" sorusu aynen duruyor.
- Report.kt, app/build.gradle.kts (2.69) degisti.

--- v2.68: KAYITLI SONUCLARDA RAPOR + BULUNAN YUZLERDE SURUKLE-BIRAK SIRALAMA ---
- Ana ekranda Kayitli sonuclar basliginin yanindaki "Album ara" kutusu kuculdu, sagina "Rapor" dugmesi geldi.
- Rapor: tum kayitlarin listesi (kisi / fotograf sayisi, tarih, analiz suresi, bulunan kisi adlari). Her kaydin album yazisi duzenlenebilir.
  Cikarken (kapat / geri / Vazgec) degisiklik varsa "Kaydedilsin mi?" sorulur; Kaydet'e basilinca kayitlara islenir ve kayitli sonuc listesinde gecerli olur. Yazi bosaltilip kaydedilirse otomatik baslik geri gelir.
- Bulunan yuzler sayfasinda bir yuze basili tutup surukleyerek yerini degistirebilirsin; sira kalici kaydedilir, ana ekrandaki Bulunan yuzler onizlemesi de ayni sirayi gosterir.
  Basili tutup kipirdatmadan birakirsan eskisi gibi "Kisiyi duzenle" penceresi acilir. Yeni bulunan kisiler listenin sonuna eklenir.
- Yeni dosya: Report.kt. Store.kt (Result.label), VM.kt, Faces.kt, MainActivity.kt, app/build.gradle.kts (2.68) degisti.

--- v2.67: SURE BILGILERI + ALBUM EKRANI IKONLARI ---
- Ustteki "Analiz suruyor" kartinda Gecen sure ve Kalan sure (tahmini) her saniye guncellenir.
- Kayitli sonuclarda her kaydin alt satirinda, sag sonda "Analiz Sure: dd:ss" gorunur (eski kayitlarda "—").
- Albumleri sec ekraninda (analiz, Nesne ara, Kisiye gore ara icin ortak): Hepsini sec / Hicbiri / Sil ikon oldu. Sil, onay sorar ve secili albumlerdeki fotograflari geri donusum kutusuna atar (Android 11+).
- "Sayi Sec" kutusu "Sayi Girin" ipuclu, yuvarlak ve ortali yeni kutu oldu; ana ekrandaki Kisiye gore ara kartinda da ayni.
- Engine.kt, Store.kt, VM.kt, MainActivity.kt, UiKit.kt, ActIcons.kt, PersonUi.kt, app/build.gradle.kts (2.67) degisti.

--- v2.66: DUZENLENENLER: BASILI TUTUP SURUKLEYEREK YER DEGISTIR ---
- Ana ekrandaki Duzenlenenler -> tum duzenlenenler sayfasinda bir fotografa basili tutup surukleyerek istedigin yere birakabilirsin; sira kalici kaydedilir ve ana ekrandaki onizleme de ayni sirayi gosterir.
- Surukleden birakirsan (basili tutup kipirdatmadan) eskisi gibi secim modu acilir.
- Yeni netlestirilenler yine en basa eklenir.
- Photos.kt, VM.kt, EditedStore.kt, MainActivity.kt, app/build.gradle.kts (2.66) degisti.

--- v2.65: KISIYE GORE ARA: SAYI SEC KUTUSU ANA EKRANDA ---
- Kisiye gore ara kartinda (yuz secilince) ad kutusunun altinda "Sayi Sec" kutusu. Albumlerde her albumden yalnizca en yeni N fotografta aranir; bos = hepsi. Album ekranindaki kutuyla ayni deger.
- PersonUi.kt, app/build.gradle.kts (2.65) degisti.

--- v2.64: ALBUM EKRANI: SAYI SEC (ILK N FOTOGRAFI ANALIZ ET) ---
- Albumleri sec ekraninda sag ustte "Sayi Sec" kutusu. Rakam yazilirsa (orn. 1000) secili HER albumden yalnizca en yeni N fotograf analiz edilir; bos birakilirsa hepsi taranir.
- Analiz (Erkek / Kadin / Erkek & Kadin), Nesne ismi aramasi ve Kisiye gore arama icin gecerlidir.
- Sinirli analiz ayri kayit/devam anahtari kullanir; sinirsiz analizle karismaz.
- Engine.kt, ObjectSearch.kt, PersonSearch.kt, VM.kt, MainActivity.kt, app/build.gradle.kts (2.64) degisti.

--- v2.63: GALERI > NESNE FILTRESI: GOGUS / PENIS / VAJINA ARAMASI KESKIN ---
- Galeri > Nesne filtresine gogus, meme, penis, vajina, cinsel organ, popo, ciplak vb. yazilinca artik ML Kit etiketleri (chest, skin, human body...) degil, cihazda calisan NudeNet (YOLOv8, ONNX) dedektoru kullanilir. Yalnizca ilgili bolumun ACIKTA gorundugu fotograflar listelenir; kiyafetli olanlar gelmez.
- gogus = kiyafetsiz kadin + erkek gogsu; meme / breast = yalnizca kadin gogsu; penis = acikta erkek genital; vajina = acikta kadin genital; ciplak = bunlarin herhangi biri (+ popo).
- Keskinlik: puan esigi %50 (NudeDetector.MIN_SCORE), fotografin en az %0.6'sini kaplayan bolge sarti, kapali/acik siniflar ayni bolgede yarisinca yuksek puanli kazanir. Puanlar saklandigi icin esik degisince yeniden tarama gerekmez.
- Bebek / cocuk etiketi tasiyan fotograflar bu aramalarda hic gelmez; etiketi okunamamis fotograf da gosterilmez.
- Kelime + bolum birlikte yazilirsa ("gogus plaj") sonuc ikisini de saglamak zorundadir.
- Model: nudenet.onnx (~12 MB). APK icinde app/src/main/assets/nudenet.onnx varsa o, yoksa ilk aramada internetten 320n indirilir (tek sefer). Daha isabetli 640m modeli assets'e nudenet.onnx adiyla konabilir.
- Diger nesne aramalari (araba, kedi...) ve ana ekrandaki Nesne ara degismedi.
- Yeni dosya: NudeDetector.kt. ObjectSearch.kt, PhotoLabels.kt, Gallery.kt, app/build.gradle.kts (2.63) degisti.

--- v2.62: GALERI > NESNE FILTRESI: YAZARKEN PROGRAMIN KAPANMASI ENGELLENDI ---
- Nesne ismi penceresi acikken arka planda tarama baslamaz (yazma bitince baslar).
- Tarama ilerlemesi artik ana is parcacigindan guvenle guncellenir; tarama / sonuc hesabi sirasinda olusan hatalar programi kapatmaz.
- Yazma kutusunda klavyedeki "Bitti" tusu da filtreyi uygular; 80 karakter siniri eklendi.
- Gallery.kt, app/build.gradle.kts (2.62) degisti.

--- v2.61: GALERI: SECILENLERI TASI / SIL, TAM EKRANDA NETLESTIR / TASI / SIL ---
- Galeri'de klasor, grup ve Turban ekranlarinda bir ya da daha fazla foto secilince altta cubuk cikar: "Tasi" ve "Sil".
- Tasi: album secme penceresi acilir (mevcut ya da yeni album); fotograflar orijinal klasorden kalkar, secilen albume tasinir. Gruplar, bulunanlar ve sayilar kendiliginden guncellenir.
- Sil: onaydan sonra secili ogeler telefondan silinir (Android 11+'da tek sistem onayi). Yuze gore grup icindeki secimler de silinebilir.
- Tam ekran (cift dokunus): altta Netlestir, Tasi, Sil dugmeleri. Netlestir kopya uretir, orijinal korunur (Duzenlenenler'de gorunur). Video'da Netlestir yok.
- Silinen / tasinan ogeler ekrandaki izgaradan ve gruplardan hemen kalkar. Gallery.kt, VM.kt degisti.

--- v2.60: MINIK PANO TEK SATIR + YUKARIDA, NESNE FILTRESINDE INSAN UZVU ARAMA ---
- Ana ekrandaki pano (tarih, saat, ilce, hava) tek satir oldu ve tema / ayarlar dugmelerinin hemen altina, aralarinda bosluk kalmayacak sekilde yukari alindi.
- Galeri > Nesne filtresi: kol, bacak, kalca, ayak, el, parmak, goz, burun, kulak, agiz, dudak, boyun, omuz, gogus, karin, sirt, vucut, uzuv vb. yazilinca ilgili etiketi (arm, leg, hip, foot, eye, nose...) tasiyan fotograflar hicbir ek sansur / eleme olmadan listelenir. Tumu cihazda (internetsiz) calisir.
- MiniPanel.kt, MainActivity.kt, ObjectSearch.kt, app/build.gradle.kts (2.60) degisti.
- Not: ML Kit etiketleri kesin degildir; bir uzuv fotografta kucuk ya da kismi gorunuyorsa etiketlenmemis olabilir. Daha once etiketlenmis fotograflar yeniden taranmaz.

--- v2.59: KAYDEDILEN YUZLER / UNLULER PENCERESI: HERHANGI BIR YERE DOKUNUNCA TUMU ACILIR ---
- Ana ekrandaki "Kaydedilen yuzler" ve "Unluler" pencerelerinde "Tumu >" yazisi kaldirildi (yalnizca sayi gorunur).
- Pencerenin herhangi bir yerine (baslik, bos alan, yuzlerin uzerine) dokununca o pencerenin tum yuzlerinin oldugu sayfa acilir. Yuze basili tutmak eskisi gibi duzenleme penceresini acar.
- SavedFaces.kt degisti. (v2.58'deki MiniPanel ve Gallery.kt OptIn duzeltmesi dahil.)

--- v2.58: ANA EKRANDA MINIK PANO (TARIH, SAAT, ILCE, HAVA DURUMU) ---
- Ana ekranda sag ustte, ayarlar carkinin altinda kucuk pano: tarih, anlik saat (saniyeli), konum simgesiyle ilce adi, hava durumu simgesi ve derece.
- Ilk acilista konum izni istenir (yaklasik konum yeterli). Izin verilmezse panoda "Konum izni ver" yazisi cikar, dokununca tekrar sorar.
- Hava durumu Open-Meteo'dan (ucretsiz, anahtarsiz), ilce adi Android Geocoder'dan (olmazsa BigDataCloud) alinir. 15 dakikada bir yenilenir.
- Yeni dosya: MiniPanel.kt. MainActivity.kt, AndroidManifest.xml (konum izinleri), build.gradle.kts degisti.

--- v2.57: BULUNANLARI YUZE GORE GRUPLA (NESNE / KISI ARAMA), KAYITLI SONUC BASLIGI ---
- Nesne ara ve Kisiye gore ara sonuc ekranlarinda arama bitince "Yuze gore grupla" dugmesi: bulunan fotograflar ArcFace ile kisi kisi gruplanir (ilerleme cubugu + Iptal). Gruba dokununca o kisinin fotograflari acilir, tam ekranda yalnizca o grubun fotograflari gezilir. "Gruplara don" / "Grubu kapat" ve geri tusu (once grup, sonra gruplama, sonra ekran).
- Arama yeniden baslayinca ya da bulunanlar degisince (benzerlik esigi) gruplar sifirlanir.
- Kayitli sonuclar: baslik her zaman yalnizca "N album: Klasor1, Klasor2, ..." (album sayisi + klasor adlari). Klasor taramalarinda da ayni. Kayitli sonuc penceresi, kisiler ekraninin basligi ve kayitli sonuc aramasi da ayni bilgiyi kullanir.
- Yeni dosya: FoundGroup.kt. SearchUi.kt, PersonUi.kt, VM.kt, MainActivity.kt degisti.

--- v2.56: GALERI KLASOR LISTESI: BASILI TUT, SEC, SIL ---
- Galeri klasor listesinde bir klasore basili tutunca klasor secilir. Bir klasor seciliyken dokunmak secimi degistirir (secim yokken dokunmak klasoru acar).
- Secim varken "Sil" dugmesi: secili klasorlerin icindeki TUM fotograf ve videolar (filtreden bagimsiz) ve tek tek secilen ogeler onay penceresinden sonra telefondan silinir. Android 11+'da tek sistem onay penceresi cikar. Silinenler kayitli sonuclardan ve listelerden de temizlenir.
- Klasor adi degistirme: tam olarak 1 klasor seciliyken "Adi degistir" dugmesi (onceden basili tutmaydi).
- Gallery.kt, VM.kt degisti.

--- v2.55: KAYITLI SONUC BASLIGI DUZELTMESI ---
- Kayitli sonuclarda albumlerden yapilan taramada baslik artik yalnizca "N album: Klasor1, Klasor2, ..." seklinde (sayi + klasor adlari). Onceden sayi iki kez yaziyordu ("3 album: 3 album • ...") ve cinsiyet filtresi eki de basliga giriyordu; tek albumde klasor adi yerine albüm numarasi gorunuyordu. Eski kayitlar da dogru gorunur.
- Not: "Yuze gore grupla" galeride bir klasor acikken (Foto, Kadin, Erkek, Nesne, Hepsi) ve Turban filtresinde zaten vardir (v2.54).
- MainActivity.kt degisti.

--- v2.54: GALERI: KLASOR SONUCLARINI YUZE GORE GRUPLA, KAYITLI SONUC BASLIGI ---
- Galeri > bir klasor acikken (Foto, Kadin, Erkek, Nesne, Hepsi filtreleri): ekrandaki fotograflar icin "Yuze gore grupla" dugmesi. Ilerleme cubugu ve "Iptal" var; sonuc kisi kisi gruplanir, gruba dokununca o kisinin fotograflari acilir. "Grubu kapat" duz izgaraya doner; geri tusu once grubu, sonra gruplamayi, sonra klasoru kapatir.
- Kayitli sonuclar: birden cok album secilmisse baslik "N album: Album1, Album2, ..." olur (yalnizca album sayisi ve adlari). Tek albumde eski "Album Ismi: XXX" kalir.
- Gallery.kt, TurbanScan.kt, MainActivity.kt degisti.

--- v2.53: TURBAN TARAMASINI DURDUR / SURDUR ---
- Galeri > Turban: tarama surerken sag ustteki yuzdeli kutuda kirmizi "Durdur" dugmesi. Dokununca tarama hemen iptal olur; o ana kadar bulunanlar ve taranan fotograflar saklanir, listede kalir.
- Durdurulunca "Tarama durduruldu" yazisi ve "Taramayi surdur" dugmesi cikar; kaldigi yerden devam eder (taranmislar atlanir). Durdurulmus taramada Turban filtresine tekrar girince tarama kendiliginden baslamaz.
- Durdurulmus taramada bulunanlar icin "Yuze gore grupla" da kullanilabilir. Gruplama sirasinda kutuda "Iptal" dugmesi var.
- TurbanScan.kt degisti.

--- v2.52: GALERI: COKLU SECIM, CIFT DOKUNUSLA TAM EKRAN, KALDIGI YERDEN DEVAM ---
- Klasor / album listesi: her klasorun kapaginda sag ustte secim yuvarlagi; dokununca klasor secilir (birden fazla). Klasorun kendisine dokunmak yine klasoru acar. Ustte "Tumunu sec" / "Temizle".
- Klasorun icinde: tek dokunus fotografi / videoyu secer ya da secimini kaldirir (sag ustte yuvarlak isaret, secili olan cercevelenir). Hizli cift dokunus tam ekran acar. Ustte "Tumunu sec" / "Temizle".
- Tam ekranda sag ustteki yuvarlakla o fotograf da secilebilir.
- Secimler geri donunce, klasor degisince, tam ekrandan cikinca korunur; klasor listesi ve her klasorun izgarasi kaldigi kaydirma yerinden devam eder. Secim yalnizca "Temizle" ile ya da uygulama kapaninca silinir.
- Gallery.kt degisti.
- Not: Secilenlerle yapilacak islem (tasi, paylas, sil vb.) henuz yok; sadece secim.

--- v2.51: TURBAN FILTRESI: TUM KLASORLER, ILERLEME CUBUGU, YUZE GORE GRUPLA ---
- Galeri > Turban: klasor listesi yerine telefondaki TUM klasorler / albumler taranir; yalnizca turbanli / esarpli / bandanali KADIN fotograflari tek izgarada gosterilir (bulunanlar tarama surerken canli eklenir).
- Tarama surerken sag ustte asama + yuzde (ornek "Taraniyor %37", 1250 / 3400) ve ici yesil dolan cubuk gorunur. Taranan fotograflar telefonda saklanir; ikinci acilista yalnizca yeniler taranir. Tarama yarida kalirsa kaldigi yerden surer.
- Tarama bitince "Yuze gore grupla" dugmesi cikar: bulunan yuzler ArcFace ile ayristirilir, ayni kisiye ait fotograflar gruplanir (sag ustte "Gruplaniyor %..." cubugu). Gruba dokununca o kisinin fotograflari acilir; geri tusu grup listesine, sonra duz listeye doner.
- Karar yuz bazindadir: ayni yuzde ortu etiketi (headscarf, hijab, veil, turban, scarf, kerchief, bandana) var ve sakal / biyik isareti yok. Eski kayitlardaki turbanli fotograflar bir kez yeniden taranir.
- Yeni dosya: TurbanScan.kt. Gallery.kt, GalleryAttrs.kt degisti.
- Sinir: ML Kit etiketlerine dayanir, kesin degildir; kadin kaniti zayif olan (cinsiyeti belirsiz) ortulu yuzler de listeye girebilir. Gruplama icin ArcFace modeli inmis olmali.

--- v2.50: GALERI FILTRESI ---
- Galeri sayfasinin sag ustunde filtre dugmesi: Foto, Video, Kadin, Erkek, Nesne, Turban, Hepsi (varsayilan Hepsi = foto + video).
- Foto / Video / Hepsi: klasor listesi ve icindekiler buna gore degisir; videolarda kucuk resim uzerinde oynat isareti, dokununca tam ekranda buyuk oynat dugmesi telefonun video oynaticisini acar. Video izni (READ_MEDIA_VIDEO) eklendi.
- Kadin / Erkek / Turban: klasoru acinca fotograflar cihazda (internetsiz) yuz bulma + etiketleme ile taranir, uyanlar ilerledikce gorunur; sonuc galleryattrs.json'da saklanir (ikinci acilis aninda).
- Nesne: filtre secilince nesne ismi sorulur (araba, kedi, belge ...); Nesne ara ile ayni sozluk ve etiketler (photolabels.json) kullanilir.
- Yeni dosya: GalleryAttrs.kt. Gallery.kt, MainActivity.kt, AndroidManifest.xml, app/build.gradle.kts degisti.
- Sinir: Kadin / Erkek / Turban tahmini ML Kit etiketlerine dayanir (Analiz'deki cinsiyet tahminiyle ayni yontem); kesin degildir.

--- v2.49: GALERI: KLASOR ACILMAMA HATASI, KLASOR ADI DEGISTIRME ---
- Hata: Galeri'de klasore dokununca "Fotograflar okunuyor..." yazisinda kaliyordu. Fotograflari yukleyen islem klasor listesi ekrandan kalkinca iptal oluyordu; artik GalleryScreen icinde (ekran acik kaldigi surece) yuklenir.
- Yeni: Galeri'de klasore basili tutunca "Klasor adini degistir" penceresi acilir. Klasordeki tum fotograflar ayni ust dizinde yeni adli klasore tasinir (Android 11+'da sistem izin penceresi bir kez cikar).
- Galeri klasor listesi her sirada 4 klasor gosterir (kucuk onizleme, ad ve fotograf sayisi; yol bilgisi listeden kalkti, adi degistirme penceresinde duruyor).
- Sinir: Android yalnizca DCIM/ ve Pictures/ altindaki klasorlere izin verir (WhatsApp, Download vb. yeniden adlandirilamaz). Ayni adli klasor varsa uyarir. Yalnizca fotograflar tasinir; ayni klasordeki videolar eski yerinde kalir.

--- v2.48: PLAY STORE IZIN DUZENLEMESI ---
- MANAGE_MEDIA ve REQUEST_IGNORE_BATTERY_OPTIMIZATIONS izinleri kaldirildi.
- Tasima her zaman sistem izin penceresiyle (createWriteRequest) yapilir; Tasima izni karti ve yonlendirme penceresi silindi.
- Pil dugmeleri artik pil optimizasyonu ayar listesini acar (izin gerektirmez); analiz baslayinca otomatik pil istegi kaldirildi.

--- v2.26: GALERI SAYFASI (2. SAYFA) ---
- Alt cubukta iki sayfa: FotoLiz (ana sayfa) ve Galeri.
- Galeri: telefondaki TUM klasorler / albumler (Kamera, Ekran Goruntuleri, WhatsApp, Download ... ne varsa) kapak resmi, ad, fotograf sayisi ve konumuyla listelenir; en cok fotografi olan en ustte.
- Klasore dokununca fotograflari acilir; fotografa dokununca tam ekran, saga-sola kaydirmali gorunur. Geri tusu: goruntuleyici > klasor > klasor listesi > ana sayfa.
- Sayfaya her girilişte liste tazelenir. Foto izni yoksa "Izin ver" dugmesi cikar.
- Yeni dosya: Gallery.kt (Screen.Gallery, VM.back ve MainActivity'ye baglandi).

--- v2.24: ALBUM FILTRESI, BILDIRIM ISIGI, KAYITLI YUZLER TAM EKRAN ---
- Albumleri sec: Benzerlik esigi yazisi kaldirildi. Analiz filtresi tek sirada (Erkek / Kadin / Erkek & Kadin / Nesne ismi); her acilista secim BOS gelir, secili olana tekrar dokununca kalkar; filtre secilmeden Analiz baslat acilmaz.
- Analiz suruyor kartinin yanip sonme araligi 6 sn.
- Analiz uygulama on planda degilken biterse sonuc otomatik acilmaz; ana ekranda yesil "Analiz bitti" karti 3 sn'de bir yanip soner, dokununca sonuc acilir (sonuca girilince uyari kalkar).
- Kaydedilen yuzler dugmesi: tam ekran, her sirada 5 yuz. Dokununca ad ekle/degistir, basili tutup surukleyince sira degisir.

--- v2.23: YUZLERE KAYDET, KLAS SONUC BASLIGI, DUZENLEME KOPYASI ---
- Tek fotograf ekrani: yuze dokununca acilan "Yuz ayrintisi" penceresine "Yuzlere kaydet" dugmesi eklendi. Yuzun basi (sac dahil) orijinal cozunurlukten kirpilip netlestirilir ve Kaydedilen yuzler'e eklenir (ayni kisi zaten varsa uyarir).
- Kayitli sonuclar: her kartin basligi kalin puntolu, iki renkte: "Taranan Album Sayisi: N" (mavi) + yaninda "Album Ismi: XXX" (turuncu).
- Duzenle (kalem): telefonun duzenleyicisine yalnizca OKUMA izni verilir (orijinalin ustune yazamaz). Duzenleyiciden donunce o sirada olusan yeni kopya otomatik olarak yalnizca Duzenlenenler'e eklenir; orijinal fotograf yerinde ve kisinin fotograflari arasinda kalir.

--- v2.21: BULUNAN YUZLER ---
- Tasima: "Bulunan yuzler"den acilan bir kisinin fotograflari albume tasinirsa o fotograflar kisiden dusulur; hic fotografi kalmayan kisi (ve onizlemesi) panodan kalkar.
- Bulunan yuzler her yeni analizde temizlenir ve yalnizca son analizin kisileri gorunur. Kayitli sonuc acilinca (Kullan) o sonucun kisileri panoya eklenir. Guncellemeden sonraki ilk acilista mevcut kayitlarin hepsi gorunur; ilk yeni analizde temizlenir.
- Sac rengi: KATI kurallar. Analiz sirasinda yuzun hemen ustundeki gercek sac bolgesi ORIJINAL fotografta olculur (hairstore.json). Yeterli kanit yoksa "belirsiz" olur (eskiden her belirsiz durum "esmer" sayiliyordu). Yeni filtre: "Kadin - Sac belirsiz". Eski yuzlerde sac rengi yeniden hesaplanir (kucuk resimden, daha kati kararla); en dogru sonuc icin analizi yeniden calistir.
- Filtre: "Nesne ismine gore suz" kutusu. Yazilan nesne (araba, kedi...) kisinin en fazla 40 fotografinda gorunuyorsa kisi listede kalir; cinsiyet / sac filtresiyle birlikte calisir. Etiketler telefonda saklanir (photolabels.json), ikinci arama anindadir.
- Yeniden analizde ayni adli eski kucuk resimlerin cinsiyet / sac tahminleri silinir (eski kisinin tahmini yeni yuze yapismasin).

--- v2.20: ALBUM ANALIZ FILTRESI ---
- Albumleri sec ekraninda "Analiz filtresi": Erkek / Kadin / Erkek & Kadin / Nesne ismi.
- Erkek ya da Kadin: yalnizca o cinsiyetteki yuzler gruplanir (cinsiyet cihazda tahmin edilir; belirsiz yuzler alinmaz). Filtreye uymayan yuz icin parmak izi hesaplanmaz. Sonuc ayri kaydedilir (ayni albumlerin tum yuz analiziyle karismaz) ve yarim kalirsa ayni filtreyle devam eder.
- Erkek & Kadin: eski davranis (tum yuzler + yuzsuz fotograflar nesne adina gore).
- Nesne ismi: yazilan nesne secili albumlerde aranir (Nesne ara ile ayni motor); sonuc ekranindan secilip albume kaydedilir.

--- v2.19: HIZ / KARARLILIK ---
- Analiz bilgi kartinin yanip sonme araligi 9 sn.
- Yuz modeli (ONNX) is parcacigi sayisi, ayni anda calisan 3 fotograf icin CPU cekirdeklerine gore ayarlandi (asiri is parcacigi yavaslatiyordu).
- Kayitli sonuclar daha hizli okunur (yuz vektoru kompakt yazilir; eski kayitlar aynen okunur) ve acilista bir kez okunur.
- Sonuc dosyasi once gecici dosyaya yazilip yer degistirilir: yazarken uygulama kapansa kayit bozulmaz.
- Bildirim ilerlemesi 1,5 sn'de bir guncellenir.

--- v2.16: KILIT OTURUMU ---
- Bir kez dogrulaninca (sifre / desen / parmak izi), Ayarlar > Kilit isteme suresi dolana kadar programin HICBIR yerinde (Ayarlar, kayit silme, Drive, geri yukleme, kilit degistirme) tekrar sorulmaz. Sure dolunca bir sonraki korumali islemde yeniden sorulur; uygulamadan sureden uzun cikip donulurse acilista kilitlenir. Sure "Hemen" ise uygulamadan cikilana kadar gecerlidir.

--- v2.15: UNLULER BOLUMU, SAAT SIMGESI ---
- Ana ekran: "Unluler (N)" dugmesi. Bulunan yuzlerde bir kisiye basili tutup "Unlulere tasi" denince kisi Bulunan yuzler panosundan cikar, Unluler'e gecer.
- Unluler ekrani: tasinan kisiler; dokununca kaydedilen (ve sonradan analizlerde eslesen) tum fotograflari acilir; basili tutunca ad degistirme / Unlulerden cikarma.
- Unluler Drive yedegine ve elle yedege dahildir (celebs.json + celebs/).
- Kilit isteme suresi: saat simgesi + buyuk punto sure.

--- v2.14: SAC RENGI, YUZ FILTRESI ILERLEME CUBUGU, YUZE DOKUNUNCA TUM FOTOGRAFLAR ---
- Bulunan yuzler: filtre icin yuzler analiz edilirken ekranin altinda temaya uygun ilerleme cubugu (x / y ve yuzde).
- Sac rengi algoritmasi yeniden yazildi (ortanca parlaklik + oran; kahve / koyu tonlar hep ESMER, sarisin icin guclu kanit aranir). Eski otomatik tahminler silinip yeni algoritmayla yeniden hesaplanir; elle duzeltmeler korunur.
- Bulunan yuzlerde bir yuze dokununca o kisinin tum analizlerdeki TUM fotograflari izgara olarak acilir.
- Ayarlar > Drive: son yedegin tarih, saat, boyut ve icerik bilgisi buyuk puntolu, renkli kutuda.

--- v2.13: MODEL KALICI, DRIVE'DA ESKI YEDEGI BULMA ---
- Model: indirilen / secilen model Download/FotoLiz/FotoLiz_arcface_model.onnx olarak telefonda kalir (kopya var mi dosyaya bakilir). Yeniden kurulumda once oradan alinir; bulunamazsa 174 MB'yi sessizce indirmek yerine "Dosyayi sec / Indir" sorulur.
- Drive: hesap baglanip klasor secilince klasordeki en son yedek aranir; bulunursa tarih, dosya adi ve boyutuyla gosterilip "Yuklensin mi? Evet / Hayir" sorulur (Evet'te kilit varsa dogrulanir).
- Bu soru cevaplanmadan otomatik yedek BASLAMAZ: yeni kurulumdaki bos veri Drive'daki eski yedegin ustune yazilmaz. Hayir dersen sonraki yedek eskinin ustune yazar.
- Yedek tek dosyadir (FOTOLIZYEDEK.zip), her 10 dk ayni dosyanin uzerine yazilir.

--- v2.12: ANALIZ KARTI, DRIVE LAMBASI, GERI YUKLEME ONAYI ---
- Ana ekran: analiz surerken ustteki bilgi karti 4 sn'de bir temanin karsit rengine bir kez yanip soner; kartin altinda temaya uygun ilerleme cubugu ve yuzde gosterilir.
- Ayarlar > Drive: baslikta durum lambasi (yesil = duzgun calisiyor, kirmizi = hata, sari = bekliyor, gri = kurulmadi). Dugmeler renkli ve belirgin.
- Drive yedegi tek dosyadir (FOTOLIZYEDEK.zip): her 10 dk'da ayni dosyanin uzerine yazilir, yeni dosya olusturulmaz.
- "Drive'dan geri yukle": once "geri yuklenecek, devam edilsin mi? Evet / Hayir" sorulur, sonra secili kilit (sifre / desen / parmak izi) dogrulanir; ancak ondan sonra yuklenir.
- Uygulama kilidi: sifre / desen / parmak izi pencerelerinde simgeler; "Kilit isteme suresi" icin minik OK dugmesi - basilmadan sure uygulanmaz.

--- v99: UYGULAMA KILIDI: UC SECENEKTEN BIRI ---
- Ayarlar > Uygulama kilidi: "Sifre / Desen / Parmak izi" secenekleri. Hangisi secili ise YALNIZCA o istenir (program acilisi, Ayarlar, kayit silme, Drive ayarlari).
- Parmak izi secilince sifre / desen ozeti silinir. Android 11+ telefonlarda parmak izi okunmazsa telefonun kendi ekran kilidi yedek olarak kullanilabilir.
- Yontemi degistirmek icin once mevcut koruma dogrulanir. Eski "Parmak izi ile de ac" anahtari kaldirildi (yerini bu secim aldi).

--- v98: DRIVE: HESAP SECME, TUM KLASORLER ---
- "Google hesabini sec ve bagla": telefondaki Google hesaplari listelenir, istedigin hesabi secersin; sonra Drive izin ekrani gelir.
- Klasor secme penceresi Drive'daki TUM klasorleri listeler (ana dizin + "Benimle paylasilanlar"); icine girip secebilirsin. Yeni izin gerekiyorsa (eski surumden gelenler) izin ekrani kendiliginden acilir.
- Not: Google Cloud'da kapsam .../auth/drive olmali (v95 notuna bak).

--- v97: ILETISIM ---
- Facebook: https://www.facebook.com/duyguyagizoglu (Facebook uygulamasi varsa uygulamada, yoksa tarayicida acilir).
- WhatsApp: 905531659893 icin mesaj yazma ekrani acilir (WhatsApp / WhatsApp Business kuruluysa uygulamada).
- Iletisim: e-posta (fotoliz@gmail.com), telefon (+90 553 165 98 93) ve adres (Tire, Izmir 35900) satirlari simgeli; dokununca mail / arama / harita acilir.

--- v96: YAPIMCIYA ULAS ---
- "Sikayet ve onerileriniz: e-posta gonder" dugmesi e-posta ekranini dyagizoglu@gmail.com adresi ve konu satiri dolu olarak acar.
- Instagram satiri: telefonda Instagram uygulamasi varsa https://www.instagram.com/yagizyagizogluu/ profili dogrudan uygulamada acilir; yoksa tarayicida acilir.
- Adresler Contact.kt dosyasindaki Dev nesnesindedir.

--- v95: DRIVE AYARLARI KILITLI, ISTEDIGIN KLASOR, BAGLANTIYI KALDIR ---
- Drive hesabi baglaninca hesap ve klasor KILITLENIR. Klasoru degistirmek, otomatik yedegi / Wi-Fi secenegini degistirmek ve baglantiyi kaldirmak icin
  parmak izi / desen / sifre istenir (kilit hic tanimli degilse once tanimlatilir).
- "Drive baglantisini kaldir" tum ayarlari sifirlar (hesap, klasor, son yedek bilgisi). Sonra yeniden baglayip klasoru bastan secersin.
- Klasor artik Drive'dan SECILIR: baglaninca klasor secme penceresi acilir; klasorlere girip cikabilir, "Yeni klasor olustur" ile yenisini acabilirsin.
  Yedek dosyasi (TARIH_SAAT_FOTOLIZYEDEK.zip) secilen klasore konur; klasorde baska dosyalara dokunulmaz.
- ONEMLI - GOOGLE CLOUD'DA IZIN (KAPSAM) DEGISTI: drive.file yerine https://www.googleapis.com/auth/drive gerekir (klasor listesini okumak icin).
  Google Cloud > OAuth izin ekrani (Veri erisimi / Scopes) > kapsam ekle: .../auth/drive. Uygulama "Test" durumundaysa ve e-postan Test kullanicilarindaysa dogrulama gerekmez.
  Eski surumde bagliysan: Drive baglantisini kaldir, yeniden bagla, yeni izni onayla, klasoru sec.

--- v94 ---
- Sistem sagligi > Depolama: "Yeterli bos yer var: 23.45 GB bos." seklinde bos yer KB/MB/GB/TB olarak gosterilir (az olunca uyari metinlerinde de).

--- v93: DUZENLENENLER ---
- Netlestir / Kirp ile olusan kopya artik Duzenlenenler'e TASINIR: orijinal fotograf yuzun fotograflari listesinden cikar (telefondaki dosyaya dokunulmaz, galeride durur).
- Duzenlenenlere ulasim: (1) Kisiler ekraninin ustunde yesil "Duzenlenenler (N fotograf)" dugmesi (tum kisilerin duzenlenenleri tek izgarada),
  (2) bir kisinin foto izgarasinda ust satirda yesil "Duzenlenenler (n)" dugmesi; icindeyken "Asillar" dugmesi geri dondurur. Eski alt bolum de duruyor.

--- v92 ---
- Analiz ekraninda sagdaki yuzde artik "Taranan %70" seklinde (ayni yesil kalin yazi).
- Analiz sirasinda bir yuze dokununca acilan tam ekran onizlemede, sag ustteki bilginin altinda yesil, dolan ilerleme cubugu.

--- v91: ANALIZ EKRANI: TEK SATIR DURUM, GERCEK KISI SAYISI ---
- Analiz durum satiri tek satirda: "Analiz Edilen Sayi:869 / Toplam Bakilacak Sayi:1257 • Bulunan Yuz:200 • 06:09 dk" (kalan sure dk:sn).
- "Bulunan Yuz" ve "Bulunan yuzler (n)" artik GERCEK kisi sayisidir: ayni kisi birden cok fotografta cikarsa tekrar sayilmaz.
  Alttaki yuvarlak onizlemelerde de bir kisi yalnizca bir kez gorunur (ilk karesi). Yuze dokununca o kisinin fotograflari yine acilir.
- Canli sayim, yuz benzerligi 0.40 ustu olani ayni kisi sayar (Engine.kt LIVE_THR); bitince asil gruplama sonucu ayri hesaplanir ve ozette gosterilir.

--- v90: ARAMA DURDUR/DEVAM ET, ANA EKRAN ILERLEME CUBUGU, ZOOM, MODEL KALICI KOPYA ---
- Nesne arama ekraninda KIRMIZI "Durdur" ve yaninda YESIL "Devam et": Durdur aramayi duraklatir, Devam et kaldigi fotografdan surdurur (bulunanlar korunur).
- Arama surerken (ya da duraklatilmisken) ANA EKRANDA, "Arama suruyor" satirinin altinda yesil, ici dolan ilerleme cubugu + yuzde, taranan/toplam ve bulunan sayisi gorunur.
- Foto izgarasindan (Sec / incele) bir fotografa dokunup acinca IKI PARMAKLA yakinlastir/uzaklastir (6x'e kadar); yakinlasinca tek parmakla kaydir; cift dokunus 2.5x yakinlastirir/geri alir. Yakinlasmamisken kaydirma onceki/sonraki fotografa gecer. Analiz sirasindaki onizleme penceresinde de calisir.
- Yuz modeli (~174 MB) indirilince Download/FotoLiz/FotoLiz_arcface_model.onnx olarak telefona da kopyalanir (ilk acilista, onceden inmis model de kopyalanir). Uygulama KALDIRIP yeniden kurulursa model once bu kopyadan geri yuklenir; internetten tekrar indirilmez.
  Not: Android bazi surumlerde yeniden kurulan uygulamanin eski dosyasini otomatik okumasina izin vermeyebilir. O durumda ana ekranda "Daha once kaydedilen modeli dosyadan sec" dugmesi cikar; Download/FotoLiz icindeki dosyayi secmeniz yeter.
  ONEMLI: kopyanin olusmasi icin once bu surumu ESKISININ USTUNE kurun (kaldirmayin), uygulamayi bir kez acin; sonra kaldir-kur yapabilirsiniz.

--- v89: GOOGLE DRIVE YEDEGI, KILIT (SIFRE / DESEN / PARMAK IZI), YARIM KALAN ANALIZ, KAYDEDILEN YUZLER ---
- Ana ekran: "Albumlerden sec" dugmesi artik nesne aramanin hemen altinda.
- GOOGLE DRIVE YEDEGI (Ayarlar > Google Drive yedegi):
  * "Google Drive hesabini bagla" ile hesap baglanir; klasor adi yazilir (yoksa Drive ana dizininde olusturulur).
  * Yedek dosyasi: TARIH_SAAT_FOTOLIZYEDEK.zip (ornek 2026-10-28_14-30-05_FOTOLIZYEDEK.zip). Klasorde yedek varsa UZERINE YAZILIR (icerik degisir, ad guncel saate cevrilir).
  * Icerik: program ayarlari, analiz kayitlari, bulunan yuzlerin kucuk resimleri, kaydedilen yuzler. Fotograflar ve sifre/desen yedege girmez.
  * Otomatik yedek: her 10 dakikada bir, uygulama KAPALIYKEN de (WorkManager). Veri degismemisse yukleme atlanir. Uygulamadan cikarken de hemen bir tur calisir. "Yalnizca Wi-Fi" secenegi var.
  * "Simdi yedekle", "Drive'dan geri yukle" dugmeleri; en altta EN SON ALINAN YEDEGIN bilgisi (tarih, dosya adi, boyut, kayit sayisi, son kontrol, varsa hata).
  * Sistem sagligi panosunda "Drive yedegi" maddesi cikar (yesil/sari/kirmizi).
  * Kapsam "drive.file": uygulama yalnizca kendi olusturdugu klasor ve dosyalari gorur (Drive'daki diger dosyalariniza erisemez).
  * ONEMLI - BIR KEZLIK GOOGLE CLOUD KURULUMU (yoksa "OAuth istemcisi tanimli degil" hatasi alinir):
    1) https://console.cloud.google.com adresinde yeni proje olusturun.
    2) API'ler ve Hizmetler > Kitaplik > "Google Drive API" > Etkinlestir.
    3) OAuth izin ekrani: Kullanici turu "Harici"; uygulama adi FotoLiz; kapsam olarak .../auth/drive.file ekleyin.
       "Test" durumundaysa kendi Gmail adresinizi "Test kullanicilari"na ekleyin. (Test durumunda izin 7 gunde bir yenilenmek zorunda kalir;
       drive.file hassas olmayan bir kapsamdir, "Uygulamayi yayinla" derseniz genelde dogrulama gerekmeden kalici calisir.)
    4) Kimlik bilgileri > Kimlik bilgisi olustur > OAuth istemci kimligi > Uygulama turu "Android".
       Paket adi: com.fotoliz.app
       SHA-1: F2:7D:FD:98:62:64:0D:35:BC:84:5A:49:92:62:2B:17:03:59:D5:BC   (app/debug.keystore'un parmak izi; keystore degismedikce sabittir)
    5) Koda hicbir sey yazmaniz gerekmez; APK'yi kurup Ayarlar'dan hesabi baglayin.
- KILIT (Ayarlar > Uygulama kilidi): sifre ya da desen tanimlayin, istenirse parmak izi de acin. Kilit tanimliysa:
  * program acilirken, 1 dakikadan uzun sure arka planda kalip donunce,
  * Ayarlar acilirken (icindeki tum degisiklikler korunur),
  * kayitli sonuclar / kaydedilen yuz silinirken dogrulama istenir. Parmak izi okutulmazsa sifre/desen sorulur.
  * Onceden silme korumasi icin sifre/desen tanimlamis olanlarda da artik acilis kilidi devreye girer ("Program acilirken sor" anahtariyla kapatilabilir).
- YARIM KALAN ANALIZ: analiz her fotograftan sonra ilerlemesini diske yazar. Durdur'a basilsa, uygulama kapansa ya da sistem oldurse bile
  ana ekrandaki "Kayitli sonuclar" listesinde "Yarim kaldi (x / y fotograf)" olarak gorunur. Dokununca ya da ayni albumleri tekrar secince
  "Daha once yariya kesildi, tamamlanmadi. Devam edilsin mi?" sorulur: Devam et / Bastan basla / Yarim kaydi sil.
  (Sadece albumlerden/klasorden yapilan analiz icin; nesne ve kisi aramalari kaydedilmez.)
- KAYDEDILEN YUZLER (ana ekranin en altinda): "Fotograftan ekle" ya da "Bulunanlardan ekle" ile istedigin yuzu kaydet (Bulunan yuzler panosunda da "Kaydedilen yuzlere ekle" var).
  Yuze BASILI TUTUP surukleyerek sirasini degistir; dokununca ad gir (ad yuzun altinda gorunur), "Bu kisiyi albumlerde ara" ya da "Listeden kaldir".

--- v88: YEDEKLE / GERI YUKLE, SISTEM SAGLIGI ---
- Kayitlar guncellemede silinmez (paket adi + imza sabit). Uygulamayi KALDIRIP yeniden kurarsan Android program klasorunu siler; bunun icin yedek eklendi.
- Ayarlar > Veriler: "Kayitlari yedekle" (zip dosyasina, istedigin yere) ve "Yedekten geri yukle" (mevcut kayitlar silinmez, yedektekiler eklenir).
- Otomatik yedek: uygulamadan cikarken kayit degistiyse Download/FotoLiz/FotoLiz_yedek.zip guncellenir. Yeniden kurulumda bu dosyayi "Yedekten geri yukle" ile secin.
- Yeni kurulumda kayit yokken bir kez sorulur: yedekten geri yukle / yok, devam et.
- Ayarlar'in en ustundeki trafik lambasi kaldirildi; en ustte "Sistem sagligi" bilgilendirmesi var (her servisin durumu ve duzeltme dugmeleri).

--- v87: KAYDET / KAYITLIYI AC ---
- Sonuc ekraninin ustunde "Kaydet" dugmesi: benzerlik esigiyle birlesen gruplar, adlar ve silinen/tasinan fotograflarla birlikte mevcut hâli kalici kaydeder.
- Geri ile ana ekrana donerken (esik birlestirmesi uygulanmamissa) sonuc otomatik kaydedilir.
- Ana ekranda "Kayitli sonuclar"dan bir kayda dokununca acilan pencere artik kisi sayisi, fotograf sayisi, tarih ve yuz onizlemeleri gosterir; "Kayitliyi ac" ana dugmedir, yeniden analiz gerekmez.

--- v86: YUZ KUCUK RESIMLERI DUZELDI ---
- Bulunan yuzlerdeki yamuk/siyah koseli kucuk resimler duzeltildi: yuz, goz cizgisine gore dogru yonde dondurulup dik kirpilir (Analyzer.kt uprightCrop).
- Eski analizlerin kucuk resimleri eski hâliyle kalir; duzgun gorunmesi icin albumu yeniden analiz edin.

--- v85: TEMALAR ---
- Ustte (gunes/ay simgesinin yaninda) yeni tema simgesi (palet). Basinca onizleme penceresi acilir: Acik, Koyu, Spor, Eglenceli, Is ve Otomatik temalarin kucuk uygulama onizlemeleri gorunur.
- Beginilen temaya dokunun, "Uygula"ya basin; secim hatirlanir. "Vazgec" hicbir sey degistirmez.
- Spor: koyu zemin, neon yesil + turuncu. Eglenceli: pembe + sari + mavi. Is: soguk gri zemin, lacivert vurgu.
- Renkler UiKit.kt icindeki appColorScheme fonksiyonundadir.

--- v84: FOTOLIZ (yeni ad ve ozellikler) ---
- Her yerde "YuzGrupla" adi FotoLiz oldu: klasor, paket adi (com.fotoliz.app), uygulama adi. APK dosyasi artik FotoLiz.apk.
- DIKKAT: paket adi degistigi icin telefon bunu YENI bir uygulama olarak kurar; eski surumun kayitli sonuclari bu uygulamaya tasinmaz (eski uygulamayi isterseniz silebilirsiniz).
- Tek fotograf ekraninda (tam ekran) yuzlerin etrafinda cerceve cikar; yuze dokununca ayrinti penceresi acilir (kisi adi/kodu, fotograf sayisi, benzerlik, netlik) ve "Kapak resmi yap" ile o yuz kisinin kapak resmi olur.
- Kayitli sonuclar: uzerine basili tutunca secim modu acilir; ustte "Tumunu sec" ve yaninda cop kutusu cikar. Cop kutusuna basinca "Emin misiniz?" sorulur (Evet = kirmizi, Hayir = yesil), Evet denirse secili kayitlar silinir (fotograflara dokunulmaz).
- Ayarlar'in en ustunde trafik isigi: yukaridan asagi yesil, sari, kirmizi.
- Ayarlar > "Yapimciya ulas": sikayet/oneri e-postasi, Instagram, Facebook, WhatsApp, Iletisim. Adresler Contact.kt dosyasindaki Dev nesnesinde; bos birakilan alan icin dokununca "henuz eklenmedi" uyarisi cikar.

--- v80: KISIYE GORE ARAMA ---
- Ana ekranda nesne aramanin altinda "Kisiye gore ara": "Yuz sec (fotograftan)" ile bir fotograf secin, icindeki yuzlerden aranacak kisiye dokunun (ya da "Kayitli kisiler"den onceki analizlerde bulunan bir kisiyi secin).
- "Albüm seç ve kisiyi ara": secilen albumlerdeki o kisinin gorundugu tum fotograflar bulunur (arka planda surer, canli listelenir).
- Sonuc ekraninda benzerlik esigi kaydiricisi (0.25-0.70, varsayilan 0.40) ve albüm adi kutusu var. Adi duzenleyip "Kaydet" derseniz galeride o adla (Pictures/<ad>/) albüm olusturulur ve bulunan TUM fotograflar oraya tasinir (Android onay penceresi cikar).
- "Sec / incele" ile fotograflari tek tek secip yanlislari cikarabilir, sonra Tasi'yi kullanabilirsiniz.

--- v79: FOTOLIZ ---
- Programin adi Fotoliz oldu (paket adi ayni: eski surumun uzerine guncellenir).
- Ana ekranda nesne arama: kutuya nesne adini yazin (araba, kedi, deniz, evrak...), "Albüm seç ve ara" ile albumleri secin; o nesnenin gorundugu fotograflar bulunur. Virgulle birden cok nesne aranir (araba, kedi). Ingilizce de yazilabilir (car).
- Arama arka planda surer; sonuclar canli listelenir, sonuc fotograflarini toplu tasi/sil/netlestir yapabilirsiniz.

--- v74 ---
- Yuzlere alfabe kodu (A, B, C, Ç...) ve elle etiket (ornek TURBAN A). Foto ekraninda Etiket dugmesi.
- Netlestir: secili fotograflarin hepsine uygulanir (2x buyutme + dogal keskinlestirme), kopya olarak kaydedilir.
- Duzenlenenler (kirpilan/netlestirilen) ayri bolumde, adi sonuna (2) eklenir.

--- v73 ---
- Duzenle: sistemin varsayilan duzenleyicisi dogrudan acilir (yazma izni hatasi giderildi).
- Albume tasi penceresinde her albumun kapak fotografi solda.
- Yuzun icinde ust satirda Tumunu sec / Secimi kaldir.

--- v72 ---
- Arka plan guvencesi: analiz baslayinca pil kisitlamasi muafiyeti istenir (bir kez); analiz ekraninda da buton var.
- Xiaomi/MIUI icin: Ayarlar > Uygulamalar > FotoLiz > Otomatik baslat ACIK, Pil tasarrufu > Kisitlama yok; son uygulamalar ekraninda uygulamayi kilitleyin.

--- v71 ---
- Analiz ekraninda "Bulunan yuzler" sayisi artik durum satirindaki yuz sayisiyla ayni; bulunan her yuz icin yuvarlak onizleme eklenir.
- Ana ekranda surum numarasi gosterilir (yeni APK kuruldu mu diye kontrol icin).

--- v69 ---
- Analiz ekrani: ustte su an analiz edilen fotograf (sirayla akar), altta bulunan yuzler yuvarlak onizleme olarak canli eklenir.
- Derleme hatalari duzeltildi (Pager opt-in, asImageBitmap).

--- v68 ---
- Kisiye dokununca fotograf izgarasi: uzun basis veya sol ustteki daire ile coklu secim; secim modunda tek dokunus = sec/birak, hizli cift dokunus = tam ekran goster (secim korunur).
- Alt cubuk: Tumu / Tasi / Sil / Birak. Tasi: telefondaki albumler (DCIM ve Pictures altindakiler) veya yeni album olustur.
- Tam ekran gorunturu: kaydirarak gez; Duzenle (sistem duzenleyicisi), Kirp (uygulama ici, kopya olarak kaydeder), Tasi, Sil.
- Tasima/silme Android'in onay penceresini gosterir (izin gerektirir).

1) GitHub'da yeni depo olusturun.
2) Zip'i acin; ICINDEKI her seyi (.github klasoru dahil) depoya yukleyin.
3) Model dosyasi eklemenize gerek yok: uygulama ilk acilista yuz modelini (ArcFace, ~174 MB) kendisi indirir (internet gerekir, bir kez).
4) Actions sekmesi > "APK Olustur" > calisma bitince en altta Artifacts > FotoLiz-APK indirin (zip icinden FotoLiz.apk).

--- v67 ---
- Guncelleme uyumu: paket adi (com.fotoliz.app) ve imza (app/debug.keystore) sabit, versionCode her derlemede otomatik artar. Yeni APK eskisinin uzerine kurulur, veriler (kayitli sonuclar, indirilen model) korunur.
- Not: .github ve debug.keystore dosyalarini silmeyin/degistirmeyin; imza degisirse Android guncellemeyi reddeder.

--- v66 ---
- Benzerlik esigi artik album secim ekraninda (altta). Varsayilan 0.25; sonuc ekraninda yine degistirilebilir (0.15-0.70).
- Analiz sirasinda sadece guvenli birlestirme yapilir; asil birlestirme bu esikle yapilir.

--- v65 ---
- Model secme ve klasor secme adimlari kaldirildi. Ana ekranda sadece "Albumlerden sec" var; model ilk acilista otomatik iner.
- APK kucuk (model icinde degil), build.yml artik model indirmez.

--- v64 ---
- YUZ MODELI DEGISTI: Qualcomm MobileFaceNet yerine InsightFace ArcFace R50 (WebFace600K, 512 boyut) + onnxruntime. Gozluk/sakal/makyaj farkina cok daha dayanikli.
- Esikler yeni modele gore ayarlandi: MERGE_THR 0.40 (Clusterer.kt). Bolunuyorsa 0.35, karisiyorsa 0.45.
- Not: model buyuk oldugu icin analiz eskisinden yavas (yuz basina ~0.1-0.3 sn). Ilk calistirmada model telefona kopyalanir.
- Eski analiz sonuclari eski modelle uretildi; albumu yeniden analiz edin.

--- v63 degisiklikleri (daha hassas gruplama) ---
- YUZ HIZALAMA: goz/burun/agiz noktalariyla yuz, modelin egitildigi standart 112x112 poza getirilir (donuk/egik yuzlerde buyuk fark yaratir).
- Ayna (flip) ile cift olcum: her yuzun parmak izi duz + ayna goruntunun ortalamasi (FLIP_TTA, Analyzer.kt).
- Hassas yuz bulma + poz acilari (FAST_DETECT=false). Yandan/kucuk/dusuk kaliteli yuzler grup kurmaz, sonradan eklenir.
- Gruplama artik fotograflar bittikten sonra yapilir (siraya bagimli degil): once saf cekirdek gruplar, sonra derin birlesim.
- Her grup farkli gorunumlu (gozluklu, sakalli, makyajli...) ornekleri saklar; gruplar bu ornekler uzerinden kopru kurarak birlesir.
- Ayni fotografta birlikte gorunen iki yuz asla ayni kisi sayilmaz (farkli kisilerin karismasini engeller).
- Ayar: Clusterer.kt basindaki MERGE_THR (0.48). Ayni kisi hala bolunuyorsa 0.42, farkli kisiler karisiyorsa 0.54 yapin.

--- v62 degisiklikleri ---
- ASIL HATA duzeltildi: model girisi rewind() edilmiyordu, her yuzde hata verip sessizce atlaniyordu (0 yuz).
- Analiz on plan servisinde calisir: ekran kapansa / uygulamadan cikilsa da durmaz, bitince sonuc kaydedilir ve acilir.
- 3 kat paralel isleme, tek gecisli hizli decode, hizli yuz bulma (Analyzer.kt basindaki sabitlerle ayarlanir).
- Hata olursa artik gizlenmez; ilk 8 fotograf hatali ise hemen durup nedenini yazar.
- Sonuc ekraninda benzerlik kaydiricisi (otomatik birlestirme) ve uzun basip elle birlestirme eklendi. Esik 0.50.
