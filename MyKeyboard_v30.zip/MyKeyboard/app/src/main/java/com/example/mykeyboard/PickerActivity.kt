package com.example.mykeyboard

import android.app.Activity
import android.content.Intent
import android.os.Bundle

/** Klavyedeki ataç tuşu için saydam seçici: dosya, fotoğraf, çizim vb. seçtirir. */
class PickerActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (b != null) return   // döndürme vb. sonrası seçici zaten açık
        try {
            val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
                addCategory(Intent.CATEGORY_OPENABLE)
                type = "*/*"
            }
            startActivityForResult(i, 1)
        } catch (_: Exception) { finish() }
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val uri = data?.data
        if (resultCode == RESULT_OK && uri != null) {
            try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            val mime = contentResolver.getType(uri) ?: "application/octet-stream"
            ImeService.pending = Pair(uri, mime)
        }
        finish()
    }
}
