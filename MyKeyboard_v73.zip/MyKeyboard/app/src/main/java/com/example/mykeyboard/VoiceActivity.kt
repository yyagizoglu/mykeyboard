package com.example.mykeyboard

import android.Manifest
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

/**
 * Klavyedeki mikrofon tuşu: sesle yazma.
 * Kendi dinleyicimiz var: konuşma tanıyıcı kısa bir sessizlikte oturumu kapatsa bile dinlemeyi hemen yeniden başlatır ve
 * metni biriktirir; konuşman bittikten sonra 1 SANİYE daha bekler (nefes/düşünme araları), yeni ses gelirse devam eder.
 * Mikrofon izni yoksa ya da tanıma servisi yoksa eski Google konuşma penceresine döner.
 */
class VoiceActivity : Activity() {
    companion object {
        private const val GRACE_MS = 1000L        // konuşma bittikten sonra ek bekleme
        private const val FIRST_WORD_MS = 9000L   // hiç konuşulmadıysa en fazla bu kadar bekle
        private const val REQ_PERM = 7
        private const val REQ_GOOGLE = 2
    }

    private var focus: AudioFocusRequest? = null
    private val handler = Handler(Looper.getMainLooper())
    private var sr: SpeechRecognizer? = null
    private var recIntent: Intent? = null
    private val acc = StringBuilder()
    private var lastPartial = ""
    private var startedAt = 0L
    private var done = false
    private var finishArmed = false
    private var finishRequested = false
    private var busyRetries = 0
    private var statusTv: TextView? = null
    private var textTv: TextView? = null
    private var root: View? = null

    private val finishRunnable = Runnable { complete() }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (b != null) return
        grabAudioFocus()   // müzik/video/bildirim sesleri mikrofona karışmasın
        buildUi()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startCustom()
        else requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), REQ_PERM)
    }

    @Deprecated("Deprecated in Java")
    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode != REQ_PERM || done) return
        if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) startCustom() else fallbackGoogle()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun buildUi() {
        val dim = FrameLayout(this).apply { setBackgroundColor(0x66000000) }
        dim.setOnClickListener { onFinishTap() }
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(20), dp(18), dp(20), dp(16))
            background = GradientDrawable().apply { setColor(0xFF26282C.toInt()); cornerRadius = dp(22).toFloat() }
            isClickable = true
        }
        val mic = ImageView(this).apply { setImageResource(R.drawable.ic_mic) }
        ObjectAnimator.ofPropertyValuesHolder(mic,
            PropertyValuesHolder.ofFloat(View.SCALE_X, 1f, 1.25f),
            PropertyValuesHolder.ofFloat(View.SCALE_Y, 1f, 1.25f)).apply {
            duration = 650; repeatCount = ObjectAnimator.INFINITE; repeatMode = ObjectAnimator.REVERSE; start()
        }
        card.addView(mic, LinearLayout.LayoutParams(dp(44), dp(44)))
        statusTv = TextView(this).apply { text = "Hazırlanıyor…"; setTextColor(Color.WHITE); textSize = 17f; gravity = Gravity.CENTER }
        card.addView(statusTv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        textTv = TextView(this).apply { setTextColor(0xFFB4B8BF.toInt()); textSize = 14f; maxLines = 4; gravity = Gravity.CENTER }
        card.addView(textTv, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(6) })
        val btn = TextView(this).apply {
            text = "Bitir"; setTextColor(Color.WHITE); textSize = 16f; gravity = Gravity.CENTER
            background = GradientDrawable().apply { setColor(0xFF43A047.toInt()); cornerRadius = dp(18).toFloat() }
            setPadding(dp(30), dp(10), dp(30), dp(10))
            setOnClickListener { onFinishTap() }
        }
        card.addView(btn, LinearLayout.LayoutParams(-2, -2).apply { topMargin = dp(14) })
        dim.addView(card, FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM).apply { setMargins(dp(14), 0, dp(14), dp(24)) })
        setContentView(dim, ViewGroup.LayoutParams(-1, -1))
        root = dim
    }

    // ---------- Kendi dinleyicimiz ----------
    private fun startCustom() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { fallbackGoogle(); return }
        try {
            val r = SpeechRecognizer.createSpeechRecognizer(this)
            r.setRecognitionListener(listener)
            sr = r
            recIntent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3600L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000L)
            }
            startedAt = SystemClock.elapsedRealtime()
            r.startListening(recIntent)
        } catch (_: Exception) { fallbackGoogle() }
    }

    private fun restart(delay: Long = 0L) {
        if (done) return
        handler.postDelayed({
            if (done) return@postDelayed
            try { sr?.startListening(recIntent) } catch (_: Exception) { complete() }
        }, delay)
    }

    private fun armFinish() {
        if (finishArmed || acc.isBlank()) return
        finishArmed = true
        handler.postDelayed(finishRunnable, GRACE_MS)   // konuşma bitti: 1 sn nefes payı
    }

    private fun disarmFinish() {
        finishArmed = false
        handler.removeCallbacks(finishRunnable)
    }

    private fun bestOf(b: Bundle?): String? {
        val list = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
        val conf = b?.getFloatArray(SpeechRecognizer.CONFIDENCE_SCORES)
        var best = 0
        if (list != null && conf != null && conf.size == list.size) {
            for (k in conf.indices) if (conf[k] > conf[best]) best = k
        }
        return list?.getOrNull(best)
    }

    private val listener = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) { busyRetries = 0; statusTv?.text = "Dinliyorum…" }
        override fun onBeginningOfSpeech() { disarmFinish() }   // yeni ses geldi: bekleme iptal
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
        override fun onPartialResults(partialResults: Bundle?) {
            val p = bestOf(partialResults) ?: return
            if (p.isBlank()) return
            disarmFinish()
            lastPartial = p
            textTv?.text = (acc.toString() + " " + p).trim()
        }
        override fun onResults(results: Bundle?) {
            val t = bestOf(results)
            if (!t.isNullOrBlank()) {
                if (acc.isNotEmpty()) acc.append(' ')
                acc.append(t.trim())
                lastPartial = ""
                textTv?.text = acc.toString()
            }
            if (finishRequested) { complete(); return }
            armFinish()
            restart()   // nefes arasında kapanma: hemen yeniden dinle, 1 sn içinde ses gelmezse bitir
        }
        override fun onError(error: Int) {
            if (done) return
            if (finishRequested) { complete(); return }
            when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> fallbackGoogle()
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> {
                    if (busyRetries++ < 6) restart(250) else complete()
                }
                SpeechRecognizer.ERROR_NO_MATCH -> {
                    armFinish()
                    if (acc.isBlank() && SystemClock.elapsedRealtime() - startedAt > FIRST_WORD_MS) complete() else restart()
                }
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> {
                    if (acc.isNotBlank() || SystemClock.elapsedRealtime() - startedAt > FIRST_WORD_MS) complete() else restart()
                }
                else -> {   // ağ/sunucu/ses hatası
                    if (acc.isBlank()) Toast.makeText(this@VoiceActivity, "Ses tanıma çalışmadı, tekrar dene", Toast.LENGTH_SHORT).show()
                    complete()
                }
            }
        }
    }

    private fun onFinishTap() {
        if (done) return
        if (finishRequested) { complete(); return }
        finishRequested = true
        statusTv?.text = "Bitiriliyor…"
        disarmFinish()
        try { sr?.stopListening() } catch (_: Exception) {}
        handler.postDelayed({ complete() }, 1500)   // son sonuç gelmezse yine de bitir
    }

    private fun complete() {
        if (done) return
        done = true
        handler.removeCallbacksAndMessages(null)
        destroyRecognizer()
        val t = (if (acc.isBlank()) lastPartial else acc.toString()).trim()
        if (t.isNotEmpty()) {
            ImeService.pendingText = t
            ImeService.pendingAt = SystemClock.elapsedRealtime()
        }
        releaseAudioFocus()
        finish()
    }

    private fun destroyRecognizer() {
        try { sr?.cancel() } catch (_: Exception) {}
        try { sr?.destroy() } catch (_: Exception) {}
        sr = null
    }

    // ---------- Yedek yol: Google konuşma penceresi ----------
    private fun fallbackGoogle() {
        if (done) return
        handler.removeCallbacksAndMessages(null)
        destroyRecognizer()
        root?.visibility = View.GONE
        try {
            val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "tr-TR")
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 3600L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 3000L)
                putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_MINIMUM_LENGTH_MILLIS, 1000L)
            }
            startActivityForResult(i, REQ_GOOGLE)
        } catch (_: Exception) {
            releaseAudioFocus()
            Toast.makeText(this, "Sesle yazma (Google) bulunamadı", Toast.LENGTH_SHORT).show()
            done = true
            finish()
        }
    }

    private fun grabAudioFocus() {
        try {
            val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val req = AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_EXCLUSIVE)
                .setAudioAttributes(AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_VOICE_COMMUNICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
                .setOnAudioFocusChangeListener { }
                .build()
            am.requestAudioFocus(req)
            focus = req
        } catch (_: Exception) {}
    }

    private fun releaseAudioFocus() {
        try {
            val f = focus ?: return
            (getSystemService(Context.AUDIO_SERVICE) as AudioManager).abandonAudioFocusRequest(f)
            focus = null
        } catch (_: Exception) {}
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        destroyRecognizer()
        releaseAudioFocus()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val list = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
        val conf = data?.getFloatArrayExtra(RecognizerIntent.EXTRA_CONFIDENCE_SCORES)
        var best = 0
        if (list != null && conf != null && conf.size == list.size) {
            for (k in conf.indices) if (conf[k] > conf[best]) best = k
        }
        val text = list?.getOrNull(best)
        if (resultCode == RESULT_OK && !text.isNullOrBlank()) {
            ImeService.pendingText = text
            ImeService.pendingAt = SystemClock.elapsedRealtime()
        }
        done = true
        releaseAudioFocus()
        finish()
    }
}
