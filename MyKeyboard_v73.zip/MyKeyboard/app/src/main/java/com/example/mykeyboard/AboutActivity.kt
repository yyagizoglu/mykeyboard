package com.example.mykeyboard

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Hakkında: yapımcı bilgisi ve telif hakları metni. */
class AboutActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val d = resources.displayMetrics.density
        val ver = try { packageManager.getPackageInfo(packageName, 0).versionName } catch (_: Exception) { "" }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((22 * d).toInt(), (48 * d).toInt(), (22 * d).toInt(), (32 * d).toInt())
        }
        fun title(t: String) = col.addView(TextView(this).apply {
            text = t; textSize = 20f; setTypeface(typeface, Typeface.BOLD)
            setPadding(0, (18 * d).toInt(), 0, (6 * d).toInt())
        })
        fun body(t: String) = col.addView(TextView(this).apply { text = t; textSize = 15f; setLineSpacing(0f, 1.15f) })

        col.addView(TextView(this).apply {
            text = "KlavyemBenim"; textSize = 28f; setTypeface(typeface, Typeface.BOLD)
        })
        body("Sürüm $ver")

        title("Yapımcı hakkında")
        body("Yapımcı: Yağız Yağızoğlu\n\nBu uygulamanın baştan aşağıya tüm kodlaması ve programlaması Yağız Yağızoğlu'na aittir.")

        title("Telif hakları ve kanuni haklar")
        body(
            "© 2026 Yağız Yağızoğlu. Tüm hakları saklıdır.\n\n" +
            "KlavyemBenim; kaynak kodu, tasarımı, ekran düzeni, simgesi ve adıyla birlikte bir yazılım eseridir. " +
            "5846 sayılı Fikir ve Sanat Eserleri Kanunu'na göre bilgisayar programları da eser sayılır ve eser sahibi, eseri meydana getirdiği anda koruma kazanır; ayrıca bir tescil yaptırması gerekmez.\n\n" +
            "Eser sahibine kanun iki tür hak tanır. Manevi haklar: eserin kime ait olduğunun belirtilmesi, eserde izinsiz değişiklik yapılmasının engellenmesi ve eserin ilk kez ne zaman yayımlanacağına karar verme. " +
            "Mali haklar: eserin çoğaltılması, yayılması, işlenmesi, satılması ya da kiraya verilmesi gibi kullanımlar üzerinde tek yetkili olma.\n\n" +
            "Bu nedenle yapımcının önceden yazılı izni olmadan bu uygulamanın veya herhangi bir parçasının:\n" +
            "• çoğaltılması, kopyalanması,\n" +
            "• satılması, kiralanması, ücret karşılığı veya ücretsiz dağıtılması,\n" +
            "• değiştirilerek, adı ya da simgesi değiştirilerek yeniden yayımlanması,\n" +
            "• kaynak kodunun alınıp başka bir üründe kullanılması\n" +
            "yasaktır. İzinsiz kullanım hâlinde eser sahibinin kanundan doğan hukuki ve cezai yollara başvurma hakkı saklıdır.\n\n" +
            "Uygulama kişisel kullanım için sunulmuştur. Kullanım hakkı, eserin mülkiyetinin ya da telif haklarının devri anlamına gelmez."
        )

        title("Üçüncü taraf hizmetler")
        body("Sesle yazma, Google çeviri ve Google Drive yedekleme gibi özellikler ilgili şirketlerin hizmetlerinden yararlanır; bu hizmetlerin hakları sahiplerine aittir.")

        body("\nBu metin bilgilendirme amaçlıdır, hukuki danışmanlık yerine geçmez.")
        setContentView(ScrollView(this).apply {
            addView(col, ViewGroup.LayoutParams(-1, -2))
        })
    }
}
