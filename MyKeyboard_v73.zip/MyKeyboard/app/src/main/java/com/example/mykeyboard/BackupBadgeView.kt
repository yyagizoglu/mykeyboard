package com.example.mykeyboard

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import android.view.animation.LinearInterpolator
import androidx.core.graphics.PathParser
import kotlin.math.PI
import kotlin.math.sin

/**
 * Otomatik yedek simgesi: Google yedek bulutu + içinde yukarı çıkan ok (hareketli). Başarısızsa kırmızı bulut + "!" (titrer).
 * show() ile görünür, birkaç saniye sonra kendiliğinden kaybolur. Dokununca yedek bilgisi açılır (ImeService bağlar).
 */
class BackupBadgeView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val cloud = PathParser.createPathFromPathData(
        "M19.35,10.04C18.67,6.59 15.64,4 12,4 9.11,4 6.6,5.64 5.35,8.04 2.34,8.36 0,10.91 0,14c0,3.31 2.69,6 6,6h13c2.76,0 5,-2.24 5,-5 0,-2.64 -2.05,-4.78 -4.65,-4.96z"
    )
    private val cloudPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val glyph = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE
        strokeWidth = 2.1f; strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
    }
    private val dot = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFFFFFFF.toInt(); style = Paint.Style.FILL }
    private var phase = 0f
    private var ok = true
    private var anim: ValueAnimator? = null
    private val hideRunnable = Runnable { fadeOut() }

    fun show(success: Boolean, durationMs: Long = 6000L) {
        ok = success
        removeCallbacks(hideRunnable)
        animate().cancel()
        alpha = 1f
        visibility = VISIBLE
        anim?.cancel()
        anim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = if (success) 1100L else 700L
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { phase = it.animatedValue as Float; invalidate() }
            start()
        }
        postDelayed(hideRunnable, durationMs)
    }

    private fun fadeOut() {
        animate().alpha(0f).setDuration(350).withEndAction { hideNow() }.start()
    }

    fun hideNow() {
        removeCallbacks(hideRunnable)
        animate().cancel()
        anim?.cancel(); anim = null
        visibility = GONE
        alpha = 1f
    }

    override fun onDetachedFromWindow() {
        removeCallbacks(hideRunnable)
        anim?.cancel(); anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(c: Canvas) {
        val w = width.toFloat(); val h = height.toFloat()
        val s = minOf(w, h) / 24f
        val wave = sin(phase * 2 * PI).toFloat()
        c.save()
        c.translate((w - 24f * s) / 2f, (h - 24f * s) / 2f)
        c.scale(s, s)
        c.translate(0f, -0.7f * wave)                       // hafif zıplama
        val pulse = 1f + 0.06f * wave
        c.scale(pulse, pulse, 12f, 12f)                     // nabız
        if (!ok) c.rotate(5f * sin(phase * 4 * PI).toFloat(), 12f, 12f)
        cloudPaint.color = if (ok) 0xFF4285F4.toInt() else 0xFFE53935.toInt()
        c.drawPath(cloud, cloudPaint)
        if (ok) {
            // Ok bulutun içinde alttan yukarı süzülür
            val dy = 3.2f - 6.4f * phase
            glyph.alpha = (90 + 165 * sin(PI * phase)).toInt().coerceIn(0, 255)
            c.save(); c.translate(0f, dy)
            c.drawLine(12f, 16.4f, 12f, 9.3f, glyph)
            c.drawLine(8.8f, 12.4f, 12f, 9.2f, glyph)
            c.drawLine(15.2f, 12.4f, 12f, 9.2f, glyph)
            c.restore()
        } else {
            glyph.alpha = 255
            c.drawLine(12f, 8.6f, 12f, 13.6f, glyph)
            c.drawCircle(12f, 16.4f, 1.25f, dot)
        }
        c.restore()
    }
}
