# MyKeyboard
- Üst sol yuvarlak buton: Google Çeviri (alandaki yazıyı çeviriye gönderir)
- Üstte: en başta SON KOPYALANAN METNİN önizlemesi (dokununca yapıştırır) + son 3 ekran görüntüsü
- Sağ üst pano: ☆ ile sabitle, "Sabitler" sekmesi, basılı tutup sürükleyerek sırala
- ?123 -> semboller, =\< -> 2. sembol sayfası, 1234 -> sayı tuşları

## APK nasıl alınır
A) Android Studio: klasörü aç -> Build > Build APK.
B) Sadece telefonla: GitHub'a yeni repo aç, dosyaları yükle -> Actions > "Build APK" -> Artifacts'tan APK indir.
Kurduktan sonra uygulamayı aç: 1) etkinleştir 2) seç 3) ekran görüntüsü izni.

## v1.5
- Sol üst: ▦ = Google Çeviri (Türkçe⇄İngilizce), yanında pano
- Sağ üst: boyut (yükseklik, genişlik %60-100, sol/orta/sağ hizalama, titreşim)
- Pano: öğeye basılı tut = sabitle/çöz, ≡ tutamacıyla sürükle = sırala
- Çift dokunuş ⇧ = Caps Lock, silme tuşu hızlanarak tekrar eder

## v3.0 (v61)
- Üst şerit: son kopyalanan metin önizlemesi + son 3 ekran görüntüsü (eskiden 5)
- Yandaki tuşa sıçrama koruması: aynı parmağın taşan "hayalet" dokunuşu yok sayılır
- Silme tuşu: sabit ritimli tekrar (bazı uygulamalarda ani hızlanma düzeltildi)
- Yazım denetimi: yanlış/Türkçeye uymayan kelime kırmızı altı çizili; kelimeye dokununca ya da basılı tutup seçince
  klavyenin üst şeridinde doğru yazılış önerileri çıkar (✓ Doğru = bir daha işaretleme)
  Tam sözlük için telefonun yazım denetimi açık + Türkçe olmalı; yerleşik kurallar (…br, q/w/x, ünlüsüz) her zaman çalışır

## v3.1
- Yanlış kelime artık kırmızı DÜZ çizgiyle (kırmızı alt çizgi) işaretlenir
- Doğru yazılış önerileri kelime bitince (boşluğa basınca) hemen üst şeritte çıkar; dokununca kelimeyi düzeltir, boşluk korunur

## v3.2
- Yanlış kelimeye basılı tutup seçince doğru yazılış önerileri üst şeritte çıkar (kelime önceden işaretlenmemiş olsa bile anında denetlenir)
- Tuş hedefleme: parmağın temas yaması hangi harfe daha çok basıyorsa o harf seçilir; komşu harfler yok sayılır
- Hayalet dokunuş koruması sıkılaştırıldı (yan tuşa taşan ikinci dokunuş daha geniş alanda ve daha uzun süre yok sayılır)

## v3.3
- Chrome/Brave gibi tarayıcı alanlarında yazım denetimi artık çalışır (eskiden bu alanlar yanlışlıkla dışlanıyordu)
- 4+ ünsüz arka arkaya gelen kelimeler (gecyrsn, beklyrm…) yanlış sayılır; öneri için telefonun yazım denetleyicisine de sorulur
- Üst şeritte yanlış kelime kırmızı altı çizili gösterilir (uygulama çizgiyi çizmese de görünür); metinde de hafif kırmızı zemin
