# MyKeyboard
- Üst sol yuvarlak buton: Google Çeviri (alandaki yazıyı çeviriye gönderir)
- Üstte: en başta SON KOPYALANAN METNİN önizlemesi (dokununca yapıştırır) + son 3 ekran görüntüsü
- Sağ üst pano: ☆ ile sabitle, "Sabitler" sekmesi, basılı tutup sürükleyerek sırala
- ?123 -> semboller, =\< -> 2. sembol sayfası, 1234 -> sayı tuşları

## APK nasıl alınır
A) Android Studio: klasörü aç -> Build > Build APK.
B) Sadece telefonla: GitHub'a yeni repo aç, dosyaları yükle -> Actions > "Build APK" -> Artifacts'tan APK indir.
Kurduktan sonra uygulamayı aç: 1) etkinleştir 2) seç 3) ekran görüntüsü izni.

## v1.5
- Sol üst: ▦ = Google Çeviri (Türkçe⇄İngilizce), yanında pano
- Sağ üst: boyut (yükseklik, genişlik %60-100, sol/orta/sağ hizalama, titreşim)
- Pano: öğeye basılı tut = sabitle/çöz, ≡ tutamacıyla sürükle = sırala
- Çift dokunuş ⇧ = Caps Lock, silme tuşu hızlanarak tekrar eder

## v3.0 (v61)
- Üst şerit: son kopyalanan metin önizlemesi + son 3 ekran görüntüsü (eskiden 5)
- Yandaki tuşa sıçrama koruması: aynı parmağın taşan "hayalet" dokunuşu yok sayılır
- Silme tuşu: sabit ritimli tekrar (bazı uygulamalarda ani hızlanma düzeltildi)
- Yazım denetimi: yanlış Türkçe kelime kırmızı altı çizili; kelimeye dokununca öneri listesi çıkar
  (Android'in yazım denetimi gerekir: Ayarlar > Dil > Yazım denetimi açık + Türkçe)
